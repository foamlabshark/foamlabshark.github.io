#pragma OPENCL EXTENSION cl_khr_fp64 : enable

__kernel void triad(uint n, double scalar, __global const double *a,
                    __global const double *b, __global double *out) {
    size_t i = get_global_id(0);
    if (i < n) out[i] = a[i] + scalar * b[i];
}

__kernel void sum_stage(uint n, __global const double *input,
                        __global double *partial, __local double *tile) {
    size_t i = get_global_id(0);
    size_t lane = get_local_id(0);
    tile[lane] = i < n ? input[i] : 0.0;
    barrier(CLK_LOCAL_MEM_FENCE);
    for (size_t stride = get_local_size(0) / 2; stride > 0; stride /= 2) {
        if (lane < stride) tile[lane] += tile[lane + stride];
        barrier(CLK_LOCAL_MEM_FENCE);
    }
    if (lane == 0) partial[get_group_id(0)] = tile[0];
}
