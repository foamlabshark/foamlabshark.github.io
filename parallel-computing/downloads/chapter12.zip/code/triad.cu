#include <cuda_runtime.h>
#include <stddef.h>
__global__ void triad(unsigned n, double scalar, const double *a,
                      const double *b, double *out) {
    size_t i = (size_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) out[i] = a[i] + scalar * b[i];
}
