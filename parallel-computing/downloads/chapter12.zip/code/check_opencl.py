"""Run the reader's FP64 examples on Windows OpenCL GPUs, using only ctypes."""
import ctypes as c
import json
from pathlib import Path

cl = c.WinDLL("OpenCL.dll")
ptr, uint, size, integer = c.c_void_p, c.c_uint, c.c_size_t, c.c_int
bits = c.c_ulonglong
ref = c.byref
def bind(name, result, *args):
    fn = getattr(cl, name)
    fn.restype = result
    fn.argtypes = args
    return fn
def ok(status):
    if status != 0: raise RuntimeError(f"OpenCL status {status}")
platform_ids = bind("clGetPlatformIDs", integer, uint, ptr, ptr)
device_ids = bind("clGetDeviceIDs", integer, ptr, bits, uint, ptr, ptr)
info = bind("clGetDeviceInfo", integer, ptr, uint, size, ptr, ptr)
context = bind("clCreateContext", ptr, ptr, uint, ptr, ptr, ptr, ptr)
queue = bind("clCreateCommandQueue", ptr, ptr, ptr, bits, ptr)
program = bind("clCreateProgramWithSource", ptr, ptr, uint, ptr, ptr, ptr)
build = bind("clBuildProgram", integer, ptr, uint, ptr, c.c_char_p, ptr, ptr)
kernel = bind("clCreateKernel", ptr, ptr, c.c_char_p, ptr)
buffer = bind("clCreateBuffer", ptr, ptr, bits, size, ptr, ptr)
set_arg = bind("clSetKernelArg", integer, ptr, uint, size, ptr)
launch = bind("clEnqueueNDRangeKernel", integer, ptr, ptr, uint, ptr, ptr, ptr, uint, ptr, ptr)
read = bind("clEnqueueReadBuffer", integer, ptr, ptr, uint, size, size, ptr, uint, ptr, ptr)
def devices():
    n = uint()
    ok(platform_ids(0, None, ref(n)))
    platforms = (ptr*n.value)()
    ok(platform_ids(n, platforms, None))
    for plat in platforms:
        m = uint()
        status = device_ids(plat,4,0,None,ref(m))
        if status == -1: continue
        ok(status)
        devs = (ptr*m.value)()
        ok(device_ids(plat,4,m,devs,None))
        yield from devs
def run(dev):
    name=c.create_string_buffer(256)
    ok(info(dev,0x102B,len(name),name,None))
    devptr=ptr(dev)
    err=integer()
    owned=[]
    def keep(handle,kind):
        ok(err.value)
        owned.append((handle,bind("clRelease"+kind,integer,ptr)))
        return handle
    try:
        ctx=keep(context(None,1,ref(devptr),None,None,ref(err)),"Context")
        q=keep(queue(ctx,dev,0,ref(err)),"CommandQueue")
        source=c.c_char_p(Path(__file__).with_name("kernels.cl").read_bytes())
        prog=keep(program(ctx,1,ref(source),None,ref(err)),"Program")
        ok(build(prog,1,ref(devptr),None,None,None))
        tri=keep(kernel(prog,b"triad",ref(err)),"Kernel")
        red=keep(kernel(prog,b"sum_stage",ref(err)),"Kernel")
        def buf(n,data=None):
            return ptr(keep(buffer(ctx,33 if data is not None else 1,n*8,data,ref(err)),"MemObject"))
        def enqueue(k,n,args,local_bytes=0):
            for idx,arg in enumerate(args):ok(set_arg(k,idx,c.sizeof(arg),ref(arg)))
            if local_bytes:ok(set_arg(k,len(args),local_bytes,None))
            work=size((n+127)//128*128)
            ok(launch(q,k,1,None,ref(work),ref(size(128)),0,None,None))
        for n in (1,127,128,129,1000,18000):
            values=(c.c_double*n)(*range(n))
            ones=(c.c_double*n)(*[1]*n)
            a,b,out=buf(n,values),buf(n,ones),buf(n)
            enqueue(tri,n,[uint(n),c.c_double(2),a,b,out])
            got=(c.c_double*n)()
            ok(read(q,out,1,0,n*8,got,0,None,None))
            if list(got)!=[i+2 for i in range(n)]: raise ValueError("Triad mismatch")
            length=n
            while True:
                blocks=(length+127)//128
                sums=buf(blocks)
                enqueue(red,length,[uint(length),a,sums],128*8)
                if blocks==1:break
                length,a=blocks,sums
            total=c.c_double()
            ok(read(q,sums,1,0,8,ref(total),0,None,None))
            if total.value!=n*(n-1)//2:raise ValueError("sum mismatch")
        return {"device":name.value.decode(),"lengths":[1,127,128,129,1000,18000],"triad":"pass","reduction":"pass","sum_18000":total.value}
    finally:
        for handle,release in reversed(owned):release(handle)
if __name__=="__main__":
    print(json.dumps([run(dev) for dev in devices()],indent=2))
