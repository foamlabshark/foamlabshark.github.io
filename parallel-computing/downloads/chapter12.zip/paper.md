# 第 12 章｜GPU 编程语言基础

原著：Robert Robey、Yuliana Zamora，Manning，2021。原书 p.417–459 / PDF p.453–495。

按原书小节阅读核心段落译文、图 12.1–12.5 和代码讲解。

## 小节索引

- [第 12 章导读｜GPU 编程语言基础](#12-intro)
- [12.1 原生 GPU 接口要解决哪些问题](#12.1)
- [12.2 CUDA 与 HIP 的执行模型](#12.2)
- [12.2.1 构建第一个 CUDA 程序](#12.2.1)
- [12.2.1（续）从循环到线程索引](#12.2.1-kernel)
- [12.2.1（续）启动、复制与计时](#12.2.1-host)
- [12.2.2 CUDA 归约的第一遍](#12.2.2)
- [12.2.2（续）第二遍应该读取多少项](#12.2.2-pass2)
- [12.2.3 把 CUDA 示例迁移到 HIP](#12.2.3)
- [12.3 OpenCL 的平台、设备与上下文](#12.3)
- [12.3.1 构建 OpenCL 内核并绑定实参](#12.3.1)
- [12.3.1（续）设备程序为何需要构建日志](#12.3.1-build)
- [12.3.2 OpenCL 的分组归约](#12.3.2)
- [12.3.2（续）局部内存与第二遍](#12.3.2-pass2)
- [12.4 SYCL：用 C++ 表达设备工作](#12.4)
- [12.4（续）两层 lambda 分别在哪里执行](#12.4-accessors)
- [12.5 高层性能可移植框架](#12.5)
- [12.5.1 Kokkos：View、执行空间与并行模式](#12.5.1)
- [12.5.2 RAJA：让循环服从执行策略](#12.5.2)
- [12.6 进一步探索与本章小结](#12.6)
- [12.6.1 延伸阅读](#12.6.1)
- [12.6.2 练习与参考结果](#12.6.2)

## 术语约定

|原文|译法|说明|
|---|---|---|
|kernel launch|内核启动|配置工作范围并提交计算|
|scratchpad|组内暂存|线程组协作使用的存储|
|accessor|访问器|声明缓冲区的访问需求|
|execution policy|执行策略|选择并行循环的执行方式|
|view|视图|带类型、维度与布局的数组访问对象|

<a id="12-intro"></a>
## 第 12 章导读｜GPU 编程语言基础
原书 p.417–419。

<a id="S001"></a>
**Source:** 原书 p.417 / PDF p.453 · S001

**Original:** This chapter covers lower-level languages for GPUs. We call these native languages because they directly reflect features of the target GPU hardware.

**中文:** 本章探讨面向 GPU 的低层语言。作者称它们为原生语言，因为这些语言直接反映了目标 GPU 的硬件特性。

<a id="N001"></a>
### 带着同一条算式阅读

**讲解：** 设 a[i]=i、b[i]=1、scalar=2。每个工作项负责一个 i，写出 c[i]=i+2。本章把这条算式放进六种编程接口，逐一追踪索引从哪里来、数组放在哪里、主机何时能读取 c。第二个例子是数组求和，此时工作项之间还要交换部分和。

<a id="F001"></a>
### 图 12.1
**Source:** 原书 p.418 / PDF p.454 · C001
**Placed near:** 第 12 章导读｜GPU 编程语言基础

![图 12.1](assets/fig12_1.png)

**Original caption:** The interoperability map for the GPU languages shows an increasingly complex situation. Four GPU languages are shown at the top with the various hardware devices at the bottom. The arrows show the code generation pathways from the languages to the hardware. The dashed lines are for hardware that is still in development.

**中文图注:** 上排是语言，下排是硬件，箭头表示作者写作时的代码生成路径，虚线代表当时仍在开发的路径。

**Reading note:** 把箭头理解成一条需要编译器、运行时和驱动共同支持的路径。图中 SYCL、HIP 等实现和设备的状态反映出版时期。


<a id="12.1"></a>
## 12.1 原生 GPU 接口要解决哪些问题
原书 p.419–420。

<a id="S002"></a>
**Source:** 原书 p.419 / PDF p.455 · S002

**Original:** A GPU programming language must have several basic features. It is helpful to understand what these features are so that you can recognize these in each GPU language.

**中文:** GPU 编程语言需要具备若干基本功能。了解这些功能，就能在学习另一种 GPU 语言时辨认出对应的部分。

<a id="N002"></a>
### 沿一次计算追踪对象

**讲解：** 主机选择设备并取得执行上下文，准备设备程序和缓冲区，提交带索引范围的 kernel，最后依据完成事件来取回结果。每一步都可以问一个具体问题，例如“这次提交使用的 c 与我准备读取的 c 是否对应同一份数据？”

<a id="N003"></a>
### 源码组织与编译时间

**讲解：** CUDA 可以在一个 .cu 文件里放主机代码和设备代码，编译器分别生成对应指令。原书 OpenCL 示例把设备源作为字符串交给驱动构建。单源 C++ 框架把并行循环体写成 lambda，由执行策略决定生成哪种目标代码。


<a id="12.2"></a>
## 12.2 CUDA 与 HIP 的执行模型
原书 p.420–421。

<a id="N004"></a>
### 对应章节 10 的索引模型

**讲解：** 一次启动建立网格，网格由线程块组成。一个块负责一段连续元素，块内线程号表示这段里的偏移。CUDA 和 HIP 都能用 blockIdx、blockDim、threadIdx 写出这个映射。主机代码负责给足线程，并为尾块留下边界检查。


<a id="12.2.1"></a>
## 12.2.1 构建第一个 CUDA 程序
原书 p.421–424。

<a id="S003"></a>
**Source:** 原书 p.422 / PDF p.458 · S003

**Original:** The key addition is a pattern rule on lines 9–10, which converts a file with a .cu suffix into an object file.

**中文:** 构建文件中关键的新增部分在第 9–10 行。这条模式规则把后缀为 .cu 的源文件编译为目标文件。

<a id="K001"></a>
**代码出处：** Shell · 对应清单 12.1 的单文件编译步骤，资料包提供 triad.cu

```text
nvcc -O2 -c triad.cu -o triad.o
```

<a id="N005"></a>
### 命令语法

**讲解：** nvcc 驱动设备编译与主机 C++ 编译。-c 到生成目标文件为止，-o 指定文件名。把目标文件链接成可执行程序还需要包含 main 的主机驱动和对应运行库。

<a id="K002"></a>
**代码出处：** CMake · 清单 12.2–12.3 的教学写法，创建可编译的 kernel 目标

```text
cmake_minimum_required(VERSION 3.18)
project(triad LANGUAGES CXX CUDA)
add_library(triad_kernel OBJECT triad.cu)
```

<a id="N006"></a>
### 构建目标与架构

**讲解：** LANGUAGES CUDA 启用 CUDA 编译规则。书中既展示旧 FindCUDA，又介绍一等语言支持。指定架构时依据部署设备和工具链支持选择，书中 sm_30 等历史默认值不能直接用于推断今天的构建行为。


<a id="12.2.1-kernel"></a>
## 12.2.1（续）从循环到线程索引
原书 p.424–427。

<a id="S004"></a>
**Source:** 原书 p.425 / PDF p.461 · S004

**Original:** As is typical with GPU kernels, we strip the for loop from the computational block. This leaves the loop body on line 14.

**中文:** 像处理典型 GPU kernel 那样，我们从计算代码块中取出 for 循环的外壳，留下第 14 行的循环体。

<a id="K003"></a>
**代码出处：** CUDA C++ · 清单 12.4 教学展开，文件 triad.cu

```text
#include <cuda_runtime.h>
#include <stddef.h>
__global__ void triad(unsigned n, double scalar, const double *a,
                      const double *b, double *out) {
    size_t i = (size_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) out[i] = a[i] + scalar * b[i];
}
```

<a id="N007"></a>
### 把一行代码读成一句话

**讲解：** __global__ 声明供主机启动的设备入口。若当前线程在第 1 块、块宽 512、块内编号 12，它负责 i=524。const double * 表示通过这个指针读取元素，double *out 提供写入位置。示例假设输出与输入没有会引起跨线程冲突的重叠。

<a id="E001"></a>
**Source:** 原书 p.426 / PDF p.462 · E001

$$
G=\lfloor N/B\rfloor+[N\bmod B\ne0]
$$

N=1000、B=512 时启动 2 块，最后一块有 488 个有效元素。N=0 时主机可以直接返回。用商和余数也避免了 N+B−1 这一步的整数加法溢出。


<a id="12.2.1-host"></a>
## 12.2.1（续）启动、复制与计时
原书 p.425–429。

<a id="K004"></a>
**代码出处：** CUDA 主机端 · 清单 12.5–12.6 的顺序节选，调用方须检查每次 API 返回值

```text
// a_d、b_d、c_d 已在当前设备分配，主机数组已初始化
cudaMemcpy(a_d, a, bytes, cudaMemcpyHostToDevice);
cudaMemcpy(b_d, b, bytes, cudaMemcpyHostToDevice);
triad<<<blocks, threads>>>(n, scalar, a_d, b_d, c_d);
cudaError_t launch_status = cudaGetLastError();
cudaError_t finish_status = cudaDeviceSynchronize();
// 两次状态检查成功后读取结果
cudaMemcpy(c, c_d, bytes, cudaMemcpyDeviceToHost);
```

<a id="N008"></a>
### 尖括号与圆括号

**讲解：** <<<blocks, threads>>> 配置启动规模。圆括号内的参数按 kernel 声明顺序传入。cudaMemcpy 第三个参数按字节计数，double 数组需要 n*sizeof(double)。若只计量 kernel，应区分提交时刻和设备完成时刻。若目的是比较整项任务，则应计入必要的传入和传回。

<a id="S005"></a>
**Source:** 原书 p.427 / PDF p.463 · S005

**Original:** Sometimes the first call to a GPU will be slower due to initialization costs.

**中文:** 第一次调用 GPU 有时较慢，因为这次调用还承担初始化开销。

<a id="N009"></a>
### 页锁定与托管内存

**讲解：** 清单先用普通主机数组，练习再改成 cudaMallocHost，并与 cudaFreeHost 配对。比较时保持相同的数据量、方向、预热和重复次数。托管内存可以由运行时迁移页面，读取设备刚写入的结果仍需满足完成与可见性要求。


<a id="12.2.2"></a>
## 12.2.2 CUDA 归约的第一遍
原书 p.429–431。

<a id="S006"></a>
**Source:** 原书 p.430 / PDF p.466 · S006

**Original:** Because the reduction sum within the block is going to be used in both reduction passes, we put the code in a device subroutine and call it on line 42.

**中文:** 两遍归约都要在块内求和，因此作者把这段代码放进设备子程序，在第 42 行调用。

<a id="F002"></a>
### 图 12.2
**Source:** 原书 p.431 / PDF p.467 · C002
**Placed near:** 12.2.2 CUDA 归约的第一遍

![图 12.2](assets/fig12_2.png)

**Original caption:** Pair-wise reduction tree for a warp that sums up values in log n steps.

**中文图注:** 两两相加，逐层缩小待合并的值，最后得到一个和。

**Reading note:** 图中的 log n 指依赖链的层数。对 n 个输入，总加法次数仍为 n−1。把执行深度与总工作量分开，才能解释并行归约的收益。

<a id="K005"></a>
**代码出处：** CUDA C++ · 清单 12.7–12.8 教学修正版，使用一维、大小为 2 的幂的线程块

```text
__global__ void sum_stage(unsigned n, const double *input, double *partial) {
    extern __shared__ double tile[];
    unsigned lane = threadIdx.x;
    size_t i = (size_t)blockIdx.x * blockDim.x + lane;
    tile[lane] = i < n ? input[i] : 0.0;
    __syncthreads();
    for (unsigned step = blockDim.x / 2; step > 0; step /= 2) {
        if (lane < step) tile[lane] += tile[lane + step];
        __syncthreads();
    }
    if (lane == 0) partial[blockIdx.x] = tile[0];
}
```

<a id="N010"></a>
### 为什么无效线程也写入零

**讲解：** 末块缺少的元素用加法单位元补齐。所有线程先填自己的槽，再到达同一道块级屏障。每层只有低半区线程相加，但屏障放在 if 外，整个块可以一起进入下一层。启动时第三个尖括号参数应提供 B*sizeof(double) 字节的动态共享存储。

<a id="N011"></a>
### 逐行校核原书

**讲解：** 清单 12.8 第 17 行把 __syncthreads() 放进 tiX 小于 warp 宽度的条件块；一个块有多个 warp 时，参与线程不一致。清单 12.7 第 47 行还让各块的 0 号线程写同一 blocksum 地址。教学代码让每块只写 partial[blockIdx.x]，再合并这些独立结果。


<a id="12.2.2-pass2"></a>
## 12.2.2（续）第二遍应该读取多少项
原书 p.432–435。

<a id="S007"></a>
**Source:** 原书 p.432 / PDF p.468 · S007

**Original:** To avoid more than two kernels for larger arrays, we use one thread block and loop on lines 67–69 to read and sum any additional data into the shared scratchpad.

**中文:** 对于较大的数组，作者仍然只启用一个线程块，通过第 67–69 行的循环分批读取额外的数据，把和累加到共享暂存区。这样两遍 kernel 就能完成归约。

<a id="K006"></a>
**代码出处：** CUDA 主机端 · 多遍教学方案，B≥2，首遍 src 指原输入、dst 指 tmp_a，同一有序 stream

```text
// 约定 n > 0，B 是合法的 2 的幂，两个临时数组容量充足
unsigned length = n;
do {
    unsigned groups = length / B + (length % B != 0);
    sum_stage<<<groups, B, B*sizeof(double)>>>(length, src, dst);
    length = groups;
    // 下一遍读取刚写好的结果，并写入另一块存储
    src = dst;
    dst = (dst == tmp_a) ? tmp_b : tmp_a;
} while (length > 1);
```

<a id="N012"></a>
### 先数临时数组

**讲解：** 原书第二遍用一个块，各线程以块宽为步长遍历局部和。无论采用单块步进还是上面的多遍树，输入长度都应等于上一遍的块数。清单 12.10 第 115 行印成 nsize，会按原数组长度读取较短的 redscratch，产生越界。

<a id="N013"></a>
### 用书后练习做检查

**讲解：** 18,000 个元素按 128 线程分块，第一遍得到 141 个局部和。重复分块时长度依次变为 141、2、1。输入取 0 到 17,999，整数精确和为 161,991,000。此范围内 double 可精确表示这些整数，适合检查遗漏和重复。


<a id="12.2.3"></a>
## 12.2.3 把 CUDA 示例迁移到 HIP
原书 p.435–438。

<a id="S008"></a>
**Source:** 原书 p.437 / PDF p.473 · S008

**Original:** Now let’s turn our attention to the HIP source in listing 12.12.

**中文:** 现在来看清单 12.12 中的 HIP 源代码。

<a id="K007"></a>
**代码出处：** HIP C++ · 对应清单 12.12，最后两行展示调用参数的位置

```text
#include <hip/hip_runtime.h>
__global__ void triad_hip(unsigned n, double scalar, const double *a,
                          const double *b, double *out) {
    size_t i = (size_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) out[i] = a[i] + scalar*b[i];
}
// 主机侧，在有效 stream 上启动
// hipLaunchKernelGGL(triad_hip, dim3(blocks), dim3(threads), 0, stream,
//                    n, scalar, a_d, b_d, c_d);
```

<a id="N014"></a>
### 迁移时按角色配对

**讲解：** cudaMalloc 对应 hipMalloc，cudaMemcpy 对应 hipMemcpy，cudaFree 对应 hipFree。hipLaunchKernelGGL 的前五个位置依次给 kernel、网格、块、动态共享内存字节数、stream，之后才是 kernel 的数据参数。Triad 循环体可以直接沿用。

<a id="N015"></a>
### 归约还要迁移同步假设

**讲解：** HIPIFY 可以协助改写大量 API，仍需核对第三方库、编译目标、子组宽度、屏障和边缘块。书中的旧 HCC、HIP_ADD_EXECUTABLE 和安装路径属于该版示例环境。先用不依赖固定 warp 宽度的教学版树，再在目标平台验证。


<a id="12.3"></a>
## 12.3 OpenCL 的平台、设备与上下文
原书 p.438–439。

<a id="N016"></a>
### 主机端比 CUDA 多做哪些事

**讲解：** 从平台枚举设备，选定设备后创建 context，在 context 中建立命令队列、程序及缓冲区。机器上的 ICD 加载器可以发现多个厂商平台。找到一个 GPU 后，还要检查内核所需的精度、组大小和局部存储等能力。

<a id="N017"></a>
### 实机对应

**讲解：** 本章提供 Windows 检查脚本 check_opencl.py。它枚举 GPU，为每个设备分别创建上下文，从随包的 kernels.cl 构建设备程序，提交同样的工作并读回结果。这样可以分辨程序究竟在哪个设备上运行。


<a id="12.3.1"></a>
## 12.3.1 构建 OpenCL 内核并绑定实参
原书 p.439–445。

<a id="S009"></a>
**Source:** 原书 p.444 / PDF p.480 · S009

**Original:** OpenCL requires a separate call for every kernel argument.

**中文:** OpenCL 需要分别为每个 kernel 参数进行一次设置调用。

<a id="K008"></a>
**代码出处：** OpenCL C · 对应清单 12.15，随包 kernels.cl 中实际运行的 Triad

```text
#pragma OPENCL EXTENSION cl_khr_fp64 : enable

__kernel void triad(uint n, double scalar, __global const double *a,
                    __global const double *b, __global double *out) {
    size_t i = get_global_id(0);
    if (i < n) out[i] = a[i] + scalar * b[i];
}
```

<a id="N018"></a>
### 两个 global 的语法区别

**讲解：** CUDA 的 __global__ 修饰可启动的函数，OpenCL C 用 __kernel 修饰入口。OpenCL 的 __global 在这里修饰指针所指对象的地址空间。get_global_id(0) 取得第 0 维全局索引。此例使用 FP64，需要设备支持 double。

<a id="K009"></a>
**代码出处：** OpenCL 主机端 C · 对应上方教学内核签名，实际程序逐次检查返回码

```text
clSetKernelArg(kernel, 0, sizeof(cl_uint),   &n);
clSetKernelArg(kernel, 1, sizeof(cl_double), &scalar);
clSetKernelArg(kernel, 2, sizeof(cl_mem),    &a_buf);
clSetKernelArg(kernel, 3, sizeof(cl_mem),    &b_buf);
clSetKernelArg(kernel, 4, sizeof(cl_mem),    &out_buf);
clEnqueueNDRangeKernel(q, kernel, 1, NULL, &global_size, &local_size,
                       0, NULL, NULL);
```

<a id="N019"></a>
### 读取这组六行

**讲解：** 参数编号从 0 开始。标量传值的地址和对应字节数，缓冲区传 cl_mem 句柄的地址及句柄大小。最后一次调用中，1 表示一维，global_size 表示总工作项数，local_size 表示每组工作项数。队列里的命令执行完毕后，主机才能安全消费返回结果。


<a id="12.3.1-build"></a>
## 12.3.1（续）设备程序为何需要构建日志
原书 p.439–445。

<a id="S010"></a>
**Source:** 原书 p.440 / PDF p.476 · S010

**Original:** The common way for OpenCL code to function is to have a separate source file that must be located at run time, which is then compiled once the device is known.

**中文:** 一种常见的 OpenCL 程序组织方式是单独提供设备源文件。程序运行时需要找到该文件，选定设备后再编译。

<a id="N020"></a>
### 书中的两个辅助函数

**讲解：** EZCL_Lite 封装了设备探测与程序构建；embed_source.pl 将 .cl 源码嵌入主机程序，解决分发后找不到文件或文件版本不一致的问题。内核仍需要在对应设备上构建。本章资料则把 .cl 与检查脚本放在同一目录，便于修改后重跑。

<a id="K010"></a>
**代码出处：** OpenCL C 主机接口 · 清单 12.18 的诊断流程节选

```text
cl_int status = clBuildProgram(program, 1, &device, NULL, NULL, NULL);
if (status != CL_SUCCESS) {
    size_t bytes = 0;
    clGetProgramBuildInfo(program, device, CL_PROGRAM_BUILD_LOG,
                          0, NULL, &bytes);
    /* 分配 bytes 字节，再以相同参数读取日志内容 */
}
```

<a id="N021"></a>
### 释放顺序

**讲解：** 命令队列执行与主机提交是分开的。先确认依赖此缓冲区的结果已完成，再结束对象生命周期。原书的简版有意缩短错误检查，排查实际问题时应保留失败 API、状态码和构建日志。


<a id="12.3.2"></a>
## 12.3.2 OpenCL 的分组归约
原书 p.445–449。

<a id="S011"></a>
**Source:** 原书 p.445 / PDF p.481 · S011

**Original:** The sum reduction in OpenCL is similar to that in CUDA.

**中文:** OpenCL 的求和归约与 CUDA 的做法相似。

<a id="F003"></a>
### 图 12.3
**Source:** 原书 p.445 / PDF p.481 · C003
**Placed near:** 12.3.2 OpenCL 的分组归约

![图 12.3](assets/fig12_3.png)

**Original caption:** Comparison of OpenCL and CUDA reduction kernels: sum_within_block

**中文图注:** 左右两列对照块内求和子程序的地址空间、线程编号和同步调用。

**Reading note:** 读图时从共享数组的声明开始，再看每次屏障是否由整组共同执行。原书对照图保留了旧例子的 warp 宽度假设。

<a id="F004"></a>
### 图 12.4
**Source:** 原书 p.446 / PDF p.482 · C004
**Placed near:** 12.3.2 OpenCL 的分组归约

![图 12.4](assets/fig12_4.png)

**Original caption:** Comparison for the first of two kernel passes for the OpenCL and CUDA reduction kernels

**中文图注:** 第一遍把各组的和写入较小的临时数组。

**Reading note:** OpenCL 通过 __local 参数取得局部暂存，CUDA 使用动态共享内存。两种方式都需要主机按每组工作项数提供足够字节。

<a id="K011"></a>
**代码出处：** OpenCL C · 组内求和教学修正版，随包内核使用 128 个工作项

```text
__kernel void sum_stage(uint n, __global const double *input,
                        __global double *partial, __local double *tile) {
    size_t i = get_global_id(0);
    size_t lane = get_local_id(0);
    tile[lane] = i < n ? input[i] : 0.0;
    barrier(CLK_LOCAL_MEM_FENCE);
    for (size_t stride = get_local_size(0) / 2; stride > 0; stride /= 2) {
        if (lane < stride) tile[lane] += tile[lane + stride];
        barrier(CLK_LOCAL_MEM_FENCE);
    }
    if (lane == 0) partial[get_group_id(0)] = tile[0];
}
```


<a id="12.3.2-pass2"></a>
## 12.3.2（续）局部内存与第二遍
原书 p.446–449。

<a id="F005"></a>
### 图 12.5
**Source:** 原书 p.447 / PDF p.483 · C005
**Placed near:** 12.3.2（续）局部内存与第二遍

![图 12.5](assets/fig12_5.png)

**Original caption:** Comparison of the second pass for the reduction sum

**中文图注:** 第二遍读取第一遍生成的局部和，再合成最终结果。

**Reading note:** 单组方案可用步长循环读取超过一组大小的临时数组。本章可运行示例反复提交同一个 sum_stage，每次传入上一遍实际输出的长度。

<a id="K012"></a>
**代码出处：** OpenCL 主机端 C · 给教学内核第 4 个参数预留每组独享的局部内存

```text
clSetKernelArg(reduce, 3, local_size * sizeof(cl_double), NULL);
```

<a id="N022"></a>
### 这里为何传 NULL

**讲解：** 第 4 个参数类型为 __local double *。绑定它时只指定字节数，运行时为每个组分配暂存。barrier(CLK_LOCAL_MEM_FENCE) 使本组工作项在该阶段汇合，并对 local 存储访问排序。组间的阶段顺序由有序队列或显式事件依赖保证。

<a id="N023"></a>
### 本机核对结果

**讲解：** 两块 GPU 均完成长度 1、127、128、129、1000、18000 的 FP64 Triad 和分层归约。128 的两侧检查尾块，在 18000 时三遍归约返回 161991000。每个 Triad 输出元素也与主机参考值逐项一致。


<a id="12.4"></a>
## 12.4 SYCL：用 C++ 表达设备工作
原书 p.449–452。

<a id="N024"></a>
### 队列与设备选择

**讲解：** 原书用 DPC++ 工具链演示 SYCL。queue 连接到某个设备与上下文，主机向队列提交命令组。default selector 的选择与实现和可用设备有关。要确认一次运行的位置，可以读取所选设备名称。

<a id="K013"></a>
**代码出处：** SYCL 2020 C++ · 使用 <sycl/sycl.hpp> 的教学写法，选择失败时处理异常

```text
sycl::queue q{sycl::gpu_selector_v};
auto name = q.get_device().get_info<sycl::info::device::name>();
```

<a id="N025"></a>
### 原书标题里的 experimental

**讲解：** 标题描述当时的发展阶段。本页以 SYCL 2020 的命名空间和选择器重述代码。一个 SYCL 实现可提供不同后端，部署时需核对设备与实现支持。


<a id="12.4-accessors"></a>
## 12.4（续）两层 lambda 分别在哪里执行
原书 p.450–452。

<a id="S012"></a>
**Source:** 原书 p.451 / PDF p.487 · S012

**Original:** The lambda capture clause, [&], specifies capturing outside variables used in the routine by reference.

**中文:** lambda 的捕获列表 [&] 指定按引用捕获函数体用到的外部变量。

<a id="K014"></a>
**代码出处：** SYCL 2020 · 清单 12.21 的 buffer/accessor 教学展开

```text
// a、b、out 是主机 vector<double>，长度 n 相同且非零
{
    sycl::buffer<double,1> A(a.data(), sycl::range<1>(n));
    sycl::buffer<double,1> B(b.data(), sycl::range<1>(n));
    sycl::buffer<double,1> C(out.data(), sycl::range<1>(n));
    q.submit([&](sycl::handler& h) {
        auto x = A.get_access<sycl::access::mode::read>(h);
        auto y = B.get_access<sycl::access::mode::read>(h);
        auto z = C.get_access<sycl::access::mode::write>(h);
        h.parallel_for(sycl::range<1>(n), [=](sycl::id<1> i) {
            z[i] = x[i] + scalar*y[i];
        });
    });
    q.wait_and_throw();
}
// 关联可写主机存储的输出 buffer 已结束生命周期，可读取 out
```

<a id="N026"></a>
### 外层捕获与内层捕获

**讲解：** 外层 [&] 在主机提交命令时引用 buffer，向 handler 声明本次访问。内层 [=] 把 accessor 和标量按值捕获到设备计算体里。read 与 write 帮助运行时确定命令之间的数据依赖。

<a id="N027"></a>
### 主机何时可以读

**讲解：** wait_and_throw 等待提交的工作并提供异步错误处理时点。对与主机数组关联的 buffer，应通过 host_accessor 获取受管理的主机访问，或在其生命周期结束并写回后使用原数组。原主机存储应始终比关联的 buffer 活得久。


<a id="12.5"></a>
## 12.5 高层性能可移植框架
原书 p.452–453。

<a id="N028"></a>
### 把算法和执行选择写在不同位置

**讲解：** 在 Triad 中，索引 i 的工作始终是一次乘加。换执行空间时可能同时改变并行策略、数据布局和可访问存储。Kokkos 用 View 和执行策略表达这些选择；RAJA 把循环与执行策略组合，允许逐个替换已有循环。


<a id="12.5.1"></a>
## 12.5.1 Kokkos：View、执行空间与并行模式
原书 p.452–455。

<a id="S013"></a>
**Source:** 原书 p.455 / PDF p.491 · S013

**Original:** The Kokkos program starts with Kokkos::initialize and Kokkos::finalize. These commands start up those things that are needed for the execution space, such as threads.

**中文:** Kokkos 程序用 initialize 和 finalize 界定运行环境的生命周期。初始化会准备执行空间所需的资源，例如线程。

<a id="K015"></a>
**代码出处：** Kokkos C++ · 清单 12.22–12.23 对照示例，scalar=2 时 host(i) 应为 i+2

```text
// 在 Kokkos 初始化后执行，三个 View 在 finalize 前析构
using View = Kokkos::View<double*>;
View a("a", n), b("b", n), out("out", n);
Kokkos::parallel_for("init", n, KOKKOS_LAMBDA(int i) {
    a(i) = i; b(i) = 1.0;
});
Kokkos::parallel_for("triad", n, KOKKOS_LAMBDA(int i) {
    out(i) = a(i) + scalar*b(i);
});
Kokkos::fence();
auto host = Kokkos::create_mirror_view_and_copy(Kokkos::HostSpace{}, out);
```

<a id="N029"></a>
### 星号、圆括号和执行空间

**讲解：** View<double*> 声明一维 double 视图。a(i) 使用视图提供的索引运算符。多维 View 可以按执行空间选取布局，改变最快变化的维。构建库时启用的后端决定此程序可选择哪些执行空间。

<a id="N030"></a>
### 三个并行模式

**讲解：** parallel_for 适合独立元素，parallel_reduce 表达多项合并，parallel_scan 表达按索引顺序的前缀关系。按数据依赖选择模式后，再决定执行策略。


<a id="12.5.2"></a>
## 12.5.2 RAJA：让循环服从执行策略
原书 p.455–457。

<a id="S014"></a>
**Source:** 原书 p.457 / PDF p.493 · S014

**Original:** The required changes for RAJA are to include the RAJA header file on line 2 and to change the computation loop to a Raja::forall.

**中文:** 这个 RAJA 示例的改动包括在第 2 行引入 RAJA 头文件，并把计算循环改写为 RAJA::forall 调用。

<a id="K016"></a>
**代码出处：** RAJA C++ · 清单 12.25 的 CPU OpenMP 策略，三个数组是主机可访问的存储

```text
RAJA::RangeSegment indices(0, n);
RAJA::forall<RAJA::omp_parallel_for_exec>(indices, [=](int i) {
    out[i] = a[i] + scalar*b[i];
});
```

<a id="N031"></a>
### 尖括号里选择循环如何执行

**讲解：** RangeSegment(0,n) 是半开区间。forall 的模板参数选择后端，lambda 保留循环体。[=] 复制指针的值；指针指向的数组可通过这些地址访问。书中示例用 new[] 分配主机内存，配合 CPU OpenMP 后端。

<a id="K017"></a>
**代码出处：** RAJA C++ · 练习扩展，需启用 CUDA 后端并事先准备有效设备缓冲区

```text
RAJA::forall<RAJA::cuda_exec<128>>(RAJA::RangeSegment(0, n),
    [=] RAJA_DEVICE (int i) {
        out_d[i] = a_d[i] + scalar*b_d[i];
    });
```

<a id="N032"></a>
### 练习中的两处修改

**讲解：** 移植初始化循环时，a_d[i]=i 和 b_d[i]=1 也要由对应策略执行。先准备 GPU 可访问的存储，再执行初始化和 Triad，确保相应操作完成后才把结果传回。把 CPU 策略名换成 GPU 策略名只完成了执行选择这一步。


<a id="12.6"></a>
## 12.6 进一步探索与本章小结
原书 p.457–459。

<a id="S015"></a>
**Source:** 原书 p.457 / PDF p.493 · S015

**Original:** Think of these as dialects of a common language rather than completely different ones.

**中文:** 可以把这些写法看作同一种并行语言的不同方言。

<a id="N033"></a>
### 对照读完一条计算路径

**讲解：** 读 CUDA 和 HIP 时，从启动配置追到设备指针。读 OpenCL 时，检查 set-arg 的参数位置与队列。读 SYCL 时，看 accessor 声明的访问。读 Kokkos 和 RAJA 时，先辨认执行策略和数据所在的空间。最后回到同一个问题：哪个操作保证结果已经可以使用？


<a id="12.6.1"></a>
## 12.6.1 延伸阅读
原书 p.457–458。

<a id="S016"></a>
**Source:** 原书 p.457 / PDF p.493 · S016

**Original:** Even with the initial functionality shown, you can begin to implement some real application codes.

**中文:** 仅用本章已经展示的基础功能，就可以开始实现一些实际应用程序。

<a id="N034"></a>
### 按问题查资料

**讲解：** 原书列举 CUDA 编程教材、OpenCL in Action、Khronos 规范及 Kokkos 教程等资料。学习启动和地址空间时查语言规范，遇到同步和版本差异时查目标实现。讲义末尾链接 CUDA、HIP、OpenCL、SYCL、Kokkos 和 RAJA 的官方文档。


<a id="12.6.2"></a>
## 12.6.2 练习与参考结果
原书 p.458–459。

<a id="N035"></a>
### 练习 1 · 页锁定主机数组

**讲解：** 对同一数组大小分别用普通页和页锁定分配，记录传入、计算、传回和端到端时间。首次初始化和分配成本单列。能否提速应由实际运行回答。

<a id="N036"></a>
### 练习 2–3 · 归约与 HIP 迁移

**讲解：** 以 128 为组宽，用索引初始化 18,000 个值。先核对局部和数目 141，再核对总和 161991000。迁移到 HIP 后重查共享内存字节数、整块屏障以及第二遍参数。两块 GPU 的 OpenCL 检查结果可用作算法参考。

<a id="N037"></a>
### 练习 4–5 · 把初始化也移到设备

**讲解：** SYCL 用写 accessor 在初始化命令组中填充输入，再用读 accessor 提交计算。RAJA 用相同执行策略将两个初始化循环改为 forall，并确保设备地址有效。在两种写法里均可用 i+2 逐项校验输出。


## 技术核对来源

- [R54 · Khronos SYCL 2020](https://registry.khronos.org/SYCL/specs/sycl-2020/html/sycl-2020.html)
- [R55 · Khronos OpenCL](https://www.khronos.org/opencl/)
- [R56 · AMD HIP](https://rocm.docs.amd.com/projects/HIP/en/latest/)
- [R57 · Kokkos Core](https://kokkos.org/kokkos-core-wiki/)
- [R58 · RAJA](https://raja.readthedocs.io/)
- [R59 · NVIDIA CUDA 编程指南](https://docs.nvidia.com/cuda/archive/12.4.1/cuda-c-programming-guide/index.html)