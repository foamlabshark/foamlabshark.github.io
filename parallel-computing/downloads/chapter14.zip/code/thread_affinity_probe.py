"""Observe temporary binding of the current test thread on single-group Windows."""
import ctypes as c
import json
import sys
from pathlib import Path

def run():
    if sys.platform != "win32":
        raise SystemExit("This experiment uses the Windows API.")
    k = c.WinDLL("kernel32", use_last_error=True)
    word = c.c_size_t
    class Processor(c.Structure):
        _fields_ = [("Group", c.c_ushort), ("Number", c.c_ubyte), ("Reserved", c.c_ubyte)]
    def api(name, result, *args):
        f = getattr(k, name); f.restype=result; f.argtypes=args
        return f
    group_count=api("GetActiveProcessorGroupCount", c.c_ushort)
    if group_count()!=1:
        raise SystemExit("This teaching example is limited to a single processor group.")
    current_process=api("GetCurrentProcess", c.c_void_p)
    current_thread=api("GetCurrentThread", c.c_void_p)
    get_mask=api("GetProcessAffinityMask", c.c_int, c.c_void_p, c.POINTER(word), c.POINTER(word))
    set_mask=api("SetThreadAffinityMask",word,c.c_void_p,word)
    location=api("GetCurrentProcessorNumberEx",None,c.POINTER(Processor))
    allowed=word();system=word()
    if not get_mask(current_process(),c.byref(allowed),c.byref(system)):
        raise c.WinError(c.get_last_error())
    ids=[i for i in range(c.sizeof(word)*8) if allowed.value & (1<<i)]
    thread=current_thread()
    previous=0; measurements=[]
    try:
        for i in ids[:2]:
            prior=set_mask(thread,1<<i)
            if not prior:raise c.WinError(c.get_last_error())
            if not previous:previous=prior
            seen=set()
            for _ in range(64):
                p=Processor();location(c.byref(p));seen.add((p.Group,p.Number))
            if seen!={(0,i)}:raise AssertionError((i,seen))
            measurements.append(dict(target_logical_cpu=i,samples=64,observed=sorted(seen)))
    finally:
        if previous and not set_mask(thread,previous):raise c.WinError(c.get_last_error())
    return dict(process_allowed=ids,initial_thread_mask=hex(previous),restored=True,measurements=measurements)
if __name__=='__main__':
    print(json.dumps(run(),indent=2))
