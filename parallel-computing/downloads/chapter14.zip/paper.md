# 第 14 章｜亲和性与拓扑
原书 p.489–527，PDF p.525–563。核心段落译文与逐节讲解。
## 小节索引

- [第 14 章导读｜亲和性：与操作系统内核协作](#14-intro)
- [14.1 并行程序为何关心亲和性](#14.1)
- [14.2 从拓扑图找到核、PU 与 NUMA 域](#14.2)
- [14.3 OpenMP：选择 places 与绑定策略](#14.3)
- [14.3（续）读取每个工作线程的报告](#14.3-report)
- [14.3（续）向量加法的伸缩性](#14.3-study)
- [14.3（实验）Windows 线程掩码与采样位置](#14.3-lab)
- [14.4 MPI 进程亲和性](#14.4)
- [14.4.1 核对 MPI 启动器的默认行为](#14.4.1)
- [14.4.2 在四台节点上安排 32 个 rank](#14.4.2)
- [14.4.2（续）从插槽收紧到核与硬件线程](#14.4.2-bind)
- [14.4.3 分开理解映射、编号和绑定](#14.4.3)
- [14.5 混合 MPI + OpenMP 的资源分配](#14.5)
- [14.5（续）比较 rank 与线程组合](#14.5-scaling)
- [14.6 从命令行施加亲和性](#14.6)
- [14.6.1 hwloc-bind 与拓扑对象](#14.6.1)
- [14.6.2 LIKWID：给线程和 rank 选择位置](#14.6.2)
- [14.7 在运行时设置与更换亲和性](#14.7)
- [14.7.1 在可执行程序内自动绑定](#14.7.1)
- [14.7.2 在 MPI 阶段与线程阶段间切换](#14.7.2)
- [14.8 延伸探索与本章小结](#14.8)
- [14.8.1 延伸阅读](#14.8.1)
- [14.8.2 练习：改变运算强度再测放置](#14.8.2)

<a id="14-intro"></a>
## 第 14 章导读｜亲和性：与操作系统内核协作
原书 p.489–492。

**Source:** 原书 p.491 / PDF p.527

**Original:** We’ll go into more depth about affinity, placement, and the order of threads or ranks in this chapter.

**中文:** 本章将深入讨论亲和性、放置位置，以及线程或进程编号的排列顺序。

### 第四部分的起点

进程放在哪里，会影响它到内存、网卡和其他进程的距离。后面三章接着讨论如何向批处理系统申请资源、如何跨进程读写文件，以及如何用开发工具观察结果。

### 先学会读一行报告

假设输出写着 rank 0、thread 1、CPU mask 0,44。rank 与 thread 标识执行者，最后一项给出操作系统允许该线程运行的两个逻辑 CPU。要判断 0 和 44 是否共享物理核，还需要本机拓扑。


<a id="14.1"></a>
## 14.1 并行程序为何关心亲和性
原书 p.492–493。

**Source:** 原书 p.492 / PDF p.528

**Original:** Because parallel processes generally synchronize periodically during a run, scheduling a single thread that ends up waiting on another process that is not active has no benefit.

**中文:** 并行进程在运行期间通常会周期性同步。如果只调度一个线程，而它很快便要等待尚未运行的另一个进程，那么这次调度也推进不了计算。

### 同步放大尾部延迟

一轮计算末尾有屏障，最慢的参与者决定下一轮何时开始。固定线程可降低迁移后重新填充缓存的代价。亲和掩码限制允许执行的位置，调度器仍决定何时运行；绑定也不能单独实现同时调度整组进程的 gang scheduling。

### NUMA、缓存、SMT

跨 NUMA 域读取常常比本地读取昂贵，具体差距以实际机器为准。在同一域移动仍可能丢失私有缓存中的数据。SMT 同胞共享执行资源和部分缓存，缓存份额不一定平均。把两个线程放同核是否有利，要同时观察容量、带宽、计算及等待。


<a id="14.2"></a>
## 14.2 从拓扑图找到核、PU 与 NUMA 域
原书 p.493–495。

**Source:** 原书 p.494 / PDF p.530

**Original:** The gray boxes in figure 14.1, each labeled core and containing two light rectangles labled PU for processing unit, are physical cores.

**中文:** 图 14.1 中，每个标为 core 的灰框都是一个物理核，框内两个标为 PU 的浅色矩形表示两个处理单元。

### 图 14.1
原书 p.494 / PDF p.530。

![图 14.1](assets/fig14_1.png)

The Intel Skylake Gold architecture with two NUMA domains and 88 processing cores reveals  the complexity of higher-end compute nodes.

原书双路 Skylake Gold 的拓扑图，展示 NUMA 域、缓存、物理核、逻辑处理单元和外设的位置关系。

沿一个 core 向下数 PU，沿 socket 向上数 NUMA 域。图注里的 88 指本例的逻辑处理单元；物理核是 44 个。socket 与 NUMA 域的对应需从实际拓扑读取。

### 图 14.2
原书 p.495 / PDF p.531。

![图 14.2](assets/fig14_2.png)

Output from lscpu command for the Intel Skylake Gold processor.

lscpu 输出列出每核线程数、插槽数量、CPU 编号与 NUMA 域。

Linux CPU 编号可能交错。书中 0 和 44 是同胞，不能把这个差值当作其他系统的通用规律。

**代码出处：** Linux Shell · 先读取拓扑，按需要再展开外设。命令依赖相应工具及版本。

```text
lscpu
lscpu -e=CPU,CORE,SOCKET,NODE
lstopo --no-io
```

### 作业可用资源

系统拥有的逻辑 CPU 与当前作业获准使用的集合可能不同。联合查看调度器的资源分配、进程掩码与硬件拓扑，避免把整台节点的容量写成自己可用的容量。


<a id="14.3"></a>
## 14.3 OpenMP：选择 places 与绑定策略
原书 p.495–496。

**Source:** 原书 p.495 / PDF p.531

**Original:** Tying a thread to the location of the memory it uses is important to achieve good memory latency and bandwidth.

**中文:** 让线程靠近它访问的内存，有助于获得较低的访存延迟与较高的带宽。

**代码出处：** POSIX Shell · 四线程教学设置，实际可用 places 取决于作业分配和运行库

```text
export OMP_NUM_THREADS=4
export OMP_PLACES=cores
export OMP_PROC_BIND=spread
./vecadd_opt3
```

### 读懂两个变量

OMP_PLACES 描述运行库看到的有序位置集合。cores 通常令一个 place 包含一颗物理核的可用硬件线程；threads 以硬件线程为粒度；sockets 的粒度更粗。OMP_PROC_BIND=close 偏向靠近父线程所在位置，spread 在分区内拉开线程，primary 绑定到主线程所在 place。true 的具体放置策略依实现。

### 首次触碰仍需配合

若大数组由一个线程写遍，页面可能集中在它所在的 NUMA 域。并行初始化时使用与后续计算相容的静态分区，再观察 spread 是否利用了多个内存控制器。绑定本身不会把已有页面自动搬到本地。


<a id="14.3-report"></a>
## 14.3（续）读取每个工作线程的报告
原书 p.497–501。

**代码出处：** Linux C / OpenMP · 对原书报告程序的简化教学函数，固定大小 cpu_set_t 适用于相应 CPU 编号范围

```text
#define _GNU_SOURCE
#include <omp.h>
#include <sched.h>
#include <stdio.h>
void report_threads(void) {
    #pragma omp parallel
    {
        cpu_set_t allowed;
        int rc = sched_getaffinity(0, sizeof allowed, &allowed);
        int place = omp_get_place_num();
        int cpu = sched_getcpu();
        #pragma omp critical(report)
        {
            printf("thread=%d place=%d cpu_now=%d allowed=",
                   omp_get_thread_num(), place, cpu);
            if (rc == 0) {
                for (int k=0; k<CPU_SETSIZE; ++k)
                    if (CPU_ISSET(k, &allowed)) printf("%d ", k);
            } else { perror("sched_getaffinity"); }
            putchar('\n');
        }
    }
}
```

### 图 14.3
原书 p.501 / PDF p.537。

![图 14.3](assets/fig14_3.png)

Affinity and placement report for OMP_PLACES=cores and  OMP_PROC_BIND=close. Each thread can run on two possible virtual cores.

在原书 cores 与 close 的组合下，线程 0 的掩码含 0、44，线程 1 的掩码含 1、45。

报告中写作 OpenMP socket 的字段来自 omp_get_place_num()。该函数给出 place 编号，须结合 OMP_PLACES 才能解释到哪一层硬件。

### 三列各答一个问题

sched_getaffinity 的第一个参数 0 表示调用线程。CPU_ISSET 测试某个逻辑 CPU 位是否置位。sched_getcpu 只给采样瞬间的位置，允许集合很大时，下次采样可以不同。critical 把一整行输出放在同一个互斥区域，离开并行区后再做正式计时。


<a id="14.3-study"></a>
## 14.3（续）向量加法的伸缩性
原书 p.500–503。

### 图 14.4
原书 p.503 / PDF p.539。

![图 14.4](assets/fig14_4.png)

OpenMP affinity and placement settings of OMP_PROC_BIND=spread boosts the  parallel scaling by 50%. The lines are for various numbers of threads for a particular setting and are ordered roughly from high to low in the legend.

不同位置集合与绑定策略下，向量加法相对单线程基准的加速随线程数变化。

本例带宽受限。若前几个线程集中在同一插槽，另一插槽的内存带宽可能闲置。细小的曲线差异还需结合重复运行的波动判断。

### 如何复算单个结果

原书从 0.0221 降至 0.0166，用时减少约 24.9%，加速比约 1.33。这个百分比与曲线标题中的伸缩性改善采用不同基线；保留原计时单位，在实际程序中另核对计时器的单位。

**代码出处：** POSIX Shell · 在获准资源内扫描线程数；每组配置应多次运行并校验和

```text
for bind in close spread; do
  for threads in 1 2 4 8; do
    OMP_NUM_THREADS="$threads" OMP_PLACES=cores OMP_PROC_BIND="$bind" ./vecadd_opt3
  done
done
```

### 结果如何记录

固定数组大小、分配策略和编译选项，先预热，再记录每次耗时及中位数、离散程度。若测试次数很少，优先报告各次原始时间。仅对本例可以说 44 个物理核已经取得较好带宽，不能据此预测所有计算型 kernel 的 SMT 收益。


<a id="14.3-lab"></a>
## 14.3（实验）Windows 线程掩码与采样位置
原书 p.497–501。

### 在本机做什么

随包 Python 实验在一个新进程中调用 Windows API，读取进程可用掩码，然后短暂将该测试线程分别约束在两个不同的逻辑 CPU。测试结束恢复它原来的线程掩码。实验限定单一处理器组。

**代码出处：** Python 伪代码 · 实际 ctypes 签名、错误处理和采样见 thread_affinity_probe.py

```text
mask = 1 << cpu_id
previous = SetThreadAffinityMask(thread_handle, mask)
# 采样线程实际所在的处理器组和编号
# finally 中用函数返回的 previous 恢复原掩码
```

### 本次观测

进程允许集合为 0–15，测试线程初始掩码为 0xffff。指定逻辑 CPU 0 后，64 次采样均为组 0、CPU 0；指定 CPU 1 后，64 次均为组 0、CPU 1。这个实验核对允许集合与采样位置的对应。它不提供 OpenMP 放置策略的速度比较。


<a id="14.4"></a>
## 14.4 MPI 进程亲和性
原书 p.503–504。

### 三个粒度

多个 rank 可分布在不同主机，一台主机内又有插槽、物理核和硬件线程。先选每台机器承担的工作量，再选每个 rank 靠近哪些硬件资源，最后查看其允许执行的 CPU 集合。

### 工具和标准

本节的 mpirun 选项是 Open MPI 实现提供的接口。MPI 标准定义通信和 rank 语义，不统一规定这些启动参数。批系统、启动器与站点配置都可能施加额外限制。


<a id="14.4.1"></a>
## 14.4.1 核对 MPI 启动器的默认行为
原书 p.504。

**Source:** 原书 p.504 / PDF p.540

**Original:** Some HPC centers might set other defaults such as always binding to cores. This binding policy may make sense for most MPI jobs but can cause problems with applications using both OpenMP threading and MPI.

**中文:** 有些 HPC 中心会设置自己的默认值，例如总是绑定到核。对许多纯 MPI 作业，这种策略可能合适，但对 MPI 和 OpenMP 混合的应用则可能造成问题。

### 默认值要从当前运行取得

原书举出的“至多两个进程绑定 core、更多进程绑定 socket”等规则属于作者当时的实现。作业提交脚本、MPI 版本或超额订阅都可能改变默认值。用 mpirun --version 和 --report-bindings 连同实际 rank 输出保存证据。


<a id="14.4.2"></a>
## 14.4.2 在四台节点上安排 32 个 rank
原书 p.504–507。

**Source:** 原书 p.504 / PDF p.540

**Original:** For most use cases, it is sufficient to use simple controls to place processes and to bind these to hardware components.

**中文:** 对多数使用场景，只需用简单的控制选项确定进程的放置方式，并将它们绑定到相应硬件组件。

### 图 14.5
原书 p.506 / PDF p.542。

![图 14.5](assets/fig14_5.png)

For mpirun -n 32, all of our processes are on the cn328 node. The affinity is  set to the NUMA region (socket).

第一组报告显示 32 个 rank 位于同一节点，允许范围对应各自的 NUMA 区域。

先看主机名，再看掩码。不同 rank 有不同掩码，并不能证明它们使用了不同物理节点。

### 图 14.6
原书 p.506 / PDF p.542。

![图 14.6](assets/fig14_6.png)

The MPI processes are spread out across the four nodes, cn328 through 331. 

把每节点的进程数设为 8 后，32 个 rank 分布到四台主机。

四台各 128 GiB 节点的标称内存相加约为 512 GiB，具体程序仍应给系统、MPI 和临时缓冲留余量。分配四台节点不自动把单个数组分布出去。

**代码出处：** Shell · 假设调度器已分配四台合适的节点；ppr 表示每个指定资源的进程数

```text
mpirun -n 32 --map-by ppr:8:node --report-bindings ./MPIAffinity
```

### 看整行启动参数

-n 32 是总 rank 数，ppr:8:node 是每台节点 8 个。若作业只分到一台机器，启动器不会凭此选项再申请三台。原书的 -N / --npernode 属于相应版本的写法。


<a id="14.4.2-bind"></a>
## 14.4.2（续）从插槽收紧到核与硬件线程
原书 p.507–509。

### 图 14.7
原书 p.507 / PDF p.543。

![图 14.7](assets/fig14_7.png)

With the placement set to four processes per socket, the order of the ranks  changes. Now the four adjacent ranks are on the same NUMA region.

按每插槽四个进程安排后，一台节点内的 rank 编号顺序改变。

先判断相邻 rank 是否在同一插槽，再结合程序实际通信邻居选择顺序。相邻编号只有在通信图上也相邻时才可能缩短通信距离。

### 图 14.8
原书 p.507 / PDF p.543。

![图 14.8](assets/fig14_8.png)

The affinity from binding to a core changes the affinity for the processes to  a hardware core. Each hardware core represents two virtual cores because of hyperthreading. We get two locations for each process.

绑定到 core 后，一个进程的掩码限制为同一物理核的两个 SMT 逻辑处理器。

两个 CPU 编号代表同一物理核上的两个执行位置。允许两位不能解释为获得了两个完整物理核。

### 图 14.9
原书 p.508 / PDF p.544。

![图 14.9](assets/fig14_9.png)

The process placement from the hwthread option limits where the  processes can run to only one location.

绑定到硬件线程后，每个进程的允许集合缩为单一逻辑 CPU。

进一步检查同时运行的 rank 是否落在同胞线程上。单一掩码避免迁移，但不同 rank 仍可能争用同一物理核的资源。

**代码出处：** Shell · 现代 Open MPI 用 package 表示处理器封装；例子假设四台双路节点

```text
mpirun -n 32 --map-by ppr:4:package --bind-to core --report-bindings ./MPIAffinity
```


<a id="14.4.3"></a>
## 14.4.3 分开理解映射、编号和绑定
原书 p.509–511。

**Source:** 原书 p.509 / PDF p.545

**Original:** At the level of the operating system, you can set where each process is allowed to run.

**中文:** 在操作系统层面，你可以指定每个进程允许在哪些处理器上运行。

### 图 14.10
原书 p.509 / PDF p.545。

![图 14.10](assets/fig14_10.png)

Placement report from the --report-bindings option to mpirun shows where ranks are bound  with the letter B.

--report-bindings 按 rank 标出绑定到的 socket、core 和硬件线程。

同一行同时含多个编号空间。P# 或 Linux CPU 编号与 hwloc 的逻辑索引不一定一致，应依据拓扑和输出格式对应。

### 用三步还原布局

mapping 决定各计算资源容纳多少进程；ranking 决定这些位置按什么顺序编号；binding 决定每个进程能在哪些处理器上运行。32 个 rank 同样均分四台节点，连续编号集中在同一主机与轮转编号会给最近邻通信带来不同拓扑。

### 读取报告时保留启动器上下文

原书展示 --map-by、--rank-by、--bind-to。支持的对象名和修饰符随 Open MPI 大版本变化，socket 在其他版本可写作 package。用 rank、hostname 与实际掩码验证最终结果。


<a id="14.5"></a>
## 14.5 混合 MPI + OpenMP 的资源分配
原书 p.511–514。

**Source:** 原书 p.511 / PDF p.547

**Original:** Our goal in this section is to understand how to set affinity for hybrid MPI and OpenMP applications. Getting affinity right for these hybrid situations can be tricky.

**中文:** 本节要理解的是 MPI 与 OpenMP 混合程序的亲和性设置。在这种组合中，要得到预期放置并不容易。

### 图 14.11
原书 p.513 / PDF p.549。

![图 14.11](assets/fig14_11.png)

The MPI ranks are placed in a round-robin fashion across the sockets with two slots to  accommodate the two OpenMP threads. The placement is restricted to a NUMA domain to keep memory close to the threads. The processes are not bound tightly to any particular virtual core, and the scheduler can move these around freely within the NUMA domain.

各 rank 交替分到两个插槽，同一 rank 的线程掩码仍可覆盖较大的 NUMA 区域。

rank 的外层放置已经分开，但线程是否独占物理核或逻辑 CPU，需要再看每个工作线程自己的报告。

### 图 14.12
原书 p.514 / PDF p.550。

![图 14.12](assets/fig14_12.png)

The process and thread affinity are now constrained to a logical core, and the two OpenMP  threads per rank are located on the hyperthread pairs (0 and 44 in the figure). The ranks are packed close in order to reduce communication costs for more complicated programs. The MPI ranks are pinned to hardware cores and the thread affinity is to the hyperthread.

书中 rank 0 的两个线程分别被约束到逻辑 CPU 0 和 44。

两个位置是同一物理核上的 SMT 同胞。本图展示两线程共享一个核的策略。若实验需要两颗物理核，应为每 rank 分配两个 core 并调整 places。

### 图 14.13
原书 p.514 / PDF p.550。

![图 14.13](assets/fig14_13.png)

Output without OMP_PROC_BIND=true shows that the MPI ranks are pinned to hardware cores.

去掉显式 OpenMP 绑定设置后，原书报告里同 rank 的两条线程都能在 0 或 44 上运行。

线程继承父执行环境的约束，运行库可以在外层允许范围内进一步收紧。实际亲和性应同时检查调度器、MPI 和 OpenMP 三层。

**代码出处：** 教学配置 · 一台双路节点，每封装两个 rank；每 rank 申请两颗可用物理核

```text
export OMP_NUM_THREADS=2
export OMP_PLACES=cores
export OMP_PROC_BIND=close
mpirun -n 4 --map-by ppr:2:package:PE=2 --bind-to core --report-bindings ./StreamTriad
```

### 检查预算

本例共 4 个 rank，每 rank 两条线程，合计 8 条线程。PE=2 按启动器对 processing element 的定义解释，采用 core 还是硬件线程会影响核数。用 OMP_NUM_THREADS 指定团队大小，不会自动扩张外层给予的 CPU 集合。


<a id="14.5-scaling"></a>
## 14.5（续）比较 rank 与线程组合
原书 p.515–516。

### 同一总资源量做比较

在固定总核数的实验里，依次比较较多 rank 配少量线程与较少 rank 配较多线程。记录每节点 rank 数、每 rank 线程数、每线程允许集合、首触页面位置和通信量。为每种组合用相同问题、结果容差和计时范围。

### 为什么 Triad 的曲线可能接近

循环只有两读一写，主要消耗节点内存带宽，MPI 进程间没有近邻交换。对于真实分区网格，更少的 rank 可能减少幽灵边界和通信缓冲；线程同步、共享缓存和 NUMA 远端流量也可能增加。

### 读清单 14.3

shell 的 \$((...)) 进行整数算术，\${OMP_NUM_THREADS} 取环境变量。原清单第 39 行末尾多出的右花括号应去掉。若 PE 数由线程数除以每核线程数得到，必须检查可整除、没有得到 0，且这确实是本次想使用 SMT 同胞的方案。


<a id="14.6"></a>
## 14.6 从命令行施加亲和性
原书 p.516。

### 用启动包装器

有些程序没有自带的线程或进程放置界面，可将绑定工具置于可执行文件之前。它先选择 CPU 集合，再在这个环境中启动目标程序。多个工具同时写掩码时可能覆盖之前的决定，应读取最终线程掩码。


<a id="14.6.1"></a>
## 14.6.1 hwloc-bind 与拓扑对象
原书 p.516–518。

**Source:** 原书 p.516 / PDF p.552

**Original:** Because there are many hwloc tools, as an introduction, we’ll just look at a couple of these.

**中文:** hwloc 包含许多工具，这里先选其中几个作为入门。

### 图 14.14
原书 p.517 / PDF p.553。

![图 14.14](assets/fig14_14.png)

The lstopo image shows the bound location in green (shaded core) at the lower left. This shows  that process 22 is bound to the 22nd and 66th virtual cores, which are hyperthreads for a single physical core.

lstopo 用阴影标出被绑定的物理核及其两个逻辑处理器。

截图中物理核 22 的同胞编号为 22 和 66。查看自己的机器时，应让输出指明逻辑对象编号还是操作系统 PU 编号。

**代码出处：** Shell · 第一行列举相交的核，第二行在所选核的约束下启动拓扑查看器；使用前核对本机 hwloc 对象编号

```text
hwloc-calc --intersect core machine:0
hwloc-bind core:0 -- lstopo --no-io --pid 0
```

### 同一个 core:0 依赖输入拓扑

作业 cpuset 可能只暴露节点的一个子集。使用 core 或 package 等层次标识可少依赖硬编码 OS 编号，但仍需读出允许的对象。批作业中从资源分配获得这些位置。


<a id="14.6.2"></a>
## 14.6.2 LIKWID：给线程和 rank 选择位置
原书 p.518–520。

### 图 14.15
原书 p.519 / PDF p.555。

![图 14.15](assets/fig14_15.png)

The likwid-pin output is at the top of the screen, followed by our placement report output. 

上半是 likwid-pin 对工作线程的放置记录，下半是应用自己的掩码报告。

对照运行时线程号与应用线程号。这两种编号可能还包含运行库辅助线程，先看完整映射，再解释性能。

### 图 14.16
原书 p.520 / PDF p.556。

![图 14.16](assets/fig14_16.png)

The placement report for likwid-mpirun shows that each rank is pinned to cores in numeric order.

likwid-mpirun 的默认示例显示 rank 按编号占据核。

一段连续编号可能全部位于第一插槽。带宽型应用若想利用两路内存控制器，应检查每插槽的实际进程数和内存位置。

**代码出处：** Shell · 原书双路各 22 核机器示例。S0/S1 表示两个 socket 域，@ 连接两个选择集合。

```text
likwid-pin -p
likwid-pin -c S0:0-21@S1:0-21 ./vecadd_opt3
```

### 先核对编号方案

LIKWID 的 S、N、M 等对象与域内索引依当前配置解释。若工具选择的 CPU 少于应用实际请求的线程数，可能发生复用或超额订阅。运行库也可能自行绑定，故以最终报告为准。


<a id="14.7"></a>
## 14.7 在运行时设置与更换亲和性
原书 p.520–522。

**Source:** 原书 p.520 / PDF p.556

**Original:** What if the user didn’t need to worry about affinity? It is challenging to get users to use the complicated invocations to properly place and pin processes.

**中文:** 能否让用户少操心亲和性？要让每位用户都正确使用复杂的启动参数来安排和绑定进程，并不容易。

### 把决策下沉到程序

程序可以查询当前资源范围与拓扑，根据阶段需求放置执行者。书中 QUO 以栈保存旧绑定，在新阶段扩大或收紧允许集合，退出时恢复。程序仍需遵守批系统分配，不能假定可以占用节点的全部核。


<a id="14.7.1"></a>
## 14.7.1 在可执行程序内自动绑定
原书 p.521–522。

### 图 14.17
原书 p.523 / PDF p.559。

![图 14.17](assets/fig14_17.png)

The output from the autobind demo shows cores initially bound to sockets, but  afterwards, these are bound to hardware cores.

autobind 的前后两次报告展示 rank 的允许集合从整个插槽缩小到一个物理核。

发布一项绑定策略前，用同一报告函数记录改变前后，可看出程序确实修改了允许集合。掩码改变不代表内存页自动随之迁移。

**代码出处：** C / 原书 libquo · 教学片段，实际核对象索引需结合节点内 rank 和获准资源计算

```text
/* 清单 14.5 中的接口关系；qcontext 和 noderank 已取得 */
QUO_bind_push(qcontext, QUO_BIND_PUSH_PROVIDED, QUO_OBJ_CORE, noderank);
/* 检查返回状态，执行此阶段的工作并记录掩码 */
QUO_bind_pop(qcontext);
```

### 同步与恢复

作者先建立 QUO 上下文，获取拓扑、分配成员，进入阶段前 push，完成后 pop，最后释放上下文。MPI_Barrier 可以协调参与者，usleep(rank*1000) 仅错开时间或输出，不能代替同步或建立跨进程内存一致性。


<a id="14.7.2"></a>
## 14.7.2 在 MPI 阶段与线程阶段间切换
原书 p.522–525。

**Source:** 原书 p.522 / PDF p.558

**Original:** Suppose we have an application with one part that wants to use all MPI ranks and another part that works best with OpenMP threads. To handle this, we need to switch the affinities during run time.

**中文:** 假设程序的一部分适合使用所有 MPI rank，另一部分更适合使用 OpenMP 线程。为了协调这两种阶段，可以在运行时切换亲和性。

### 图 14.18
原书 p.524 / PDF p.560。

![图 14.18](assets/fig14_18.png)

For the MPI region, the processes are bound to the hardware cores. When we enter the OpenMP  region, the affinities are expanded to the whole node.

MPI 阶段中各 rank 受单核约束，进入线程阶段后，参与者的掩码扩展至更大的节点内资源集合。

放宽掩码只表示线程可在更广范围调度。还要确认其他 rank 已按协议让出资源，并在阶段结束后恢复绑定。

### 谁参与，谁等待

先完成上一阶段未结束的通信，选出将运行线程库的 rank；其他 rank 在约定位置等待。参与 rank 扩大可用集合，建立 OpenMP 团队，结束后归还资源并恢复 MPI 阶段。所有可能的返回路径都应处理绑定栈和集体调用。


<a id="14.8"></a>
## 14.8 延伸探索与本章小结
原书 p.525–527。

### 交付一份可解释的放置报告

保存节点清单、每节点进程数、每进程线程数、绑定策略、线程掩码与实际时间。比较结果时区分容量、带宽、通信和运行波动；这样换到另一台机器时能再次推导合适的布局。


<a id="14.8.1"></a>
## 14.8.1 延伸阅读
原书 p.525–526。

### 按工具查文献

原书给出 NERSC 和 Argonne 的位置报告资料、Open MPI 的 mpirun 手册、hwloc、LIKWID 以及 LANL 的 libquo 案例。命令解释应匹配安装版本，尤其核对默认映射、PE 单位和调度器的 cpuset。


<a id="14.8.2"></a>
## 14.8.2 练习：改变运算强度再测放置
原书 p.526–527。

**代码出处：** C · 原书练习 3–5 的合并循环；输入取适当范围，并与双循环结果核对

```text
for (int i=0; i<n; ++i) {
    double x=a[i], y=b[i];
    c[i] = x+y;
    d[i] = sqrt(x*x+y*y);
}
```

### 练习 1–2

给两种机器画拓扑图，标出物理核、SMT 同胞、NUMA 域以及作业可用范围。固定向量大小比较线程设置，用测量回答“哪种配置适合这个输入”。

### 练习 3–5

把向量加法替换为模长运算，比较同胞线程是否能隐藏计算延迟。再把两个结果放在一个循环里，查看输入复用与额外写入怎样改变有效流量。x*x 可能溢出或下溢，若需宽数值范围，可采用 hypot 作为精度对照。

### 练习 6

在程序内设置亲和性，进入前保存掩码，运行时采样，退出后恢复。本章附带本机 Windows 的最小实验；在 Linux/OpenMP/MPI 下，应以相应线程与 rank 报告重复验证。


## 技术参考

[官方参考文档](https://docs.open-mpi.org/en/main/tuning-apps/affinity.html)