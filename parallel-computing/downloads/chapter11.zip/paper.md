# 第 11 章｜基于指令的 GPU 编程

原著：Robert Robey、Yuliana Zamora，Manning，2021。原书 p.371–416 / PDF p.407–452。

核心段落对照与全部编号小节讲解；保留图 11.1–11.5、表 11.1–11.4。不是逐段全文翻译。旧编译器与硬件成绩保留历史语境。

## 小节索引

- [第 11 章导读｜基于指令的 GPU 编程](#11-intro)
- [11.1 从计算迁移到数据管理](#11.1)
- [11.2 OpenACC 入门](#11.2)
- [11.2.1 编译 OpenACC 程序](#11.2.1)
- [11.2.2 kernels 与 parallel loop](#11.2.2)
- [11.2.2（续）归约与顺序计算](#11.2.2-reduction)
- [11.2.3 数据区域与数组切片](#11.2.3)
- [11.2.3（续）跨循环保留数据](#11.2.3-lifetime)
- [11.2.3（续）设备指针与主机映射](#11.2.3-deviceptr)
- [11.2.4 gang、worker 与 vector](#11.2.4)
- [11.2.4（续）stencil 与指针交换](#11.2.4-stencil)
- [11.2.5 STREAM Triad 的性能变化](#11.2.5)
- [11.2.6 函数调用与原子操作](#11.2.6)
- [11.2.6（续）异步队列与等待](#11.2.6-async)
- [11.2.6（续）CUDA 互操作与多设备](#11.2.6-interop)
- [11.3 OpenMP 的 GPU 卸载](#11.3)
- [11.3.1 编译与确认执行设备](#11.3.1)
- [11.3.2 拆解 target teams distribute parallel for](#11.3.2)
- [11.3.2（续）设备归约与结果回传](#11.3.2-reduction)
- [11.3.3 target data 与跨循环驻留](#11.3.3)
- [11.3.3（续）enter、exit 与 update](#11.3.3-lifetime)
- [11.3.3（续）omp_target_alloc 与设备地址](#11.3.3-deviceptr)
- [11.3.4 OpenMP stencil 调优](#11.3.4)
- [11.3.5 高级 OpenMP：函数与 loop](#11.3.5)
- [11.3.5（续）nowait 与任务依赖](#11.3.5-async)
- [11.3.5（续）扫描、分配器与 mapper](#11.3.5-memory)
- [11.4 延伸探索与本章小结](#11.4)
- [11.4.1 延伸阅读](#11.4.1)
- [11.4.2 练习与参考思路](#11.4.2)

## 术语约定

|原文|译法|说明|
|---|---|---|
|data region|数据区域|设备数据生命周期范围|
|present|已存在|要求设备中存在所需映射|
|copyin|复制输入|传入设备的映射语义|
|create|创建存储|不自动初始化数据|
|target|目标设备执行|OpenMP 设备执行构造|
|map|映射|主机与设备对应对象关系|
|device pointer|设备指针|用于设备地址空间的指针|
|offload|卸载|将计算交由目标设备执行|

<a id="11-intro"></a>
## 第 11 章导读｜基于指令的 GPU 编程
原书 p.371–372。

<a id="S001"></a>
**Source:** 原书 p.371 / PDF p.407 · S001

**Original:** In this case, OpenACC pragmas direct the compiler to generate GPU code.

**中文:** 在这里，OpenACC 编译指令引导编译器生成 GPU 代码。

<a id="N001"></a>
### 这章与上一章的联系

**讲解：** 第 10 章解释工作组、索引和同步；这一章让编译器承担更多映射工作。程序员仍要保证迭代独立、数据可用和生命周期正确。几行 pragma 可以生成 kernel，但不自动保证正确、确实在 GPU 执行或已经加速。

<a id="N002"></a>
### 版本与范围

**讲解：** 保留 11.1–11.4 及全部编号子小节，长小节按计算、数据和优化拆分。原书 PGI 19.7、IBM XL 16、旧 GCC 与 nvprof 的描述属于历史环境，不代表当前支持情况或性能排名。


<a id="11.1"></a>
## 11.1 从计算迁移到数据管理
原书 p.373–374。

<a id="F001"></a>
### 图 11.1
**Source:** 原书 p.373 / PDF p.409 · C001
**Placed near:** 11.1 从计算迁移到数据管理

![图 11.1](assets/fig11_1.png)

**Original caption:** Steps to implement a GPU port with the pragma-based languages. Offloading the work to a GPU causes data transfers that slow down the application until the data movement is reduced.

**中文图注:** 先迁移计算，再管理数据驻留，最后优化 kernel。

**Reading note:** 原图强调常见迁移过程，并非所有程序都会先慢后快。每一步都应先比较结果，再检查是否卸载、复制了多少数据及完整运行时间。

<a id="K001"></a>
**代码出处：** C · OpenACC 计算指令示意，数据映射随后展开

```text
#pragma acc parallel loop
for (int i=0; i<n; ++i) c[i]=a[i]+scalar*b[i];
```

<a id="K002"></a>
**代码出处：** Fortran · 同一循环的指令形式

```text
!$acc parallel loop
do i=1,n
  c(i)=a(i)+scalar*b(i)
end do
!$acc end parallel loop
```

<a id="N003"></a>
### 指令与子句

**讲解：** #pragma acc 或 #pragma omp 后先写构造，再写参数化子句；它们不是可任意拼接的自然语言。Fortran 指令前缀为 !\$acc 或 !\$omp，原书后文出现 !#acc 属于拼写问题。

<a id="N004"></a>
### 三步都有证据

**讲解：** 计算迁移：看编译反馈并确认执行设备；数据管理：看主机与设备复制；kernel 优化：看占用率、访存和吞吐。只比较最内层 kernel 时间会漏掉初始化、通信和 I/O。


<a id="11.2"></a>
## 11.2 OpenACC 入门
原书 p.374–375。

<a id="S002"></a>
**Source:** 原书 p.374 / PDF p.410 · S002

**Original:** It is normal to encounter an initial slowdown on your journey to faster computations on a GPU.

**中文:** 最初把程序移到 GPU 时遇到减速，是常见情况。

<a id="N005"></a>
### 减速是诊断起点

**讲解：** 可能只生成了顺序 kernel，也可能每轮来回复制大数组。先区分二者再修改；不能靠继续增加线程或把所有循环标为 independent 来解决。

<a id="F002"></a>
### 图 11.2
**Source:** 原书 p.375 / PDF p.411 · C002
**Placed near:** 11.2 OpenACC 入门

![图 11.2](assets/fig11_2.png)

**Original caption:** Output from the pgaccelinfo command shows the type of GPU and its characteristics.

**中文图注:** 原书设备查询输出显示 GPU 型号、容量、线程及资源限制。

**Reading note:** 这是历史 PGI 工具截图，不是当前机器配置。NVIDIA HPC SDK 文档提供 nvaccelinfo 等工具；查询到设备只是环境检查，仍须确认程序真正运行在目标设备上。[R51]


<a id="11.2.1"></a>
## 11.2.1 编译 OpenACC 程序
原书 p.375–377。

<a id="S003"></a>
**Source:** 原书 p.374 / PDF p.410 · S003

**Original:** Often the most difficult step is getting a working OpenACC compiler toolchain.

**中文:** 最困难的一步，往往是获得能够正常工作的 OpenACC 编译工具链。

<a id="K003"></a>
**代码出处：** Shell · NVIDIA HPC SDK 编译函数示例，依实际支持平台配置；不是原书旧 PGI 命令原样复制

```text
nvc -O2 -acc -Minfo=accel -c triad_acc.c -o triad_acc.o
```

<a id="K004"></a>
**代码出处：** Shell · GCC 解析 OpenACC 的示例；GPU offload 还依赖其构建、插件和目标支持

```text
gcc -O2 -fopenacc -c triad_acc.c -o triad_acc.o
```

<a id="N006"></a>
### 编译成功不等于 GPU 成功

**讲解：** 原书 -acc -Mcuda 属于旧 PGI 用法，不是 GCC 选项。_OPENACC 可帮助判断实现宣称的版本，但不是所有特性都正确支持的证明；先用小程序验证目标设备与所需功能。

<a id="N007"></a>
### 别名规则是语义约束

**讲解：** restrict 或类型别名优化标志不是“强制编译器忽略真实重叠”。只有调用者满足相应访问约定时才能使用；否则可能得到错误结果。对复杂二维指针，尤其不能仅凭参数声明推断行间独立。


<a id="11.2.2"></a>
## 11.2.2 kernels 与 parallel loop
原书 p.377–383。

<a id="S004"></a>
**Source:** 原书 p.377 / PDF p.413 · S004

**Original:** The first is the kernels pragma that gives the compiler freedom to auto-parallelize the code block.

**中文:** 第一种是 kernels 指令，它让编译器自行分析并行化该代码块。

<a id="K005"></a>
**代码出处：** C · kernels 教学片段；n>0，数组有效且当前无既有映射

```text
#pragma acc kernels copyin(a[0:n],b[0:n]) copyout(c[0:n])
{
    for (int i=0; i<n; ++i) c[i]=a[i]+scalar*b[i];
}
```

<a id="N008"></a>
### 分析与承诺

**讲解：** kernels 让编译器分析能否并行，可能生成多个 kernel 或保留顺序执行。parallel loop 表达更明确的并行意图，正确性责任也更直接落在程序员身上；不能用它掩盖循环携带依赖。

<a id="K006"></a>
**代码出处：** C · parallel loop 教学片段，对应清单 11.2–11.3 的核心操作

```text
#pragma acc parallel loop copyin(a[0:n],b[0:n]) copyout(c[0:n])
for (int i=0; i<n; ++i) c[i]=a[i]+scalar*b[i];
```

<a id="N009"></a>
### 读编译反馈

**讲解：** 区分“生成设备代码”“循环已并行”“生成数据复制”三种报告。原书的 loop carried dependence 可能提示别名或真实依赖，应从访问地址证明安全，不能仅因输出不理想就删除约束。


<a id="11.2.2-reduction"></a>
## 11.2.2（续）归约与顺序计算
原书 p.382–383。

<a id="K007"></a>
**代码出处：** C · 原书质量求和例子的简化教学版

```text
double sum = 0.0;
#pragma acc parallel loop copyin(a[0:n]) reduction(+:sum)
for (int i=0; i<n; ++i) sum += a[i];
```

<a id="N010"></a>
### 冒号两侧各是什么

**讲解：** + 是归约操作，sum 是归约变量。初始化原始 sum，不能依赖私有副本的单位元替代原始初值。并行合并改变浮点顺序，应按应用误差标准验证。

<a id="N011"></a>
### serial 与 seq

**讲解：** serial 是设备上的单一执行计算区域；loop seq 表达循环顺序执行。它们有不同语法位置，不能在任何 parallel 区域内部随意嵌套 serial 构造。若一小段工作不能并行，可以考虑保持设备数据驻留，再执行单独的顺序计算区域。


<a id="11.2.3"></a>
## 11.2.3 数据区域与数组切片
原书 p.383–387。

<a id="S005"></a>
**Source:** 原书 p.383 / PDF p.419 · S005

**Original:** Addressing the excessive data movement will start yielding an overall speedup.

**中文:** 解决过量的数据移动之后，程序才开始获得整体加速。

<a id="S006"></a>
**Source:** 原书 p.383 / PDF p.419 · S006

**Original:** The range specification is subtly different for C/C++ and Fortran.

**中文:** C/C++ 与 Fortran 的数组范围写法存在细微但重要的区别。

<a id="K008"></a>
**代码出处：** C · 结构化数据区域，花括号确定生命周期

```text
#pragma acc data copyin(a[0:n],b[0:n]) copyout(c[0:n])
{
    /* 一个或多个设备计算区域 */
}
```

<a id="N012"></a>
### 切片的第二项

**讲解：** C/C++ 的 a[start:length] 第二项是长度，不是末尾下标。a[2:5] 涵盖 2、3、4、5、6。Fortran a(2:5) 通常表达上下界，涵盖 2 到 5；不能按字面直接互换。

<a id="N013"></a>
### 四种常见数据动作

**讲解：** copyin：建立所需设备数据并在需要时传入；copyout：在需要时建立设备存储并于退出时传回；copy：双向；create：仅建立存储、不初始化值。已有映射会影响实际动作，不能把 copyin 当成每遇到一次都强制刷新。

<a id="N014"></a>
### present 不是更新

**讲解：** present 要求所需范围已在设备数据环境中；它不负责把主机后来修改的值再次复制。主机改了输入后用 update device，主机需要设备新结果时用 update self，并确保相关计算已完成。[R50]


<a id="11.2.3-lifetime"></a>
## 11.2.3（续）跨循环保留数据
原书 p.384–386。

<a id="S007"></a>
**Source:** 原书 p.384 / PDF p.420 · S007

**Original:** The structured data region is delimited by a code block.

**中文:** 结构化数据区域由一个代码块界定。

<a id="K009"></a>
**代码出处：** C · 完整教学函数 triad_acc.c；主机输入已初始化，数组不重叠且进入时无既有设备映射

```text
void triad_acc(int n, int repeats, const double *a,
               const double *b, double *c, double scalar) {
    if (n <= 0 || repeats <= 0) return;
    #pragma acc data copyin(a[0:n],b[0:n]) copyout(c[0:n])
    {
        for (int r=0; r<repeats; ++r) {
            #pragma acc parallel loop present(a[0:n],b[0:n],c[0:n])
            for (int i=0; i<n; ++i) c[i]=a[i]+scalar*b[i];
        }
    }
}
```

<a id="N015"></a>
### 为什么移到外面

**讲解：** 把数据区域包住重复循环，可让输入传入一次、最终结果传出一次。循环内的 present 使数据驻留意图明确。若主机每轮要消费或修改数据，必须补齐必要更新，不能为少复制而删除算法需要的传输。

<a id="K010"></a>
**代码出处：** C · 非结构化数据生命周期示意；读取 c 前须已由设备写入完成

```text
#pragma acc enter data copyin(a[0:n]) create(c[0:n])
/* 多个计算阶段，必要时更新 */
#pragma acc update device(a[0:n])
#pragma acc update self(c[0:n])
#pragma acc exit data delete(a[0:n],c[0:n])
```

<a id="N016"></a>
### enter/exit 不自动覆盖所有异常路径

**讲解：** 非结构化数据区域适合对象生命周期，但每条退出路径都应正确释放或保留映射；主机先 free 仍被运行库关联的内存，可能导致错误。嵌套映射和引用计数也需按规范管理，不把 delete 当作无条件通用清理。


<a id="11.2.3-deviceptr"></a>
## 11.2.3（续）设备指针与主机映射
原书 p.386–387。

<a id="K011"></a>
**代码出处：** C · acc_malloc/deviceptr 教学片段；不是完整程序

```text
#include <openacc.h>
double *d = (double *)acc_malloc((size_t)n * sizeof(double));
/* 检查分配成功；d 是设备地址 */
#pragma acc parallel loop deviceptr(d)
for (int i=0; i<n; ++i) d[i]=1.0;
/* 同步并完成所有使用后 */
acc_free(d);
```

<a id="N017"></a>
### 设备地址不能在主机随便解引用

**讲解：** deviceptr 表示指针已指向设备存储，不要求运行库再次按主机地址查映射。设备分配、主机分配与映射存储是三种不同来源，释放接口和生命周期必须匹配。

<a id="N018"></a>
### 减少主机副本的条件

**讲解：** 只在 GPU 上初始化和使用的数据，可考虑只分配设备存储。若后续要保存文件或在 CPU 使用结果，仍需要明确的结果传回；不能把输出删除后得到的时间当作同一任务性能。


<a id="11.2.4"></a>
## 11.2.4 gang、worker 与 vector
原书 p.387–393。

<a id="F003"></a>
### 图 11.3
**Source:** 原书 p.388 / PDF p.424 · C003
**Placed near:** 11.2.4 gang、worker 与 vector

![图 11.3](assets/fig11_3.png)

**Original caption:** The hierarchy of the levels in OpenACC: gangs, workers, and vectors

**中文图注:** OpenACC 的并行层级：gang、worker 和 vector。

**Reading note:** 这些是抽象并行层级，不是规范强制的一对一 CUDA 硬件映射。原书把 worker 等同 warp 的概括不宜推广；实际映射依编译器和目标架构。

<a id="K012"></a>
**代码出处：** C · 两层循环调度教学片段；n=rows*cols，整数乘积合法，128 仅为示例

```text
#pragma acc parallel loop gang vector_length(128) present(a[0:n])
for (int j=0; j<rows; ++j) {
    #pragma acc loop vector
    for (int i=0; i<cols; ++i) a[j*cols+i] *= 2.0;
}
```

<a id="N019"></a>
### 先看访存再调参数

**讲解：** 连续内层循环常适合 vector；外层分给 gang。vector_length、num_workers、num_gangs 会改变资源使用和调度，不能把 128 或 warp 大小当作所有设备的最优值。

<a id="K013"></a>
**代码出处：** C · collapse(2) 教学示例；合并满足要求的嵌套迭代空间

```text
#pragma acc parallel loop collapse(2) vector_length(128) present(a[0:n])
for (int j=0; j<rows; ++j)
    for (int i=0; i<cols; ++i) a[j*cols+i] *= 2.0;
```

<a id="N020"></a>
### 语法校核

**讲解：** 在这里用 vector_length(128) 设置 parallel 区域参数，不将原书某些 vector(32) 片段机械拼进所有组合指令。tile 与 collapse 有各自适用约束；依赖不能靠改变调度消除。


<a id="11.2.4-stencil"></a>
## 11.2.4（续）stencil 与指针交换
原书 p.390–393。

<a id="F006"></a>
### 表 11.1
**Source:** 原书 p.392 / PDF p.428 · C006
**Placed near:** 11.2.4（续）stencil 与指针交换

![图 11.T1](assets/fig11_T1.png)

**Original caption:** Run times for the OpenACC stencil kernel optimizations

**中文图注:** 原书 OpenACC stencil 的历史时间对比。

**Reading note:** 5.237 s 降至 0.818 s 的主改进来自计算和数据区域；0.802 与 0.806 s 差异很小。没有误差条和重复测量信息时，不宜将细小差异解释为普遍优劣。

<a id="N021"></a>
### 不能无条件断言必须复制

**讲解：** 原书 GPU 示例把新数组逐元素复制回旧数组，容易理解但增加流量。正确管理映射、数据角色和指针关联时，也可设计双缓冲轮换；单独交换主机指针不保证所有设备指针关联自动正确。

<a id="N022"></a>
### 检查边界与计时

**讲解：** 两个缓冲区的边界都须符合物理条件；计时累加量先初始化；结果验证在必要传回之后进行。原书的复制回数组开销，不应误称为 PCIe 主机设备传输。


<a id="11.2.5"></a>
## 11.2.5 STREAM Triad 的性能变化
原书 p.393。

<a id="F007"></a>
### 表 11.2
**Source:** 原书 p.393 / PDF p.429 · C007
**Placed near:** 11.2.5 STREAM Triad 的性能变化

![图 11.T2](assets/fig11_T2.png)

**Original caption:** Run times from OpenACC stream triad kernel optimizations

**中文图注:** 原书 STREAM Triad 从顺序设备代码、计算区域到数据驻留的时间变化。

**Reading note:** 39.6/0.590≈67.1，是原书环境与计时口径下的比值。118.5 ms 的计算区域版本可能被传输主导，不能只凭 kernel 已并行就预期总时间下降。

<a id="N023"></a>
### 两类慢分开诊断

**讲解：** 1771 ms 的失败并行化案例与 118 ms 的大量传输案例原因不同。先看生成代码和运行剖析，再决定修正依赖表达还是扩大数据驻留范围。


<a id="11.2.6"></a>
## 11.2.6 函数调用与原子操作
原书 p.394。

<a id="S008"></a>
**Source:** 原书 p.393 / PDF p.429 · S008

**Original:** Many other features in OpenACC are available to handle more complex code.

**中文:** OpenACC 还有许多功能可用于处理更复杂的代码。

<a id="K014"></a>
**代码出处：** C · routine seq 设备函数声明教学示例

```text
#pragma acc routine seq
static double square(double x) { return x*x; }

/* 在合法设备计算区域调用 square */
```

<a id="N024"></a>
### routine 的作用

**讲解：** 告诉编译器为函数生成适合设备调用的版本及相应并行属性，不等于函数里的所有循环自动并行。跨文件编译、设备链接和不受支持的库调用仍需单独处理。

<a id="K015"></a>
**代码出处：** C · 原子更新教学片段；histogram 在设备可用且 bin 在范围内

```text
#pragma acc atomic update
histogram[bin] += 1;
```

<a id="N025"></a>
### 原子操作的边界

**讲解：** 保护这一次受支持的存储更新，不是锁住整个数据结构或让周围多条语句组成事务。热点地址上的竞争仍可能严重影响性能；可考虑局部聚合后归约。


<a id="11.2.6-async"></a>
## 11.2.6（续）异步队列与等待
原书 p.394–395。

<a id="K016"></a>
**代码出处：** C · 清单 11.11 的依赖结构教学化；队列中两段工作彼此独立

```text
#pragma acc parallel loop present(xface[0:n]) async(1)
for (int i=0; i<n; ++i) xface[i]=1.0;
#pragma acc parallel loop present(yface[0:n]) async(2)
for (int i=0; i<n; ++i) yface[i]=2.0;
#pragma acc wait(1,2)
/* 两组结果就绪后，再提交依赖它们的工作 */
```

<a id="N026"></a>
### async 暴露机会，不保证重叠

**讲解：** 队列编号区分工作序列，等待保证所需工作完成；硬件资源、数据关联和运行时影响实际并发。释放数组、CPU 读结果和后继设备操作前，都要审查依赖。


<a id="11.2.6-interop"></a>
## 11.2.6（续）CUDA 互操作与多设备
原书 p.395–396。

<a id="F004"></a>
### 图 11.4
**Source:** 原书 p.395 / PDF p.431 · C004
**Placed near:** 11.2.6（续）CUDA 互操作与多设备

![图 11.4](assets/fig11_4.png)

**Original caption:** Is it a device pointer or a host pointer? One points to the GPU memory and the other to the CPU memory, respectively. OpenACC keeps a map between arrays in the two address spaces and provides routines for retrieving each.

**中文图注:** 区分主机地址、映射对应的设备地址，以及直接分配得到的设备地址。

**Reading note:** host_data use_device 用于在指定主机代码区域向设备库传递映射后的设备地址，不是把设备内容复制到主机。函数内部的地址使用方式必须符合被调库要求。

<a id="K017"></a>
**代码出处：** C · CUDA 等设备库互操作示意

```text
#pragma acc host_data use_device(x,y)
{
    /* 调用接收设备指针的库，且其队列/流依赖已经协调 */
}
```

<a id="N027"></a>
### 统一内存与显式映射

**讲解：** 托管或统一内存可简化部分代码，但页面迁移、首次访问、同步与平台支持仍需分析。原书旧 PGI 的 managed 参数不是通用 OpenACC 标准语法，不能照搬到所有编译器。

<a id="N028"></a>
### 设备选择也影响映射

**讲解：** 多 GPU 程序要保持分配、计算、更新和释放使用一致的设备上下文。设备号与 MPI rank 的对应应按每节点可见设备设计，不能假设全局 rank 就是本地 GPU 编号。


<a id="11.3"></a>
## 11.3 OpenMP 的 GPU 卸载
原书 p.396–397。

<a id="S009"></a>
**Source:** 原书 p.396 / PDF p.432 · S009

**Original:** We’ll use the same examples as we did for the OpenACC section 11.2.

**中文:** 这里继续使用 11.2 节 OpenACC 部分的相同示例。

<a id="N029"></a>
### 相同任务，两种接口

**讲解：** OpenMP 把设备卸载与原有线程、SIMD、任务模型结合。章节对两者实现成熟度的评价是出版时期观察，不能当作当前编译器排名。下面通过同一 Triad 计算对比构造和数据动作。


<a id="11.3.1"></a>
## 11.3.1 编译与确认执行设备
原书 p.397–398。

<a id="S010"></a>
**Source:** 原书 p.397 / PDF p.433 · S010

**Original:** We start with how to set up a build environment and compile an OpenMP code.

**中文:** 我们先从搭建构建环境和编译 OpenMP 代码开始。

<a id="K018"></a>
**代码出处：** C · 教学设备检查片段；需放在完整程序中并链接 OpenMP

```text
#include <omp.h>
int on_host = 1;
#pragma omp target map(from:on_host)
{ on_host = omp_is_initial_device(); }
/* on_host != 0 表示此区域在初始设备执行 */
```

<a id="N030"></a>
### CPU OpenMP 支持不等于卸载支持

**讲解：** -fopenmp 可能仅启用 CPU 线程；GPU 目标还需相应编译器后端、设备运行库和驱动。原书 OpenMPAccel.cmake 是随书自定义模块，不是所有 CMake 都自带的通用模块。

<a id="N031"></a>
### 防止把回退误报为 GPU

**讲解：** 除了查看编译输出，还要检查实际执行设备。可在支持的环境使用 OMP_TARGET_OFFLOAD=MANDATORY 诊断必须卸载的路径；该设置不安装设备支持，也不代替正确性验证。


<a id="11.3.2"></a>
## 11.3.2 拆解 target teams distribute parallel for
原书 p.398–402。

<a id="F005"></a>
### 图 11.5
**Source:** 原书 p.399 / PDF p.435 · C005
**Placed near:** 11.3.2 拆解 target teams distribute parallel for

![图 11.5](assets/fig11_5.png)

**Original caption:** The target, teams, and distribute directives enable more hardware resources. The parallel for simd directive spreads out the work within each workgroup.

**中文图注:** target 指定设备执行区域；teams、distribute、parallel、for 与 simd 组织不同层级的工作。

**Reading note:** 这是概念示意，不应据此断言每个构造固定映射到一个 CUDA 硬件层级。simd 不是正确卸载所有循环都必须添加的开关。

<a id="K019"></a>
**代码出处：** C · OpenMP Triad 教学片段；n>0，主机输入已初始化，数组互不重叠

```text
#pragma omp target teams distribute parallel for     map(to:a[0:n],b[0:n]) map(from:c[0:n])
for (int i=0; i<n; ++i) c[i]=a[i]+scalar*b[i];
```

<a id="N032"></a>
### 逐个关键词理解

**讲解：** target 创建设备执行区域；teams 创建团队集合；distribute 分配迭代给团队；parallel 创建团队内并行区域；for 分配迭代给线程；simd 可进一步表达 SIMD 并行。选择合法组合，不要求每个问题都写最长的指令。[R52]

<a id="N033"></a>
### map 描述对象范围

**讲解：** map(to:) 指定传入语义，map(from:) 指定传回语义，map(tofrom:) 双向，map(alloc:) 只分配所需存储。指针值本身与它所指的 n 个元素不是同一对象，应明确写出数组范围，避免依赖特定编译器推断。

<a id="N034"></a>
### 隐式映射不是按栈堆二分

**讲解：** 标量可能按 firstprivate 等规则处理，指针与聚合类型有各自规则。不能把原书“栈数组自动复制、堆数组不复制”的概括当作完整规范；显式映射更便于审查。


<a id="11.3.2-reduction"></a>
## 11.3.2（续）设备归约与结果回传
原书 p.402。

<a id="K020"></a>
**代码出处：** C · OpenMP 设备求和教学片段；输入有效

```text
double sum=0.0;
#pragma omp target teams distribute parallel for     map(to:a[0:n]) map(tofrom:sum) reduction(+:sum)
for (int i=0; i<n; ++i) sum+=a[i];
```

<a id="N035"></a>
### target 不能漏掉

**讲解：** 单独 teams distribute parallel for 不自动意味着在 GPU 执行；需要设备执行上下文。归约结果要在正确时点返回主机，开启 nowait 后也必须等依赖完成再读。


<a id="11.3.3"></a>
## 11.3.3 target data 与跨循环驻留
原书 p.402–406。

<a id="K021"></a>
**代码出处：** C · 完整教学函数 triad_omp.c；数组不重叠，主机输入有效，进入前没有既有映射

```text
void triad_omp(int n, int repeats, const double *a,
               const double *b, double *c, double scalar) {
    if (n<=0 || repeats<=0) return;
    #pragma omp target data map(to:a[0:n],b[0:n]) map(from:c[0:n])
    {
        for (int r=0; r<repeats; ++r) {
            #pragma omp target teams distribute parallel for                 map(alloc:a[0:n],b[0:n],c[0:n])
            for (int i=0; i<n; ++i) c[i]=a[i]+scalar*b[i];
        }
    }
}
```

<a id="S011"></a>
**Source:** 原书 p.402 / PDF p.438 · S011

**Original:** The data movement directives in OpenMP are similar to those in OpenACC with both a structured and dynamic version.

**中文:** OpenMP 的数据移动指令与 OpenACC 类似，也有结构化与动态两种形式。

<a id="N036"></a>
### target data 不执行 GPU 计算

**讲解：** 外层管理数据环境，其中的普通主机语句仍在主机执行；真正设备计算由内部 target 构造触发。内层 alloc 映射复用外层已存在的设备存储，最终外层 from 传回 c。[R53]

<a id="N037"></a>
### 不初始化不等于零

**讲解：** alloc 没有将旧主机内容传入，也不保证设备缓冲清零。输出数组若只有部分元素被 kernel 写入，传回剩余元素可能得到未定义的值；要么初始化，要么只传回实际有效范围。


<a id="11.3.3-lifetime"></a>
## 11.3.3（续）enter、exit 与 update
原书 p.403–404。

<a id="K022"></a>
**代码出处：** C · 非结构化数据生命周期示意；c 必须已正确写入并完成

```text
#pragma omp target enter data map(to:a[0:n]) map(alloc:c[0:n])
/* 完成设备计算；必要时更新主机或设备版本 */
#pragma omp target update to(a[0:n])
#pragma omp target update from(c[0:n])
#pragma omp target exit data map(delete:a[0:n],c[0:n])
```

<a id="N038"></a>
### to 与 from 的方向

**讲解：** 方向以主机和设备数据环境关系理解：update to 将当前主机值送往设备，update from 将当前设备值送回主机。更新不能替代分配，也不自动解决异步计算与主机修改的竞争。

<a id="N039"></a>
### 退出与引用计数

**讲解：** release、delete 和 from 的语义不同，嵌套映射下引用计数影响何时释放和传输。教学示例假设独占、明确配对的生命周期；实际对象共享映射时应设计所有权。


<a id="11.3.3-deviceptr"></a>
## 11.3.3（续）omp_target_alloc 与设备地址
原书 p.404–406。

<a id="S012"></a>
**Source:** 原书 p.406 / PDF p.442 · S012

**Original:** As we have seen, there are a lot of different options for data management for the GPU.

**中文:** 正如前面所见，GPU 数据管理有许多不同选择。

<a id="K023"></a>
**代码出处：** C · 设备专用分配教学片段，需 omp.h；省略分配错误处理

```text
int dev=omp_get_default_device();
double *d=(double *)omp_target_alloc((size_t)n*sizeof(double),dev);
/* 检查 d；本例需要可用的目标设备 */
#pragma omp target teams distribute parallel for device(dev) is_device_ptr(d)
for (int i=0; i<n; ++i) d[i]=1.0;
omp_target_free(d,dev);
```

<a id="N040"></a>
### 设备号与释放匹配

**讲解：** 分配时选定的设备必须与使用和释放相匹配。is_device_ptr 告知实现该指针已可在设备使用，不是自动将任意主机指针转换为设备指针。

<a id="N041"></a>
### declare target 不等于通用 malloc

**讲解：** declare target 使适用的函数或对象能在设备环境使用，但不会自动深拷贝所有指针所指对象。原书在设备代码内分配的方案也有运行时、堆大小和编译器支持约束，不能作为所有实现通用替代。


<a id="11.3.4"></a>
## 11.3.4 OpenMP stencil 调优
原书 p.406–410。

<a id="K024"></a>
**代码出处：** C · 仅展示内核映射结构；主机端两缓冲区均已初始化且边界有效，实际推荐放入持久数据区域

```text
#pragma omp target teams distribute parallel for collapse(2)     map(to:old[0:count]) map(tofrom:next[0:count])
for (int j=1; j<rows-1; ++j)
    for (int i=1; i<cols-1; ++i) {
        int k=j*cols+i;
        next[k]=(old[k]+old[k-1]+old[k+1]+old[k-cols]+old[k+cols])/5.0;
    }
```

<a id="N042"></a>
### 为何明确标出边界

**讲解：** 上面的 kernel 只写内部点，不能把未初始化的 next 边界作为有效结果。完整程序应保证两份缓冲的边界一致，并在同步后轮换角色；count=rows*cols 的乘积与索引类型也需检查。

<a id="F008"></a>
### 表 11.3
**Source:** 原书 p.410 / PDF p.446 · C008
**Placed near:** 11.3.4 OpenMP stencil 调优

![图 11.T3](assets/fig11_T3.png)

**Original caption:** Run times from OpenMP stencil kernel optimizations

**中文图注:** 原书 OpenMP stencil 的历史时间对比。

**Reading note:** 19.01 s 到 18.97 s 表明数据优化后 kernel 仍可能是瓶颈；collapse 后 3.035 s、拆分指令后 2.50 s 仅反映该 IBM XL/V100 案例，不能外推成固定排名。

<a id="F009"></a>
### 表 11.4
**Source:** 原书 p.410 / PDF p.446 · C009
**Placed near:** 11.3.4 OpenMP stencil 调优

![图 11.T4](assets/fig11_T4.png)

**Original caption:** Run times from OpenMP stream triad kernel optimizations

**中文图注:** 原书 OpenMP Triad 数据驻留后的时间明显下降。

**Reading note:** 原书 OpenACC 与 OpenMP 的 CPU 基线来自不同平台，不能仅比较各自加速比来判断语言优劣。需要同一问题、硬件、精度、测量范围与重复实验。

<a id="N043"></a>
### 不要无条件使用 static,1

**讲解：** 循环调度、团队分配和 SIMD 子句处于不同层级。某个 schedule(static,1) 在一个编译器上的访存优势，不保证适用于所有实现；优先剖析实际访存与生成代码。


<a id="11.3.5"></a>
## 11.3.5 高级 OpenMP：函数与 loop
原书 p.411–414。

<a id="K025"></a>
**代码出处：** C · 设备可调用函数教学示例

```text
#pragma omp declare target
static double square_omp(double x) { return x*x; }
#pragma omp end declare target
```

<a id="N044"></a>
### loop 的含义

**讲解：** loop 让程序员描述迭代可并发执行，把部分映射选择留给编译器；bind、上下文与组合规则仍要遵守。它不是在任何位置都能无条件替换 distribute parallel for simd 的字符串。

<a id="N045"></a>
### 参数不是硬件承诺

**讲解：** num_teams、thread_limit、simdlen 对应不同层级与约束，simdlen 不是“每个工作组的线程数”。支持情况和实际分配仍依规范、实现及运行条件。


<a id="11.3.5-async"></a>
## 11.3.5（续）nowait 与任务依赖
原书 p.412。

<a id="K026"></a>
**代码出处：** C · target 任务教学片段；所有相关对象在完成前保持有效

```text
int ready=0;
#pragma omp target teams distribute parallel for nowait     depend(out:ready) map(tofrom:a[0:n])
for (int i=0; i<n; ++i) a[i]*=2.0;
/* 主机可进行与 a 无关的独立工作 */
#pragma omp taskwait
/* 到这里再读取 a 或释放它 */
```

<a id="N046"></a>
### token 是依赖位置

**讲解：** ready 在此用于标识依赖，不是设备算出的布尔就绪标志。更复杂链条需由符合规则的兄弟任务使用匹配 depend 项；不相关的任务不能仅靠名字相同就自动排序。

<a id="N047"></a>
### nowait 不等于流编号

**讲解：** OpenMP 用任务依赖组织异步工作，不与 OpenACC 的整数队列编号一一等同。数据映射、拷贝和任务完成之间也有依赖；不能在任务尚未完成时离开数据生命周期。


<a id="11.3.5-memory"></a>
## 11.3.5（续）扫描、分配器与 mapper
原书 p.411–414。

<a id="N048"></a>
### scan 与 atomic

**讲解：** reduction(inscan,...) 配合 scan 表达前缀扫描，不能只加一个归约子句就省去规定结构。atomic 保护单个受支持的访问操作，不替代全局屏障或多变量事务。新语法应先做小规模测试。

<a id="N049"></a>
### 分配器不保证固定物理位置

**讲解：** OpenMP 分配器、内存空间和 traits 表达资源与属性需求；具体支持、回退行为及设备可访问性要查实现。不能把低延迟分配器自动等同 CUDA shared memory。

<a id="N050"></a>
### 深拷贝仍需描述结构

**讲解：** declare mapper 可以描述结构成员及所指数据的映射，但运行库不会自动推断任意指针图的所有权、循环引用和长度。先把每个数组的范围与生命周期写清，再设计 mapper。


<a id="11.4"></a>
## 11.4 延伸探索与本章小结
原书 p.414–416。

<a id="S013"></a>
**Source:** 原书 p.414 / PDF p.450 · S013

**Original:** You should test new functionality in a small example before adding it to a large application.

**中文:** 把新功能加入大型应用之前，应先用小例子进行测试。

<a id="N051"></a>
### 本章带走的工作流

**讲解：** 检查工具链与实际设备；迁移可证明独立的计算；明确设备存储与主机数据版本；消除不必要传输；最后依据证据优化 kernel。每一步保持正确性基线，不把“已卸载”当作“已加速”。


<a id="11.4.1"></a>
## 11.4.1 延伸阅读
原书 p.414–416。

<a id="S014"></a>
**Source:** 原书 p.414 / PDF p.450 · S014

**Original:** Both OpenACC and OpenMP are large languages with many directives, clauses, modifiers, and functions.

**中文:** OpenACC 和 OpenMP 都有大量构造，包含许多指令、子句、修饰符和函数。

<a id="N052"></a>
### 原书推荐

**讲解：** OpenACC 规范与最佳实践、OpenMP 规范与示例，以及 Using OpenMP—The Next Step 等资料。书中 2.x/3.0/5.0 的版本背景保留，具体支持应查实际编译器。

<a id="N053"></a>
### 核对原则

**讲解：** 规范定义合法语义，编译器文档说明支持方式，剖析结果说明实际执行。三种证据相互补充；单看教程代码或某次成功输出，不能证明复杂映射在所有设备可移植。


<a id="11.4.2"></a>
## 11.4.2 练习与参考思路
原书 p.416。

<a id="N054"></a>
### 练习 1–3：环境与带宽

**讲解：** 列出可用编译器、设备和运行库，分别确认计算目标；运行相同 Triad 输入，校验结果后再测量。有效流量按 3*n*sizeof(datatype)，统一 GB/s 或 GiB/s，明确计时是否包括传输。

<a id="E001"></a>
**Source:** 原书 p.416 / PDF p.452 · E001

$$
B_{\mathrm{GB/s}}=3ns/(10^9t)
$$

两读一写的有效流量口径，不等于硬件实际显存事务字节数。t 必须覆盖已经完成的对应工作。

<a id="N055"></a>
### 练习 4–5：按真实用途映射

**讲解：** 设备初始化的临时数组用 create/alloc；主机输入用 copyin/to；需要返回的结果用 copyout/from；需要双向的才用 copy/tofrom。质量和归约先置合适初值，并检查浮点误差与结果传回时点。

<a id="K027"></a>
**代码出处：** C · 练习六平方半径归约；输入有限，最终半径为 sqrt(max_r2)

```text
double max_r2=0.0;
#pragma omp target teams distribute parallel for     map(to:x[0:n],y[0:n]) map(tofrom:max_r2) reduction(max:max_r2)
for (int i=0; i<n; ++i) {
    double r2=x[i]*x[i]+y[i]*y[i];
    if (r2>max_r2) max_r2=r2;
}
```

<a id="N056"></a>
### 练习六的可手算答案

**讲解：** 令 x 从 1 到 N、y 从 N 到 1，则 x+y=N+1。平方半径在两个端点最大，为 N²+1；N=20000000 时再取平方根。先用小 N 验证，避免用大数组掩盖映射或初始化问题。OpenACC 对应 parallel loop reduction(max:max_r2)。


## 技术核对来源

- [R50 · OpenACC 规范与历史版本](https://www.openacc.org/specification)
- [R51 · NVIDIA OpenACC 入门指南](https://docs.nvidia.com/hpc-sdk/compilers/openacc-gs/index.html)
- [R52 · OpenMP 5.2：构造与术语](https://openmp.org/spec-html/5.2/openmpsu2.html)
- [R53 · OpenMP 5.2：target data](https://openmp.org/spec-html/5.2/openmpse82.html)