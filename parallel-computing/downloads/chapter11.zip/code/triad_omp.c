void triad_omp(int n, int repeats, const double *a,
               const double *b, double *c, double scalar) {
    if (n<=0 || repeats<=0) return;
    #pragma omp target data map(to:a[0:n],b[0:n]) map(from:c[0:n])
    {
        for (int r=0; r<repeats; ++r) {
            #pragma omp target teams distribute parallel for                 map(alloc:a[0:n],b[0:n],c[0:n])
            for (int i=0; i<n; ++i) c[i]=a[i]+scalar*b[i];
        }
    }
}
