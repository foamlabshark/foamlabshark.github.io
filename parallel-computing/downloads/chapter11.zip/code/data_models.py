"""Serial data-lifecycle illustrations, not a full OpenACC/OpenMP runtime model."""
def triad(a,b,s):
    if len(a)!=len(b):raise ValueError('length mismatch')
    return [x+s*y for x,y in zip(a,b)]

def check():
    for n in [0,1,2,7,31,128]:
        a=[float(i+1) for i in range(n)];b=[2.0]*n
        for repeat in [1,2,16]:
            # Copy inputs once, compute repeatedly, copy final output once.
            da,db=a[:],b[:]
            for _ in range(repeat):dc=triad(da,db,.5)
            c=dc[:]
            assert c==[x+1.0 for x in a]
    host=[1.,2.,3.];device=host[:]
    host[0]=100.
    assert device[0]==1.  # Existing allocation does not automatically refresh.
    device[:]=host       # explicit update to/device
    assert device[0]==100.
    device[1]=42.
    assert host[1]==2.
    host[:]=device       # explicit update from/self
    assert host[1]==42.
    assert list(range(2,2+5))==[2,3,4,5,6]
    for n in range(1,513):
        values=[(i+1)**2+(n-i)**2 for i in range(n)]
        assert max(values)==n*n+1
    assert 20_000_000**2+1==400_000_000_000_001
    rows,cols=5,7
    old=[float(j*cols+i) for j in range(rows) for i in range(cols)]
    nxt=old[:]
    for j in range(1,rows-1):
        for i in range(1,cols-1):
            k=j*cols+i;nxt[k]=(old[k]+old[k-1]+old[k+1]+old[k-cols]+old[k+cols])/5
    assert nxt[:cols]==old[:cols] and nxt[-cols:]==old[-cols:]
    assert all(nxt[j*cols]==old[j*cols] and nxt[j*cols+cols-1]==old[j*cols+cols-1] for j in range(rows))
    print('Triad, explicit updates, slice length, 512 radius cases and stencil boundary checks passed.')
    print('Serial models only: no directive compilation, runtime mapping or GPU performance validation.')
if __name__=='__main__':check()
