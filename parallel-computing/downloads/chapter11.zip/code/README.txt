triad_acc.c 和 triad_omp.c 是对应的完整教学函数，不含 main。前置条件：数组有效、互不重叠、输入已初始化、没有外层既有设备映射。n 或 repeats 非正时不执行。
OpenACC 示例可在合适环境用 nvc -O2 -acc -Minfo=accel -c triad_acc.c；OpenMP 卸载编译选项依设备与工具链配置，不能仅凭 -fopenmp 认定在 GPU 执行。
当前没有编译或运行 C/OpenACC/OpenMP。data_models.py 已执行 Triad、显式更新、切片、512 组最大半径及 stencil 边界串行模型验证；不模拟完整映射引用计数、不证明并发正确或 GPU 性能。commands_and_fragments.txt 为片段合集，不是可执行脚本。