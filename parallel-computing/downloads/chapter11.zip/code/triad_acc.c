void triad_acc(int n, int repeats, const double *a,
               const double *b, double *c, double scalar) {
    if (n <= 0 || repeats <= 0) return;
    #pragma acc data copyin(a[0:n],b[0:n]) copyout(c[0:n])
    {
        for (int r=0; r<repeats; ++r) {
            #pragma acc parallel loop present(a[0:n],b[0:n],c[0:n])
            for (int i=0; i<n; ++i) c[i]=a[i]+scalar*b[i];
        }
    }
}
