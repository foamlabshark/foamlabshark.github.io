# 第 17 章｜改进代码的工具与资源
原书 p.579–613，PDF p.615–649。核心段落译文与逐节讲解。
## 小节索引

- [第 17 章导读｜改善代码的工具与资源](#17-intro)
- [17.1 用版本控制保存可复现的基线](#17.1)
- [17.1.1 分布式版本控制](#17.1.1)
- [17.1.2 集中式仓库](#17.1.2)
- [17.2 用单调时钟计量时间](#17.2)
- [17.3 从测量问题选择剖析器](#17.3)
- [17.3.1 日常使用的文本报告](#17.3.1)
- [17.3.2 全程序概览与调用路径](#17.3.2)
- [17.3.3 用中等粒度的指标选择优化方向](#17.3.3)
- [17.3.4 深入硬件事件](#17.3.4)
- [17.4 微基准与小型应用](#17.4)
- [17.4.1 给本机建立可参照的上限](#17.4.1)
- [17.4.2 从 mini-app 学习实现](#17.4.2)
- [17.5 区分越界、泄漏和未初始化读取](#17.5)
- [17.5.1 Valgrind Memcheck](#17.5.1)
- [17.5.2 用 Dr. Memory 检查二维分配](#17.5.2)
- [17.5.3 商业内存检测工具](#17.5.3)
- [17.5.4 编译器插桩](#17.5.4)
- [17.5.5 用边界哨兵定位覆盖](#17.5.5)
- [17.5.6 GPU 内存诊断](#17.5.6)
- [17.6 检测线程间的数据竞争](#17.6)
- [17.6.1 阅读 Intel Inspector 的报告](#17.6.1)
- [17.6.2 Archer 与 OpenMP 同步](#17.6.2)
- [17.7 并行调试器](#17.7)
- [17.7.1 TotalView](#17.7.1)
- [17.7.2 DDT](#17.7.2)
- [17.7.3 本地 Linux 调试工具](#17.7.3)
- [17.7.4 设备端调试](#17.7.4)
- [17.8 用 Darshan 读并行 I/O 报告](#17.8)
- [17.9 用包管理器记录依赖](#17.9)
- [17.9.1 macOS 包管理](#17.9.1)
- [17.9.2 Windows 与 Linux 子系统](#17.9.2)
- [17.9.3 Spack 的依赖规格](#17.9.3)
- [17.10 用模块切换工具链](#17.10)
- [17.10.1 Tcl Environment Modules](#17.10.1)
- [17.10.2 Lua 实现 Lmod](#17.10.2)
- [17.11 反思与练习](#17.11)

<a id="17-intro"></a>
## 第 17 章导读｜改善代码的工具与资源
原书 p.579–581。

**Source:** 原书 p.579 / PDF p.615

**Original:** From version control systems to debugging, the available capabilities, whether commercial or open source, are essential to enable the rapid iterations of parallel application development.

**中文:** 从版本控制到调试，无论商业工具还是开源工具，它们提供的能力都支持并行应用开发中的快速迭代。

### 用一次改动串起全章

若修改了一个 MPI 网格循环，可以先用 Git 标记基线，再保存正确结果、定时范围和运行参数。结果出错时查内存与竞争，速度下降时查热点与 I/O，最后把编译器、MPI 和依赖的版本一起记入复现说明。表 17.1 是全章按任务组织的工具导航。


<a id="17.1"></a>
## 17.1 用版本控制保存可复现的基线
原书 p.582–583。

**Source:** 原书 p.582 / PDF p.618

**Original:** Version control for software is one of the most basic of software engineering practices and critically important when developing parallel applications.

**中文:** 版本控制是软件工程的基础实践，对并行程序开发尤其重要。

### 图 17.1
原书 p.582 / PDF p.618。

![图 17.1](assets/fig17_1.png)

Selecting a type of version control is dependent on your work pattern. Centralized  version control is for when everyone is at a location with access to a single server. Distributed version control gives you a full copy of your repository on your laptop and desktop and allows you to go worldwide and mobile.

集中式仓库与分布式仓库的工作流程。

左侧工作副本连接中心仓库，右侧克隆保有项目历史。两者都可以承担团队协作，差别主要在本地可完成的历史操作和同步方式。

**代码出处：** Shell · 检查未提交改动并取得本次测量对应的源代码版本

```text
git status --short
git diff
git rev-parse HEAD
```


<a id="17.1.1"></a>
## 17.1.1 分布式版本控制
原书 p.582–583。

### 在计算节点之外工作

Git、Mercurial 的完整克隆通常包含可本地查询的提交历史。离线时仍可比较版本、提交和分支，恢复连接后再同步。记录运行版本时还要说明工作区是否有未提交的补丁，否则同一提交号仍可能产生不同结果。


<a id="17.1.2"></a>
## 17.1.2 集中式仓库
原书 p.583。

**Source:** 原书 p.582 / PDF p.618

**Original:** In a centralized version control system there is just one central repository.

**中文:** 集中式版本控制系统只有一个中央仓库。

### 谁保存权威历史

Subversion 的中心仓库接受提交并为修订编号，工作副本保留本地修改。集中管理有利于统一备份和访问控制，分布式仓库也可通过受控远端实施权限。选择时看网络条件、协作与备份方式。原书表 17.1 中两小节的编号顺序与正文不同，本讲义按正文编号。


<a id="17.2"></a>
## 17.2 用单调时钟计量时间
原书 p.583–585。

### 先决定要测什么

测量一个迭代阶段经过了多久，适合用单调时钟；统计程序用了多少 CPU 时间则有另一套接口。主机提交 GPU 工作后立即停表，只测到了提交开销。MPI 中按进程计算各自时间差，再归约最大值，可以观察最慢的参与者。

**代码出处：** C · 清单 17.1–17.2 的秒数换算，字段同属一个时钟

```text
#include <time.h>
// 假定已使用 clock_gettime(CLOCK_MONOTONIC, ...) 取得两次成功读数
double elapsed(struct timespec start, struct timespec stop) {
    return (double)(stop.tv_sec - start.tv_sec)
         + (double)(stop.tv_nsec - start.tv_nsec) * 1e-9;
}
```

### 跨秒的例子

从 8 秒 900000000 纳秒到 9 秒 100000000 纳秒，秒差为 1，纳秒差为负 800000000，合计 0.2 秒。CLOCK_REALTIME 会受到系统校时影响。C++ 中测经过时间可使用 std::chrono::steady_clock。


<a id="17.3"></a>
## 17.3 从测量问题选择剖析器
原书 p.585–590。

**Source:** 原书 p.585 / PDF p.621

**Original:** A profiler is a programmer tool that measures some aspect of the performance of an application.

**中文:** 剖析器是用来测量应用程序某一方面性能的编程工具。

**Source:** 原书 p.585 / PDF p.621

**Original:** A profiler is a programmer tool that measures some aspect of the performance of an application.

**中文:** 剖析器是供程序员测量应用某一方面性能的工具。

### 由外而内

表 17.2 把工具分成文本摘要、全程序概览、面向优化的指标和详细硬件分析。先问时间花在哪个阶段，再定位函数、源码行和事件。若程序在等文件系统，只收集浮点指令数通常解释不了总时间。


<a id="17.3.1"></a>
## 17.3.1 日常使用的文本报告
原书 p.586–587。

**代码出处：** Shell · 在相应 GNU 环境中读取使用 -pg 编译、链接和运行后生成的采样文件

```text
gprof ./solver gmon.out
```

### 读一份短报告

LIKWID 可针对核心与性能事件组计数，gprof 提供采样和调用统计，gperftools、timemory 也提供轻量入口。保留输入规模与线程绑定，再比较两次运行。不同工具的采样周期和统计分母可能不同。


<a id="17.3.2"></a>
## 17.3.2 全程序概览与调用路径
原书 p.587–588。

**Source:** 原书 p.587 / PDF p.623

**Original:** High-level tools are the best choice for a quick overview of the performance of your application.

**中文:** 作者建议，要快速浏览应用整体的性能表现，可以从全局概览工具入手。

### 从包含成本追到自身成本

一个求解函数可能因调用昂贵的矩阵乘法而位居首位。沿调用链继续向下，区分函数自身成本与包含子调用的成本。KCachegrind 是报告查看器；Cachegrind 可模拟缓存行为，Callgrind 提供调用关系。原书也用 MAP 说明如何观察多进程的不平衡。


<a id="17.3.3"></a>
## 17.3.3 用中等粒度的指标选择优化方向
原书 p.588–590。

**Source:** 原书 p.588 / PDF p.624

**Original:** Medium-level profilers are often used when trying to fine-tune optimizations.

**中文:** 对已有优化进一步微调时，常常需要中等粒度的剖析工具。

### 建立可检查的假设

原书举出 Advisor、CrayPat、AMD µProf，以及 GPU 时间线工具。若某循环带宽接近同机 STREAM 实测上限，先问能否复用数据；若向量化报告指出循环依赖，先验证这些依赖来自真实读写还是指针别名。历史安装命令与软件名称需匹配实际环境。


<a id="17.3.4"></a>
## 17.3.4 深入硬件事件
原书 p.590。

**Source:** 原书 p.590 / PDF p.626

**Original:** The challenge with these tools is that they produce so much information, it can be time-consuming to understand and use the results.

**中文:** 这些工具的难点在于输出的信息量很大，理解和利用结果也需要时间。

### 选择一个可解释的区间

HPCToolkit、TAU 与 Open|SpeedShop 把调用上下文、采样或硬件事件联系起来。若要解释线程等待，先限定相同迭代区间，再看哪些调用路径上的等待增加。计数器复用、采样误差与采集开销都会影响结论。


<a id="17.4"></a>
## 17.4 微基准与小型应用
原书 p.591–594。

**Source:** 原书 p.591 / PDF p.627

**Original:** Benchmarks are more appropriate for measuring the performance of a system. Mini-apps are more focused on application areas and how best to implement the algorithms for various architectures, but the difference between these can be blurred at times.

**中文:** 基准程序更适于测量系统性能。小型应用更关注具体应用领域，以及怎样为不同架构实现算法；两者的边界有时并不清晰。


<a id="17.4.1"></a>
## 17.4.1 给本机建立可参照的上限
原书 p.591。

### 给测量结果一个背景

在相同 NUMA 放置和数据规模下，STREAM 给出简单数组循环的带宽参照。其他基准覆盖通信或求解器等负载。先统一精度、工作量与计时范围，再判断应用距离这个参照还有多少改进空间。


<a id="17.4.2"></a>
## 17.4.2 从 mini-app 学习实现
原书 p.591–594。

### 找与真实算法相似的例子

LULESH 体现非结构网格流体力学，CloverLeaf 采用笛卡尔网格，miniGhost 关注幽灵层交换，miniFE 代表有限元稀疏问题。观察它们的访问顺序、通信体积与并行粒度，再核对真实程序是否具有相同特征。

### 怎样使用代理程序

保存运行用例和参考结果，改变一个实现因素，再用真实应用的一段代表性输入复核。原书列出的 DOE 代理应用与 Mantevo 资源，适合用来建立这样一组可重复的小实验。


<a id="17.5"></a>
## 17.5 区分越界、泄漏和未初始化读取
原书 p.594。

**Source:** 原书 p.594 / PDF p.630

**Original:** For robust applications, you need a tool to detect and report memory errors.

**中文:** 为了让应用可靠运行，需要工具来检测并报告内存错误。

### 三种问题的证据不同

访问数组末尾以外的地址是越界；失去最后一个可达指针可能造成泄漏；读取没有赋值的元素属于未初始化读取。一个程序能输出合理数字，仍可能同时包含这三类缺陷。


<a id="17.5.1"></a>
## 17.5.1 Valgrind Memcheck
原书 p.594–595。

**代码出处：** Shell · 在受支持平台上收集泄漏与未初始化值来源

```text
valgrind --leak-check=full --track-origins=yes ./example
```

### 先处理第一条可解释的错误

带调试符号构建，选能触发故障的小输入。优先追查较早的非法访问，再看退出时的泄漏摘要。报告中仍可达的内存、直接泄漏和间接泄漏含义不同。


<a id="17.5.2"></a>
## 17.5.2 用 Dr. Memory 检查二维分配
原书 p.595–597。

### 图 17.2
原书 p.596 / PDF p.632。

![图 17.2](assets/fig17_2.png)

Report from Dr. Memory shows that an uninitialized read at line 11 and a memory leak for memory  allocated at line 8. ~~Dr.M~~ Dr. Memory version 2.3.0 ~~Dr.M~~ ~~Dr.M~~ NO ERRORS FOUND: ~~Dr.M~~ 0 unique, 0 total unaddressable access(es) ~~Dr.M~~ 0 unique, 0 total uninitialized access(es) ~~Dr.M~~ 0 unique, 0 total invalid heap argument(s) ~~Dr.M~~ 0 unique, 0 total warning(s) ~~Dr.M~~ 0 unique, 0 total, 0 byte(s) of leak(s) ~~Dr.M~~ 0 unique, 0 total, 0 byte(s) of possible leak(s) ~~Dr.M~~ ERRORS IGNORED: ~~Dr.M~~ 24 unique, 46 total,  14053 byte(s) of still-reachable allocation(s) ~~Dr.M~~ (re-run with "-show_reachable" for details) ~~Dr.M~~ Details: Chapter17/DrMemory/DrMemory-Linux-2.3.0-1/drmemory/logs/DrMemory-memoryexample.147746.000/results.txt No errors reported! Figure 17.3 This Dr. Memory report shows that the uninitialized memory error and the leak are fixed.

Dr. Memory 报出未初始化读取，并指出分配发生的位置。

检查行数 jmax 和列数 imax 是否都在用于计算尺寸前赋值。栈信息给出错误触发点和分配点，两者可能隔着多个函数。

### 图 17.3
原书 p.596 / PDF p.632。

![图 17.3](assets/fig17_3.png)

This Dr. Memory report shows that the uninitialized memory error and the leak are fixed.

修正后同一输入下的 Dr. Memory 报告。

此路径未再报错。原书提醒 imax 在第一次运行中并未被工具点名，说明读报告后仍需审查输入和其他执行路径。

**代码出处：** C · 清单 17.3 的释放顺序；分配失败时只清理此前成功的行

```text
// rows、cols 已验证，x 的每一行都已分别成功分配
for (size_t j = 0; j < rows; ++j) free(x[j]);
free(x);
```

### 为什么先释放行

x 保存行指针。先释放 x 会失去找到各行数据的途径；只释放各行则会漏掉指针表。若采用一次连续分配的数据布局，需要按实际所有权设计释放顺序。


<a id="17.5.3"></a>
## 17.5.3 商业内存检测工具
原书 p.597。

### 按程序依赖选择

原书以 Purify 和 Insure++ 为例。评估工具时看它能否覆盖编译器、库、线程模型和出错输入；可复现的错误与有源码行号的调用栈比工具品类更有助于修复。产品描述保留出版语境。


<a id="17.5.4"></a>
## 17.5.4 编译器插桩
原书 p.597。

**代码出处：** Shell · AddressSanitizer 教学编译命令，依赖兼容的编译器与运行库

```text
clang -g -O1 -fsanitize=address -fno-omit-frame-pointer example.c -o example
```

### 按缺陷选择检测器

AddressSanitizer 检测多类地址错误，MemorySanitizer 面向未初始化值使用，ThreadSanitizer 面向数据竞争。应给相关编译及链接目标配置相应选项，再运行覆盖故障路径的输入。插桩后的时间不作为优化版的基准。


<a id="17.5.5"></a>
## 17.5.5 用边界哨兵定位覆盖
原书 p.597–599。

**Source:** 原书 p.597 / PDF p.633

**Original:** Several tools place blocks of memory before and after memory allocations to detect out-of-bounds memory accesses and to also track memory leaks.

**中文:** 有些工具在分配区前后布置额外的内存块，以检测越界访问，同时追踪内存泄漏。

### 图 17.4
原书 p.599 / PDF p.635。

![图 17.4](assets/fig17_4.png)

The dmalloc log file shows an out-of-bounds memory access at line 11.

dmalloc 日志指出分配边界附近的写入破坏了保护区域。

分配 N 个元素时，最后一个有效下标是 N−1。若在后续检查或 free 时才发现哨兵变化，应回溯前面的写入循环。

**代码出处：** C · 半开索引区间；i<=n 会多写一项

```text
for (size_t i=0; i<n; ++i) x[i]=0.0;
```

### 为什么有些错误稍后才显现

保护页可能在访问时立即触发异常，哨兵字节则可能在检查分配块时才被发现。这些技术针对不同布局和边界，越界仍落在可访问页面中时也可能继续运行。

### 清单 17.4 的分配大小

原书按 imax*sizeof(double *) 分配 double 数组，循环又用 jmax 作上限。应采用与元素匹配的 sizeof *x，并让分配长度和写入上限使用同一个已经验证的值。指针和 double 在某些平台上恰好同宽，不能依靠这个巧合。


<a id="17.5.6"></a>
## 17.5.6 GPU 内存诊断
原书 p.599。

### 把报告关联到具体 kernel

原书讨论 CUDA-MEMCHECK。对支持 NVIDIA Compute Sanitizer 的环境，可从 memcheck 检查设备访问，再选 racecheck 等适用工具。保留设备行信息与小网格输入，并在同步点检查执行错误。

**代码出处：** Shell · CUDA 示例诊断命令，需适配的设备、运行时与可执行程序

```text
compute-sanitizer --tool memcheck ./solver
```


<a id="17.6"></a>
## 17.6 检测线程间的数据竞争
原书 p.599–601。

**Source:** 原书 p.599 / PDF p.635

**Original:** Tools to detect thread race conditions (also called data hazards) are critical in developing OpenMP applications.

**中文:** 检测线程竞争的工具在开发 OpenMP 应用时十分重要。

### 写入者与读者必须有顺序

当两个线程访问同一存储位置、至少一方写入，且缺乏所需同步时，会发生数据竞争。输出有时正确也不提供顺序保证。调查时先找两条访问路径，再找本应连接它们的同步关系。


<a id="17.6.1"></a>
## 17.6.1 阅读 Intel Inspector 的报告
原书 p.600。

### 历史界面的阅读方法

从第 7 章的报告选一对冲突访问，分别确认线程、内存位置与源码栈，再决定变量应当私有、按区分工还是用归约。Inspector 的当前生命周期可查资源页 R33；原书软件仓库安装步骤属于历史资料。


<a id="17.6.2"></a>
## 17.6.2 Archer 与 OpenMP 同步
原书 p.600–601。

### 图 17.5
原书 p.601 / PDF p.637。

![图 17.5](assets/fig17_5.png)

Output from the Archer data race detection tool

Archer 报告列出可能冲突的访问及线程建立路径。

工具需要理解 OpenMP 的同步机制。运行库内部栈帧也要调查，不凭“发生在启动时”就把一条报告归为误报。

### 构建系统与运行库要配套

清单 17.5 展示 clang-archer 与 Archer 库的旧构建方式。设置普通 CMake 变量 CC 并不自动替换已经选定的 C 编译器。独立构建目录、相容的 OpenMP 运行库和正确调试符号都有助于复现。


<a id="17.7"></a>
## 17.7 并行调试器
原书 p.602–604。

**Source:** 原书 p.602 / PDF p.638

**Original:** Parallel programmers also need additional capabilities targeted at dealing with multiple processes and threads.

**中文:** 并行程序员还需要专门处理多进程、多线程的调试能力。

### 先缩小最早出现差异的范围

对比串行与并行结果，定位最早出现差异的迭代和 rank，观察该时刻的调用栈、缓冲区、邻居号和请求句柄。程序挂起时，所有进程的等待位置通常比单一进程的栈更有信息。


<a id="17.7.1"></a>
## 17.7.1 TotalView
原书 p.602。

### 多个进程同时看

并行调试器可按进程或线程组切换观察对象。以 MPI 收发卡住为例，先找一组停在接收的 rank，再核对对端是否发出了匹配的标签和通信器。断点本身会扰动时序，应保存可复现输入。


<a id="17.7.2"></a>
## 17.7.2 DDT
原书 p.602–603。

### 从异常 rank 回看正常 rank

原书以 DDT 展示 HPC 站点常见的图形化调试工作流。把出错 rank 的局部数组区间、幽灵层与相邻 rank 对照，往往比逐进程翻页更快。实际启动器参数取决于站点的作业调度与安装。


<a id="17.7.3"></a>
## 17.7.3 本地 Linux 调试工具
原书 p.603。

**代码出处：** GDB · --args 之后是被调试程序及其参数

```text
gdb --args ./solver input.dat
# 进入 gdb 后逐条输入
break main
run
backtrace
info threads
```

### 从一处断点开始

break 设置暂停位置，run 在调试器中启动程序，backtrace 打印当前栈，info threads 列出当前进程的线程。普通单进程 GDB 会话只观察它所控制的目标。


<a id="17.7.4"></a>
## 17.7.4 设备端调试
原书 p.603–604。

### 索引错误要看设备上下文

CUDA-GDB 与 ROCgdb 面向各自工具链。核对选中的 kernel、线程块和局部线程，再打印全局索引与数组边界。调试编译和断点会改变优化与时序，因此应另行测量正常发布构建。


<a id="17.8"></a>
## 17.8 用 Darshan 读并行 I/O 报告
原书 p.604–607。

### 图 17.6
原书 p.606 / PDF p.642。

![图 17.6](assets/fig17_6.png)

The graphs are part of the output from the Darshan I/O characterization tool. Both the standard  IO (POSIX) and MPI-IO are shown. From the graph on the upper right, we can confirm that MPI-IO used collective rather than independent operations.

Darshan 报告将 POSIX 与 MPI-IO 的访问次数、操作类型和尺寸分布并列。

上部图中可辨认 collective 与 independent 的调用次数。应用层的 collective 写可能在下层产生多次 POSIX 操作，两层统计不能简单相加当作总数据量。

**代码出处：** Shell · 对已经采集的日志做文本解析，具体命令依安装版本

```text
darshan-parser job.darshan
```

### 给每个计数找分母

先确认进程数、文件、数据集尺寸和读写范围。比较 I/O 总字节、请求大小、元数据时间和最慢进程。原书用家目录的 NFS 做实验，不能把该图直接解释为所有并行文件系统的表现。


<a id="17.9"></a>
## 17.9 用包管理器记录依赖
原书 p.607–609。

### 构建可复现的环境

同一份源代码在不同编译器、MPI 或数学库下可能产生不同结果。包管理器帮助选择依赖和版本，再配合源代码版本、构建参数及运行时模块记录，才能还原一次实验。


<a id="17.9.1"></a>
## 17.9.1 macOS 包管理
原书 p.607–608。

### Homebrew 与 MacPorts

两者按各自前缀组织工具与库。若程序能编译但运行时找不到动态库，应核对编译所用的头文件和实际加载的库来自哪个安装前缀，并记录 CPU 架构。


<a id="17.9.2"></a>
## 17.9.2 Windows 与 Linux 子系统
原书 p.608。

### 明确二进制的运行环境

Windows 原生工具链和 WSL 的 Linux 程序使用不同的路径、库与运行时。保存实验记录时写明命令在哪一边执行。GPU 工具还需验证该环境确实能访问目标设备。


<a id="17.9.3"></a>
## 17.9.3 Spack 的依赖规格
原书 p.608–609。

**Source:** 原书 p.609 / PDF p.645

**Original:** You’ll find many Spack commands. Table 17.3 provides a few to get you started.

**中文:** Spack 提供许多命令，表 17.3 选了几条作为入门。

**代码出处：** Shell · spec 展示依赖解析方案，+mpi 启用相应变体，find 检查已安装实例

```text
spack spec hdf5+mpi
spack find hdf5
```

### 包名相同可能是不同构建

HDF5 是否带并行支持、链接哪种 MPI、由哪个编译器生成，都会影响应用。对照依赖树与实际加载的库，再解释“能找到 HDF5 但并行接口不可用”一类错误。


<a id="17.10"></a>
## 17.10 用模块切换工具链
原书 p.609–611。

**Source:** 原书 p.611 / PDF p.647

**Original:** Set the same modules for compiling and running your code. If the path to the library changes, your code may crash or give you the wrong results.

**中文:** 编译和运行时应加载一致的模块。库路径一旦改变，程序可能崩溃，也可能产生错误结果。

**代码出处：** Shell · 查可见模块、已加载模块及一个模块将修改的环境，名称依站点而异

```text
module avail
module list
module show gcc
```

### 把环境写进作业记录

模块可修改 PATH、库路径与编译器相关变量。保存 module list 的输出，并在提交脚本中使用明确的版本。交互 shell 与批作业的启动文件可能不同，要在作业里确认最终环境。


<a id="17.10.1"></a>
## 17.10.1 Tcl Environment Modules
原书 p.612。

### 读懂一次环境变更

Tcl modulefile 可通过 prepend-path 把某个 bin 目录放到 PATH 前面，setenv 设置环境变量。module load 更改当前 shell 的可见工具链。检查 module show 和编译器版本，能够定位同名命令被不同目录遮蔽的问题。


<a id="17.10.2"></a>
## 17.10.2 Lua 实现 Lmod
原书 p.612。

### 从编译器到 MPI 的层次

Lmod 可按编译器与 MPI 组织层次模块，切换底层工具链会改变可见的软件集合。使用 module spider 探索站点的软件与前置条件，并以 module list 核对当前状态。


<a id="17.11"></a>
## 17.11 反思与练习
原书 p.612–613。

**Source:** 原书 p.612 / PDF p.648

**Original:** Instead, you should look at what the tool does and how easy it is to use.

**中文:** 应当看这个工具能解决什么问题，以及使用它需要多少工夫。

**Source:** 原书 p.613 / PDF p.649

**Original:** Measuring performance is the first step towards improving application performance.

**中文:** 测量性能是改进应用性能的第一步。

### 练习 1–3

用一个有确定预期输出的小程序验证未初始化读取或越界报告，再分别修正和复跑。线程实验可在独立示例中对共享累加与 reduction 写法进行比较，记录触发竞争的两处访问。

### 练习 4–5

对同一 MPI-I/O 程序改变数据规模与文件系统，用 Darshan 核对请求数、总字节和总时长；再用 Spack 查询所需工具的依赖规格。把日志与修正前后的提交号放在一起，构成可复查的一次开发记录。


## 技术参考

[官方参考文档](https://www.mcs.anl.gov/research/projects/darshan/)