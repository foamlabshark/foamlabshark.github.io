#include <stdio.h>
#include <omp.h>

int main(void) {
    printf("Before parallel: %d thread\n", omp_get_num_threads());
    #pragma omp parallel
    {
        int nt = omp_get_num_threads();
        int tid = omp_get_thread_num();
        printf("thread %d of %d\n", tid, nt);
    }
    return 0;
}
