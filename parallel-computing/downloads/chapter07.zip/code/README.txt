第 7 章代码与模型

hello_openmp.c、pairwise_tasks.c 是完整教学 C 程序；当前环境未找到 gcc/clang/cl，因此没有编译或执行 OpenMP。
在已配置 GCC OpenMP 的 POSIX 环境可用：
gcc -O2 -fopenmp hello_openmp.c -o hello_openmp
gcc -O2 -fopenmp pairwise_tasks.c -o pairwise_tasks
OMP_NUM_THREADS=4 ./hello_openmp
OMP_NUM_THREADS=4 ./pairwise_tasks
第二个程序示例期望 sum = 15。
Windows 的编译和链接选项取决于实际工具链；PowerShell 设置环境变量用 $env:OMP_NUM_THREADS = "4"。
commands_and_fragments.txt 是讲义片段集合，不是整份可执行脚本。

thread_models.py 使用 Python 标准库，已运行通过 1040 组 N/P 分区、原书与教学版扫描、求和检查，另有多步 stencil 固定边界与 Kahan 误差案例。
原书扫描在本模型覆盖的空输入、空分块、不整除情形正确，不能把这些情形误报为原书越界。
原书任务成对求和对 [1,2,3,4,5] 得到 12，修正后为 15，验证了奇数长度漏项。
模型串行模拟阶段顺序，不是并发执行、数据竞争检测或硬件性能基准。
