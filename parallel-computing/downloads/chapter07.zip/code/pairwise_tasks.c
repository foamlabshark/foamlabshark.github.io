#include <stdio.h>
#include <omp.h>
static double pair_task(const double *a, long lo, long hi) {
    long n = hi - lo;
    if (n == 0) return 0.0;
    if (n == 1) return a[lo];
    long mid = lo + n / 2;
    double left, right;
    #pragma omp task shared(left) firstprivate(a,lo,mid) if(n > 1024)
    { left = pair_task(a, lo, mid); }
    #pragma omp task shared(right) firstprivate(a,mid,hi) if(n > 1024)
    { right = pair_task(a, mid, hi); }
    #pragma omp taskwait
    return left + right;
}

int main(void) {
    const double data[] = {1,2,3,4,5};
    double sum = 0.0;
    #pragma omp parallel shared(sum,data)
    {
        #pragma omp single
        { sum = pair_task(data,0,5); }
    }
    printf("sum = %g (expected 15)\n", sum);
    return sum == 15.0 ? 0 : 1;
}
