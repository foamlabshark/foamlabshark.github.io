"""Chapter 7 serial teaching models. No OpenMP runtime or hardware benchmark."""
from math import fsum, isclose
from random import Random

def bounds(n, p):
    if type(n) is not int or type(p) is not int or n < 0 or p < 1:
        raise ValueError('n >= 0 and p >= 1 must be integers')
    return [(n*t//p, n*(t+1)//p) for t in range(p)]

def scan(a, p):
    out = [0]*len(a); totals=[]
    for b,e in bounds(len(a),p):
        s=0
        for i in range(b,e): out[i],s=s,s+a[i]
        totals.append(s)
    offset=0
    for (b,e),total in zip(bounds(len(a),p),totals):
        for i in range(b,e):out[i]+=offset
        offset+=total
    return out

def printed_scan(a,p):
    """Original listing 7.22 index operations, to check the source algorithm including empty blocks."""
    n=len(a);out=[0]*n
    for b,e in bounds(n,p):
        if b<e:
            out[b]=0
            for i in range(b+1,e):out[i]=out[i-1]+a[i-1]
    if p==1:return out
    for t in range(1,p):
        b=n*(t-1)//p;e=n*t//p
        if b<e:out[e]=out[b]+a[e-1]
        if b<e-1:out[e]+=out[e-1]
    for b,e in bounds(n,p):
        for i in range(b+1,e):out[i]+=out[b]
    return out

def pairwise(a,lo=0,hi=None):
    if hi is None:hi=len(a)
    if hi==lo:return 0
    if hi-lo==1:return a[lo]
    mid=lo+(hi-lo)//2
    return pairwise(a,lo,mid)+pairwise(a,mid,hi)

def printed_pairwise(a,lo,hi):
    if hi-lo==1:return a[lo]
    half=(hi-lo)//2
    return printed_pairwise(a,lo,lo+half)+printed_pairwise(a,hi-half,hi)

def kahan_state(a):
    s=c=0.0
    for v in a:
        corrected=v+c;new=s+corrected
        c=corrected-(new-s);s=new
    return s,c

def kahan_blocked(a,p):
    parts=[kahan_state(a[b:e]) for b,e in bounds(len(a),p)]
    s,c=kahan_state([x for part in parts for x in part])
    return s+c

def stencil(a,steps,p):
    """Synchronous phases; fixed edges copied to both buffers."""
    rows=len(a);cols=len(a[0]);old=[r[:] for r in a];new=[r[:] for r in a]
    for _ in range(steps):
        for b,e in bounds(rows-2,p):
            for j in range(1+b,1+e):
                for i in range(1,cols-1):
                    new[j][i]=(old[j][i]+old[j][i-1]+old[j][i+1]+old[j-1][i]+old[j+1][i])/5
        old,new=new,old
    return old

def check():
    rng=Random(7);cases=0
    for n in range(65):
        for p in range(1,17):
            bs=bounds(n,p)
            assert [i for b,e in bs for i in range(b,e)]==list(range(n))
            sizes=[e-b for b,e in bs]
            assert max(sizes)-min(sizes)<=1
            a=[rng.randrange(-7,12) for _ in range(n)]
            expected=[sum(a[:i]) for i in range(n)]
            assert scan(a,p)==expected
            assert printed_scan(a,p)==expected
            assert pairwise(a)==sum(a)
            assert kahan_blocked(a,p)==fsum(a)
            cases+=1
    # Confirm the odd-length defect in the printed recursive task algorithm.
    assert printed_pairwise([1,2,3,4,5],0,5)==12
    assert pairwise([1,2,3,4,5])==15
    a=[1e16]+[1.0]*10000+[-1e16]
    s,c=kahan_state(a)
    assert s+c==fsum(a)==10000.0
    grid=[[float(j*7+i) for i in range(7)] for j in range(6)]
    for steps in [0,1,2,7]:
        expected=stencil(grid,steps,1)
        for p in [1,2,3,4,8,16]:
            result=stencil(grid,steps,p)
            assert result==expected
            assert result[0]==grid[0] and result[-1]==grid[-1]
            assert all(result[j][0]==grid[j][0] and result[j][-1]==grid[j][-1] for j in range(6))
    for args in [(-1,4),(2,0),(1.5,2),(2,True)]:
        try:bounds(*args)
        except ValueError:pass
        else:raise AssertionError(args)
    print(f'{cases} partition/scan/sum cases passed; stencil phases and original scan and odd-task defect verified.')
    print('Serial models only: no OpenMP concurrency, race-detector, or performance validation.')

if __name__=='__main__':check()
