# 第 7 章｜写出高效的 OpenMP 程序

原著：Robert Robey、Yuliana Zamora，Manning，2021。原书 p.207–252 / PDF p.243–288。

采用核心段落中英对照与全部编号小节讲解，保留 16 幅原图和 2 张原表。不是逐段全文译本。代码修正与教学补充明确标记。

## 小节索引

- [第 7 章导读｜写出高效的 OpenMP 程序](#7-intro)
- [7.1 OpenMP 简介](#7.1)
- [7.1.1 线程、内存与竞争条件](#7.1.1)
- [7.1.1（续）NUMA 与首次触碰](#7.1.1-numa)
- [7.1.2 从 Hello World 建立线程团队](#7.1.2)
- [7.1.2（续）为什么线程编号会打印错](#7.1.2-race)
- [7.1.2（续）single、masked 与屏障](#7.1.2-single)
- [7.2 三种使用路线](#7.2)
- [7.2.1 循环级 OpenMP：快速开始](#7.2.1)
- [7.2.2 高层次 OpenMP：扩大并行区域](#7.2.2)
- [7.2.3 MPI 加 OpenMP：分层并行](#7.2.3)
- [7.3 标准循环级 OpenMP](#7.3)
- [7.3.1 向量加法与并行初始化](#7.3.1)
- [7.3.2 STREAM Triad 与计时](#7.3.2)
- [7.3.3 五点 stencil：双缓冲与边界](#7.3.3)
- [7.3.4 怎样读取速度提升与效率](#7.3.4)
- [7.3.5 reduction：全局求和](#7.3.5)
- [7.3.6 哪些循环能分工](#7.3.6)
- [7.4 变量作用域与数据共享属性](#7.4)
- [7.5 函数级 OpenMP：指针与所指对象](#7.5)
- [7.5（续）Fortran 的 SAVE 与局部对象](#7.5-fortran)
- [7.6 高层次 OpenMP 的目标](#7.6)
- [7.6.1 四步改造过程](#7.6.1)
- [7.6.1（续）手工计算线程区间](#7.6.1-bounds)
- [7.6.2 合并 stencil 的并行区域](#7.6.2)
- [7.7 OpenMP 线程与 SIMD 混合](#7.7)
- [7.8 进阶示例：依赖决定结构](#7.8)
- [7.8.1 分方向 stencil 与面数据](#7.8.1)
- [7.8.2 线程化 Kahan 补偿求和](#7.8.2)
- [7.8.3 分块前缀扫描](#7.8.3)
- [7.9 用工具检查正确性与性能](#7.9)
- [7.9.1 从剖析图找线程开销](#7.9.1)
- [7.9.2 数据竞争检测与回归测试](#7.9.2)
- [7.10 基于任务的成对求和](#7.10)
- [7.10（续）任务粒度与可复现性](#7.10-granularity)
- [7.11 延伸探索与本章小结](#7.11)
- [7.11.1 延伸阅读](#7.11.1)
- [7.11.2 练习与参考思路](#7.11.2)

## 公式索引

- [E001](#E001) · 原书 p.226 · Sₚ = T₁ / Tₚ；Eₚ = Sₚ / p
- [E002](#E002) · 原书 p.234 · bₜ = floor(Nt/P)，eₜ = floor(N(t+1)/P)
- [E003](#E003) · 原书 p.241 · Xⱼ,ᵢ₊½ = (aⱼ,ᵢ₊₁+aⱼ,ᵢ)/2；Yⱼ₊½,ᵢ = (aⱼ₊₁,ᵢ+aⱼ,ᵢ)/2
- [E004](#E004) · 原书 p.247 · Tₚ ≈ 2αN/P + βP + T_sync

## 术语约定

|原文|译法|说明|
|---|---|---|
|thread team|线程团队|执行一个并行区域的一组线程|
|worksharing|工作共享|将工作分配给现有团队|
|data race|数据竞争|未适当排序的冲突访问|
|barrier|屏障|团队的同步点|
|first touch|首次触碰|常见内存策略下首次实际访问影响页面位置|
|NUMA|非统一内存访问|不同区域的访问成本不同|
|shared|共享|引用共同对象|
|private|私有|每个执行上下文使用副本|
|firstprivate|初值私有|为私有副本复制进入时的值|
|lastprivate|末值回写|按逻辑最后迭代等规则回写|
|nowait|不等待|移除相应构造的结束同步|
|masked|掩选执行|由选定线程执行关联块|
|task|任务|交由团队调度的工作单元|
|taskwait|任务等待|等待规定的子任务完成|
|granularity|粒度|每个并行工作单元的工作量|
|exclusive scan|排他前缀扫描|每项保存它之前的累计量|

<a id="7-intro"></a>
## 第 7 章导读｜写出高效的 OpenMP 程序
原书 p.207–208。

<a id="S001"></a>
**Source:** 原书 p.208 / PDF p.244 · S001

**Original:** We show that high-level OpenMP is efficient for algorithms containing many short loops of computational work.

**中文:** 本章将说明：对于包含许多短计算循环的算法，高层次 OpenMP 组织方式可以提高效率。

<a id="N001"></a>
### 本章要解决什么

**讲解：** 第 6 章把一条指令用于多个数据元素；这一章把工作交给多个线程。先做对，再确认线程启动、等待、内存带宽和 NUMA 位置各占多少时间，最后决定是否扩大并行区域。

<a id="N002"></a>
### 阅读路线

**讲解：** 保留 7.1–7.11 及全部编号子小节。基础部分从 Hello World、变量作用域和循环分工开始；进阶部分讲持久并行区域、stencil、补偿求和、前缀扫描与任务递归。长小节拆成续页，原书页码一直保留。

<a id="N003"></a>
### 代码标注方式

**讲解：** “原书整理”保留算法结构并去除排版注释；“教学修正版”明确指出修改理由。原书实验数字只是历史案例，本讲义没有把模型测试称作真实 OpenMP 并发测试。


<a id="7.1"></a>
## 7.1 OpenMP 简介
原书 p.208。

<a id="S002"></a>
**Source:** 原书 p.208 / PDF p.244 · S002

**Original:** OpenMP is one of the most widely supported open standards for threads and shared-memory parallel programming.

**中文:** OpenMP 是获得广泛支持的线程与共享内存并行编程开放标准之一。

<a id="N004"></a>
### pragma、directive 与运行库

**讲解：** C/C++ 通常用 #pragma omp ... 告诉编译器如何组织并行；Fortran 用 !\$omp ... 指令。omp_get_thread_num 等是运行库函数，需要正确头文件或模块及链接配置。指令、库函数、环境变量共同构成使用方式。

<a id="F001"></a>
### 图 7.1
**Source:** 原书 p.209 / PDF p.245 · C001
**Placed near:** 7.1 OpenMP 简介

![图 7.1](assets/fig7_1.png)

**Original caption:** Conceptual visualization of the programming effort required to improve performance using either MPI or OpenMP

**中文图注:** MPI 与 OpenMP 的编程投入和性能收益概念图。

**Reading note:** 曲线没有量化坐标，也不是基准结果。不能据此断言 MPI 必然快于 OpenMP；问题规模、数据分布和机器结构决定合适的组合。

<a id="N005"></a>
### 这章的边界

**讲解：** 这里讨论 CPU 共享内存线程。OpenMP 标准还包含 SIMD 和设备卸载，不应把整个 OpenMP 等同于“只支持 CPU 单节点”。跨节点的 MPI 与线程组合在第 8 章展开。


<a id="7.1.1"></a>
## 7.1.1 线程、内存与竞争条件
原书 p.208–210。

<a id="S003"></a>
**Source:** 原书 p.209 / PDF p.245 · S003

**Original:** Within a threaded parallel construct, each variable can be either shared or private.

**中文:** 在线程并行构造中，变量可能由线程共享，也可能为线程私有。

<a id="F002"></a>
### 图 7.2
**Source:** 原书 p.210 / PDF p.246 · C002
**Placed near:** 7.1.1 线程、内存与竞争条件

![图 7.2](assets/fig7_2.png)

**Original caption:** The threaded memory model helps with understanding which variables are shared and which are private. Each thread, shown by the squiggly lines, has its own instruction pointer, stack pointer, and stack memory but shares the heap and static memory data.

**中文图注:** 线程通常各有执行状态和栈，并共享进程的堆与静态数据区域。

**Reading note:** 这是帮助理解的内存布局图，不是 OpenMP 数据共享属性的完整判定规则。外部栈变量也可以共享；私有指针也可能指向同一个共享数组。

<a id="N006"></a>
### 共享不是“任意同时写都安全”

**讲解：** 两个线程无序地访问同一存储单元，且至少一个访问是写，就可能产生数据竞争。即使两个线程写入相同数值，也不能据此认定安全。原书将其解释成“最后写入者获胜”只是示意，不能当作有竞争程序的合法结果规则。[R27]

<a id="N007"></a>
### flush 不是冲洗整个硬件缓存

**讲解：** OpenMP 的 flush 描述内存视图和访问顺序的约束，不要求将所有缓存写回 DRAM，也不等同于硬盘刷新。单独添加 flush 不能修复所有竞争；必须建立符合程序依赖的同步关系。barrier 还要求团队线程汇合，atomic 和 critical 则有各自的同步范围。[R28]


<a id="7.1.1-numa"></a>
## 7.1.1（续）NUMA 与首次触碰
原书 p.209–210。

<a id="S004"></a>
**Source:** 原书 p.210 / PDF p.246 · S004

**Original:** On some computing nodes, blocks of memory are closer to some processors than others.

**中文:** 在某些计算节点上，一些内存块离某些处理器更近。

<a id="N008"></a>
### first touch 的含义

**讲解：** 在常见的按需分配、局部 NUMA 策略下，首次实际写入页面的线程会影响物理页落在哪个 NUMA 区域。它以页为单位，不是每个数组元素单独分配；只读访问、页面预先存在、交错策略、页迁移及大页都会影响结果。

<a id="N009"></a>
### 三件事一起考虑

**讲解：** 工作分配决定谁算哪些元素，线程绑定决定在哪个处理器执行，内存策略决定页面位置。并行初始化尽量匹配后续访问分区，但不能仅加一条 pragma 就保证局部内存。原书“远端约慢两倍”是机器相关经验。

<a id="N010"></a>
### 不是改变共享属性

**讲解：** 把页面放近线程不会让 shared 数组变成 private。NUMA 讨论访问成本；OpenMP 的共享属性讨论对象是否相同，二者必须分开。


<a id="7.1.2"></a>
## 7.1.2 从 Hello World 建立线程团队
原书 p.211–214。

<a id="F017"></a>
### 表 7.1
**Source:** 原书 p.211 / PDF p.247 · C017
**Placed near:** 7.1.2 从 Hello World 建立线程团队

![图 7.T1](assets/fig7_T1.png)

**Original caption:** Roadmap of OpenMP topics in this chapter

**中文图注:** 本章 OpenMP 构造与主题路线表。

**Reading note:** 保留原表，但表中 Fortran 的 #pragma do for 不是正确语法，应使用 !\$omp do 等指令；循环分工也不总是均分。critical 是互斥区域，atomic 保护受支持的特定存储操作，不宜都简单叫作锁。

<a id="K001"></a>
**代码出处：** C · 教学整理，对应清单 7.1–7.3，p.212–214；完整程序 hello_openmp.c

```text
#include <stdio.h>
#include <omp.h>

int main(void) {
    printf("Before parallel: %d thread\n", omp_get_num_threads());
    #pragma omp parallel
    {
        int nt = omp_get_num_threads();
        int tid = omp_get_thread_num();
        printf("thread %d of %d\n", tid, nt);
    }
    return 0;
}
```

<a id="N011"></a>
### 逐行语法

**讲解：** parallel 后的花括号是并行区域，每个团队线程都执行一次该块。nt 和 tid 声明在块内，是每次执行的局部自动变量；%d 接收 int。离开并行区域有隐式屏障，随后由发起线程继续。区域外 omp_get_num_threads() 在此返回 1，即使环境变量请求了更多线程。

<a id="K002"></a>
**代码出处：** Shell · GCC 与 POSIX shell 示例；不是 PowerShell 命令

```text
gcc -O2 -fopenmp hello_openmp.c -o hello_openmp
export OMP_NUM_THREADS=4
./hello_openmp
```

<a id="K003"></a>
**代码出处：** PowerShell · 已用支持 OpenMP 的工具链编译成 exe 后运行

```text
$env:OMP_NUM_THREADS = "4"
.\hello_openmp.exe
```

<a id="N012"></a>
### 原书拼写校核

**讲解：** p.212 前文的 omp_set_threads 应为 omp_set_num_threads；编译选项正文 -fopen 应为 -fopenmp。OMP_NUM_THREADS 或 num_threads 设置的是请求，实际团队大小还受运行库配置、资源限制和动态调整影响。打印结果的顺序不保证按线程编号排列。


<a id="7.1.2-race"></a>
## 7.1.2（续）为什么线程编号会打印错
原书 p.213–214。

<a id="F003"></a>
### 图 7.3
**Source:** 原书 p.214 / PDF p.250 · C003
**Placed near:** 7.1.2（续）为什么线程编号会打印错

![图 7.3](assets/fig7_3.png)

**Original caption:** Variables in the previous example are defined before the parallel region, thus these are shared variables in the heap. Each thread writes to these, and the final value is determined by which one writes last. The shading represents progression through time with writes at different clock cycles by various threads in a non-deterministic fashion. This situation and similar situations are called race conditions because the results can vary from run to run.

**中文图注:** 多个线程把编号写入同一个变量，示意写操作相互覆盖。

**Reading note:** 图注把外部局部变量说成位于 heap 并不准确：main 的自动变量可以在栈上，仍被并行区共享。更关键的是未同步写构成数据竞争，不能依赖图示的最终值。

<a id="K004"></a>
**代码出处：** C · 原书清单 7.2 的问题缩减示例，不要作为正确代码使用

```text
int tid;
#pragma omp parallel shared(tid)
{
    tid = omp_get_thread_num();  /* 错误示范：并发写共享变量 */
    printf("%d\n", tid);
}
```

<a id="N013"></a>
### 修复思路

**讲解：** 让每个线程在 parallel 块内声明自己的 tid，或者显式使用 private(tid) 并在线程内部先赋值。单纯把 printf 放进 critical 仍不能修复 critical 外的共享写；被保护的是具体操作，不是变量名称自动获得永久保护。


<a id="7.1.2-single"></a>
## 7.1.2（续）single、masked 与屏障
原书 p.215–217。

<a id="S005"></a>
**Source:** 原书 p.215 / PDF p.251 · S005

**Original:** The thread ID is a different value on each run.

**中文:** 每次运行时，执行这段输出的线程编号可能不同。

<a id="K005"></a>
**代码出处：** C · 教学整理，对应清单 7.4–7.6；masked 需要相应编译器支持

```text
#pragma omp parallel
{
    #pragma omp single
    { printf("one selected thread: %d\n", omp_get_thread_num()); }
    /* single 默认在末尾同步 */

    #pragma omp masked
    { printf("primary thread: %d\n", omp_get_thread_num()); }
    /* masked 本身没有末尾屏障 */
}
```

<a id="N014"></a>
### 谁执行，谁等待

**讲解：** single 由团队中的某一个线程执行，未指定 nowait 时末尾有隐式屏障。masked 不带 filter 时由主线程执行，进入和退出均不隐含屏障；其他线程跳过该块并继续，不会自动“休眠等主线程”。需要结果时再安排正确的同步。[R29][R30]

<a id="N015"></a>
### 版本与排版

**讲解：** 原书在此按 OpenMP 5.1 使用 masked，旧示例可能用 master；本讲义按 5.2 规范核对基本语义，不承诺所有编译器完整支持。>> Spawn threads >> 和 Implied Barrier 是书中排版提示，不能复制进 C 源码。


<a id="7.2"></a>
## 7.2 三种使用路线
原书 p.217–219。

<a id="F004"></a>
### 图 7.4
**Source:** 原书 p.217 / PDF p.253 · C004
**Placed near:** 7.2 三种使用路线

![图 7.4](assets/fig7_4.png)

**Original caption:** The recommended reading for each of the scenarios depends on the use case for your application.

**中文图注:** 按循环级、高层次和 MPI+OpenMP 三种使用场景组织阅读路线。

**Reading note:** 先学习循环与作用域，再按需求扩大并行区域。图中的章节推荐不代表所有程序都应走到最复杂的方案。

<a id="N016"></a>
### 先问瓶颈在哪里

**讲解：** 若少数长循环占用多数时间，可以先用循环级并行；若反复进入许多短循环，团队管理和同步可能值得优化；若单节点内存不够或需要跨节点扩展，就要结合分布式内存方法。


<a id="7.2.1"></a>
## 7.2.1 循环级 OpenMP：快速开始
原书 p.217–218。

<a id="S006"></a>
**Source:** 原书 p.218 / PDF p.254 · S006

**Original:** Even when the end goal is a more efficient implementation, this loop-level approach is often the first step when introducing thread parallelism to an application.

**中文:** 即使最终目标是更高效的实现，循环级方法也常常是给程序引入线程并行的第一步。

<a id="N017"></a>
### 适用条件

**讲解：** 热点集中于几个循环、迭代间可独立执行、内存能装入一个节点，通常适合从 parallel for 开始。改动小也要检查正确性；OpenMP 不会替程序员自动消除数据依赖。


<a id="7.2.2"></a>
## 7.2.2 高层次 OpenMP：扩大并行区域
原书 p.218。

<a id="S007"></a>
**Source:** 原书 p.218 / PDF p.254 · S007

**Original:** The OpenMP language does not change, but the method of its use does.

**中文:** OpenMP 的语言机制没有改变，改变的是组织与使用它们的方法。

<a id="N018"></a>
### 术语解释

**讲解：** high-level OpenMP 在本书里指从整个调用流程组织较大的并行区域、明确线程分区并减少不必要同步。这不是一条新指令，也不保证比 parallel for 更快。重构前后应使用相同结果基准。


<a id="7.2.3"></a>
## 7.2.3 MPI 加 OpenMP：分层并行
原书 p.218–219。

<a id="N019"></a>
### 进程与线程分工

**讲解：** MPI 进程负责较大子域，进程内部的线程协作处理共享数据。每个 NUMA 区域布置进程是可能的选择，但不是通用最优值；线程数、通信量、内存占用和绑定要共同衡量。

<a id="N020"></a>
### 不要把逻辑线程等同于物理核

**讲解：** 原书提到用线程利用硬件多线程资源。逻辑线程会共享核心执行资源，增加线程数不等于等量增加计算与带宽。混合通信还需要确认 MPI 的线程支持等级，详见第 8 章。


<a id="7.3"></a>
## 7.3 标准循环级 OpenMP
原书 p.219–220。

<a id="K006"></a>
**代码出处：** C · 循环工作共享的教学最小内核；数组须有效且满足独立迭代条件

```text
#pragma omp parallel for schedule(static)
for (int i = 0; i < n; ++i) {
    c[i] = a[i] + b[i];
}
```

<a id="N021"></a>
### parallel 与 for 不同

**讲解：** parallel 建立线程团队并执行并行区域；for 把迭代分配给现有团队。parallel for 是两者的组合。for 不会为每个迭代新建线程，单独的 simd 也不会建立线程团队。

<a id="K007"></a>
**代码出处：** POSIX shell · 线程绑定示例，策略需按机器测试

```text
export OMP_PLACES=cores
export OMP_PROC_BIND=close
```

<a id="N022"></a>
### 绑定参数校核

**讲解：** 原书 p.219、226 的 OMP_CPU_BIND 不是标准 OpenMP 绑定环境变量，应使用 OMP_PROC_BIND。close、spread 等策略的效果取决于可用 places、进程限制及 NUMA 拓扑。这里的示例不是默认性能建议。


<a id="7.3.1"></a>
## 7.3.1 向量加法与并行初始化
原书 p.220–222。

<a id="F005"></a>
### 图 7.5
**Source:** 原书 p.221 / PDF p.257 · C005
**Placed near:** 7.3.1 向量加法与并行初始化

![图 7.5](assets/fig7_5.png)

**Original caption:** Adding a single OpenMP pragma on the main vector add computation loop (on the left) results in the a and b arrays being touched first by the main thread; the data is allocated near thread zero. The c array is first touched during the computation loop and, therefore, the memory for the c array is close to each thread. On the right, adding an OpenMP pragma on the initialization loop results in the memory for the a and b arrays being placed near the thread where the work is done.

**中文图注:** 串行初始化可能把 a、b 页面集中在主线程所在区域；并行初始化可以使页面更接近后续计算线程。

**Reading note:** 图描述常见首次触碰策略下的情况。确保初始化和计算分配一致，且线程没有迁移；页面粒度和实际操作系统策略仍会影响结果。

<a id="K008"></a>
**代码出处：** C · 教学整理，对应清单 7.7–7.8；数组在并行区外已分配

```text
#pragma omp parallel default(none) shared(a,b,c,n)
{
    #pragma omp for schedule(static)
    for (int i = 0; i < n; ++i) {
        a[i] = 1.0; b[i] = 2.0; c[i] = 0.0;
    }
    #pragma omp for schedule(static)
    for (int i = 0; i < n; ++i)
        c[i] = a[i] + b[i];
}
```

<a id="N023"></a>
### default(none) 的用途

**讲解：** 要求显式说明没有预定属性的变量如何共享，帮助审查遗漏；循环声明的 i 具有相应私有属性。a、b、c 在这里是共享指针变量，元素也指向共同数组；不同线程写不同元素。

<a id="F006"></a>
### 图 7.6
**Source:** 原书 p.223 / PDF p.259 · C006
**Placed near:** 7.3.1 向量加法与并行初始化

![图 7.6](assets/fig7_6.png)

**Original caption:** Output from the numactl and numastat commands. The distance between memory regions is highlighted. Note that the NUMA utilities use the term “node” differently than we have defined it. In their terminology, each NUMA region is a node. We reserve the node terminology for a separate distributed memory system such as another desktop or tray in a rack-mounted system.

**中文图注:** 原书机器上的 NUMA 区域、内存统计与距离输出。

**Reading note:** 这里的 node 指 NUMA 区域，不一定是一整台服务器。10 和 21 是相对距离指标，不是精确实测纳秒或保证的 2.1 倍运行时间。该输出不是当前电脑的配置。


<a id="7.3.2"></a>
## 7.3.2 STREAM Triad 与计时
原书 p.222–224。

<a id="K009"></a>
**代码出处：** C · 教学计时片段；调用线程相同，输入已初始化

```text
double start = omp_get_wtime();
#pragma omp parallel for schedule(static)
for (int i = 0; i < n; ++i)
    c[i] = a[i] + scalar * b[i];
double seconds = omp_get_wtime() - start;
```

<a id="N024"></a>
### 一行计算里的语法

**讲解：** 乘法先于加法；a[i]、b[i] 是输入，c[i] 是输出。原书重复 16 次取平均，但应区分首次运行、热缓存与内存带宽饱和。这里的 omp_get_wtime 返回秒，要显示毫秒需乘 1000。

<a id="N025"></a>
### 结果不能只用一次无意义赋值保活

**讲解：** 原书 c[1]=c[2] 不能作为通用的防优化保证。应校验并消费输出，例如计算校验和后打印，同时不要把校验开销混入宣称的内核时间。若数组有重叠或输出跨迭代依赖，此循环不再安全独立。


<a id="7.3.3"></a>
## 7.3.3 五点 stencil：双缓冲与边界
原书 p.224–226。

<a id="K010"></a>
**代码出处：** C · 清单 7.10 的平坦数组教学整理；尺寸乘积须在 int 范围内

```text
#pragma omp parallel for schedule(static)
for (int j = 1; j < rows - 1; ++j) {
    for (int i = 1; i < cols - 1; ++i) {
        int k = j * cols + i;
        next[k] = (old[k] + old[k-1] + old[k+1]
                 + old[k-cols] + old[k+cols]) / 5.0;
    }
}
double *tmp = old; old = next; next = tmp;
```

<a id="N026"></a>
### 为什么需要两个数组

**讲解：** 每步读取 old 的旧值、写入 next，避免某个线程读到其他线程已经覆盖的新值。parallel for 结束后团队完成，串行交换指针；固定边界条件应在两个缓冲区都正确初始化。

<a id="N027"></a>
### 原书清单的检查点

**讲解：** 计时累加量必须初始化为 0；清单中的 init_time、flush_time 等不可直接未初始化就 +=。原书把 x 与 xnew 边界分别设为 5 和 0，再交换，可能造成边界交替；若要求固定边界，应保持两份一致。

<a id="N028"></a>
### 缓存驱逐循环不等于 omp flush

**讲解：** 写入名为 flush 的大数组是尝试制造冷缓存的实验手段，不是 OpenMP flush 指令，也不能保证指定缓存行全部被驱逐。要防止无用写被优化，并说明计时包含哪些阶段。


<a id="7.3.4"></a>
## 7.3.4 怎样读取速度提升与效率
原书 p.226–227。

<a id="F018"></a>
### 表 7.2
**Source:** 原书 p.226 / PDF p.262 · C018
**Placed near:** 7.3.4 怎样读取速度提升与效率

![图 7.T2](assets/fig7_T2.png)

**Original caption:** Shown are the run times in msecs. The speedup on a Skylake Gold 6152 dual socket node with the GCC version 8.2 compiler is a factor of ten on 88 threads. Adding an OpenMP pragma on the initialization to get proper first-touch memory allocation returns an additional speedup.

**中文图注:** 原书的串行、简单循环并行及加入首次触碰优化的时间比较。

**Reading note:** 表按原样保留，单位沿用原表 msecs，但向量规模与计时函数必须复核；未据此计算绝对带宽。比值可用于理解方法，不能当作当前机器预测。

<a id="E001"></a>
**Source:** 原书 p.226 / PDF p.262 · E001

$$
S_p=T_1/T_p,\qquad E_p=S_p/p
$$

S 是加速比，E 是以线程数 p 归一化的效率；串行与并行时间必须覆盖同样的计算与计时范围。

<a id="N029"></a>
### 重算 stencil 示例

**讲解：** 简单并行：62.56/3.686≈16.97，除以 88 得 19.3%。加入 first touch：62.56/3.311≈18.89，效率约 21.5%。从 3.686 降到 3.311 是时间减少约 10.2%，不要与加速比增加混淆。

<a id="N030"></a>
### 不要只看线程数

**讲解：** 88 个逻辑线程不是 88 份互不影响的物理核心资源。带宽饱和、同步、共享缓存和硬件多线程都会限制扩展；低效率并不自动证明 OpenMP 写法错误。


<a id="7.3.5"></a>
## 7.3.5 reduction：全局求和
原书 p.227。

<a id="S008"></a>
**Source:** 原书 p.227 / PDF p.263 · S008

**Original:** The reduction operation computes a local sum on each thread and then sums all the threads together.

**中文:** 归约先在各线程上计算局部和，再把线程的结果合并。

<a id="K011"></a>
**代码出处：** C · 清单 7.11 核心整理

```text
double sum = 0.0;
#pragma omp parallel for reduction(+:sum)
for (long i = 0; i < n; ++i)
    sum += a[i];
```

<a id="N031"></a>
### 冒号和初值

**讲解：** reduction(+:sum) 中 + 指合并运算，冒号后是归约变量。线程私有副本按运算单位元初始化，但原始 sum 仍参加最终组合，所以开启 OpenMP 时也必须初始化；不只是关闭 OpenMP 时才需要。

<a id="N032"></a>
### 浮点归约的限制

**讲解：** 合并顺序通常不固定，浮点加法又不满足严格结合律，因此不同线程数或调度可能给出不同末位。测试应按误差要求比较，而不是把所有末位差异都叫作数据竞争。


<a id="7.3.6"></a>
## 7.3.6 哪些循环能分工
原书 p.227–228。

<a id="K012"></a>
**代码出处：** C · 循环携带依赖教学反例

```text
/* 不能直接 parallel for：每次依赖前一次写入 */
for (int i = 1; i < n; ++i)
    a[i] = a[i-1] + b[i];
```

<a id="N033"></a>
### 规范形式与依赖是两个问题

**讲解：** 编译器能计算迭代空间，不等于这些迭代可以同时安全执行。原书将计数变量概括为整数；实际 C/C++ 规范还支持满足条件的指针或随机访问迭代器等形式，应查对应标准与实现。

<a id="N034"></a>
### 反转顺序不是证明

**讲解：** 改变顺序后结果变化能提示依赖，但一次测试结果相同不能证明没有依赖；浮点归约即使正确也会受顺序影响。需要分析每次迭代读写的地址以及同步机制。


<a id="7.4"></a>
## 7.4 变量作用域与数据共享属性
原书 p.228–229。

<a id="S009"></a>
**Source:** 原书 p.228 / PDF p.264 · S009

**Original:** To convert an application or routine to high-level OpenMP, you need to understand variable scope.

**中文:** 要把程序或例程改造成高层次 OpenMP 实现，必须理解变量作用域。

<a id="F007"></a>
### 图 7.7
**Source:** 原书 p.228 / PDF p.264 · C007
**Placed near:** 7.4 变量作用域与数据共享属性

![图 7.7](assets/fig7_7.png)

**Original caption:** Summary of thread scoping rules for OpenMP applications

**中文图注:** 原书对共享、私有和归约属性的简表。

**Reading note:** 这是教学概括，不替代标准。“所有循环索引都私有”不能脱离语言和构造语境；栈/堆也不是唯一判据。按声明位置、存储期、所属构造和显式子句逐项分析。

<a id="K013"></a>
**代码出处：** C · 清单 7.12 的对照教学修正版

```text
double x = 7.0;
#pragma omp parallel private(x)
{
    x = 1.0;  /* 私有副本先赋值再使用 */
}
printf("%g\n", x);  /* 原始 x 仍为 7.0 */
```

<a id="N035"></a>
### private 不会销毁外部变量

**讲解：** private 创建新的副本，不自动复制原值，也不自动写回原变量。原书示例外部 x 未初始化，退出后读 x 仍无有效初值；不能推广成所有原变量在退出时都“变为未定义”。

<a id="N036"></a>
### 四个容易混淆的子句

**讲解：** shared 引用共同对象；private 使用独立副本；firstprivate 为各副本复制进入时的值；lastprivate 写回逻辑上最后一次迭代的结果，不是最后跑完线程的结果。哪些构造允许哪些子句要单独核对。


<a id="7.5"></a>
## 7.5 函数级 OpenMP：指针与所指对象
原书 p.229–231。

<a id="K014"></a>
**代码出处：** C · 函数参数与局部变量的教学片段

```text
void update_range(double *a, long begin, long end) {
    for (long i = begin; i < end; ++i)
        a[i] *= 2.0;
}
```

<a id="N037"></a>
### 函数参数的指针值可以私有，数组仍共享

**讲解：** 不同线程调用函数，各有参数 a 这个局部指针对象，但它们可能携带相同地址，指向同一数组。只有写入区间互不重叠，或冲突访问有正确同步，才可安全协作。把指针声明在函数内部不等于复制整块数组。

<a id="N038"></a>
### 静态指针不是共享缓冲区的唯一办法

**讲解：** 原书用 static double **yface 让线程看到同一指针。更容易控制生命周期的办法是在调用者分配一次并通过参数传入。static 会保留跨调用状态，可能妨碍同时调用、嵌套团队和重入；分配后、释放前仍需同步。

<a id="N039"></a>
### 原清单不能原样套用

**讲解：** 清单 7.14 在函数内部又放置 parallel，并让局部 thread_id 被多线程写；若函数已由团队集体调用，还可能形成意外嵌套团队。应在明确的并行上下文里直接查询当前编号，不额外引入该竞争区域。


<a id="7.5-fortran"></a>
## 7.5（续）Fortran 的 SAVE 与局部对象
原书 p.230–231。

<a id="K015"></a>
**代码出处：** Fortran · 作用域教学片段，不是完整并行计算程序

```text
subroutine example(n, y)
  integer, intent(in) :: n
  real, intent(inout) :: y(n)
  real :: tmp
  real, save :: persistent = 0.0
  real, allocatable :: scratch(:)
  ! tmp 与 scratch 的使用仍需遵守并行调用语境
end subroutine example
```

<a id="N040"></a>
### SAVE 表示存储期，不等于堆

**讲解：** 带 SAVE 的变量跨调用保留状态，在相应并行语境下可能被线程共享。Fortran 声明中的初始化通常隐含 SAVE；这与在可执行语句中赋值不同。是否位于某个物理栈或堆是实现细节。

<a id="N041"></a>
### 实参与形参必须一起分析

**讲解：** y 的数据共享情况不能仅凭它出现在子程序参数表就断言私有。原书清单 7.13 的 allocatable z 还缺少其所述数组的维度声明。threadprivate 是独立指令，用于允许的持久对象，不是任意局部变量都能套用。


<a id="7.6"></a>
## 7.6 高层次 OpenMP 的目标
原书 p.231–234。

<a id="S010"></a>
**Source:** 原书 p.231 / PDF p.267 · S010

**Original:** The central high-level OpenMP strategy is to improve on standard loop-level parallelism by minimizing fork/join overhead and memory latency.

**中文:** 高层次 OpenMP 的核心策略，是通过减少分叉／汇合开销和内存延迟，改进标准循环级并行。

<a id="F008"></a>
### 图 7.8
**Source:** 原书 p.232 / PDF p.268 · C008
**Placed near:** 7.6 高层次 OpenMP 的目标

![图 7.8](assets/fig7_8.png)

**Original caption:** Visualization of high-level OpenMP threading. Threads are spawned once and left dormant when not needed. Thread bounds are specified manually and synchronization is minimized.

**中文图注:** 以较大的并行区域组织多段计算，并明确各线程的上下界。

**Reading note:** 原图的 dormant 是概念描述：线程是等待、自旋还是执行后续代码取决于构造与运行库。常见运行库也会重用线程池，不能把每次 parallel 都等同于新建操作系统线程。

<a id="N042"></a>
### 优化目标不是 pragma 越少越好

**讲解：** 减少重复团队管理和无用等待可以有效，但必要屏障不能省。手工分区仍可能在缓存行边界出现伪共享，也不会自动消除邻居数据依赖或改善负载均衡。


<a id="7.6.1"></a>
## 7.6.1 四步改造过程
原书 p.232–234。

<a id="F009"></a>
### 图 7.9
**Source:** 原书 p.233 / PDF p.269 · C009
**Placed near:** 7.6.1 四步改造过程

![图 7.9](assets/fig7_9.png)

**Original caption:** High-level OpenMP starts with a loop-level OpenMP implementation and merges parallel regions together to reduce the cost of thread spawning. We use the animal images to represent where the changes are made and the relative speed of the actual implementation. The conventional loop level OpenMP shown with the turtle is faster, but there is overhead with each parallel do that limits speedup. The dog represents the relative gain in speed from merging parallel regions.

**中文图注:** 先把多个循环级并行区域合并，保留各循环的分工与必要屏障。

**Reading note:** 图中的动物只是相对速度的示意，不是性能量表。合并区域后要确认以前只执行一次的代码没有被每个线程重复执行。

<a id="F010"></a>
### 图 7.10
**Source:** 原书 p.233 / PDF p.269 · C010
**Placed near:** 7.6.1 四步改造过程

![图 7.10](assets/fig7_10.png)

**Original caption:** The next steps for high-level OpenMP add nowait clauses to do or for loops, which reduce synchronization costs. Then we calculate the loop bounds ourselves and explicitly use these in the loops to avoid even more synchronization. Here, the cheetah and the hawk identify the changes made in both implementations. The hawk (on the right) is faster than the cheetah (on the left) as the overhead of the OpenMP is reduced.

**中文图注:** 进一步只删除不需要的等待，并按明确区间手工分配工作。

**Reading note:** 图中性能顺序是原书案例说明。nowait 只移除相应结束同步，不验证数据依赖；需要跨线程结果时必须另设同步。[R31]

<a id="N043"></a>
### 逐步改，不要一次重写

**讲解：** 先得到正确的循环级版本；合并并行区域；依据读写依赖删除多余屏障或手工分区；将确实局部的数据私有化。每一步都与基准比较，并改变线程数和输入尺寸检查边界。


<a id="7.6.1-bounds"></a>
## 7.6.1（续）手工计算线程区间
原书 p.234–236。

<a id="E002"></a>
**Source:** 原书 p.234 / PDF p.270 · E002

$$
b_t=\left\lfloor Nt/P\right\rfloor,\qquad e_t=\left\lfloor N(t+1)/P\right\rfloor
$$

线程 t 负责半开区间 [bₜ,eₜ)。要求 N≥0、P≥1、0≤t<P。内部行从 1 开始时，对两个端点都加 1。

<a id="K016"></a>
**代码出处：** C · 清单 7.16 分区公式整理；乘积必须不溢出 long

```text
long begin = n * tid / nt;
long end   = n * (tid + 1) / nt;
for (long i = begin; i < end; ++i) {
    /* 只写属于本线程的输出元素 */
}
```

<a id="N044"></a>
### 为什么不会漏项

**讲解：** 相邻线程的 end 等于后一个线程的 begin，第一个 begin 为 0，最后一个 end 为 N。N 不能整除 P 时，各区间长度最多差 1；N<P 时有空区间，代码必须接受 begin==end。

### 线程分区与邻居依赖

调整元素数和线程数，查看半开区间、空线程及 stencil 所需的跨区邻居。采用本书的手工 floor 分区，不能当作所有 schedule(static) 实现的精确分配结果。

交互版本见网页小节 7.6.1（续）。展示手工线程区间、空线程和邻居依赖，不是性能预测。

<a id="N045"></a>
### 索引不是地址隔离

**讲解：** 一个线程写自己区间，并不意味着它只读自己区间。stencil 需要边界邻居，前缀扫描需要前面线程的总和；同步应依据这些依赖设置。大规模索引要使用足够宽的类型并检查乘积溢出。


<a id="7.6.2"></a>
## 7.6.2 合并 stencil 的并行区域
原书 p.234–237。

<a id="K017"></a>
**代码出处：** C · 清单 7.15–7.16 的教学修正版；两缓冲区含一致的固定边界

```text
#pragma omp parallel shared(old,next,rows,cols,steps)
{
    for (int step = 0; step < steps; ++step) {
        #pragma omp for schedule(static)
        for (int j = 1; j < rows - 1; ++j) {
            for (int i = 1; i < cols - 1; ++i) {
                int k = j * cols + i;
                next[k] = (old[k] + old[k-1] + old[k+1]
                         + old[k-cols] + old[k+cols]) / 5.0;
            }
        }  /* for 屏障：本轮全部输出完成 */
        #pragma omp single
        {
            double *tmp = old; old = next; next = tmp;
        }  /* single 屏障：指针交换后再进入下一轮 */
    }
}
```

<a id="N046"></a>
### 为什么要有两道同步

**讲解：** 第一道防止其他线程还在写 next 就交换数组；第二道防止其他线程在交换完成前就进入下一轮。single 默认末尾屏障满足第二个需求。若改用 masked 或 tid==0，就要补上交换后的 barrier。

<a id="N047"></a>
### 原书清单 7.15 的关键缺口

**讲解：** p.235 交换共享指针之后没有屏障。下一轮的 omp for 在进入时不提供所需屏障，且前面的驱逐循环使用 nowait，因此可能与指针交换发生竞争。清单 7.16 的末尾显式屏障展示了所需思路。

<a id="F011"></a>
### 图 7.11
**Source:** 原书 p.237 / PDF p.273 · C011
**Placed near:** 7.6.2 合并 stencil 的并行区域

![图 7.11](assets/fig7_11.png)

**Original caption:** Optimizing the OpenMP pragmas both reduces the number of pragmas required and improves the performance of the stencil kernel.

**中文图注:** 原书几个 stencil 优化版本的计时输出。

**Reading note:** 逐行可见阶段时间并非严格单调改善。计时范围和同步位置必须一致；没有对本机运行这些历史程序，也不以减少 pragma 数量作为正确性证据。


<a id="7.7"></a>
## 7.7 OpenMP 线程与 SIMD 混合
原书 p.237–240。

<a id="K018"></a>
**代码出处：** C · 清单 7.17 的混合并行内核

```text
#pragma omp parallel for simd schedule(static)
for (int i = 0; i < n; ++i)
    c[i] = a[i] + scalar * b[i];
```

<a id="K019"></a>
**代码出处：** C · 清单 7.18 的教学整理：外层按行分线程，内层向量化

```text
#pragma omp parallel for schedule(static)
for (int j = 1; j < rows - 1; ++j) {
    #pragma omp simd
    for (int i = 1; i < cols - 1; ++i) {
        int k = j * cols + i;
        next[k] = (old[k] + old[k-1] + old[k+1]
                 + old[k-cols] + old[k+cols]) / 5.0;
    }
}
```

<a id="N048"></a>
### 两层资源

**讲解：** 线程处理不同迭代分块，SIMD 在每个线程内部处理多个元素。连续内层数据访问有利于向量化，但内存带宽饱和后，增加两者都不一定继续提速。OMP_SIMD 是原书自行约定的条件编译宏，不是标准自动定义的开关。

<a id="N049"></a>
### 读原书的四线程数字

**讲解：** p.240 stencil 阶段由 17.374676 降到 13.943251，约加速 1.246 倍；总时间由 34.499799 降到 31.454906，仅约 1.097 倍。局部内核提升与总程序提升应分别报告。


<a id="7.8"></a>
## 7.8 进阶示例：依赖决定结构
原书 p.240。

<a id="N050"></a>
### 三个例子的共同问题

**讲解：** 分方向 stencil 要保留邻接面数据；Kahan 求和要维护每个分块的误差状态；前缀扫描要把前面分块的累计量传给后面分块。都不能仅在原串行循环前加 parallel for。

<a id="N051"></a>
### 三张审查表

**讲解：** 对每个阶段写清：谁产生数据、谁读取数据、何时能释放或覆盖。再检查每个线程进入同步点的顺序一致，空分块也不能跳过团队必须遇到的屏障。


<a id="7.8.1"></a>
## 7.8.1 分方向 stencil 与面数据
原书 p.240–244。

<a id="F012"></a>
### 图 7.12
**Source:** 原书 p.241 / PDF p.277 · C012
**Placed near:** 7.8.1 分方向 stencil 与面数据

![图 7.12](assets/fig7_12.png)

**Original caption:** The x face of a stencil aligned with the threads needs private storage for each thread. The pointer should be on the stack, and each thread should have a different pointer. The y face needs to share the data, so we define one pointer in the static data region where both threads can access it.

**中文图注:** 沿行分工时，x 方向面量可存在线程局部缓冲；y 方向面量涉及相邻线程，需要共享或交换。

**Reading note:** 图中小段分配代码是示意，不可当作有效 double** 二维分配。局部缓冲也能来自堆；共享 yface 不一定必须用 static，可以由调用者分配并传入。

<a id="E003"></a>
**Source:** 原书 p.241 / PDF p.277 · E003

$$
X_{j,i+1/2}=(a_{j,i+1}+a_{j,i})/2,\quad Y_{j+1/2,i}=(a_{j+1,i}+a_{j,i})/2
$$

这是清单 7.19 的面量平均，面量必须从更新前的 a 计算。原书后续把中心与四个面量平均；它与 7.3.3 的中心加四邻点平均并不是同一个离散算子。

<a id="K020"></a>
**代码出处：** C · 清单 7.20 的阶段示意；省略分配与 yface 循环，不是可独立编译程序

```text
/* 所有团队线程按同样顺序调用，yface 已由调用者分配 */
for (int j = begin; j < end; ++j)
    for (int i = 0; i < cols - 1; ++i)
        xface[(j-begin)*(cols-1)+i] = (a[j*cols+i+1]+a[j*cols+i])/2.0;
/* yface 的每个面由且仅由一个线程计算 */
#pragma omp barrier
/* 然后读取相邻 yface，计算本区输出 */
#pragma omp barrier
/* 全部读完之后，才允许释放共享工作数组 */
```

<a id="N052"></a>
### 局部索引与全局索引

**讲解：** xface 只分配 end-begin 行，所以访问用 j-begin；yface 用全局行号，因两个线程都可能读取同一边界面。第一道屏障保证跨区面量准备完成，最后一道保证共享缓冲不会被提前释放。

<a id="F013"></a>
### 图 7.13
**Source:** 原书 p.244 / PDF p.280 · C013
**Placed near:** 7.8.1 分方向 stencil 与面数据

![图 7.13](assets/fig7_13.png)

**Original caption:** The threaded version of the split stencil has a super-linear speedup for two to eight threads.

**中文图注:** 原书分方向 stencil 在少量线程时出现超线性加速。

**Reading note:** 分块后工作集可能更好地适配缓存，导致相对某个串行基线超过理想线。仍须核对基线优化、算法、频率、计时范围与结果，不能据此期待线程越多越快。


<a id="7.8.2"></a>
## 7.8.2 线程化 Kahan 补偿求和
原书 p.244–245。

<a id="S011"></a>
**Source:** 原书 p.244 / PDF p.280 · S011

**Original:** We first sum up the values on each thread in the first phase of the calculation. Then we sum the values across the threads to get the final sum as the following listing shows.

**中文:** 第一阶段由各线程对自己的数据求和；随后再合并各线程的结果，得到最终总和。

<a id="K021"></a>
**代码出处：** C · 清单 7.21 的正补偿记号教学修正版

```text
typedef struct { double sum, correction; } Acc;
static void add_term(Acc *s, double value) {
    double corrected = value + s->correction;
    double next = s->sum + corrected;
    s->correction = corrected - (next - s->sum);
    s->sum = next;
}
/* 每个线程使用自己初始化为 {0.0, 0.0} 的 Acc */
```

<a id="N053"></a>
### 原书两处加数错误

**讲解：** p.245 第 27 行应把 corrected_next_term 加到 local.sum，而不是再次加 local.correction；全局合并第 53 行有相同问题。讲义的 add_term 使用真正的校正项。补偿变量的正负约定必须从头到尾一致，不能拼接不同版本。

<a id="N054"></a>
### 跨线程如何合并

**讲解：** 线程先把状态放入互不重叠的槽位，屏障后由一个线程依次把局部 sum 与 correction 加入全局补偿累加器。显式传入共享工作区更容易管理重入；原书 static 状态不适合多个团队同时调用。

<a id="N055"></a>
### 精度不等于完全可复现

**讲解：** 分块改变仍会改变浮点运算顺序。补偿算法通常降低误差，但不保证所有输入正确舍入，也不保证不同线程数逐位一致。不能开启会随意重排浮点表达式的优化后仍假定补偿关系完整保留。


<a id="7.8.3"></a>
## 7.8.3 分块前缀扫描
原书 p.246–247。

<a id="S012"></a>
**Source:** 原书 p.246 / PDF p.282 · S012

**Original:** The implementation process has three phases:

**中文:** 这一实现过程分为三个阶段：

<a id="N056"></a>
### 三阶段展开

**讲解：** 每个线程计算本块排他前缀和及块总和；一个线程对块总和做排他扫描，得到各块偏移；所有线程再把自己的偏移加到本块输出。空块的总和必须为 0。

<a id="K022"></a>
**代码出处：** C · 教学修正版阶段片段；调用者提供独立输入输出和至少 nt 项的共享工作数组，所有整数和须不溢出

```text
/* 阶段 1：本块排他扫描 */
long long local = 0;
for (long i = begin; i < end; ++i) {
    out[i] = local;
    local += in[i];
}
totals[tid] = local;
#pragma omp barrier
#pragma omp single
{
    long long offset = 0;
    for (int t = 0; t < nt; ++t) {
        offsets[t] = offset;
        offset += totals[t];
    }
} /* 默认屏障：所有偏移准备完毕 */
for (long i = begin; i < end; ++i)
    out[i] += offsets[tid];
#pragma omp barrier
```

<a id="N057"></a>
### 为什么另设块总和数组

**讲解：** 原书清单 7.22 把偏移存入各块的首个输出，读写关系较隐蔽。按书中 floor 分区和条件检查，空块也能被正确跳过；随附模型对 N=0、N<P 和不整除情况做了核对。教学版另设 totals/offsets 是为了显式展示阶段依赖，并非声称原版在这些情形必然越界。输入输出应独立，整数累计量不能溢出。

<a id="E004"></a>
**Source:** 原书 p.247 / PDF p.283 · E004

$$
T_P\approx 2\alpha N/P+\beta P+T_{\mathrm{sync}}
$$

原书只给出约 2T₁/P 的理想估计。这里补充串行块偏移 O(P) 和同步开销，解释线程增加后为什么会停止受益；这不是硬件预测。

<a id="N058"></a>
### 新语法与手工算法

**讲解：** OpenMP 还定义 reduction(inscan,...) 与 scan 来表达前缀计算，但其组合限制和工具链支持需核对。这里保留原书三阶段方法，重点理解数据依赖，而不是保证某个编译器会自动采用最快算法。[R32]


<a id="7.9"></a>
## 7.9 用工具检查正确性与性能
原书 p.247–249。

<a id="N059"></a>
### 把问题分开测

**讲解：** 内存越界、未初始化、数据竞争、性能瓶颈是不同问题。一次正常输出不能证明没有竞争；一次 race detector 无报告也只能覆盖实际执行路径和该工具识别的同步。

<a id="N060"></a>
### 实验记录应包括什么

**讲解：** 记录编译器、OpenMP 运行库、线程数、绑定、输入尺寸、边界条件和比较容差。每次重构先比较结果，再比较计时；至少包含奇数长度、空块以及线程数超过工作量的情况。

<a id="N061"></a>
### 工具类别校核

**讲解：** 原书将 Cachegrind 描述为调用图工具；缓存与分支模拟主要由 Cachegrind 提供，调用关系剖析通常使用 Callgrind。工具名称、版本与 OpenMP 运行库的兼容性应分别确认。


<a id="7.9.1"></a>
## 7.9.1 从剖析图找线程开销
原书 p.248。

<a id="F014"></a>
### 图 7.14
**Source:** 原书 p.248 / PDF p.284 · C014
**Placed near:** 7.9.1 从剖析图找线程开销

![图 7.14](assets/fig7_14.png)

**Original caption:** These are results from Allinea/ARM MAP showing the majority of the compute time on the highlighted line of code. We often use indicators like this to show us the location of bottlenecks.

**中文图注:** 原书 Allinea/ARM MAP 界面显示热点代码行及时间分布。

**Reading note:** 历史界面用于讲解剖析方法：先看热点、等待和内存使用，再判断线程开销。图不是本机测量，也不保证当前产品名称和界面相同。

<a id="N062"></a>
### 不要只凭一条高亮做结论

**讲解：** 热点可能是正常的大量有效计算，也可能来自等待或访存。结合线程时间线、采样归因、输入规模和完整运行时间；比较前后采用同一测量设置。


<a id="7.9.2"></a>
## 7.9.2 数据竞争检测与回归测试
原书 p.248–249。

<a id="F015"></a>
### 图 7.15
**Source:** 原书 p.249 / PDF p.285 · C015
**Placed near:** 7.9.2 数据竞争检测与回归测试

![图 7.15](assets/fig7_15.png)

**Original caption:** Intel® Inspector report showing detection of thread race conditions. Here the items listed as Data race under the Type heading on the panel to the upper left show all the places where there is currently a race condition.

**中文图注:** 原书 Intel Inspector 报告列出检测到的数据竞争位置。

**Reading note:** 应理解成这次检测发现的位置，不是所有可能竞争的穷尽列表。Intel 官方现已发布终止生命周期通知，产品不再提供常规下载；保留截图是为了读懂原书。[R33]

<a id="N063"></a>
### 先建立基准再改并行

**讲解：** 原书强调先完成回归测试：若串行版本本来就不正确，无法把差异归因于并行化。缩小到可手算的输入、改变线程数与调度、检查边界和错误路径，通常更有助于定位问题。


<a id="7.10"></a>
## 7.10 基于任务的成对求和
原书 p.250–251。

<a id="F016"></a>
### 图 7.16
**Source:** 原书 p.250 / PDF p.286 · C016
**Placed near:** 7.10 基于任务的成对求和

![图 7.16](assets/fig7_16.png)

**Original caption:** The task-based implementation recursively splits the array into half on the downward sweep. Once an array size of 1 occurs, the task sums pairs of data in the upward sweep.

**中文图注:** 递归向下切分数组，在向上返回时合并两部分的和。

**Reading note:** 图采用 16 个元素，掩盖了奇数长度的边界问题。正确区间必须是 [lo,mid) 与 [mid,hi)，二者连续、不重叠且覆盖全部元素。

<a id="K023"></a>
**代码出处：** C · 清单 7.23 的教学修正版；1024 仅为可调示例阈值

```text
static double pair_task(const double *a, long lo, long hi) {
    long n = hi - lo;
    if (n == 0) return 0.0;
    if (n == 1) return a[lo];
    long mid = lo + n / 2;
    double left, right;
    #pragma omp task shared(left) firstprivate(a,lo,mid) if(n > 1024)
    { left = pair_task(a, lo, mid); }
    #pragma omp task shared(right) firstprivate(a,mid,hi) if(n > 1024)
    { right = pair_task(a, mid, hi); }
    #pragma omp taskwait
    return left + right;
}
```

<a id="K024"></a>
**代码出处：** C · 仅由一个线程生成根任务；并行团队执行后续任务

```text
double sum = 0.0;
#pragma omp parallel shared(sum,a,n)
{
    #pragma omp single
    { sum = pair_task(a, 0, n); }
}
```

<a id="N064"></a>
### 原书奇数长度会漏项

**讲解：** 原清单两个子区间都取 nsize/2 个元素：当 nsize=5 时得到 [0,2) 与 [3,5)，漏掉索引 2；nsize=0 又没有退出条件。修正版用 mid 作为两区间共同端点，并处理空输入。

<a id="N065"></a>
### shared、firstprivate、taskwait

**讲解：** left/right 是父调用的局部结果槽，必须让子任务写回这些对象；区间端点与指针值使用 firstprivate 固定任务输入。taskwait 等待当前任务此前生成的子任务完成，确保结果可读且父局部变量还活着。[R34]


<a id="7.10-granularity"></a>
## 7.10（续）任务粒度与可复现性
原书 p.251。

<a id="N066"></a>
### task 不等于新建一个线程

**讲解：** 任务由团队线程调度执行。任务太细主要增加任务创建、调度和同步开销，不是每创建一个任务就新增一个操作系统线程。上页 if 条件为假时产生未延迟任务，仍有任务语义；进一步优化可直接走串行叶子例程。

<a id="N067"></a>
### final 的方向要看清

**讲解：** 原书 final(nsize > 10) 在大问题时就把任务设为 final，使其中生成的后代成为 included/final task，可能过早压低并行度。若希望小问题停止展开，需根据算法重新设计截止策略，不能仅凭 final 这个词猜测行为。[R35]

<a id="N068"></a>
### 固定归约树的边界

**讲解：** 固定区间切分与固定表达式通常让合并次序不依赖任务完成先后。它仍不保证跨编译器、浮点选项和硬件逐位相同，也不等同于精确求和。数值验证与任务性能应分别进行。


<a id="7.11"></a>
## 7.11 延伸探索与本章小结
原书 p.251–252。

<a id="S013"></a>
**Source:** 原书 p.252 / PDF p.288 · S013

**Original:** Understanding variable scope across threads is important in getting OpenMP code to work.

**中文:** 要让 OpenMP 代码正确工作，理解变量在线程间的作用域十分重要。

<a id="N069"></a>
### 本章收获

**讲解：** 先建立线程团队，再分配独立迭代；分清指针对象与所指数据；必要同步由真实数据依赖决定；用内存局部性和测量结果指导优化。高层次 OpenMP 的价值来自减少真实开销，而不是形式上的代码简短。


<a id="7.11.1"></a>
## 7.11.1 延伸阅读
原书 p.251–252。

<a id="N070"></a>
### 原书阅读线索

**讲解：** 保留 Chapman、Jost 与 Van Der Pas 的 Using OpenMP（2008）、Pacheco 的 An Introduction to Parallel Programming（2011）、Zamora 的高层次 OpenMP 讲义及 LLNL 教程等阅读方向。版本较早的材料适合概念学习，具体语义再查 OpenMP 规范。

<a id="N071"></a>
### 本讲义的核对方式

**讲解：** 技术说明以所链接的 OpenMP 5.2 规范条目为明确版本基线，并保留 GCC 等编译器资料。书中 SC21 等会议链接属于历史资料，不作为当前活动时间表或下载安装建议。


<a id="7.11.2"></a>
## 7.11.2 练习与参考思路
原书 p.252。

<a id="N072"></a>
### 练习一：高层次向量加法

**讲解：** 将初始化与多次向量加法放入一个 parallel 区域，使用两个或多个 omp for 分工。验证所有输出都是期望值，再测分区和同步；没有跨线程依赖的循环才考虑 nowait。

<a id="K025"></a>
**代码出处：** C · 练习二参考片段：最大值归约

```text
/* 前置条件：n > 0，且数组无 NaN */
double best = a[0];
#pragma omp parallel for reduction(max:best)
for (long i = 1; i < n; ++i)
    if (a[i] > best) best = a[i];
```

<a id="N073"></a>
### 练习二与三：最大值及高层次改造

**讲解：** 空输入没有自然的最大值，接口应返回状态或采用明确定义的单位元；NaN 策略也应写清。高层次版本每线程计算局部最大值，在共享槽位写入结果，屏障后合并；空线程不可读取 a[begin]。

<a id="N074"></a>
### 随附检查

**讲解：** Python 教学模型覆盖分区完整性、空线程、扫描、任务递归、stencil 阶段和补偿求和，并提供原书任务递归奇数长度漏项的反例。它是串行模型验证，不是 OpenMP 数据竞争检测，也不替代 C 工具链编译。


## 技术核对来源

- [R27 · OpenMP 5.2：内存模型](https://openmp.org/spec-html/5.2/openmpsu9.html)
- [R28 · OpenMP 5.2：flush 同步](https://openmp.org/spec-html/5.2/openmpsu13.html)
- [R29 · OpenMP 5.2：single](https://www.openmp.org/spec-html/5.2/openmpse62.html)
- [R30 · OpenMP 5.2：masked](https://www.openmp.org/spec-html/5.2/openmpse61.html)
- [R31 · OpenMP 5.2：nowait](https://openmp.org/spec-html/5.2/openmpse94.html)
- [R32 · OpenMP 5.2：scan](https://openmp.org/spec-html/5.2/openmpse28.html)
- [R33 · Intel Inspector 生命周期通知](https://www.intel.com/content/www/us/en/developer/tools/oneapi/inspector.html)
- [R34 · OpenMP 5.2：taskwait](https://www.openmp.org/spec-html/5.2/openmpse93.html)
- [R35 · OpenMP 5.2：final](https://www.openmp.org/spec-html/5.2/openmpse71.html)
- [R36 · OpenMP 5.2：构造中的变量](https://www.openmp.org/spec-html/5.2/openmpsu33.html)
- [R37 · OpenMP 5.2：被调函数中的变量](https://www.openmp.org/spec-html/5.2/openmpsu34.html)
- [R38 · OpenMP 5.2：线程绑定等环境变量](https://www.openmp.org/wp-content/uploads/OpenMPRefCard-5-2-web.pdf)
- [R39 · Valgrind：Callgrind](https://valgrind.org/docs/manual/cl-manual.html)
- [R40 · Valgrind：Cachegrind](https://valgrind.org/docs/manual/cg-manual.html)