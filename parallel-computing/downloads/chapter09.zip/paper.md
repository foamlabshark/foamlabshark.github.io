# 第 9 章｜GPU 架构与概念

原著：Robert Robey、Yuliana Zamora，Manning，2021。原书 p.309–344 / PDF p.345–380，含第三部分 p.305–307 的导读说明。

核心段落翻译与全部编号小节讲解；保留核心原图和参数表。不是逐段全文译本。型号与价格属于历史案例。

## 小节索引

- [第 9 章导读｜GPU 架构与概念](#9-intro)
- [9.1 CPU–GPU 加速平台](#9.1)
- [9.1.1 集成 GPU 与共享内存](#9.1.1)
- [9.1.2 独立 GPU 与数据驻留](#9.1.2)
- [9.2 GPU 作为线程执行引擎](#9.2)
- [9.2.1 计算单元：CU、SM 与 subslice](#9.2.1)
- [9.2.2 处理元素不是一个完整 CPU 核](#9.2.2)
- [9.2.3 SIMD、SIMT 与线程分歧](#9.2.3)
- [9.2.4 计算理论峰值 FLOP/s](#9.2.4)
- [9.3 GPU 的内存空间](#9.3)
- [9.3.1 理论显存带宽](#9.3.1)
- [9.3.2 测量 GPU STREAM 带宽](#9.3.2)
- [9.3.3 GPU Roofline 模型](#9.3.3)
- [9.3.4 mixbench：让设备与负载匹配](#9.3.4)
- [9.4 CPU–GPU 传输开销](#9.4)
- [9.4.1 PCIe 理论带宽与协商状态](#9.4.1)
- [9.4.2 主机到设备复制基准](#9.4.2)
- [9.5 多 GPU 平台与 MPI](#9.5)
- [9.5.1 跨节点 GPU 数据传输](#9.5.1)
- [9.5.2 GPU 高速互连](#9.5.2)
- [9.6 GPU 加速的三种收益](#9.6)
- [9.6.1 缩短求解时间：CloverLeaf 案例](#9.6.1)
- [9.6.2 能耗：功率必须乘时间](#9.6.2)
- [9.6.2（续）功率采样与数值积分](#9.6.2-power)
- [9.6.2（续）单任务速度与批量吞吐](#9.6.2-throughput)
- [9.6.3 云计算成本的分析方式](#9.6.3)
- [9.7 什么时候适合 GPU](#9.7)
- [9.8 延伸探索与本章小结](#9.8)
- [9.8.1 延伸阅读](#9.8.1)
- [9.8.2 练习与参考思路](#9.8.2)

## 公式索引

- [E001](#E001) · 原书 p.313
- [E002](#E002) · 原书 p.318
- [E003](#E003) · 原书 p.320
- [E004](#E004) · 原书 p.323
- [E005](#E005) · 原书 p.326
- [E006](#E006) · 原书 p.326
- [E007](#E007) · 原书 p.337
- [E008](#E008) · 原书 p.340
- [E009](#E009) · 原书 p.342

## 术语约定

|原文|译法|说明|
|---|---|---|
|compute unit|计算单元|GPU 的计算资源组织层级|
|processing element|处理元素|不能直接等同 CPU 核|
|pinned memory|页锁定内存|防止主机页面被换出的内存|
|time-to-solution|求解时间|完整任务完成时间|
|arithmetic intensity|算术强度|每字节数据流量对应的 FLOP 数|

<a id="9-intro"></a>
## 第 9 章导读｜GPU 架构与概念
原书 p.305–310。

<a id="S001"></a>
**Source:** 原书 p.309 / PDF p.345 · S001

**Original:** This chapter provides an overview of the hardware on a GPU-accelerated platform.

**中文:** 本章概述 GPU 加速平台的硬件组成。

<a id="N001"></a>
### 先建立性能模型

**讲解：** 第三部分从硬件与内存模型开始，再进入编程模型、GPU 语言和剖析流程。本章先回答：数据在哪里、经过哪些链路、哪一部分限制速度；不是把最慢循环搬到 GPU 就一定成功。

<a id="N002"></a>
### 阅读范围

**讲解：** 保留 9.1–9.8 及全部编号子小节，以核心段落翻译与解释组织。原书 V100、A100、MI50、MI100 和 Gen11 等参数属于出版时期的示例；价格、云优惠与“最新硬件”表述不当作当前选购信息。


<a id="9.1"></a>
## 9.1 CPU–GPU 加速平台
原书 p.311–313。

<a id="F001"></a>
### 图 9.1
**Source:** 原书 p.310 / PDF p.346 · C001
**Placed near:** 9.1 CPU–GPU 加速平台

![图 9.1](assets/fig9_1.png)

**Original caption:** Block diagram of GPU-accelerated system using a dedicated GPU. The CPU and GPU each have their own memory. The CPU and GPU communicate over a PCI bus.

**中文图注:** 独立 GPU 系统中，CPU 和 GPU 各有内存，通过互连交换数据。

**Reading note:** 原图采用 PCIe 连接的典型独显模型，不代表所有平台。共享内存或一致性互连平台需要单独分析，统一地址也不等于访问成本完全相同。

<a id="S002"></a>
**Source:** 原书 p.311 / PDF p.347 · S002

**Original:** An accelerator (hardware) is a special-purpose device that supplements the main general-purpose CPU in speeding up certain operations.

**中文:** 硬件加速器是辅助通用 CPU、加快特定操作的专用设备。

<a id="N003"></a>
### 分工而非替代

**讲解：** CPU 负责控制、I/O 和适合低延迟执行的工作，GPU 擅长大量可并行操作。实际应用可有复杂的数据结构和分支，是否受益取决于实现与工作负载，而不是应用名称是否与图形相关。


<a id="9.1.1"></a>
## 9.1.1 集成 GPU 与共享内存
原书 p.312。

<a id="S003"></a>
**Source:** 原书 p.312 / PDF p.348 · S003

**Original:** Integrated GPUs share RAM resources with the CPU.

**中文:** 集成 GPU 与 CPU 共享系统内存资源。

<a id="N004"></a>
### 省去独显链路不等于没有开销

**讲解：** 集成方案可能减少显式主机到独显的数据复制，但仍存在缓存一致性、访问同步、内存带宽争用和软件映射成本。CPU 与 GPU 同时运行时，还可能分享功耗预算。

<a id="N005"></a>
### 原书比较的适用范围

**讲解：** 原书对 Ice Lake、AMD APU 的比较是当时产品语境。选择平台应检查实际精度支持、带宽与功率配置，不能把“集成一定弱、独立一定强”推广到所有代际和任务。


<a id="9.1.2"></a>
## 9.1.2 独立 GPU 与数据驻留
原书 p.313。

<a id="S004"></a>
**Source:** 原书 p.313 / PDF p.349 · S004

**Original:** Due to these limitations, a poorly designed GPU application can potentially have worse performance than that with CPU-only code.

**中文:** 由于这些限制，设计不当的 GPU 应用可能比纯 CPU 程序更慢。

<a id="N006"></a>
### 把生命周期画出来

**讲解：** 输入传到设备、设备上连续计算、最后传回必要结果。每次小操作后都来回复制，可能让链路开销超过计算收益。应把能复用的数据尽量留在设备上。

<a id="E001"></a>
**Source:** 原书 p.313 / PDF p.349 · E001

$$
T_{\mathrm{total}}=T_{\mathrm{H2D}}+T_{\mathrm{kernel}}+T_{\mathrm{D2H}}+T_{\mathrm{other}}
$$

教学补充的串行阶段模型；若传输与计算实际重叠，应按依赖的关键路径计算，不能重复计入重叠时间。


<a id="9.2"></a>
## 9.2 GPU 作为线程执行引擎
原书 p.313–316。

<a id="F002"></a>
### 图 9.2
**Source:** 原书 p.315 / PDF p.351 · C002
**Placed near:** 9.2 GPU 作为线程执行引擎

![图 9.2](assets/fig9_2.png)

**Original caption:** A simplified block diagram of a GPU system showing two compute devices, each having separate GPU, GPU memory, and multiple compute units (CUs). The NVIDIA CUDA terminology refers to CUs as streaming multiprocessors (SMs).

**中文图注:** 两个计算设备各有设备内存、工作分发逻辑和多个计算单元。

**Reading note:** CU 与 SM 是帮助对照的近似层级；不同厂商、代际的内部结构不能一一等同。原书术语表应作为阅读工具，不能拿核心数量直接比较 CPU 与 GPU 性能。

<a id="N007"></a>
### 延迟隐藏的实际含义

**讲解：** 当一组线程等待内存时，调度其他就绪工作可提升执行单元利用率。硬件驻留的线程、寄存器和共享存储数量有限；原书“无限线程、零启动成本”是强调相对优势的简化说法，kernel 启动与调度仍有开销。


<a id="9.2.1"></a>
## 9.2.1 计算单元：CU、SM 与 subslice
原书 p.316。

<a id="S005"></a>
**Source:** 原书 p.316 / PDF p.352 · S005

**Original:** A GPU compute device has multiple CUs.

**中文:** 一个 GPU 计算设备包含多个计算单元。

<a id="N008"></a>
### 该层级包含什么

**讲解：** 计算单元组织执行资源、调度和片上存储；工作组/线程块被分配到可用资源。能同时驻留多少工作，不仅由线程数决定，也受每块共享内存、每线程寄存器及硬件上限限制。

<a id="N009"></a>
### 命名带有代际背景

**讲解：** 原书将 Intel subslice 与 CU/SM 对照，适用于其概念介绍。不同架构的组织、发射吞吐和精度资源可能不同；不能把同名单元视为等价算力。


<a id="9.2.2"></a>
## 9.2.2 处理元素不是一个完整 CPU 核
原书 p.316。

<a id="S006"></a>
**Source:** 原书 p.316 / PDF p.352 · S006

**Original:** These processors are not equivalent to a CPU processor; they are simpler designs, needing to perform graphics operations.

**中文:** 这些处理元素并不等同于 CPU 处理器；其设计更简单，最初面向图形操作。

<a id="N010"></a>
### 比较时用工作量与吞吐

**讲解：** CUDA core、PE、EU 都有各自架构含义，计数口径不完全一致。GPU 的大量算术资源共享部分控制和调度设施，不能将“几千个 GPU 核”解释为几千个独立 CPU 核。


<a id="9.2.3"></a>
## 9.2.3 SIMD、SIMT 与线程分歧
原书 p.316。

<a id="N011"></a>
### 执行组与数据通道

**讲解：** SIMD 强调一条指令对多个数据元素操作；SIMT 以线程表达工作，在 warp/subgroup 等执行组中调度。执行组宽度和指令吞吐是不同量，不能见到 warp=32 就给所有峰值公式再乘 32。

<a id="N012"></a>
### 分支的成本在哪里

**讲解：** 同一执行组走不同路径时，部分通道可能暂时不活跃；并不是每个线程都无条件执行所有分支的可见副作用。独立线程调度等机制也随架构变化；分歧程度、路径长度和内存访问一起影响性能。


<a id="9.2.4"></a>
## 9.2.4 计算理论峰值 FLOP/s
原书 p.316–318。

<a id="F007"></a>
### 表 9.3
**Source:** 原书 p.317 / PDF p.353 · C007
**Placed near:** 9.2.4 计算理论峰值 FLOP/s

![图 9.T3](assets/fig9_T3.png)

**Original caption:** Specifications for recent discrete GPUs from NVIDIA, AMD, and an integrated Intel GPU

**中文图注:** 原书的 GPU 参数表，用于演示计算方法。

**Reading note:** 型号和参数保留历史语境。表中 FP32/FP64、标称/Boost 频率及内存配置需要区分；不混用 Tensor 运算与普通标量/向量浮点吞吐。

<a id="E002"></a>
**Source:** 原书 p.318 / PDF p.354 · E002

$$
P_{\mathrm{TF}}=f_{\mathrm{MHz}}\,N_{\mathrm{CU}}\,N_{\mathrm{lane/CU}}\,q/10^6
$$

q 为所计执行资源每周期的 FLOP 数。按通常性能计数，一次乘加算 2 FLOP；这不等于任意 FMA 指令都只延迟一个周期。MHz 到 GFLOP/s 应除 10³，到 TFLOP/s 除 10⁶。

<a id="K001"></a>
**代码出处：** Python · 原书 p.318 参数的教学重算，不是硬件实测

```text
peak_tflops = 1530 * 80 * 64 * 2 / 1_000_000
print(peak_tflops)  # 15.6672，原书 V100 FP32 计算口径
```

<a id="N013"></a>
### 单位与精度校核

**讲解：** 原书展示式标为 GFlops/s 却直接写 MHz 乘积，缺少换算因子；后面的 TFLOP/s 示例使用了除 10⁶。FP64 资源数和吞吐要单独计算，不能统一假设为 FP32 的一半。降低精度也不保证应用恰好快两倍。

<a id="N014"></a>
### 峰值不是持续性能

**讲解：** Boost 频率可能受功率和温度限制；访存、依赖、指令组合、分支和资源占用会压低实际吞吐。峰值适合建立上界，不是对所有输入的运行速度承诺。


<a id="9.3"></a>
## 9.3 GPU 的内存空间
原书 p.318–320。

<a id="F003"></a>
### 图 9.4
**Source:** 原书 p.319 / PDF p.355 · C003
**Placed near:** 9.3 GPU 的内存空间

![图 9.4](assets/fig9_4.png)

**Original caption:** Rectangles show each component of the GPU and the memory that is at each hardware level. The host writes and reads the global and constant memory. Each of the CUs can read and write from the global memory and read from the constant memory.

**中文图注:** 原图将私有、局部、全局和常量存储对应到 GPU 概念层级。

**Reading note:** 图采用 OpenCL 术语。OpenCL local memory 接近 CUDA shared memory；CUDA local memory 则通常指线程私有但存于设备内存的区域，不是低延迟共享暂存区。

<a id="N015"></a>
### 私有不保证在寄存器里

**讲解：** 线程私有变量可能在寄存器，也可能因大小或寄存器溢出进入其他存储。共享存储的可见性按工作组/线程块定义，不能简单认为同一个 CU 上所有工作组都能互相访问彼此的局部存储。[R46]

<a id="N016"></a>
### 容量、带宽、延迟分别看

**讲解：** 显存容量决定能容纳多大工作集；带宽决定大批量搬运速率；延迟决定一次依赖访问需等待多久。缓存、合并访问和数据复用会改变实际到达显存的流量。


<a id="9.3.1"></a>
## 9.3.1 理论显存带宽
原书 p.319–321。

<a id="E003"></a>
**Source:** 原书 p.320 / PDF p.356 · E003

$$
B_{\mathrm{GB/s}}=f_{\mathrm{GHz}}\,m\,W_{\mathrm{bit}}/8
$$

f 为所采用口径的物理时钟，m 为对应传输倍率；若给的是每引脚有效 Gbit/s 数据率 R，则直接 R×W/8，不要再重复乘 DDR 倍率。

<a id="K002"></a>
**代码出处：** Python · 原书 V100 HBM2 参数的教学重算

```text
bandwidth_gbs = 0.876 * 2 * 4096 / 8
print(bandwidth_gbs)  # 897.024 GB/s
```

<a id="N017"></a>
### 识别规格表口径

**讲解：** 内存时钟、有效数据率和整条总线带宽不是同一个量。GDDR、HBM 不同类型的时钟定义和倍率需按厂商说明核对；不能把所有 GPU 内存都套用一个固定倍数。

<a id="N018"></a>
### 小数与二进制单位

**讲解：** GB/s 采用 10⁹ 字节每秒，GiB/s 采用 2³⁰ 字节每秒。相同物理带宽数值会差约 7.4%，比较报告前应统一口径。


<a id="9.3.2"></a>
## 9.3.2 测量 GPU STREAM 带宽
原书 p.321–322。

<a id="S007"></a>
**Source:** 原书 p.321 / PDF p.357 · S007

**Original:** The Babel STREAM Benchmark code measures the bandwidth of a variety of hardware with different programming languages.

**中文:** Babel STREAM 基准通过不同编程语言实现，测量多种硬件的内存带宽。

<a id="N019"></a>
### 如何读基准结果

**讲解：** Copy、Scale、Add、Triad 等内核的读写字节数不同。应明确精度、数组大小、设备驻留、预热、重复次数和计时边界，确保计算真正完成后再报告时间。工具的构建命令随版本变化，原书命令保留为历史流程。

<a id="K003"></a>
**代码出处：** Python · 带宽算式片段；n 与 elapsed_seconds 需来自实际实验

```text
# 三个 double 数组的 Triad：两读一写的有效流量口径
bytes_per_iteration = 3 * n * 8
effective_gbs = bytes_per_iteration / elapsed_seconds / 1e9
```

<a id="N020"></a>
### 有效带宽与硬件流量

**讲解：** 上述两读一写是算法有效字节计数，不必等于硬件计数器报告的真实 DRAM 流量。缓存命中、写策略和编译优化会改变实际流量；不要把计数口径差异直接判为硬件故障。


<a id="9.3.3"></a>
## 9.3.3 GPU Roofline 模型
原书 p.322–323。

<a id="F004"></a>
### 图 9.5
**Source:** 原书 p.323 / PDF p.359 · C004
**Placed near:** 9.3.3 GPU Roofline 模型

![图 9.5](assets/fig9_5.png)

**Original caption:** Roofline plots for NVIDIA V100 and AMD Vega 20 showing the bandwidth and flop limits for the two GPUs.

**中文图注:** 原书 V100 与 Vega 20 的实测 Roofline 图，用于区分带宽上限与计算上限。

**Reading note:** 图属于历史实验，不是本机测量。读取斜率和交点前，确认算术强度的字节口径、精度以及曲线对应的内存层级。

<a id="E004"></a>
**Source:** 原书 p.323 / PDF p.359 · E004

$$
P\leq\min(P_{\max},BI),\qquad I_*=P_{\max}/B
$$

P 用 GFLOP/s，B 用 GB/s，I 用 FLOP/byte，可直接相乘。若换成 FLOP/load，必须先说明每次 load 的字节数及是否计入写流量。

<a id="N021"></a>
### 如何指导优化

**讲解：** 带宽受限时，减少数据流量、提高复用或改善访存可能比增加算术资源更有用；计算受限时再检查指令吞吐、精度与执行资源。该模型是上界，低于曲线还可能受延迟、分歧和启动开销限制。


<a id="9.3.4"></a>
## 9.3.4 mixbench：让设备与负载匹配
原书 p.324–325。

<a id="N022"></a>
### 坐标变了，约束未变

**讲解：** 原书用计算率对带宽绘图，将设备的两种能力同时展示。应用线应使用一致的算术强度单位；低强度应用偏向带宽需求，高强度应用更可能利用算术峰值。

<a id="N023"></a>
### 不能把型号选择简化成一个点

**讲解：** 原书对 GTX 1080Ti、V100 的价格与匹配判断属于历史示例。设备容量、FP64 要求、软件兼容性、数据传输和端到端耗时同样重要。矩阵乘法的算术强度随规模和分块策略变化，不固定为 65 FLOP/load。


<a id="9.4"></a>
## 9.4 CPU–GPU 传输开销
原书 p.326。

<a id="S008"></a>
**Source:** 原书 p.326 / PDF p.362 · S008

**Original:** It is often critical to limit the amount of data that gets transferred back and forth to get any speedup from the GPU.

**中文:** 要从 GPU 获得加速，往往必须限制 CPU 与 GPU 之间来回传输的数据量。

<a id="N024"></a>
### 三条不同的带宽

**讲解：** 显存带宽描述 GPU 内部读写；主机设备链路描述 CPU–GPU 传输；节点网络带宽描述跨机器通信。它们相差很大，不能用 HBM 的带宽预测 PCIe 复制时间。

<a id="E005"></a>
**Source:** 原书 p.326 / PDF p.362 · E005

$$
T_{\mathrm{copy}}\approx L+D/B
$$

教学补充：L 是固定启动等开销，D 是字节数，B 是相应方向的有效字节速率。小消息可能由 L 主导，大消息才接近带宽限制。


<a id="9.4.1"></a>
## 9.4.1 PCIe 理论带宽与协商状态
原书 p.326–329。

<a id="F008"></a>
### 表 9.5
**Source:** 原书 p.328 / PDF p.364 · C008
**Placed near:** 9.4.1 PCIe 理论带宽与协商状态

![图 9.T5](assets/fig9_T5.png)

**Original caption:** PCI Express (PCIe) specifications by generation

**中文图注:** 原书 PCIe 各代参数表，供理解计算方法。

**Reading note:** 表中 Gen1–Gen5 的 x16 数值对应单向编码后上限，不能与表头“bi-directional”混用。Gen6 行沿用 128/130 因子及 2021 年份，不宜当作最终 PCIe 6.0 规范值；6.0 采用 PAM4/FLIT，需按相应规范计算。[R47]

<a id="E006"></a>
**Source:** 原书 p.326 / PDF p.362 · E006

$$
B=L_{\mathrm{lanes}}R\eta/8
$$

这里针对原书 Gen1–Gen5 常用计算口径：Gen1/2 η=8/10，Gen3–5 η=128/130。还未扣除包头等协议开销，不能无条件外推到后续编码与调制方式。

<a id="K004"></a>
**代码出处：** Python · 原书 Gen3 x16 算式重算

```text
gen3_x16_gbs = 16 * 8 * (128/130) / 8
print(gen3_x16_gbs)  # 15.753846...，单向
```

<a id="K005"></a>
**代码出处：** Linux · 只读查看 PCIe 信息；输出完整性依权限与系统而异

```text
lspci -vv
```

<a id="N025"></a>
### LnkCap 与 LnkSta

**讲解：** LnkCap 表示能力上限，LnkSta 反映当前协商速率与宽度。标着 x16 的插槽不保证设备当前跑满 x16；还要考虑上游桥、共享通道、CPU 插槽和链路负载。


<a id="9.4.2"></a>
## 9.4.2 主机到设备复制基准
原书 p.329–332。

<a id="K006"></a>
**代码出处：** CUDA C/C++ · 清单 9.1 的语法教学片段，省略完整错误处理；不能直接当生产程序

```text
float *host = NULL, *device = NULL;
size_t bytes = (size_t)n * sizeof(float);
cudaError_t err = cudaMallocHost((void **)&host, bytes);
/* 必须检查 err；失败时停止，不继续使用 host */
err = cudaMalloc((void **)&device, bytes);
/* 分配成功后初始化 host，并在计时前预热 */
err = cudaMemcpy(device, host, bytes, cudaMemcpyHostToDevice);
err = cudaDeviceSynchronize();
/* 检查每次 API 状态，并在完成后结束计时 */
cudaFree(device);
cudaFreeHost(host);
```

<a id="N026"></a>
### 指针语法与生命周期

**讲解：** cudaMallocHost 接收指针地址并写回页锁定主机地址；cudaMalloc 返回设备地址。sizeof(float) 比固定写 4 更清楚；乘积应检查溢出。主机内存与设备内存使用各自匹配的释放函数。

<a id="N027"></a>
### 计时不要只测提交

**讲解：** GPU 操作可能异步；计时边界必须覆盖实际完成。书中使用主机计时并在重复复制后同步，测的是相应流程平均耗时。事件计时与主机端到端计时可能有不同范围，不应直接混比。

<a id="F005"></a>
### 图 9.8
**Source:** 原书 p.332 / PDF p.368 · C005
**Placed near:** 9.4.2 主机到设备复制基准

![图 9.8](assets/fig9_8.png)

**Original caption:** A theoretical peak bandwidth (horizontal lines) and an empirically measured bandwidth from the micro-benchmark application are shown for a Gen3 x16 PCIe system. The figure also shows results for both pinned and pageable memory.

**中文图注:** 原书比较页锁定与可分页主机内存的传输结果，小数据量时有效带宽较低。

**Reading note:** 清单 9.2 除以 1024³，实际得到 GiB/s；与十进制 GB/s 理论线上限比较前要统一单位，因此书中约 72% 的说法也须核对口径。

<a id="N028"></a>
### Pinned 的取舍

**讲解：** 页锁定内存有助于 DMA 和异步传输，但分配成本和对系统内存的影响需考虑。它仍是主机 DRAM，不是 GPU 显存；不应把所有主机内存都长期锁定。[R46]


<a id="9.5"></a>
## 9.5 多 GPU 平台与 MPI
原书 p.332–333。

<a id="N029"></a>
### 进程与设备映射

**讲解：** 一种常见方案是每个 MPI rank 驱动一个 GPU，也可多个 rank 共享设备。先明确每节点本地 rank、可见设备编号与资源分配，避免所有进程误选 GPU 0。具体最优方案取决于硬件与运行时。

<a id="N030"></a>
### 沿数据路径分析

**讲解：** 节点内 GPU–GPU、跨 CPU 插槽 GPU–GPU、跨节点通信的路径不同。即使设备型号相同，连接到不同 PCIe 根或网卡的放置也可能产生明显性能差异。


<a id="9.5.1"></a>
## 9.5.1 跨节点 GPU 数据传输
原书 p.333–334。

<a id="N031"></a>
### 传统路径

**讲解：** 源 GPU 数据先到主机缓冲区，再经网络到远端主机，最后传给目标 GPU。额外复制和同步都应计入端到端时间；单独测 kernel 容易忽略这些成本。

<a id="N032"></a>
### 区分三种能力

**讲解：** GPU-aware MPI 表示 MPI 能处理设备缓冲；节点内 peer-to-peer 和跨节点 GPUDirect RDMA 是不同路径能力。设备指针不能作为远端可直接解引用的地址传过去。是否绕过主机暂存取决于软硬件支持，不能只看到名字就假定生效。

<a id="N033"></a>
### 通信前的数据必须就绪

**讲解：** GPU kernel 产生输出后，应按照 GPU 运行时与 MPI 实现支持的同步规则交接。MPI 返回、设备流就绪和远端计算可开始是不同事件，不能靠隐含假设连接。


<a id="9.5.2"></a>
## 9.5.2 GPU 高速互连
原书 p.334。

<a id="N034"></a>
### 读带宽数字先读口径

**讲解：** NVLink、Infinity Fabric 等名称覆盖不同代际和拓扑。单链路、设备所有链路汇总、单向和双向是不同指标；原书 300 GB/s 不能直接代入某一次点对点复制的 B。

<a id="N035"></a>
### 历史名称校核

**讲解：** 原书把 P100 和 V100 一起归入 Volta 不准确：P100 属 Pascal，V100 属 Volta。这里保留其“更快互连可减轻搬运瓶颈”的主旨，不将历史型号描述作为当前规格表。


<a id="9.6"></a>
## 9.6 GPU 加速的三种收益
原书 p.334–335。

<a id="N036"></a>
### 分别定义目标

**讲解：** 更短的单任务完成时间、更低的总能耗、更低的完成任务成本，不一定对应同一配置。还要计入迁移开发、验证、维护和软件依赖的投入。

<a id="N037"></a>
### 以完整应用为基准

**讲解：** 比较相同问题、精度、收敛标准和输出要求。GPU 内核快十倍，不表示包含初始化、I/O、通信的总程序快十倍；原书案例的加速比只能说明其测试环境。


<a id="9.6.1"></a>
## 9.6.1 缩短求解时间：CloverLeaf 案例
原书 p.335–337。

<a id="N038"></a>
### 原书数据

**讲解：** 500 个周期：Ivy Bridge 为 615.1 秒、Skylake 为 273.3 秒、V100 为 59.3 秒。按同口径比值，GPU 分别约快 10.37 倍和 4.61 倍；这些是原书历史数据，不是当前电脑的测试。

<a id="K007"></a>
**代码出处：** Python · 原书 p.335–336 的线性外推重算

```text
base, newer_cpu, gpu = 615.1, 273.3, 59.3
print(base/gpu, newer_cpu/gpu)
full_hours = gpu / 500 * 500_000 / 3600
print(full_hours)  # 约 16.47 小时
```

<a id="N039"></a>
### 外推的假设

**讲解：** 把 500 周期外推到 50 万周期，假设每步成本不变。网格自适应、输出频率、收敛变化、通信增长和长时间降频都可能破坏这一假设。应用决策应使用代表性长运行验证。


<a id="9.6.2"></a>
## 9.6.2 能耗：功率必须乘时间
原书 p.337–342。

<a id="F009"></a>
### 表 9.6
**Source:** 原书 p.337 / PDF p.373 · C009
**Placed near:** 9.6.2 能耗：功率必须乘时间

![图 9.T6](assets/fig9_T6.png)

**Original caption:** Designing a 10 TB/s bandwidth GPU and CPU system.

**中文图注:** 原书假设构建约 10 TB/s 带宽系统的成本与能耗表。

**Reading note:** 价格和带宽为历史假设，且未完整计入 GPU 主机、网络、内存和冷却。TDP 是设计相关指标，不是实际功率测量，也不是普适能耗上界。

<a id="E007"></a>
**Source:** 原书 p.337 / PDF p.373 · E007

$$
E_{\mathrm{kWh}}=NP_{\mathrm{W}}t_{\mathrm{h}}/1000
$$

仅在功率按常数估计时使用；实际变化功率应积分。12×300×24/1000=86.4 kWh，45×140×24/1000=151.2 kWh。

<a id="N040"></a>
### 原书数量不一致

**讲解：** 正文有“15 个处理器”“4 个 GPU”，但算式和表使用 45 个 CPU、12 个 GPU。应采用一致数量再比较：86.4 相对 151.2 少约 42.9%，不能把不同数量的正文和公式混算。


<a id="9.6.2-power"></a>
## 9.6.2（续）功率采样与数值积分
原书 p.339–341。

<a id="F006"></a>
### 图 9.11
**Source:** 原书 p.341 / PDF p.377 · C006
**Placed near:** 9.6.2（续）功率采样与数值积分

![图 9.11](assets/fig9_11.png)

**Original caption:** Power consumption for the CloverLeaf problem running on the V100. We integrate under the power curve to get 10.4 kJ for a run that lasted about 60 seconds. The rate of power consumption is about 61% of the nominal power specification for the V100 GPU.

**中文图注:** 原书 CloverLeaf 的 GPU 功率与利用率随时间变化。

**Reading note:** 利用率高不代表功率达到 TDP。图中的能量取决于实际采样时间窗；若比较整个系统，应包含主机等设备，且明确是否扣除空闲功耗。

<a id="E008"></a>
**Source:** 原书 p.340 / PDF p.376 · E008

$$
E_{\mathrm{J}}\approx\sum_i\frac{P_i+P_{i+1}}{2}(t_{i+1}-t_i)
$$

教学整理：梯形积分适用于时间戳和功率样本。J/3.6×10⁶ 得 kWh；采样过稀可能漏掉快速变化，不能只乘样本数量。

<a id="K008"></a>
**代码出处：** Python · 清单 9.3 积分思路的独立教学实现

```text
def energy_joules(times, watts):
    if len(times) != len(watts) or len(times) < 2:
        raise ValueError("need matching samples")
    if any(b <= a for a,b in zip(times,times[1:])):
        raise ValueError("timestamps must increase")
    return sum((a+b)/2*(t1-t0)
               for a,b,t0,t1 in zip(watts,watts[1:],times,times[1:]))
```

<a id="N041"></a>
### 监控代码如何阅读

**讲解：** 原书脚本从 nvidia-smi 日志提取时间、功率和利用率。实际解析前要确认列名、单位和缺失值；跨午夜不能只减 HH:MM:SS，宜使用完整时间戳。工具输出随版本和设备变化，不硬编码所有列的位置。


<a id="9.6.2-throughput"></a>
## 9.6.2（续）单任务速度与批量吞吐
原书 p.341–342。

<a id="N042"></a>
### 原书的 100 个作业

**讲解：** 200 个处理器：每作业用 20 个、耗时 10 小时，可同时跑 10 个，总计 100 小时。若改为每作业 40 个，在相对扩展效率 80% 时单作业用时 6.25 小时，但只能同时跑 5 个，总计 125 小时。

<a id="E009"></a>
**Source:** 原书 p.342 / PDF p.378 · E009

$$
T_{\mathrm{suite}}=\left\lceil J/\lfloor C/p\rfloor\right\rceil t_p
$$

教学模型：J 个等长作业，C 份资源，每作业 p 份，运行时间 t_p。假设无排队、无失败、无跨作业争用，且 p≤C。

<a id="N043"></a>
### 目标不同结论不同

**讲解：** 加资源缩短单任务等待时间，却可能降低整批任务的吞吐和资源效率。对真实调度，应同时看期限、资源费用与共享系统争用，不能只追求最高并行度。


<a id="9.6.3"></a>
## 9.6.3 云计算成本的分析方式
原书 p.342–343。

<a id="N044"></a>
### 比较完成任务的成本

**讲解：** 用实际计费单价乘完整运行时长，再加存储、传输及可能的重试成本。每小时便宜不一定每个结果便宜；显存不足导致换页或必须改算法，也会改变成本。

<a id="N045"></a>
### 历史示例不作报价

**讲解：** 原书提到云平台的设备与可抢占资源。这里讲比较方法，不提供未经查询的当前价格或优惠。可抢占方案需纳入中断、检查点和恢复时间；先确认任务可容忍这些行为。


<a id="9.7"></a>
## 9.7 什么时候适合 GPU
原书 p.343。

<a id="N046"></a>
### 适合的条件

**讲解：** 有足够并行工作、可批量处理、数据可复用且传输成本可摊薄时，GPU 较有潜力。先估算规模、访存、精度和总流程，再用代表性小例子测量。

<a id="N047"></a>
### 原书限制需按条件理解

**讲解：** 不规则访问、严重分歧、动态分配和深递归可能带来成本，但不是所有 GPU 编程模型都完全禁止。设备端分配和递归支持依语言、架构与工具链而定；稀疏或不规则问题也可能通过数据重排受益。

<a id="N048"></a>
### 先验证数值，再看速度

**讲解：** 改变精度或归约顺序后应按误差、稳定性和收敛标准校验。不能以更快但改变问题或答案质量的实现，宣称同一任务取得了无条件加速。


<a id="9.8"></a>
## 9.8 延伸探索与本章小结
原书 p.343–344。

<a id="S009"></a>
**Source:** 原书 p.343 / PDF p.379 · S009

**Original:** GPU architectures continue to evolve with each iteration of hardware design.

**中文:** GPU 架构随着每一代硬件设计持续演进。

<a id="N049"></a>
### 带走三个模型

**讲解：** 用峰值 FLOP/s 判断计算上界，用带宽和算术强度判断数据瓶颈，用传输及端到端计时判断迁移是否值得。具体型号会更新，这三种分析方法仍可用于新设备。


<a id="9.8.1"></a>
## 9.8.1 延伸阅读
原书 p.343–344。

<a id="N050"></a>
### 原书阅读方向

**讲解：** Deakin 等关于跨并行模型 STREAM 带宽的工作、Yang 与 Williams 的 GPU Roofline 材料，以及 Konstantinidis 与 Cotronis 的定量 GPU Roofline 论文。重点比较其测量假设、字节计数和精度口径，不只摘取一个峰值。

<a id="N051"></a>
### 技术资料怎么用

**讲解：** 本讲义为内存术语与计时补充 NVIDIA 官方最佳实践资料，为 Gen6 编码区别补充 PCI-SIG 资料；它们用于校核概念，不表示要求用户安装特定硬件或工具。


<a id="9.8.2"></a>
## 9.8.2 练习与参考思路
原书 p.344。

<a id="N052"></a>
### 练习一：性能与价格

**讲解：** 原书表 9.7 要求计算指定算术强度下的可达性能并补充当时价格。正确做法是先统一 FLOP/byte、精度和带宽，再取 min(P_max,B×I)。若做现实采购，应重新查询具体型号与当前价格，不沿用书中空白表的时代背景。

<a id="N053"></a>
### 练习二：测量能量

**讲解：** 选择可验证的应用，保存完整功率时间序列，记录设备、采样间隔、运行范围和结果正确性。用梯形积分计算能量，并说明是否计入主机与空闲功率。

<a id="N054"></a>
### 本章附带练习

**讲解：** Python 模型复算峰值、带宽、PCIe Gen3、CloverLeaf 外推、能量积分和作业吞吐。它们仅验证算式与边界，不执行 GPU 测试。CUDA 片段是语法讲解，完整内核编程将在后续章节展开。


## 技术核对来源

- [R46 · NVIDIA CUDA 最佳实践](https://docs.nvidia.com/cuda/archive/13.2.1/cuda-c-best-practices-guide/index.html)
- [R47 · PCI-SIG：PCIe 6.0 的 PAM4](https://pcisig.com/blog/why-did-pcie%C2%AE-60-specification-adopt-pam4-there-are-many-reasons)