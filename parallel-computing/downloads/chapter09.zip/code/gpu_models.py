"""Chapter 9 teaching arithmetic. Does not query or benchmark a GPU."""
from math import ceil,isclose,isfinite

def peak(mhz,units,lanes,q):return mhz*units*lanes*q/1e6

def energy(times,watts):
    if len(times)!=len(watts) or len(times)<2:raise ValueError('need matching samples')
    if not all(isfinite(v) for v in times+watts):raise ValueError('finite values required')
    if any(p<0 for p in watts) or any(b<=a for a,b in zip(times,times[1:])):raise ValueError('invalid samples')
    return sum((a+b)/2*(y-x) for a,b,x,y in zip(watts,watts[1:],times,times[1:]))

def suite(jobs,capacity,per_job,hours):
    if jobs<0 or per_job<1 or capacity<per_job or hours<0:raise ValueError('invalid resources')
    return ceil(jobs/(capacity//per_job))*hours

def check():
    assert isclose(peak(1530,80,64,2),15.6672)
    assert isclose(.876*2*4096/8,897.024)
    assert isclose(16*8*(128/130)/8,15.753846153846155)
    assert isclose(59.3/500*500000/3600,16.47222222222222)
    assert isclose(12*300*24/1000,86.4)
    assert isclose(45*140*24/1000,151.2)
    assert energy([0,10],[100,100])==1000
    assert energy([0,1,3],[0,100,100])==250
    assert energy([0,3600],[1000,1000])/3.6e6==1
    assert suite(100,200,20,10)==100
    assert suite(100,200,40,6.25)==125
    assert suite(0,200,20,10)==0
    for t,p in [([0],[10]),([0,0],[1,2]),([0,1],[-1,2]),([0,float('nan')],[1,2])]:
        try:energy(t,p)
        except ValueError:pass
        else:raise AssertionError('invalid sample accepted')
    print('Peak, bandwidth, PCIe, runtime, energy and job-throughput checks passed; no GPU execution.')
if __name__=='__main__':check()
