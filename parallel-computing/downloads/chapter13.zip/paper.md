# 第 13 章｜GPU 性能剖析与工具

原著：Robert Robey、Yuliana Zamora，Manning，2021。原书 p.460–487 / PDF p.496–523。

按原书小节阅读核心段落译文、图 13.1–13.13 和代码讲解。

## 小节索引

- [第 13 章导读｜GPU 性能剖析与工具](#13-intro)
- [13.1 选择能回答问题的性能工具](#13.1)
- [13.2 四种采集与查看方式](#13.2)
- [13.3 浅水模拟：从滑坡到水柱](#13.3)
- [13.3（续）静水压力与守恒通量](#13.3-flux)
- [13.4 用一个程序贯穿性能分析](#13.4)
- [13.4.1 构建浅水程序并观察波形](#13.4.1)
- [13.4.2 CPU 基线：把热点定位到循环](#13.4.2)
- [13.4.3 把计算循环移到 GPU](#13.4.3)
- [13.4.3（续）从时间线追溯一次复制](#13.4.3-trace)
- [13.4.4 让状态数组跨迭代驻留](#13.4.4)
- [13.4.4（实验）读两块 GPU 的 OpenCL 事件](#13.4.4-lab)
- [13.4.5 解读自动分析建议](#13.4.5)
- [13.4.6 使用 Nsight 定位问题](#13.4.6)
- [13.4.7 从 CodeXL 案例迁移到 AMD 工具](#13.4.7)
- [13.5 用三个指标提出可检验的问题](#13.5)
- [13.5.1 Occupancy 与可调度工作](#13.5.1)
- [13.5.2 发射效率与停顿原因](#13.5.2)
- [13.5.3 实际带宽与数据复用](#13.5.3)
- [13.6 把开发环境与采集环境分开](#13.6)
- [13.6.1 Docker 容器与设备访问](#13.6.1)
- [13.6.2 VirtualBox 来宾环境](#13.6.2)
- [13.7 在云端采集性能数据](#13.7)
- [13.8 延伸探索与小结](#13.8)
- [13.8.1 延伸阅读](#13.8.1)
- [13.8.2 练习与参考思路](#13.8.2)

## 公式索引

- [E001](#E001)
- [E002](#E002)
- [E003](#E003)
- [E004](#E004)

## 术语约定

|原文|译法|说明|
|---|---|---|
|profiling|性能剖析|测量程序各部分的资源与耗时|
|timeline|时间线|按时间顺序排列的执行与传输事件|
|eligible warp|可发射的 warp|已驻留且当前可执行下一条指令的子组|
|issue efficiency|发射效率|实际发射率相对可达发射率的比例|
|wall time|墙钟时间|主机侧观测到的经过时间|

<a id="13-intro"></a>
## 第 13 章导读｜GPU 性能剖析与工具
原书 p.460。

<a id="S001"></a>
**Source:** 原书 p.460 / PDF p.496 · S001

**Original:** In this chapter, we will cover the tools and the different workflows that you can use to accelerate your application development. We’ll show you how profiling tools for the GPU can be helpful.

**中文:** 本章介绍能加快应用开发的工具和几种工作流程。作者以 GPU 程序为例，说明性能剖析工具可以怎样帮助开发者。

<a id="N001"></a>
### 沿着一轮模拟读下去

**讲解：** 浅水程序的一轮迭代要处理边界、估算时间步、计算两个方向的面通量，再更新单元。作者先在 CPU 上找出用时最长的循环，再到 GPU 时间线上追问：这些时间花在求解方程，还是在搬运为求解准备的数据？

<a id="N002"></a>
### 本章实验

**讲解：** 原书图 13.1–13.13 保留了当时的工具界面。讲义另附独立的 OpenCL 事件记录，可以跟随 13.4.4 的续页，在同一输入上比较每轮复制和设备驻留两种做法。


<a id="13.1"></a>
## 13.1 选择能回答问题的性能工具
原书 p.460–461。

<a id="S002"></a>
**Source:** 原书 p.461 / PDF p.497 · S002

**Original:** NVIDIA SMI gives you hardware information along with many other system metrics.

**中文:** NVIDIA SMI 可以报告硬件信息以及多种系统指标。

<a id="N003"></a>
### 分三层观察

**讲解：** 想知道程序使用哪块卡、温度多高、功率怎样随时间变化，可以先看设备监控。要区分 CPU 等待、主机设备复制与 kernel 执行，需要时间线。要解释某个 kernel 内为何停顿，则需要更细的指令与内存计数器。采样周期很长的监控曲线容易漏掉短 kernel。

<a id="K001"></a>
**代码出处：** Shell · 查询设备名、利用率和显存使用量；读字段时留意单位和采样窗口

```text
nvidia-smi --query-gpu=name,utilization.gpu,memory.used --format=csv
```

<a id="N004"></a>
### 原书工具名

**讲解：** nvprof 负责采集，NVVP 用图形界面查看数据，PGPROF 源于 PGI。阅读后面的截图时保留这些名字。NVIDIA 的 Nsight Systems 与 Nsight Compute 分别适合系统时间线与单个 kernel 的深入分析，文末给出对应手册。


<a id="13.2"></a>
## 13.2 四种采集与查看方式
原书 p.462–463。

<a id="S003"></a>
**Source:** 原书 p.462 / PDF p.498 · S003

**Original:** Accessibility and connection speed are the determining factors in deciding which method you end up using.

**中文:** 最终采用哪种方法，主要取决于能否访问计算系统，以及连接速度如何。

<a id="F001"></a>
### 图 13.1
**Source:** 原书 p.462 / PDF p.498 · C001
**Placed near:** 13.2 四种采集与查看方式

![图 13.1](assets/fig13_1.png)

**Original caption:** There are several different methods of using the profiling tools that give you  alternatives for your application development situation.

**中文图注:** 四种工作方式把 GPU 执行、报告存储与图形界面放在不同位置。

**Reading note:** 从左向右读，分别是直接在系统运行、使用远端服务、下载剖析文件，以及先在本机开发。图中的防火墙和磁盘说明，能否搬动报告与能否交互显示是两个条件。

<a id="N005"></a>
### 如何作选择

**讲解：** 在工作站上能直接看图，就地采集和查看最方便。远端集群若支持工具的客户端/服务端模式，可让界面留在本地。批作业场景可先保存报告，再下载打开。只有本地开发设备时，可先复现数据依赖和热点，最后在目标机器重新测量。

<a id="K002"></a>
**代码出处：** Shell · 下载已有报告的命令示意。cluster 为配置好的主机名，句点表示当前目录。

```text
scp cluster:reports/case.nsys-rep .
```

<a id="N006"></a>
### 可比较的报告

**讲解：** 保存程序版本、问题大小、步数、编译选项、GPU 型号及测量区间。查看端需要能读取采集端的报告格式。手工导出的 CSV 便于统计，但可能缺少原始报告里的事件关联。


<a id="13.3"></a>
## 13.3 浅水模拟：从滑坡到水柱
原书 p.463–464。

<a id="F002"></a>
### 图 13.2
**Source:** 原书 p.464 / PDF p.500 · C002
**Placed near:** 13.3 浅水模拟：从滑坡到水柱

![图 13.2](assets/fig13_2.png)

**Original caption:** The tsunami wave that occurred at Anak Krakatau on December 22, 2018, was  caused by a sediment slide from the volcanic island.

**中文图注:** 火山岛侧翼滑坡扰动水体，形成向外传播的波。原图署名 Cristian Gomez。

**Reading note:** 这一图解释初始扰动的来源。后面的示例用简化网格观察波传播和计算开销，没有建立真实海岸线、滑坡过程与灾害预报所需的全部条件。

<a id="S004"></a>
**Source:** 原书 p.464 / PDF p.500 · S004

**Original:** The mathematical equations for the tsunami are relatively simple. These are conservation of mass and conservation of momentum.

**中文:** 作者用两个守恒原理描述这一简化问题，即质量守恒和动量守恒。

<a id="N007"></a>
### 先理解一个单元

**讲解：** 在固定水平面积 A 上，若水密度 ρ 为常数，单元质量是 ρAh。水流从左面流入、从右面流出时，单元水深 h 的变化由两个面的净流量决定。程序保存的 H 是水深，U=hu 和 V=hv 分别是两个方向的单位宽流量，也就是按密度归一化的水深积分动量。


<a id="13.3-flux"></a>
## 13.3（续）静水压力与守恒通量
原书 p.465–467。

<a id="F003"></a>
### 图 13.3
**Source:** 原书 p.465 / PDF p.501 · C003
**Placed near:** 13.3（续）静水压力与守恒通量

![图 13.3](assets/fig13_3.png)

**Original caption:** The force of gravity on the column  of water creates flow and momentum.

**中文图注:** 一根水柱内的压强随深度变化，会在相邻单元的界面产生压力作用。

**Reading note:** 竖直方向上由重力维持静水平衡；水平方向的动量变化与两侧深度积分压力的差有关。水面水平、静止时，两侧压力通量平衡。

<a id="F004"></a>
### 图 13.4
**Source:** 原书 p.466 / PDF p.502 · C004
**Placed near:** 13.3（续）静水压力与守恒通量

![图 13.4](assets/fig13_4.png)

**Original caption:** The hydrostatic  pressure caused by the force of gravity is a linear function of depth. pm g h midpoint hg h 2-- - 1 2-- -gh 2 == = h t----- - hu x------------- - hv y------------- + +0=  hu t------------- - x-----hu 2 1 2-- -gh 2 +   y-----huv++ 0=  hv t------------- x-----hvu  y-----hv 2 1 2-- -gh 2 + ++ 0=

**中文图注:** 压强随深度线性增加，积分可以用三角形面积计算。

**Reading note:** 取深度 z 自水面向下，表压 p=ρgz。将三角形面积除以密度得到 gh²/2。它是动量通量中的压力贡献，单位与 hu² 一致。

<a id="E001"></a>
**Source:** 原书 p.465 / PDF p.501 · E001

$$
\partial_t h+\partial_x(hu)+\partial_y(hv)=0
$$

无质量源时，水深的增加等于水平净流入。两个通量导数各自沿对应坐标求取。

<a id="E002"></a>
**Source:** 原书 p.466 / PDF p.502 · E002

$$
\partial_t(hu)+\partial_x(hu^2+gh^2/2)+\partial_y(huv)=0
$$

以平底、忽略额外源项的教材模型为例。第三项是 y 方向水流携带的 x 动量。

<a id="E003"></a>
**Source:** 原书 p.466 / PDF p.502 · E003

$$
\partial_t(hv)+\partial_x(huv)+\partial_y(hv^2+gh^2/2)=0
$$

把上式沿两个坐标的角色交换，就得到 y 动量方程。在有地形或摩擦的模型中还要处理相应源项。

<a id="N008"></a>
### 从面通量读出循环依赖

**讲解：** 原书先估算半个时间步时的面状态，再用这些面上的通量更新单元。两个相邻单元共用一个面的通量，在两侧更新中符号相反。这既解释了离散守恒，也解释了为何单元更新需要等到面数据就绪。

<a id="K003"></a>
**代码出处：** C · 单元更新的方向与符号，对应原书 p.465–467；面通量与时间步由数值方法提供

```text
// 教学片段：H 是水深，Fx 和 Fy 此处只代表质量通量
Hnew[k] = H[k] - dt/dx * (Fx_right - Fx_left)
               - dt/dy * (Fy_top   - Fy_bottom);
```


<a id="13.4"></a>
## 13.4 用一个程序贯穿性能分析
原书 p.467。

<a id="N009"></a>
### 给改动留下参照

**讲解：** 先运行固定网格与固定步数的串行版本，记录总质量、主要场量与墙钟时间。随后依次比较 CPU、仅迁移计算的 par1、扩大设备数据区域的 par2。若图形输出频率变化，应单独记录 I/O 和显示时间。


<a id="13.4.1"></a>
## 13.4.1 构建浅水程序并观察波形
原书 p.467–469。

<a id="S005"></a>
**Source:** 原书 p.468 / PDF p.504 · S005

**Original:** We have found that real-time graphics can accelerate code development and debugging, so we included a sample of how to use them in the example code accompanying this chapter.

**中文:** 作者发现实时图形能加快程序开发与调试，因此在本章配套代码中加入了可视化示例。

<a id="K004"></a>
**代码出处：** Shell · 原书 CMake 步骤的目录外构建写法，在配套浅水工程根目录执行，图形选项依该工程定义

```text
cmake -S . -B build -DENABLE_GRAPHICS=1
cmake --build build
```

<a id="N010"></a>
### 命令语法

**讲解：** -S . 指当前源码目录，-B build 指定构建目录。-D 向 CMake 设置缓存变量，--build 调用已配置的构建系统。图形版用颜色表示 H，用网格线标出单元，原书每 100 次迭代更新一次。性能对照要选定同一种图形配置。

<a id="F005"></a>
### 图 13.5
**Source:** 原书 p.469 / PDF p.505 · C005
**Placed near:** 13.4.1 构建浅水程序并观察波形

![图 13.5](assets/fig13_5.png)

**Original caption:** Real-time graphics output from the shallow water application. The red  stripes on the left indicate the beginning of the wave, where the landslide enters the water. The wave progresses to the right as it cross the ocean: orange, yellow, green, and blue. If you’re reading this in black and white, the left shaded region corresponds to the red, and the far right shaded region corresponds to the blue. The lines are the outlines of the computational cells.

**中文图注:** 初始波形在左侧，颜色表示波高，直线是计算单元边界。

**Reading note:** 看图可以识别波传播方向和边界反射。更严格的回归检查可比较同一时刻的 H、U、V 数组与总质量，既能捕捉明显异常，也能发现肉眼看不见的数值偏移。


<a id="13.4.2"></a>
## 13.4.2 CPU 基线：把热点定位到循环
原书 p.470–471。

<a id="S006"></a>
**Source:** 原书 p.470 / PDF p.506 · S006

**Original:** Cachegrind shows that 100% of the time is spent in the main function, which doesn’t help us much. We need a line-by-line profiler for this particular situation.

**中文:** 在作者的例子里，函数层面只看出开销都在 main 中，仍然无法选择循环。这个场景需要继续定位到源码行。

<a id="K005"></a>
**代码出处：** Shell · 支持 gprof 的 Unix 工具链示意。-pg 在编译和链接阶段启用插桩，-g 保留源码行信息

```text
cmake -S . -B build-prof -DCMAKE_C_FLAGS="-O3 -g -pg"
cmake --build build-prof
./build-prof/ShallowWater
gprof -l ./build-prof/ShallowWater gmon.out
```

<a id="N011"></a>
### 怎样从采样表决定顺序

**讲解：** 书中第二遍单元更新约占 42.95%，y 面与 x 面分别为 22.44% 和 22.34%，时间步计算为 12.06%。先查看最大的一项，再审查它读取的面数组来自哪里。行号随源码变动，名称和读写关系更可靠。

<a id="N012"></a>
### 数据口径

**讲解：** gprof 的采样分布、Cachegrind 的模拟事件和墙钟时间各有含义。把网格从 500×200 放大到 5000×2000 会改变工作集和缓存行为；采样足够多以后，仍须检查新规模是否代表实际任务。


<a id="13.4.3"></a>
## 13.4.3 把计算循环移到 GPU
原书 p.471–472。

<a id="S007"></a>
**Source:** 原书 p.471 / PDF p.507 · S007

**Original:** The implementation starts with porting the code to the GPU by moving the computation loop.

**中文:** 实现从迁移计算循环开始，让它在 GPU 上执行。

<a id="K006"></a>
**代码出处：** OpenACC C · 清单 13.1 左侧反射边界节选；假设数组映射有效、下标 0 为幽灵列

```text
#pragma acc parallel loop
for (int j=1; j<=ny; ++j) {
    H[j][0] = H[j][1];
    U[j][0] = -U[j][1];
    V[j][0] = V[j][1];
}
```

<a id="N013"></a>
### 为什么只给 U 加负号

**讲解：** 在垂直于 x 轴的反射壁面，法向动量 U 反向，切向动量 V 维持方向，H 镜像复制。循环从 j=1 到 ny，分别写入不同的边界单元。换到水平壁面时，两种动量的角色也要交换。

<a id="N014"></a>
### 区分两种复制

**讲解：** 清单 13.2 在设备上将 Hnew、Unew、Vnew 的内部值写回旧数组。这段复制消耗设备内存带宽。时间线上标为 HtoD/DtoH 的事件则是主机和设备间的数据移动。排查时应分别定位。


<a id="13.4.3-trace"></a>
## 13.4.3（续）从时间线追溯一次复制
原书 p.472–473。

<a id="K007"></a>
**代码出处：** Shell · 原书 NVVP 工具流程，第一行在兼容的采集环境生成报告，第二行打开该报告

```text
nvprof --export-profile par1.prof ./ShallowWater_par1
nvvp par1.prof
```

<a id="F006"></a>
### 图 13.6
**Source:** 原书 p.473 / PDF p.509 · C006
**Placed near:** 13.4.3（续）从时间线追溯一次复制

![图 13.6](assets/fig13_6.png)

**Original caption:** With NVIDIA’s NVVP, you can zoom into specific copies in the timeline view. Here, you can see a  zoomed in version of individual memory copies within each cycle. This allows you to see what lines these are on to help you easily refer back to the application.

**中文图注:** 放大一个迭代周期，时间线上出现与特定代码行对应的内存复制。

**Reading note:** 先选一个稳定迭代，记录起止时刻、复制方向和字节数；再查看那一行的计算区域和映射子句。长条表示经历的时间，宽度相近的两个事件也可能搬运不同的数据量。

<a id="N015"></a>
### 分母会动

**讲解：** 横向比较不同视图前先核对时间轴比例。某次复制在时间线中占主导，可能源于次数多、数据大、或每次传输的固定延迟高。只有知道次数、字节数与持续时间，才好决定扩大数据区域还是合并小传输。


<a id="13.4.4"></a>
## 13.4.4 让状态数组跨迭代驻留
原书 p.473–474。

<a id="S008"></a>
**Source:** 原书 p.473 / PDF p.509 · S008

**Original:** The next step in porting the code to the GPU is the addition of data movement directives. This allows us to further improve the application performance by eliminating expensive memory copies.

**中文:** 迁移的下一步是加入控制数据移动的指令。通过消除代价高的内存复制，还可以进一步提高程序性能。

<a id="K008"></a>
**代码出处：** OpenACC C · 根据清单 13.3 改写的数据区域片段，不含浅水求解步骤

```text
// H 已在主机初始化，Hnew 是设备上将被完整写入的临时数组
#pragma acc enter data copyin(H[0:n]) create(Hnew[0:n])
// 教学片段：此处用平坦数组表现数据生命周期
#pragma acc parallel loop present(H[0:n], Hnew[0:n])
for (int i=0; i<n; ++i) Hnew[i] = H[i];
// 后续迭代在同一设备使用这些映射
#pragma acc exit data copyout(Hnew[0:n]) delete(H[0:n])
```

<a id="N016"></a>
### 逐个读子句

**讲解：** copyin 提供初值，create 提供尚待写入的设备空间。present 要求相应范围已映射。若图形程序要在主机读取某一步的 H，可在该时点更新主机副本。原书二级下标涉及具体数组布局，示例用一维连续数组来明确传输范围。

<a id="F007"></a>
### 图 13.7
**Source:** 原书 p.474 / PDF p.510 · C007
**Placed near:** 13.4.4 让状态数组跨迭代驻留

![图 13.7](assets/fig13_7.png)

**Original caption:** This timeline from NVIDIA’s Visual Profiler NVVP shows four iterations of the computation but now  with data movement optimizations. What is interesting in this figure is not so much what you can see, but what is not there. The data movement that occurred in the previous figure is sharply reduced or no longer exists.

**中文图注:** 控制数据驻留后，多个连续迭代中的主机设备复制大幅减少。

**Reading note:** 与图 13.6 对照时，选相同的数值阶段。确认预期 kernel 仍在、结果仍正确，再检查重复复制条带是否消失。单看较空的时间线也可能误判漏掉的工作。


<a id="13.4.4-lab"></a>
## 13.4.4（实验）读两块 GPU 的 OpenCL 事件
原书 p.473–474。

<a id="N017"></a>
### 教学实验的输入

**讲解：** 取 262144 个 double 元素，a[i]=i，b[i]=1，计算 c[i]=a[i]+2b[i]。预热后重复计算八次，最终只需要最后一次输出。对照版每轮传入两数组、传回一个数组；驻留版仅在开头传入，在结尾传回。两者逐项比对所有输出。

<a id="K009"></a>
**代码出处：** Python · profile_triad.py 为队列启用 profiling，读取每条命令的 START 与 END 时间戳

```text
elapsed_ms = (event_end_ns - event_start_ns) / 1_000_000
copy_bytes = (number_of_writes + number_of_reads) * bytes_per_array
```

<a id="N018"></a>
### 预期在时间线上看到什么

**讲解：** 每数组 2 MiB。对照版 16 写、8 读和 8 个 kernel，合计 32 条命令、48 MiB 逻辑复制量。驻留版 2 写、1 读和 8 个 kernel，合计 11 条命令、6 MiB。API 的逻辑复制量与实际经过某条物理总线的字节数需要分开统计。

<a id="N019"></a>
### 本次实测

**讲解：** RTX 4060 Laptop GPU 的两次对照版墙钟时间为 7.37、7.16 ms，两次驻留版为 1.76、1.48 ms。gfx1103 的相应结果为 14.93、15.16 ms 和 4.14、3.50 ms。墙钟区间包括 Python 提交和阻塞读回，驻留同时减少了等待次数。这里只对该输入与本次运行作比较。

<a id="K010"></a>
**代码出处：** 本机实测 · 每种模式首次记录的八轮事件时长之和；墙钟包含主机调用与等待

```text
设备 / 版本              H2D(ms)   kernel(ms)   D2H(ms)   墙钟(ms)
RTX 4060 Laptop / 每轮复制     2.667     0.080     1.349     7.373
RTX 4060 Laptop / 设备驻留     0.539     0.151     0.195     1.755
gfx1103 / 每轮复制     6.533     0.914     2.651    14.934
gfx1103 / 设备驻留     0.990     1.735     0.498     4.139
```

<a id="N020"></a>
### 复现与读数

**讲解：** 下载本章包，在 Windows 上运行 python code/profile_triad.py。需要支持 FP64 与组宽 128 的 OpenCL GPU。profile_results.json 按设备保存两种模式的原始事件。每次运行覆盖该文件，保留原始样本时先复制一份。同一设备内部的事件差值可比较，不把不同设备的绝对时间戳直接相减。


<a id="13.4.5"></a>
## 13.4.5 解读自动分析建议
原书 p.474–476。

<a id="S009"></a>
**Source:** 原书 p.474 / PDF p.510 · S009

**Original:** You must judge the suggestions from the guided analysis based on your knowledge of your application.

**中文:** 需要结合你对应用程序的了解，判断自动分析给出的建议。

<a id="F008"></a>
### 图 13.8
**Source:** 原书 p.475 / PDF p.511 · C008
**Placed near:** 13.4.5 解读自动分析建议

![图 13.8](assets/fig13_8.png)

**Original caption:** NVVP provides a guided analysis section as well. Here, the user can acquire insight for further  optimizations. Note that the highlighted region shows low compute utilization.

**中文图注:** 自动分析报告指出计算利用率低，并列出其他可能的优化方向。

**Reading note:** 读出建议后，先找算法依赖。一个 kernel 必须等待前一个 kernel 生成面通量时，同时运行它们可能破坏正确性。已经消除大部分复制时，“复制与计算重叠低”的收益也会很有限。

<a id="F009"></a>
### 图 13.9
**Source:** 原书 p.476 / PDF p.512 · C009
**Placed near:** 13.4.5 解读自动分析建议

![图 13.9](assets/fig13_9.png)

**Original caption:** NVVP’s OpenACC Details window shows information on each OpenACC kernel and the cost of  each operation. We can see the cost of the data transfer in the left window for version 1 of the code versus the time for the optimized data motion in version 2 on the right.

**中文图注:** 两个版本的 OpenACC 明细并列显示，计算区域与复制的成本可以分开读取。

**Reading note:** 原书两个版本的计算部分约为 0.16 ms，占总时间比例却会随整个程序的运行时间改变。比较绝对时间和调用次数比只对照百分数更直接。

<a id="F010"></a>
### 图 13.10
**Source:** 原书 p.476 / PDF p.512 · C010
**Placed near:** 13.4.5 解读自动分析建议

![图 13.10](assets/fig13_10.png)

**Original caption:** Side-by-side code comparison showing that line 166 in version 1 of the ShallowWater code is now  line 181, which has the additional present clause.

**中文图注:** 第一版第 166 行对应第二版第 181 行，后者增加了 present 子句。

**Reading note:** 报告中的行号需回到相应版本的源文件。这里同一计算点从 4.8% 变为 0.81%，应再检查复制条目与实际耗时，不能把百分数之比视为整个应用的加速比。


<a id="13.4.6"></a>
## 13.4.6 使用 Nsight 定位问题
原书 p.476–477。

<a id="F011"></a>
### 图 13.11
**Source:** 原书 p.477 / PDF p.513 · C011
**Placed near:** 13.4.6 使用 Nsight 定位问题

![图 13.11](assets/fig13_11.png)

**Original caption:** The NVIDIA Nsight Eclipse Edition application is a code development tool. This window in the tool  shows the ShallowWater_par1 application.

**中文图注:** 原书在 Nsight Eclipse Edition 中打开浅水程序，展示源码与开发环境的关联。

**Reading note:** 这是书中年代的 IDE 界面。分析时先在系统时间线上找到关键区间，再选定一两个 kernel 检查指令或内存指标。

<a id="K011"></a>
**代码出处：** Shell · Nsight Systems 教学命令，适用于有相应 CUDA 后端、可执行文件与采集权限的环境

```text
nsys profile --trace=cuda,nvtx -o shallow ./ShallowWater_par2
nsys stats shallow.nsys-rep
```

<a id="N021"></a>
### 两类报告

**讲解：** Nsight Systems 将 CPU 活动、CUDA API、复制和 kernel 放在时间轴上；Nsight Compute 可以针对选定 CUDA kernel 采集更细的指标。硬件计数器采集可能需要重放，计时应另取代表性基准。命令选项、可用事件与报告格式依版本而异。[R60][R61]


<a id="13.4.7"></a>
## 13.4.7 从 CodeXL 案例迁移到 AMD 工具
原书 p.478。

<a id="F012"></a>
### 图 13.12
**Source:** 原书 p.478 / PDF p.514 · C012
**Placed near:** 13.4.7 从 CodeXL 案例迁移到 AMD 工具

![图 13.12](assets/fig13_12.png)

**Original caption:** The CodeXL development tool supports compiling, running, debugging, and profiling.

**中文图注:** 原书 CodeXL 界面集成代码开发、调试与性能剖析。

**Reading note:** 在另一厂商环境复现这一节，先寻找调度记录、数据传输和设备事件，再查该架构支持的计数器。这样能用同一问题组织不同格式的报告。

<a id="N022"></a>
### 工具与设备配套

**讲解：** CodeXL 是书中的历史实例。AMD ROCprofiler-SDK 提供 ROCm 轨迹与计数器相关能力，支持范围应与实际设备及系统核对。随本章提供的 gfx1103 数据来自 OpenCL 事件接口。[R62]


<a id="13.5"></a>
## 13.5 用三个指标提出可检验的问题
原书 p.479。

<a id="S010"></a>
**Source:** 原书 p.479 / PDF p.515 · S010

**Original:** We suggest the following three aspects as the most critical: occupancy, issue efficiency, and memory bandwidth.

**中文:** 作者建议优先看三个方面：驻留占用率、指令发射效率和内存带宽。

<a id="N023"></a>
### 结合起来读

**讲解：** 先看每个计算单元能否驻留足够多的工作，再看这些工作里有没有可发射指令的子组，最后检查一次有效计算搬了多少数据。指标冲突时，先核对设备、kernel、重复区间和计数器的分母。


<a id="13.5.1"></a>
## 13.5.1 Occupancy 与可调度工作
原书 p.479。

<a id="F013"></a>
### 图 13.13
**Source:** 原书 p.479 / PDF p.515 · C013
**Placed near:** 13.5.1 Occupancy 与可调度工作

![图 13.13](assets/fig13_13.png)

**Original caption:** GPUs have a lot of compute units (CUs), also called streaming multiprocessors (SMs). We  need to create a lot of work to keep the CUs busy, with enough extra work for handling stalls.

**中文图注:** 增加工作块可以覆盖更多计算单元，也给调度器提供其他可运行的工作以隐藏等待。

**Reading note:** 上图只有一个任务时存在计算单元空闲；下图同一个单元有多个候选任务时，可在一个任务等待内存期间执行另一个。要把全卡任务数量与每个 SM 上的驻留比例分开。

<a id="S011"></a>
**Source:** 原书 p.479 / PDF p.515 · S011

**Original:** A higher occupancy is not always better. The occupancy just needs to be high enough so that there is alternate work for the CUs.

**中文:** 占用率并非越高越好。有足够的工作让计算单元在等待时可以切换，就达到了提高占用率的目的。

<a id="N024"></a>
### 怎样验证一个假设

**讲解：** 工作组太大、寄存器多或共享内存需求高，都可能减少每个 SM 的驻留块数。改块大小后同时记录实际运行时间和带宽；如果通过增加寄存器溢出换来了更高占用率，就可能得不偿失。


<a id="13.5.2"></a>
## 13.5.2 发射效率与停顿原因
原书 p.480。

<a id="S012"></a>
**Source:** 原书 p.480 / PDF p.516 · S012

**Original:** An eligible wavefront is an active wavefront that is not stalled.

**中文:** 具备发射资格的 wavefront 已处于活动状态，且当前没有被阻塞。

<a id="N025"></a>
### 活动、就绪、发射

**讲解：** 子组驻留在计算单元上，只说明它有执行状态。如果下一条指令等待上一条计算或访存结果，它暂时不能发射。若多个子组都等待同一类资源，occupancy 可以很高而发射效率仍低。

<a id="N026"></a>
### 从原因回到源码

**讲解：** 依赖读等待可检查访存延迟与独立工作，屏障等待可检查线程工作量差异，内存队列拥堵可检查访问模式，执行管线忙则要辨别哪个运算单元饱和。指令包含整数、浮点和访存，发射率与 FLOP/s 的分母不同。


<a id="13.5.3"></a>
## 13.5.3 实际带宽与数据复用
原书 p.480。

<a id="E004"></a>
**Source:** 原书 p.480 / PDF p.516 · E004

$$
B_{\rm eff}=D_{\rm useful}/t
$$

以 Triad 的两读一写口径，D=3×N×sizeof(double)。用 kernel 时长得到有效 kernel 带宽，用主机端全流程时长则得到另一种指标。

<a id="N027"></a>
### 用可比较的上限

**讲解：** 先选对内存层级，再用同一精度、规模和单位比较理论值与 STREAM 等实测值。缓存命中时，按算法字节数得到的有效带宽可以高于实际 DRAM 带宽；判断是否需要合并访问、分块或重排，要配合真实事务量与复用情况。


<a id="13.6"></a>
## 13.6 把开发环境与采集环境分开
原书 p.480–485。

<a id="N028"></a>
### 要保存哪一层环境

**讲解：** 编译器、用户态库与源码可以随镜像保存；实际可用的 GPU、宿主驱动、硬件计数器权限和调度资源要在执行机器上确认。在本机查看远端报告，也应记录报告来自哪台机器。


<a id="13.6.1"></a>
## 13.6.1 Docker 容器与设备访问
原书 p.480–483。

<a id="S013"></a>
**Source:** 原书 p.480 / PDF p.516 · S013

**Original:** The Dockerfile contains the commands to build a basic OS and then to install the necessary software that it needs.

**中文:** Dockerfile 列出构建基础系统环境和安装所需软件的命令。

<a id="K012"></a>
**代码出处：** Shell · 适用于备有相应 Dockerfile、宿主 GPU 驱动和容器运行时的示意流程

```text
docker build -t shallow-study .
docker run --rm -it --gpus all shallow-study /bin/bash
```

<a id="N029"></a>
### 参数分别控制什么

**讲解：** build 的句点指定构建上下文，-t 为镜像取名。run 的 --gpus all 请求运行时暴露 GPU，-it 提供交互终端，--rm 在退出后删除容器实例。如果报告需要留存，要把输出写入挂载目录或在退出前取回。

<a id="N030"></a>
### 怎样确认可复现

**讲解：** 保存镜像版本、设备型号、运行参数与报告。书中 Ubuntu、PGI、VNC 及 XQuartz 的安装细节是历史示例。显示窗口、执行 GPU kernel、采集性能计数器是独立能力，可以分别用最小例子验证。


<a id="13.6.2"></a>
## 13.6.2 VirtualBox 来宾环境
原书 p.483–485。

<a id="S014"></a>
**Source:** 原书 p.483 / PDF p.519 · S014

**Original:** Using a virtual machine (VM) allows the user to create a guest OS within their own computer. The normal operating system is called a host, and the VM is called the guest.

**中文:** 虚拟机允许用户在自己的计算机中运行来宾操作系统。原有系统称为宿主，虚拟机中的系统称为来宾。

<a id="N031"></a>
### 原书实验目标

**讲解：** 作者在来宾 Ubuntu 中配置编译器，运行 CPU 版本浅水程序并显示图形。来宾系统能显示 3D 桌面，并不能据此推断 CUDA 设备或硬件计数器可用。要测目标 GPU，可以在具备设备访问条件的机器上采集后取回报告。


<a id="13.7"></a>
## 13.7 在云端采集性能数据
原书 p.485–486。

<a id="N032"></a>
### 按问题准备作业

**讲解：** 原书以带 Slurm、MPI 和 GPU 的云集群为例。先确定需要的 GPU 与工具支持，再选择网格、步数和采样区间。让批作业写出结果校验、运行参数、原始报告与摘要，这样实例释放后仍能分析。

<a id="N033"></a>
### 费用估计的范围

**讲解：** 数据传输、报告存储和实例占用都可能计费。书中给出的试用额度属于当时的服务条件。本次实验使用本地设备，未创建云作业。


<a id="13.8"></a>
## 13.8 延伸探索与小结
原书 p.486–487。

<a id="S015"></a>
**Source:** 原书 p.486 / PDF p.522 · S015

**Original:** The tools and workflows are the fastest changing aspects of GPU programming. While the examples in this chapter will be generally relevant, the details are likely to change.

**中文:** 在 GPU 编程中，工具与工作流程变化尤其快。本章例子反映的一般问题仍然适用，具体操作细节则可能变化。

<a id="N034"></a>
### 完成一轮分析

**讲解：** 用同一组输入定位热点，提出一个能由报告回答的问题，改变一个计算或数据路径，再对比绝对用时与数值结果。浅水例子的决定性证据是重复复制减少，而相应计算区域的用时几乎未变。


<a id="13.8.1"></a>
## 13.8.1 延伸阅读
原书 p.486–487。

<a id="N035"></a>
### 按报告类型找文档

**讲解：** 原书给出 CUDA 工具安装、从 NVVP 迁移、CodeXL、容器与虚拟化资料。读系统时间线时查 Nsight Systems 用户指南，解读 GPU 发射、驻留和内存指标时查 Nsight Compute Profiling Guide，在 ROCm 系统采集时查 ROCprofiler-SDK 的支持范围。资源页保留官方入口。


<a id="13.8.2"></a>
## 13.8.2 练习与参考思路
原书 p.487。

<a id="N036"></a>
### 练习一和二 · 为 Triad 采集轨迹

**讲解：** 先运行一次校验并预热，再跟踪完整迭代。对每条命令记录方向、字节数、设备开始与结束时刻，统计复制次数。回答“时间在哪里”时区分设备执行、主机提交和主机等待。可从 13.4.4 的本机实验及原始 JSON 入手。

<a id="N037"></a>
### 练习三 · 容器内复现

**讲解：** 按设备与编译器选择镜像，运行第 11 或 12 章能验证输出的小例子。依次确认编译器版本、实际设备名、结果与报告能否导出。若容器只提供 CPU 后端，应把该结果标为 CPU 运行。


## 技术核对来源

- [R60 · Nsight Systems User Guide](https://docs.nvidia.com/nsight-systems/UserGuide/index.html)
- [R61 · Nsight Compute Profiling Guide](https://docs.nvidia.com/nsight-compute/ProfilingGuide/index.html)
- [R62 · AMD ROCprofiler-SDK](https://rocm.docs.amd.com/projects/rocprofiler-sdk/en/latest/)