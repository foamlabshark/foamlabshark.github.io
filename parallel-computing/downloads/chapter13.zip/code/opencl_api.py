import ctypes as c
import json
from pathlib import Path

cl = c.WinDLL("OpenCL.dll")
ptr, uint, size, integer = c.c_void_p, c.c_uint, c.c_size_t, c.c_int
bits = c.c_ulonglong
ref = c.byref
def bind(name, result, *args):
    fn = getattr(cl, name)
    fn.restype = result
    fn.argtypes = args
    return fn
def ok(status):
    if status != 0: raise RuntimeError(f"OpenCL status {status}")
platform_ids = bind("clGetPlatformIDs", integer, uint, ptr, ptr)
device_ids = bind("clGetDeviceIDs", integer, ptr, bits, uint, ptr, ptr)
info = bind("clGetDeviceInfo", integer, ptr, uint, size, ptr, ptr)
context = bind("clCreateContext", ptr, ptr, uint, ptr, ptr, ptr, ptr)
queue = bind("clCreateCommandQueue", ptr, ptr, ptr, bits, ptr)
program = bind("clCreateProgramWithSource", ptr, ptr, uint, ptr, ptr, ptr)
build = bind("clBuildProgram", integer, ptr, uint, ptr, c.c_char_p, ptr, ptr)
kernel = bind("clCreateKernel", ptr, ptr, c.c_char_p, ptr)
buffer = bind("clCreateBuffer", ptr, ptr, bits, size, ptr, ptr)
set_arg = bind("clSetKernelArg", integer, ptr, uint, size, ptr)
launch = bind("clEnqueueNDRangeKernel", integer, ptr, ptr, uint, ptr, ptr, ptr, uint, ptr, ptr)
read = bind("clEnqueueReadBuffer", integer, ptr, ptr, uint, size, size, ptr, uint, ptr, ptr)
def devices():
    n = uint()
    ok(platform_ids(0, None, ref(n)))
    platforms = (ptr*n.value)()
    ok(platform_ids(n, platforms, None))
    for plat in platforms:
        m = uint()
        status = device_ids(plat,4,0,None,ref(m))
        if status == -1: continue
        ok(status)
        devs = (ptr*m.value)()
        ok(device_ids(plat,4,m,devs,None))
        yield from devs
