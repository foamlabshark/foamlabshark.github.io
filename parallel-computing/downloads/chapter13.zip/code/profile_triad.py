"""Compare repeated copies with resident buffers. Run on Windows with an FP64 OpenCL GPU."""
import ctypes as c
import json
import time
from pathlib import Path
from opencl_api import (ptr,uint,size,bits,integer,ref,bind,ok,devices,info,
                        context,queue,program,build,kernel,buffer,set_arg,launch,read)
write=bind("clEnqueueWriteBuffer",integer,ptr,ptr,uint,size,size,ptr,uint,ptr,ptr)
stamp=bind("clGetEventProfilingInfo",integer,ptr,uint,size,ptr,ptr)
release_event=bind("clReleaseEvent",integer,ptr)
def run(dev):
    name=c.create_string_buffer(256)
    ok(info(dev,0x102B,len(name),name,None))
    err=integer()
    owned=[]
    def keep(h,kind):
        ok(err.value)
        owned.append((h,bind("clRelease"+kind,integer,ptr)))
        return h
    try:
        ctx=keep(context(None,1,ref(ptr(dev)),None,None,ref(err)),"Context")
        q=keep(queue(ctx,dev,2,ref(err)),"CommandQueue")  # CL_QUEUE_PROFILING_ENABLE
        src=c.c_char_p(Path(__file__).with_name("triad.cl").read_bytes())
        prg=keep(program(ctx,1,ref(src),None,ref(err)),"Program")
        ok(build(prg,1,ref(ptr(dev)),None,None,None))
        fun=keep(kernel(prg,b"triad",ref(err)),"Kernel")
        n=262144
        a=(c.c_double*n)(*range(n)); b=(c.c_double*n)(*[1]*n); out=(c.c_double*n)()
        byte_count=c.sizeof(a)
        da,db,dc=[ptr(keep(buffer(ctx,1,byte_count,None,ref(err)),"MemObject")) for _ in range(3)]
        for i,arg in enumerate([uint(n),c.c_double(2),da,db,dc]):
            ok(set_arg(fun,i,c.sizeof(arg),ref(arg)))
        def measure(mode,steps):
            events=[]
            def event(label):
                e=ptr();events.append((label,e));return ref(e)
            start=time.perf_counter_ns()
            try:
                for step in range(steps):
                    if mode=="repeated" or step==0:
                        for target,host in [(da,a),(db,b)]:
                            ok(write(q,target,0,0,byte_count,host,0,None,event("H2D")))
                    ok(launch(q,fun,1,None,ref(size(n)),ref(size(128)),0,None,event("kernel")))
                    if mode=="repeated" or step==steps-1:
                        ok(read(q,dc,1,0,byte_count,out,0,None,event("D2H")))
                wall_ns=time.perf_counter_ns()-start
                assert all(v==i+2 for i,v in enumerate(out))
                trace=[]
                for label,e in events:
                    start_ns=bits();end_ns=bits()
                    ok(stamp(e,0x1282,8,ref(start_ns),None));ok(stamp(e,0x1283,8,ref(end_ns),None))
                    trace.append(dict(op=label,start_ns=start_ns.value,end_ns=end_ns.value))
                return dict(mode=mode,steps=steps,wall_ms=wall_ns/1e6,events=trace)
            finally:
                for _,e in events:
                    if e:release_event(e)
        measure("resident",1)
        runs=[measure(mode,8) for mode in ("repeated","resident","resident","repeated")]
        return dict(device=name.value.decode(),n=n,bytes_per_array=byte_count,runs=runs)
    finally:
        for h,release in reversed(owned):release(h)
if __name__=="__main__":
    result=[run(d) for d in devices()]
    Path(__file__).with_name("profile_results.json").write_text(json.dumps(result,indent=2),encoding="utf8")
    for device in result:
        print(device['device'],[(r['mode'],len(r['events']),round(r['wall_ms'],3)) for r in device['runs']])
