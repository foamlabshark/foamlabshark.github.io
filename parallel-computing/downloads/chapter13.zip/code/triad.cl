#pragma OPENCL EXTENSION cl_khr_fp64 : enable

__kernel void triad(uint n, double scalar, __global const double *a,
                    __global const double *b, __global double *out) {
    size_t i = get_global_id(0);
    if (i < n) out[i] = a[i] + scalar * b[i];
}

