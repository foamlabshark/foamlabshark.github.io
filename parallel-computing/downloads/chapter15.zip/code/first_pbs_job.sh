#!/bin/sh
#PBS -N mpi-demo
#PBS -l select=1:ncpus=4:mpiprocs=4
#PBS -l walltime=01:00:00
#PBS -j oe
set -eu
cd "${PBS_O_WORKDIR:?submission directory required}"
exec mpirun -n 4 ./my_parallel_app
