#!/bin/sh
#SBATCH --job-name=mpi-demo
#SBATCH --nodes=1
#SBATCH --ntasks=4
#SBATCH --time=01:00:00
#SBATCH --output=slurm-%j.out
set -eu
exec srun --ntasks=4 ./my_parallel_app
