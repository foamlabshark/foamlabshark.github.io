"""Single-writer checkpoint demonstration. Run with Python 3."""
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory


def advance(path, target, budget):
    if target < 0 or budget < 1:
        raise ValueError("invalid work size")
    if path.exists():
        state = json.loads(path.read_text(encoding="utf-8"))
        if state["version"] != 1 or state["target"] != target:
            raise ValueError("incompatible checkpoint")
        done, total = state["done"], state["total"]
        if not 0 <= done <= target or total != done * (done + 1) // 2:
            raise ValueError("inconsistent checkpoint")
    else:
        done = total = 0
    through = min(target, done + budget)
    for item in range(done + 1, through + 1):
        total += item
    state = {"version": 1, "target": target, "done": through, "total": total}
    pending = path.with_suffix(".pending")
    with pending.open("w", encoding="utf-8") as stream:
        json.dump(state, stream)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(pending, path)
    return through == target, total


if __name__ == "__main__":
    with TemporaryDirectory() as folder:
        checkpoint = Path(folder) / "state.json"
        assert advance(checkpoint, 10, 4) == (False, 10)
        checkpoint.with_suffix(".pending").write_text("{", encoding="utf-8")
        assert advance(checkpoint, 10, 4) == (False, 36)
        assert advance(checkpoint, 10, 4) == (True, 55)
        assert advance(checkpoint, 10, 4) == (True, 55)
        print("Recovered 4 -> 8 -> 10 completed items; final sum 55.")
