# 第 15 章｜批处理调度器
原书 p.528–546，PDF p.564–582。核心段落译文与逐节讲解。
## 小节索引

- [第 15 章导读｜批调度器如何分配集群资源](#15-intro)
- [15.1 共享集群为什么需要调度](#15.1)
- [15.2 在繁忙集群上安排工作](#15.2)
- [15.2.1 登录节点、计算节点与队列](#15.2.1)
- [15.2.2 多用户环境下的队列与存储习惯](#15.2.2)
- [15.3 第一次申请并运行作业](#15.3)
- [15.3（续）编写 Slurm 作业脚本](#15.3-slurm)
- [15.3（续）把同一项请求写成 PBS](#15.3-pbs)
- [15.3（续）读懂状态和环境变量](#15.3-status)
- [15.4 长作业的检查点与续算](#15.4)
- [15.4（续）让 MPI 进程在安全步共同停下](#15.4-signal)
- [15.4（续）DONE、RESTART 和提交次数](#15.4-state)
- [15.5 作业依赖与分阶段提交](#15.5)
- [15.6 延伸探索与本章小结](#15.6)
- [15.6.1 延伸阅读](#15.6.1)
- [15.6.2 练习与参考思路](#15.6.2)

<a id="15-intro"></a>
## 第 15 章导读｜批调度器如何分配集群资源
原书 p.528–529。

**Source:** 原书 p.529 / PDF p.565

**Original:** Schedulers can also be customized with plugins or add-ins that provide additional functionality, support for special workloads, and improved scheduling algorithms. You’ll also find a number of strictly commercial batch schedulers, but their functionality is similar to those presented here.

**中文:** 调度器可以通过插件扩展功能，支持特定工作负载，或改进调度算法。还有一些完全商业化的批调度器，其基本功能与本章介绍的系统相似。

**Source:** 原书 p.529 / PDF p.565

**Original:** The basic concepts of each scheduler implementation are much the same, and often, many details vary from site to site. Portability of batch scripts can still be a bit of a challenge and require some customization for each system.

**中文:** 不同调度器的基本概念大致相同，具体细节却常随计算中心而变。将批脚本移到另一套系统时，往往要作相应调整。

### 跟踪一份四进程作业

把队列里的提交号、获准使用的节点和已经启动的进程分开记录。读完本章，你可以从提交命令追到真正启动四个 MPI 进程的那一行，也能说明一次分配耗尽时，下一份作业靠哪个文件恢复计算。


<a id="15.1"></a>
## 15.1 共享集群为什么需要调度
原书 p.529–530。

**Source:** 原书 p.529 / PDF p.565

**Original:** As high performance computing systems grow in size and number of users, it becomes necessary to add some management to the system to bring order to chaos and get the most performance from the hardware. Installation of a batch scheduler can save the day (figure 15.1).

**中文:** 随着高性能计算系统扩大、用户增多，需要管理机制为共享使用建立秩序，尽可能发挥硬件性能。原书以图 15.1 说明批调度器能怎样缓解这样的冲突。

### 图 15.1
原书 p.530 / PDF p.566。

![图 15.1](assets/fig15_1.png)

Batch systems are like the supermarket checkout queueing system for a computer cluster. These help to make better use of the resources and bring more efficiency to your jobs.

调度器像集群的排队结账系统，把同时到来的作业分配到可用计算节点。

图左有多份 mpirun 同时争用同一组节点。图右先收集请求，再在资源允许时放行。队列分区、优先级和共享策略影响实际启动次序。

### 与第 14 章的亲和性相连

两组工作同时占用同一核心、缓存或内存控制器时，单次计时可能大幅波动。调度分配给出可使用的资源范围，进程和线程绑定再决定程序怎样利用这个范围。要求独占节点还应核对站点分区策略与费用。


<a id="15.2"></a>
## 15.2 在繁忙集群上安排工作
原书 p.530–532。

**Source:** 原书 p.530 / PDF p.566

**Original:** Busy clusters have lots of users and lots of work. A batch system is often implemented to manage the workload and get the most out of the system. These clusters are a different environment than a standalone, single-user workstation.

**中文:** 繁忙的集群同时面对许多用户和作业，通常通过批系统管理负载、提高资源利用率。它的工作环境与单人使用的独立工作站有明显差别。

### 先判断该去哪里做

短小的编辑、查询和提交可以放在登录节点。较重的编译、大文件传输、交互调试和长计算分别检查站点是否提供编译节点、传输节点、调试分区和计算分区。这样，其他用户仍能及时登录和提交作业。


<a id="15.2.1"></a>
## 15.2.1 登录节点、计算节点与队列
原书 p.530–531。

**Source:** 原书 p.530 / PDF p.566

**Original:** Most clusters have some nodes set aside to be front ends. These front-end nodes are also called login nodes because that is where you will be when you log in to the system.

**中文:** 多数集群会留出一些节点作为前端。用户登录时会进入这些节点，因此它们也叫登录节点。

**Source:** 原书 p.531 / PDF p.567

**Original:** Each queue has a set of policies for things like the size of jobs (such as the number of processors or memory) and how long these jobs can run.

**中文:** 每个队列都有一套策略，规定允许的作业规模，例如处理器数量或内存需求，以及作业能够运行多久。

### 资源请求的四个量

以两个节点、32 个 MPI 进程、每进程一个 CPU、最长一小时为例。节点数决定可跨多少台机器，任务数决定要启动多少进程，每任务 CPU 数决定该进程可使用的 CPU 数量，walltime 决定最长占用多久。混合 MPI/OpenMP 作业还要让线程数和绑定与每任务 CPU 请求对应。


<a id="15.2.2"></a>
## 15.2.2 多用户环境下的队列与存储习惯
原书 p.531–532。

**Source:** 原书 p.532 / PDF p.568

**Original:** Often projects get resource allocations that are used for prioritizing jobs using a “fair-share” scheduling algorithm. In these cases, you may need to submit an application for the resources that you need for your project.

**中文:** 项目常常有自己的资源配额，调度器可以按公平份额算法给作业定优先级。在这类系统上，项目可能需要先申请计算资源。

### 结合队列状态解释等待

资源够多、作业够小也可能因优先级、预约或账户限制而等待。先看具体等待原因，再决定缩短时限、调整规模还是等待分配。原书的“十个左右”是作者管理队列的经验，实际限额、数组作业并发上限由站点规定。

### 输出的生命周期

大规模中间输出通常进入 scratch 或 work，结果和能恢复计算的检查点按站点政策转存。记录清理周期、项目配额与归档目录。若计算需要三天而单份作业只准一天，就在算法设计时安排检查点。


<a id="15.3"></a>
## 15.3 第一次申请并运行作业
原书 p.532–533。

**Source:** 原书 p.532 / PDF p.568

**Original:** The interactive command-line mode is generally used for program development, testing, or short jobs. For submitting longer production jobs, it is more common to use a batch file to submit a batch job. The batch file allows the user to run applications overnight or unattended.

**中文:** 交互式命令行一般用于开发、测试和短作业。长时间的正式计算更常写成批文件提交，这样程序可以在夜间或无人值守时运行。

### 图 15.2
原书 p.533 / PDF p.569。

![图 15.2](assets/fig15_2.png)

Batch systems are typically used in either an interactive mode or a batch usage model.

交互模式先拿到资源再输入命令，批处理模式先把命令写入文件，等资源到位后执行。

两种模式都要提交资源需求。图中终端提示符只是站点示例，诊断实际位置可执行 hostname，并用 srun 在这份分配上启动具体步骤。

**代码出处：** Shell · 对应 p.533 的交互分配；srun 启动 MPI 的方式需匹配站点的 MPI 集成

```text
salloc --nodes=2 --ntasks=32 --time=01:00:00
srun --ntasks=32 ./my_parallel_app
exit
```

### 逐行读命令

salloc 等待分配并启动所配置的命令或 shell。shell 是否位于计算节点由站点配置决定。srun 启动作业步骤，32 个任务是在两个节点上的总数。最后 exit 离开由 salloc 启动的 shell，交还资源。交互调试若需要一个计算节点终端，可在已分配资源内使用站点支持的 srun --pty 启动交互 shell。


<a id="15.3-slurm"></a>
## 15.3（续）编写 Slurm 作业脚本
原书 p.534–535。

### 表 15.1
原书 p.534 / PDF p.570。

![表 15.1](assets/fig15_T1.png)

Slurm command options

原书常用 Slurm 提交选项表。

长选项使用双连字符，例如 --time=01:00:00。短选项可写成 -t 01:00:00。-N 表示节点数，-n 表示任务数。表里的 processors 需结合每任务 CPU 请求理解。

**代码出处：** Shell · 清单 15.1 的教学脚本，文件 first_slurm_job.sh；需替换或提供实际可执行文件

```text
#!/bin/sh
#SBATCH --job-name=mpi-demo
#SBATCH --nodes=1
#SBATCH --ntasks=4
#SBATCH --time=01:00:00
#SBATCH --output=slurm-%j.out
set -eu
exec srun --ntasks=4 ./my_parallel_app
```

### 谁在读哪一行

控制器读取 #SBATCH 行，批 shell 解释 set 和 exec 等普通命令。第一条有效 shell 命令出现后，Slurm 停止识别新的 #SBATCH 指令，所以这些请求应集中放在文件开头。%j 由 Slurm 展开为作业号；写在指令里的 shell 变量通常按字面读取。

**代码出处：** Shell · 提交并查询自己名下的作业；sbatch 返回的是提交回执

```text
sbatch first_slurm_job.sh
squeue -u "$USER"
```

### 如何把失败传给控制器

exec 以启动器替换这个 shell，批脚本最终返回启动器退出状态。原书 #!/bin/sh 与 &> 混用，在一些 shell 上语义不同。可用 --output 和 --error 分别设置日志，或用可移植的 > run.out 2>&1 合并标准输出与错误输出。


<a id="15.3-pbs"></a>
## 15.3（续）把同一项请求写成 PBS
原书 p.535–536。

### 表 15.2（上）
原书 p.535 / PDF p.571。

![表 15.2（上）](assets/fig15_T2a.png)

PBS command options

原书 PBS 选项表，资源列表、作业名和输出文件一栏。

PBS 的 -N 命名作业；Slurm 的 -N 请求节点。原书 nodes、ppn、procs 写法依 PBS 系列和站点而异。

### 表 15.2（续）
原书 p.536 / PDF p.572。

![表 15.2（续）](assets/fig15_T2b.png)

PBS command options (continued)

原书表 15.2 续页，队列与日志合并选项。

脚本示例使用 -j oe，把标准错误合入标准输出。可接受的队列名和资源键以本地 PBS 文档为准。

**代码出处：** Shell · 清单 15.2 的 PBS Professional 风格改写，文件 first_pbs_job.sh

```text
#!/bin/sh
#PBS -N mpi-demo
#PBS -l select=1:ncpus=4:mpiprocs=4
#PBS -l walltime=01:00:00
#PBS -j oe
set -eu
cd "${PBS_O_WORKDIR:?submission directory required}"
exec mpirun -n 4 ./my_parallel_app
```

### 一个 chunk 有哪些资源

select=1:ncpus=4:mpiprocs=4 请求一个含四个 CPU 和四个 MPI 进程槽的资源块。cd 进入 qsub 提交时的目录，目录必须能从执行节点访问。四个进程的启动与放置交给已与 PBS 配套的 MPI 启动器。

**代码出处：** Shell · 提交 PBS 作业并查询状态

```text
qsub first_pbs_job.sh
qstat -u "$USER"
```

**Source:** 原书 p.536 / PDF p.572

**Original:** You may need to specify a queue or other site-specific information for these examples. Many sites have different queues for long, short, large, and other specialized situations. Consult the local site documentation for these important details.

**中文:** 运行这些示例可能还要提供队列名称或站点专用参数。许多中心分别设置长作业、短作业、大作业和专用队列，具体要求要查当地文档。


<a id="15.3-status"></a>
## 15.3（续）读懂状态和环境变量
原书 p.537–539。

**代码出处：** Shell · 假定 job_id 与 pbs_id 已分别赋为自己的实际提交号

```text
sinfo
squeue -u "$USER"
scontrol show job "$job_id"
# PBS 查看本人的某个作业
qstat -f "$pbs_id"
```

### 读一行队列输出

示例中 PD 与 (Resources) 合在一起表示作业仍等待所需资源，R 表示已经运行。sinfo 报告节点与分区状态，squeue 关注作业，scontrol show job 可看详细请求与分配。运行结束的作业可能从当前队列消失，需要从作业日志和站点记账记录查退出状态。

### 把提交号写进记录

在 Slurm 作业内记录 SLURM_JOB_ID、SLURM_JOB_NODELIST、SLURM_NTASKS；在 PBS 作业内记录 PBS_JOBID、PBS_O_WORKDIR，并依站点支持查看节点文件。环境中的任务数跟申请方式有关。完成第一个小作业后再用这些值驱动大型启动脚本。


<a id="15.4"></a>
## 15.4 长作业的检查点与续算
原书 p.539–541。

**Source:** 原书 p.539 / PDF p.575

**Original:** The checkpointing process is useful for dealing with a limited time for a batch job and for handling system crashes or other job interruptions. You might restart your jobs manually for a small number of cases, but as the number of restarts gets larger, it becomes a real burden.

**中文:** 检查点可以应对批作业的时限，也能帮助处理系统崩溃或其他作业中断。少量续算可以手动启动，次数多了，人工处理就成为很重的负担。

### 图 15.3
原书 p.539 / PDF p.575。

![图 15.3](assets/fig15_3.png)

A checkpoint file that saves the state of the calculation is written out to disk at the conclusion of a batch job and then the next batch job reads the file and restarts the calculation where the previous job left off.

当前分配结束时保存状态，下一份作业读入检查点，从已有计算进度继续。

把求解器状态和“下一个要执行的时间步”一起定义好。若保存的是已完成步数 297，读回后从 298 开始；重新做 297 或漏做 298 都会影响结果。

### 一个可恢复的状态包含什么

除了循环计数，还要存储下一步所需场量、时间步长、网格拓扑、随机状态或求解器历史。多进程运行要给各分块约定相同的逻辑步号，并在所有分块都成功写完后发布完整性清单。

**代码出处：** Slurm · 清单 15.3 的具名信号教学示意，配合下节 C 处理函数

```text
#SBATCH --signal=USR1@160
#SBATCH --time=00:08:00
```

### 预算留给什么

原书以信号 23 请求提前约 160 秒通知。信号编号的平台差异、Slurm 通知粒度、MPI 启动器转发目标都需要在实际站点确认。预留的时间要覆盖“等到安全步边界＋写出检查点＋确认完整＋退出”。单一通知不足以覆盖突然掉电，仍可周期性保存早先的检查点。


<a id="15.4-signal"></a>
## 15.4（续）让 MPI 进程在安全步共同停下
原书 p.541–542。

**代码出处：** C / MPI · 清单 15.4 的教学片段，MPI 调用需位于函数体内；各 rank 已注册信号处理函数

```text
#include <signal.h>
static volatile sig_atomic_t stop_requested = 0;
static void on_notice(int signo) {
    (void)signo;
    stop_requested = 1;
}
/* 初始化时注册 on_notice，使用与批脚本一致的具名信号。
   以下位于所有 rank 按同一顺序进入的步边界。 */
int local_stop = stop_requested ? 1 : 0;
int any_stop = 0;
MPI_Allreduce(&local_stop, &any_stop, 1, MPI_INT, MPI_MAX,
              MPI_COMM_WORLD);
/* 若 any_stop 非零，所有 rank 保存相同步号的状态。 */
```

### 信号处理函数只置标志

原书处理函数内调用 printf。异步信号可能在 I/O 库正维护内部状态时到达，因此示例改为只写 volatile sig_atomic_t 标志。MPI 与文件 I/O 留在正常执行流里。若站点只向批 shell 发信号，还需要约定如何转交给应用。

### 广播还是归约

原书约定 rank 0 接收信号，再用 Bcast 告知其他进程。这里演示任一 rank 收到通知时都可发起停机请求，因此所有 rank 用 MAX 合并布尔标志。所有进程必须经过同一集体调用，不能有进程先返回、另一些仍在等待。


<a id="15.4-state"></a>
## 15.4（续）DONE、RESTART 和提交次数
原书 p.540–542。

**Source:** 原书 p.542 / PDF p.578

**Original:** The signal timing also needs to be tuned for how long it takes to catch the signal, complete the iterations, and write out the restart file.

**中文:** 还需要调整发送信号的时机，为应用接收信号、完成当前迭代和写出重启文件留下足够时间。

### 原书的三个判断

DONE 表示不再继续，RESTART 保存恢复时所需的步号，COUNT 限制提交次数。原书在达到最大次数时也写 DONE，可能使“达到提交上限”与“计算结果已完成”无法区分。实际脚本可分别记录完成、需续算、次数耗尽和异常退出四种状态。

**代码出处：** POSIX shell · 清单 15.3 的控制流节选；应用定义自己的退出与续算协议

```text
status=0
srun ./my_parallel_app || status=$?
if [ "$status" -ne 0 ]; then
    exit "$status"
fi
# 此处读取应用已提交的状态文件与完整性标记。
# 仅当需要续算、有有效检查点且未达到上限时才提交后继作业。
```

### 为什么要立即保存退出码

无关的 echo、date 或测试命令会覆盖 \$?。脚本若最终返回 0，调度器会据此处理 afterok，而计算本身可能已经失败。COUNT 包含首份作业时，最大提交数 4 等于首次加最多三次后继；要明确代码里“次数”统计的是哪一种。

### 可运行的小实验

资料包的 checkpoint_demo.py 每次最多处理四个整数。第一次保存 done=4、total=10，第二次恢复到 8、36，最后得到 10、55。它先写同目录临时文件，刷新并替换已提交文件，还模拟遗留半写临时文件的情况。这一单写者示例演示发布顺序；并行文件系统上的多文件持久化还要遵从站点语义。


<a id="15.5"></a>
## 15.5 作业依赖与分阶段提交
原书 p.543–545。

**Source:** 原书 p.543 / PDF p.579

**Original:** Most have a dependency feature that allows you to specify how one job depends on another. Using this dependency capability, we can get our subsequent jobs submitted earlier in the queue by submitting the next batch job prior to running our application.

**中文:** 大多数批系统都允许指定一个作业怎样依赖另一个作业。利用这个功能，可以在当前应用开始运行前提交后续作业，让后续作业更早进入队列。

### 图 15.4
原书 p.543 / PDF p.579。

![图 15.4](assets/fig15_4.png)

Automatic restart submitted at start of batch job will have more time in queue, which can give your restart job higher priority than one submitted at end of batch job (dependent on local scheduling policies).

原书对比两种续算提交时机：当前段运行前预提交、当前段结束后再提交。

预提交可提前登记依赖。能否提高优先级取决于站点对依赖等待作业的计龄、资格、资源和公平份额策略；依赖解除后仍须等到资源可用。

**代码出处：** Shell · 同一集群内固定三阶段作业链；三个脚本需由用户提供，未在本机提交

```text
set -eu
prep=$(sbatch --parsable prepare.sh)
prep_id=${prep%%;*}
run=$(sbatch --parsable --dependency="afterok:$prep_id" solve.sh)
run_id=${run%%;*}
sbatch --dependency="afterok:$run_id" summarize.sh
```

### 看懂三种符号

\$(...) 收集提交命令的标准输出，--parsable 让输出适合作为程序输入。若输出带有“;集群名”，\${var%%;*} 取本集群提交号。afterok:ID 把新作业的资格与前序作业成功退出关联起来。脚本可能已经成功提交前几段而后段失败，重试前应查询并保留已有 ID。

### 表 15.3
原书 p.545 / PDF p.581。

![表 15.3](assets/fig15_T3.png)

Dependency options for batch jobs

原书 Slurm 作业依赖类型。

afterok 等待成功结束，afterany 接受任意结束状态，afternotok 关注未成功结束；after 在开始后即可满足。singleton 还涉及同一用户和作业名。清单 15.5 真正提交依赖作业的位置是第 44 行，正文指向的第 33 行是状态判断。

### 续算链的终点

预提交的后继只获得调度资格，它启动后仍应检查已完成标记、有效检查点和重试上限。afterok 要求前序批脚本正确传递退出码。若任务因时限被杀且未及时写完，依赖关系本身无法制造一个可读的检查点。


<a id="15.6"></a>
## 15.6 延伸探索与本章小结
原书 p.545–546。

**Source:** 原书 p.545 / PDF p.581

**Original:** There are general reference materials for the Slurm and PBS schedulers, but you should also look at the documentation for your site. Many sites have customized setups and added commands and features for their specific needs.

**中文:** Slurm 与 PBS 都有通用参考材料，同时还要阅读所在计算中心的文档。许多站点会按照自身需求定制配置，并增加命令和功能。

### 按用途检索文档

先查站点的账户、分区、walltime 与文件保留规则。随后按所用调度器查询提交、启动、依赖和信号选项。最后通过一份很短的测试作业核实环境变量、MPI 启动和日志实际落点。


<a id="15.6.1"></a>
## 15.6.1 延伸阅读
原书 p.545。

### 原书资料

原书列出 SchedMD 的 Slurm 文档、LLNL 的调度器教程、Altair 的 PBS User Guide 和关于 Beowulf 集群的历史资料。阅读时将资源申请的通用概念与站点对队列和共享方式的具体配置区分开。

### 可查的手册页

Slurm 的 sbatch 说明脚本解析、信号与 dependency，salloc 说明交互分配，srun 说明任务启动与绑定。PBS Professional 的用户手册说明 select、ncpus、mpiprocs、walltime 与 qsub。本站资料页提供相应入口。


<a id="15.6.2"></a>
## 15.6.2 练习与参考思路
原书 p.546。

### 练习一 · 核对两份作业

在有提交权限的站点分别申请 16 和 32 个任务，记下两份 ID。查询各自的请求量、状态和实际分配；核对 ID 后取消自己那份 32 任务作业，再检查作业状态或记账信息。这里是原书练习，本章本地验证没有向集群投递作业。

### 练习二 · 为长计算加预处理

预处理只运行一次，写好输入和完成状态。第一份计算依赖预处理成功；后续计算段仅在有可读检查点且仍有剩余工作时继续。核对输入的版本，以免恢复任务读到别的运行留下的数据。

### 练习三 · 失败后清理

先保留启动器退出码，再检查应清理的 simulation_database 位于本作业的专用工作目录内，路径和归属都匹配后才处理。保留日志与最近已提交的检查点，最终向调度器返回原失败状态；硬杀或节点宕机可能使清理回调根本来不及执行。


## 技术参考

[官方参考文档](https://slurm.schedmd.com/sbatch.html)