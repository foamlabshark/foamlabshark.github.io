# 第 16 章｜并行文件操作
原书 p.547–578，PDF p.583–614。核心段落译文与逐节讲解。
## 小节索引

- [第 16 章导读｜并行程序怎样读写文件](#16-intro)
- [16.1 高性能存储的组成](#16.1)
- [16.2 用一个进程处理普通文件](#16.2)
- [16.3 MPI-IO｜进程、文件指针与集体调用](#16.3)
- [16.3（续）两份 subarray 描述同一批实单元](#16.3-layout)
- [16.3（续）设置文件视图，写出与读回](#16.3-view)
- [16.3（续）N 个进程对应 M 个文件](#16.3-split)
- [16.4 HDF5｜自描述的数组与数据空间](#16.4)
- [16.4（续）hyperslab 的起点、步长与块数](#16.4-hyperslab)
- [16.4（续）文件访问与一次集体写各自配置](#16.4-transfer)
- [16.4（续）独立读取与安装检查](#16.4-read)
- [16.4（实验）带 halo 的真实 HDF5 文件回读](#16.4-lab)
- [16.5 PnetCDF、netCDF-4 与 ADIOS](#16.5)
- [16.6 并行文件系统与硬件接口](#16.6)
- [16.6.1 查询 MPI-IO 实现与生效参数](#16.6.1)
- [16.6.2 通用提示：聚合与 data sieving](#16.6.2)
- [16.6.3 针对目标文件系统调参](#16.6.3)
- [16.7 延伸探索与性能实验设计](#16.7)
- [16.7.1 延伸阅读](#16.7.1)
- [16.7.2 练习与核对思路](#16.7.2)

<a id="16-intro"></a>
## 第 16 章导读｜并行程序怎样读写文件
原书 p.547–548。

**Source:** 原书 p.547 / PDF p.583

**Original:** For any computing work, the product is the output, whether it be data, graphics, or statistics. This includes final results but also intermediate output for graphics, checkpointing, and analysis.

**中文:** 计算工作的产物是输出，可以是数据、图形或统计量。除了最终结果，程序还会在中途保存用于可视化、检查点和分析的数据。

### 先画两张网格

计算时，每个进程保存自己的实单元和从邻居复制的 halo。保存全局场时，每个实单元只应出现一次。读完本章应能对一个具体值回答两个问题：它现在位于哪块本地内存？落盘后应处在哪一行、哪一列？

### 输出与检查点

绘图可能只需一个标量场；重启还可能需要时间步、网格、状态变量和求解器历史。设计检查点时先列出恢复计算需要的全部状态，再决定文件格式、写入频率以及如何验证一个完整的时间步。


<a id="16.1"></a>
## 16.1 高性能存储的组成
原书 p.548–549。

**Source:** 原书 p.549 / PDF p.585

**Original:** Burst buffers can either be placed on each node or on the IO nodes and shared via a network with the other compute nodes.

**中文:** 突发缓冲可以放在每个计算节点上，也可以放在 I/O 节点上，让其他计算节点通过网络共享。

### 图 16.1
原书 p.549 / PDF p.585。

![图 16.1](assets/fig16_1.png)

Schematic showing positioning of burst buffer hardware in between the compute resources and disk storage. Burst buffers can either be node-local or shared among nodes via a network.

突发缓冲位于计算资源与后端磁盘之间，可本地独享或经网络共享。

沿图追踪一次检查点。先写入快层可能缩短暂停时间，后续仍有数据从快层迁往持久层。记录时间时要注明完成条件和掉电、节点丢失等故障下的恢复保证。

### 各层承担不同工作

SSD/NVRAM 可吸收短时集中的写请求，磁盘承担较大容量的长期在线存储，磁带常用于归档。应用长期产生数据的速率如果持续超过后端排空速率，快层最终会满。节点本地缓冲在不同节点间的可见性也要纳入恢复方案。


<a id="16.2"></a>
## 16.2 用一个进程处理普通文件
原书 p.549–550。

**Source:** 原书 p.550 / PDF p.586

**Original:** By adding parallel communication calls at each of the transition points from serial to parallel and parallel to serial, we can make modest parallel applications work using standard files.

**中文:** 在串行与并行之间的每个转换点补上相应的通信，就可以让规模适中的并行程序继续使用普通文件。

### 图 16.2
原书 p.550 / PDF p.586。

![图 16.2](assets/fig16_2.png)

Modifications for a parallel application to work with a standard filesystem. All file operations are done from rank 0.

用广播、分发与汇集连接并行计算，文件操作集中在 rank 0。

广播复制同一份配置；scatter 把不同区段分给各 rank；gather 收回各自的结果。先辨明程序需要哪种动作，再确定根进程的缓冲区大小。

**代码出处：** C/MPI · 小配置读取教学片段，steps 为 int，所有进程按相同顺序调用

```text
int ok = 1;
if (rank == 0) {
    FILE *fp = fopen("settings.txt", "r");
    ok = fp && fscanf(fp, "%d", &steps) == 1;
    if (fp) fclose(fp);
}
MPI_Bcast(&ok, 1, MPI_INT, 0, comm);
if (!ok) MPI_Abort(comm, 1);
MPI_Bcast(&steps, 1, MPI_INT, 0, comm);
```

### 读错时也要保持一致

根进程先通知全组读取是否成功。若根进程提前返回，而其余进程已经进入 MPI_Bcast，后者可能一直等待。数十字节的配置很适合广播，把每个进程数 GiB 的结果都汇集到根进程，则要先核算根进程的内存和带宽。


<a id="16.3"></a>
## 16.3 MPI-IO｜进程、文件指针与集体调用
原书 p.551–552。

**Source:** 原书 p.551 / PDF p.587

**Original:** The MPI-IO library has both a shared file pointer across all processes and independent file pointers for each process.

**中文:** MPI-IO 同时提供由多个进程共享的文件指针，以及各进程自己的文件指针。

### 表 16.1
原书 p.551 / PDF p.587。

![表 16.1](assets/fig16_T1.png)

MPI general file routines

打开、关闭、调整长度、移动文件指针以及设置提示的 MPI 文件操作。

MPI_File_open 和 MPI_File_close 是集体调用。MPI_File_set_size 指定逻辑文件大小，实际物理空间分配和落盘行为取决于实现。

### 表 16.2
原书 p.552 / PDF p.588。

![表 16.2](assets/fig16_T2.png)

MPI independent file routines

独立读写，可选择当前位置或显式偏移。

原表对 _at 的描述容易误读。显式偏移读写以当前 file view 的 etype 为单位寻址，不改变单独文件指针，也不改变共享文件指针。

### 表 16.3
原书 p.552 / PDF p.588。

![表 16.3](assets/fig16_T3.png)

MPI collective file routines

所有参与进程协同读写，文件视图限制了各自能看到的元素。

MPI_File_write_all 可以同时使用各进程的单独文件指针。是否需要全组调用与采用哪种定位方式是两个独立问题。

### 参与范围

对同一次打开所得的文件句柄，参与集体操作的进程要按兼容顺序进入调用。某 rank 的有效元素数为零时，仍要按接口要求参与。根进程单独写头部可采用独立写，须设计与后续数组不重叠的地址范围。


<a id="16.3-layout"></a>
## 16.3（续）两份 subarray 描述同一批实单元
原书 p.552–554。

**Source:** 原书 p.553 / PDF p.589

**Original:** The first block of code in listing 16.1 shows the creation of these two data types. This only needs to be done once at the start of the program. The data types should then be freed at the end of the program in the finalize routine.

**中文:** 清单 16.1 的第一段创建这两个数据类型。程序开始时完成一次即可；结束时应在清理例程中释放它们。

### 图 16.3
原书 p.553 / PDF p.589。

![图 16.3](assets/fig16_3.png)

The 4x4 blocks of data from each process written without the halo cells to contiguous sections of the output file. The top row is the memory layout on the process, referred to as the memspace. The middle row is the memory in the file with the halo cells stripped off, referred to as the filespace. The memory in the file is actually linear, so it takes the form in the last row.

本地 4×4 实单元由 halo 包围，写入结果只留下全局场中的有效位置。

看最下面的一行：全局数组按行展开。若子块只占每行的一部分，一块的相邻两行在文件中有间隔，不能把所有 rank 的局部数组逐块串接。

**代码出处：** C/MPI · 清单 16.1 的二维教学整理，假定非空子块且维度在 int 范围内

```text
int full_mem[2] = {ny+2*ng, nx+2*ng};
int shape[2]    = {ny, nx};
int mem_at[2]   = {ng, ng};
int full_file[2]= {Ny, Nx};
int file_at[2]  = {y0, x0};
MPI_Type_create_subarray(2, full_mem, shape, mem_at,
                         MPI_ORDER_C, MPI_DOUBLE, &memtype);
MPI_Type_create_subarray(2, full_file, shape, file_at,
                         MPI_ORDER_C, MPI_DOUBLE, &filetype);
MPI_Type_commit(&memtype);
MPI_Type_commit(&filetype);
```

### 读懂六个参数

2 表示二维；完整尺寸、子块尺寸、起点依次给出；MPI_ORDER_C 使最右维 x 的下标变化最快。mem_at 从分配区起点量取，file_at 从全局网格起点量取。最后一个参数带 &，让 MPI 写回类型句柄。原清单后半段 ndim 与参数 ndims 的拼写应统一。

### 指针前提

内存类型假设整块按行连续分配。传入包含 halo 的缓冲区基址。如果传入已经跳过 halo 的首个内部元素地址，类型自带的 mem_at 会再偏移一次；若每行各自 malloc，也不能用整块的固定行跨度来描述。


<a id="16.3-view"></a>
## 16.3（续）设置文件视图，写出与读回
原书 p.554–556。

**Source:** 原书 p.552 / PDF p.588

**Original:** The MPI_File_set_view function is used to set the data layout in the file.

**中文:** MPI_File_set_view 用来指定数据在文件中的布局。

**代码出处：** C/MPI · 清单 16.2 教学整理，仅用于新建的本次试验文件；省略逐次状态检查

```text
MPI_File fh;
MPI_File_open(comm, new_path, MPI_MODE_CREATE | MPI_MODE_WRONLY,
              MPI_INFO_NULL, &fh);
MPI_Offset bytes = (MPI_Offset)Ny * Nx * sizeof(double);
MPI_File_set_size(fh, bytes);
MPI_File_set_view(fh, 0, MPI_DOUBLE, filetype, "native", MPI_INFO_NULL);
MPI_File_write_all(fh, local_base, 1, memtype, MPI_STATUS_IGNORE);
MPI_File_close(&fh);
```

### 字节与元素分清

MPI_File_set_view 的首个偏移参数按字节计。随后 MPI_File_write_at_all 的显式偏移则是视图中可见 etype 的个数。这里一次写 1 个 memtype，其中已选中 ny×nx 个 double。原书清单 16.4 将 Ny×Nx 元素数命名为 data_size 并传给设置文件大小的例程，预设字节长度需乘存储字节数，并在首次乘法前扩宽类型。

### 用另一种方式读

集体只读打开后安装一致的文件视图，MPI_File_read_all 将内部元素写入恢复数组。用不同形状的进程网格重启时重新计算本次的 file_at 和内存类型。若使用 native 表示，还需在文件说明中约定标量类型、字节序和形状。


<a id="16.3-split"></a>
## 16.3（续）N 个进程对应 M 个文件
原书 p.556–559。

### 图 16.4
原书 p.558 / PDF p.594。

![图 16.4](assets/fig16_4.png)

At large sizes, the processes can be broken up into communication groups by colors so they write out to separate files. The ranks of the subgroups are in the same order as the ranks in the original communicator.

按颜色拆分通信器，每个组写自己的文件。

组内 rank 与全局 rank 的数值可能不同。相同颜色、按原 rank 作 key，可以保留组内相对顺序。文件名需区分颜色，并在元数据中保存每个分片的全局位置。

**代码出处：** C/MPI · 清单 16.4 思路，1≤nfiles≤nranks；二维分块需在对应行或列的通信器中扫描

```text
int color = (int)((long long)rank * nfiles / nranks);
MPI_Comm file_comm;
MPI_Comm_split(comm, color, rank, &file_comm);
// 分组内有序的一维示意
MPI_Offset x0 = 0, local_n = nx;
MPI_Exscan(&local_n, &x0, 1, MPI_OFFSET, MPI_SUM, file_comm);
int fr;
MPI_Comm_rank(file_comm, &fr);
if (fr == 0) x0 = 0;
```

### 偏移从何而来

若同一行的三个块宽为 4、3、5，排他扫描得到 0、4、7，行宽为 12。MPI_Exscan 不定义组内首个 rank 的结果，因此显式置零。二维布局要先建立一致的行、列顺序，不能把所有 rank 的局部宽度无差别累加。

### 图 16.5
原书 p.559 / PDF p.595。

![图 16.5](assets/fig16_5.png)

Output from a small binary read code for the MPI-IO shows what the file contains. With MPI-IO, we had to write a small utility to check the file contents.

独立的顺序二进制读取程序逐行打印文件，用全局顺序检查块的拼接。

读写都用同一份错误的视图，局部回读有时也会“匹配”。给每个全局单元赋唯一值，如 y*Nx+x，再由完整二维参考数组进行独立比较。


<a id="16.4"></a>
## 16.4 HDF5｜自描述的数组与数据空间
原书 p.559–562。

**Source:** 原书 p.559 / PDF p.595

**Original:** HDF5 provides a self-describing parallel data format. HDF5 is called self-describing because the name and characteristics are stored in the file with the data.

**中文:** HDF5 提供自描述的并行数据格式。“自描述”是说，名称和描述数据特征的信息与数据一起存入文件。

### 把物理含义也写进去

数据集 /height 可以保存 shape=(Ny,Nx)、类型和元素内容。记录单位 m、网格坐标、时间、变量解释和算法版本后，接收文件的读者才有足够信息重建科学含义。大型数据集先看结构，再选一个小区域查看值。

### 表 16.4
原书 p.560 / PDF p.596。

![表 16.4](assets/fig16_T4.png)

HDF5 collective file routines

H5F 前缀的文件接口。

H5Fcreate 的 flags 决定如何处理同名文件。创建、打开和关闭的并行参与规则要结合具体文件驱动与元数据操作。

### 表 16.5
原书 p.560 / PDF p.596。

![表 16.5](assets/fig16_T5.png)

HDF5 dataspace routines

H5S 前缀建立和选择数据空间。

dataspace 描述维数、形状与选择范围；标量怎样编码由 datatype 描述。

### 表 16.6（上）
原书 p.560 / PDF p.596。

![表 16.6（上）](assets/fig16_T6a.png)

HDF5 dataset routines

表 16.6 上半部分，H5D 前缀操作有名字的数据集。

文件可以容纳多个数据集，每个数据集有自己的类型与形状。

### 表 16.6（续）
原书 p.561 / PDF p.597。

![表 16.6（续）](assets/fig16_T6b.png)

HDF5 dataset routines  (continued)

表 16.6 续页，按内存选择与文件选择读写数据。

选择区域元素数须匹配，形状和跨度可以不同。


<a id="16.4-hyperslab"></a>
## 16.4（续）hyperslab 的起点、步长与块数
原书 p.561–562。

**Source:** 原书 p.562 / PDF p.598

**Original:** In listing 16.5, we used the same pattern when creating the two dataspaces: create the data object, set the data size arguments, and then select a rectangular region of the array.

**中文:** 清单 16.5 用相同的思路建立两个数据空间：创建相应对象，指定尺寸，再选取数组中的矩形区域。

**代码出处：** C/HDF5 · 清单 16.5 内容整理，非空连续矩形示例

```text
hsize_t global[] = {Ny, Nx}, local[] = {ny+2*ng, nx+2*ng};
hsize_t file_at[] = {y0, x0}, mem_at[] = {ng, ng};
hsize_t count[] = {ny, nx};
hid_t fs = H5Screate_simple(2, global, NULL);
hid_t ms = H5Screate_simple(2, local, NULL);
H5Sselect_hyperslab(fs,H5S_SELECT_SET,file_at,NULL,count,NULL);
H5Sselect_hyperslab(ms,H5S_SELECT_SET,mem_at,NULL,count,NULL);
```

### 逐参数解释

H5S_SELECT_SET 以新选择替换旧选择。start 指起点，stride 指相邻块起点间距，count 指每维块数，block 指每块大小。这里两个 NULL 分别采用单位步长与单位块，选择 ny×nx 个点。使用 H5Sget_select_npoints 可以在写入前检查两侧点数。


<a id="16.4-transfer"></a>
## 16.4（续）文件访问与一次集体写各自配置
原书 p.561–566。

### 表 16.7
原书 p.561 / PDF p.597。

![表 16.7](assets/fig16_T7.png)

HDF5 property list routines

属性列表把文件访问策略与数据集传输策略区分开。

FAPL 携带通信器与文件驱动设置，DXPL 指定一次数据集传输的模式。创建文件与数据集时，还要按参与通信器的约定一致执行元数据操作。

**代码出处：** C/并行 HDF5 · 清单 16.6 的教学改写；fs、ms 来自上一单元，示例省略错误处理

```text
hid_t fapl = H5Pcreate(H5P_FILE_ACCESS);
H5Pset_fapl_mpio(fapl, comm, MPI_INFO_NULL);
hid_t f = H5Fcreate(new_path, H5F_ACC_EXCL, H5P_DEFAULT, fapl);
hid_t ds = H5Dcreate2(f, "height", H5T_IEEE_F64LE, fs,
                      H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
hid_t dxpl = H5Pcreate(H5P_DATASET_XFER);
H5Pset_dxpl_mpio(dxpl, H5FD_MPIO_COLLECTIVE);
H5Dwrite(ds, H5T_NATIVE_DOUBLE, ms, fs, dxpl, local_base);
H5Pclose(dxpl);
H5Dclose(ds);
H5Fclose(f);
H5Pclose(fapl);
```

### 同一调用的两种类型

H5Dcreate2 使用 H5T_IEEE_F64LE 描述磁盘中的数值编码。H5Dwrite 第二个参数 H5T_NATIVE_DOUBLE 描述 C 缓冲区。原书在写调用也传入小端文件类型，若希望跨主机字节序复用代码，应分别声明内存与文件类型。

### 进程无数据时

集体写中没有数据的 rank 仍需参加调用，可通过合法空选择表示零个元素。所有参与者应以一致顺序创建相同数据集。H5Dclose、H5Sclose 和 H5Pclose 分别关闭不同种类的句柄；返回负值时应采用全组一致的错误处理流程。


<a id="16.4-read"></a>
## 16.4（续）独立读取与安装检查
原书 p.564–567。

**Source:** 原书 p.567 / PDF p.603

**Original:** The example code does a verification test to check that the data read back from the file is the same as the data that we started with. We can also use the h5dump utility to print the data in the file.

**中文:** 示例会做一次校验，检查从文件读回的数据与最初的数据相同。我们还可以用 h5dump 工具打印文件中的数据。

### 图 16.6
原书 p.567 / PDF p.603。

![图 16.6](assets/fig16_6.png)

Using the h5dump command-line utility shows what is contained in the HDF5 file without having to write any code.

直接查看 HDF5 文件的数据集名称、维度、类型与内容。

先确认数据集的全局形状；再检查分块交界处的值。表面连续的数字不足以证明 y、x 坐标顺序正确。

**代码出处：** Shell · 文件结构和局部检查；最后一行采用讲义的数据集名 /height 和截取范围

```text
h5ls -r example.hdf5
h5dump -H example.hdf5
h5dump -d /height -s "0,0" -c "2,4" example.hdf5
```

### 构建清单 16.9 的意图

寻找 HDF5 包时优先选择 parallel 构建，再检查 HDF5_IS_PARALLEL 等探测结果。仅安装 MPI 或仅能创建普通 .h5 文件，都无法证明 MPIO 驱动可用。读回数据时可用只读模式打开同一文件，在当前进程网格上重新计算内存与文件选择。


<a id="16.4-lab"></a>
## 16.4（实验）带 halo 的真实 HDF5 文件回读
原书 p.561–567。

### 可复现实验

资料包的 check_hyperslabs.py 使用 h5py 的底层 H5S 选择写出全局数据集，通过另一条高层切片路径读回。原数值设为 y×Nx+x，halo 用 −999 标记。先验证整个二维场，再恢复每个块并检查内部和 halo。

**代码出处：** Python/h5py · 实验中的两次选择与一次写入，数组元素为 float64

```text
memory.select_hyperslab((halo,halo), (ny,nx))
disk.select_hyperslab((y0,x0), (ny,nx))
dataset.id.write(memory,disk,local)
```

### 本次结果

使用 h5py 3.16.0 / HDF5 2.0.0 的串行驱动实际写入并重新打开了四个临时文件。4×16 网格均分成 4 块、7×11 网格不均分成 6 块（分别带两层与零层 halo）、2×3 网格映射到 4×5 个逻辑块（6 个非空）均逐元素通过。空块在串行调度中跳过。此实验检验数据布局；集群 MPI 集体调用和并行文件系统带宽需在对应环境测量。


<a id="16.5"></a>
## 16.5 PnetCDF、netCDF-4 与 ADIOS
原书 p.568。

**Source:** 原书 p.568 / PDF p.604

**Original:** Because the files generated by your application are often used by others, using the same data standard is important.

**中文:** 应用生成的文件往往还要交给其他人使用，因此采用共同的数据标准十分重要。

### 区分两个后端

PnetCDF 通过并行接口访问经典 CDF-1、CDF-2、CDF-5 格式；netCDF-4 的 HDF5 格式并行访问可使用并行 HDF5。原书提到“并行版本建立在 HDF5 和 MPI-IO 之上”时需区分这两条路径。先检查下游软件可读的格式，再选库。

### ADIOS 的抽象

ADIOS/ADIOS2 把变量声明、写入步骤与底层引擎分开。若应用既要落盘重启又要将数据送给并行分析端，需分别检验所选引擎的持久性、读端兼容性与吞吐。


<a id="16.6"></a>
## 16.6 并行文件系统与硬件接口
原书 p.568–569。

**Source:** 原书 p.568 / PDF p.604

**Original:** There is still a mismatch between the application parallelism and the parallelism provided by the filesystem.

**中文:** 应用能暴露的并行度，与文件系统能够提供的并行度之间，仍然存在差距。

### 文件名到数据块

应用看到目录与文件，文件系统需要元数据定位对象与数据区段。许多小文件可能先把创建、打开、关闭路径压满；大文件的连续传输则可能受网络、目标数量或后端设备带宽限制。把 N 个 rank 增至 2N 以后，应分别测元数据操作和有效字节传输。


<a id="16.6.1"></a>
## 16.6.1 查询 MPI-IO 实现与生效参数
原书 p.568–572。

**Source:** 原书 p.569 / PDF p.605

**Original:** You can also verify how the MPI_Info_set calls are interpreted by the MPI-IO library with the following run-time option.

**中文:** 还可以通过相应运行时选项，检查 MPI-IO 库如何解释程序中的 MPI_Info_set 调用。

**代码出处：** Shell · Open MPI 的组件查询；组件名与可见参数以本机安装为准

```text
ompi_info --param io all
ompi_info --param io ompio --level 9
```

**代码出处：** C/MPI · key 与 value 都是字符串。文件打开完成后可释放传入的 MPI_Info

```text
MPI_Info hints;
MPI_Info_create(&hints);
MPI_Info_set(hints, "cb_nodes", "4");
// 在接受该提示的 MPI-IO 实现中，把 hints 传给 MPI_File_open
MPI_Info_free(&hints);
```

### 要找的三层证据

先查使用 ROMIO、OMPIO 或厂商实现，再看库报告的 hints，最后看实际聚合器、系统写调用数、每次请求大小和文件布局。hint 可以被忽略或调整。原书 Cray 输出中请求 8 条带，运行时却报告有效宽度为 1，是“请求值”和“生效值”分开的具体例子。

### 读一次统计输出

原书 p.571 显示 4 次集体写、1 个聚合器、2 次系统写，共写 3600 B。一次集体 MPI 调用、参与它的进程数、以及最终发生的系统调用数是不同计数。该例特定平台的统计值不能用来估算通用设备带宽。


<a id="16.6.2"></a>
## 16.6.2 通用提示：聚合与 data sieving
原书 p.572–574。

### 两阶段 I/O

多个 rank 的文件片段可能彼此交错。先按目标区段交换数据，让少数聚合器提交大而连续的写请求，有机会减少碎片化 I/O 和竞争；代价是进程间通信、暂存内存与额外复制。改变 cb_nodes 和 cb_buffer_size 后，比较同一数据量下最慢进程用时。

### data sieving

同一 rank 的请求之间有小孔洞时，可读入覆盖这些片段的大区间再挑选需要的数据。写入有孔洞的区间有时需要读—改—写并处理锁。孔洞越大，额外读取越多。调参前先看布局的跨度和有效字节数。

**代码出处：** Shell · 原书 ROMIO 查询思路，环境变量是否受支持取决于该安装

```text
ROMIO_PRINT_HINTS=1 mpirun -n 4 ./mpi_io_block2d
```

### 提示不能改变程序语义

romio_no_indep_rw 等承诺须符合整个程序后续的访问模式。若程序确有独立读写，就不能为了聚合性能声称“全部集体”。命令行、环境变量、提示文件与 MPI_Info 的优先级依实际实现而定。


<a id="16.6.3"></a>
## 16.6.3 针对目标文件系统调参
原书 p.574–577。

**Source:** 原书 p.574 / PDF p.610

**Original:** Some hints only apply to a particular filesystem, such as Lustre or GPFS. We can detect the filesystem type from within our program and set the appropriate hints for the filesystem.

**中文:** 有些提示只适用于特定文件系统，如 Lustre 或 GPFS。程序可以识别文件系统类型，再据此设置适用的提示。

### Lustre 条带的读法

stripe count 控制一个文件跨多少存储目标放置，stripe size 控制向下一个目标轮转前的一段长度。原书用 8 和 4194304（4 MiB）举例。目标可以由多块盘组成，把这两个数字理解为“8 块物理盘”会漏掉中间层。元数据服务与实际数据服务也承担不同工作。

**代码出处：** Linux · 第一句查询路径落在哪个挂载，第二句仅适用于提供 lfs 的 Lustre 环境

```text
findmnt -T /path/to/output
lfs getstripe /path/to/existing-file
```

### 清单 16.10 与其他系统

Linux statfs(path,&s) 可报告挂载类型。选输出目录作为被检查的路径，确保它与待写文件位于同一挂载。书中还讨论 GPFS、DataWarp、Panasas、OrangeFS、BeeGFS、DAOS、Weka、Ceph 和 NFS。它们的默认布局和调参接口不同，应从本地文件系统文档和站点策略确认有效参数；原书的排名和部署计划属于出版语境。


<a id="16.7"></a>
## 16.7 延伸探索与性能实验设计
原书 p.577–578。

**Source:** 原书 p.577 / PDF p.613

**Original:** You can use the micro benchmarks, IOR and mdtest, to check the best performance of a filesystem.

**中文:** 可以用 IOR 和 mdtest 等微基准测试文件系统在指定条件下所能表现出的性能。

### 把带宽和元数据率分开

IOR 的大块读写与 mdtest 的文件创建、查找、删除等工作负载回答不同问题。记录总有效字节、文件数、进程数、节点数、条带、缓存冷热、是否同步落盘与计时起止。对集体保存步骤，以共同定义的区间和最慢参与者为依据。


<a id="16.7.1"></a>
## 16.7.1 延伸阅读
原书 p.577–578。

### 原书阅读线索

Gropp、Thakur 与 Lusk 的 Using MPI-2 讨论 MPI-IO 的接口设计；Prabhat、Koziol 等的 High Performance Parallel I/O 讨论不同层次的并行存储。实际接口细节可查 MPI Forum 标准、HDF Group 文档、PnetCDF 项目及 ADIOS2 手册。


<a id="16.7.2"></a>
## 16.7.2 练习与核对思路
原书 p.578。

### 练习 1 · 查实际配置

从一次小规模作业开始，记录 MPI-IO 实现、文件系统类型、接受的 hint 与实际布局。改变一项设置，重新创建试验文件并比较报告；原有文件的布局可能由创建时配置固定。

### 练习 2 · 放大数据量

在指定临时目录分别跑 MPI-IO 与并行 HDF5 的读写。保持全局网格、变量类型、进程布局和持久化要求一致，计入文件创建、元数据及必要关闭/同步。再与 IOR 对齐工作负载，解释差异。

### 练习 3 · 从文件恢复含义

用 h5ls 看层级，再用 h5dump 看形状、类型、属性及角落小块。将全局坐标唯一值与打印出的元素逐项比较。讲义的 HDF5 实验覆盖非整除维度、不同 halo 深度及逻辑空块，可作本地复现起点。


## 技术参考

[官方参考文档](https://docs.h5py.org/en/stable/mpi.html)