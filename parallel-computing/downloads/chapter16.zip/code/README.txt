第 16 章实验：二维数据的内存选择与文件选择

用 Python 3、NumPy 和 h5py 运行：
python check_hyperslabs.py

程序在临时目录创建 4 个 HDF5 文件，再以只读方式打开。每个文件有一个 height 数据集与单位属性。它逐元素核对全局二维排列，再把每个实单元块读回带 halo 的数组，检查 halo 的哨兵值保持完整。终端输出 JSON，hyperslab_results.json 保存本次结果。

本次使用 h5py 3.16.0、HDF5 2.0.0 的串行驱动。多块逻辑区域按顺序写入，MPI 多进程通信与文件系统带宽需在并行环境单独验证。
