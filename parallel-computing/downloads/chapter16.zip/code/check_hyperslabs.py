"""Serial HDF5 exercise: write rank-like tiles, verify file layout independently."""
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import h5py
import numpy as np

def bounds(n, k, total):
    return n*k//total, n*(k+1)//total

def verify_case(directory, height, width, py, px, halo):
    path = directory / f"field-{height}x{width}-{py}x{px}-{halo}.h5"
    sentinel = -999.0
    blocks = []
    with h5py.File(path, "x") as file:
        dataset = file.create_dataset("height", (height, width), dtype="<f8")
        dataset.attrs["units"] = "m"
        for ry in range(py):
            y0, y1 = bounds(height, ry, py)
            for rx in range(px):
                x0, x1 = bounds(width, rx, px)
                ny, nx = y1-y0, x1-x0
                if nx == 0 or ny == 0:
                    continue
                local = np.full((ny+2*halo,nx+2*halo), sentinel)
                for j in range(ny):
                    for i in range(nx):
                        local[j+halo,i+halo] = (y0+j)*width + x0+i
                memory = h5py.h5s.create_simple(local.shape)
                disk = dataset.id.get_space()
                try:
                    memory.select_hyperslab((halo,halo), (ny,nx))
                    disk.select_hyperslab((y0,x0), (ny,nx))
                    assert memory.get_select_npoints() == disk.get_select_npoints() == nx*ny
                    dataset.id.write(memory,disk,local)
                finally:
                    memory.close()
                    disk.close()
                blocks.append((y0,y1,x0,x1))
    with h5py.File(path, "r") as file:
        dataset = file["height"]
        expected = np.arange(height*width,dtype=np.float64).reshape(height,width)
        assert dataset.attrs["units"] == "m"
        np.testing.assert_array_equal(dataset[...],expected)
        for y0,y1,x0,x1 in blocks:
            ny,nx = y1-y0,x1-x0
            restored = np.full((ny+2*halo,nx+2*halo),sentinel)
            inside = np.s_[halo:halo+ny,halo:halo+nx]
            dataset.read_direct(restored,np.s_[y0:y1,x0:x1],inside)
            np.testing.assert_array_equal(restored[inside],expected[y0:y1,x0:x1])
            mask = np.ones(restored.shape,dtype=bool)
            mask[inside] = False
            assert np.all(restored[mask] == sentinel)
    return {"shape":[height,width],"decomposition":[py,px],"halo":halo,
            "nonempty_blocks":len(blocks),"useful_bytes":height*width*8}

if __name__ == "__main__":
    cases = [(4,16,1,4,1),(7,11,2,3,2),(7,11,2,3,0),(2,3,4,5,1)]
    with TemporaryDirectory() as tmp:
        results = [verify_case(Path(tmp),*case) for case in cases]
    report = {"h5py":h5py.__version__,"HDF5":h5py.version.hdf5_version,
              "driver":"serial","passed_cases":results}
    print(json.dumps(report,indent=2))
