OpenFOAM v2512
本包保存本页的边界子字典示例。将 boundaryField.foam 中的内容放入 0/alpha.water 的 boundaryField，并将边界名称改为实际网格 patch。
它是配套配置片段，不包含独立求解所需的网格、物性和数值字典。
类型：constantAlphaContactAngle
说明：90° 示例用于中性润湿。改变相名称或交换相序时应重新核对角度方向；可先用静止液滴检验接触线形状和压差，再用于动态润湿计算。
官方依据：https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/src/transportModels/twoPhaseProperties/alphaContactAngle/constantAlphaContactAngle/constantAlphaContactAngleFvPatchScalarField.H
