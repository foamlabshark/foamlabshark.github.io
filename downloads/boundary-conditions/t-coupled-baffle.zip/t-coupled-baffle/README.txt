OpenFOAM v2512
本包保存本页的边界子字典示例。将 boundaryField.foam 中的内容放入 0/T 的 boundaryField，并将边界名称改为实际网格 patch。
它是配套配置片段，不包含独立求解所需的网格、物性和数值字典。
类型：compressible::turbulentTemperatureCoupledBaffleMixed
说明：本例是流体侧的温度条件；固体侧使用相同类型并将 kappaMethod 设为 solidThermo。两侧网格需要映射到对侧的区域与 patch；字段边界本身不建立网格映射。
官方依据：https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/src/thermoTools/derivedFvPatchFields/turbulentTemperatureCoupledBaffleMixed/turbulentTemperatureCoupledBaffleMixedFvPatchScalarField.H
