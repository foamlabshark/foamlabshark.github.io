OpenFOAM v2512
本包保存本页的边界子字典示例。将 boundaryField.foam 中的内容放入 0/U 的 boundaryField，并将边界名称改为实际网格 patch。
它是配套配置片段，不包含独立求解所需的网格、物性和数值字典。
类型：partialSlip
说明：速度关系为 U壁=f·U参考+(1−f)·(I−nn)·U内。示例令参考速度为零，保留内部切向速度的 75%，同时令法向速度为零。valueFraction 不是滑移长度，不能把单位为 m 的滑移长度直接填入；若物理模型给定 Navier 滑移长度，应按离散关系换算或使用相应的边界实现。
官方依据：https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/src/finiteVolume/fields/fvPatchFields/derived/partialSlip/partialSlipFvPatchField.H
