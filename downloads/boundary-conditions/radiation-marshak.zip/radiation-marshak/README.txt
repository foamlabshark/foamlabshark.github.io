OpenFOAM v2512
本包保存本页的边界子字典示例。将 boundaryField.foam 中的内容放入 0/G 的 boundaryField，并将边界名称改为实际网格 patch。
它是配套配置片段，不包含独立求解所需的网格、物性和数值字典。
类型：MarshakRadiation
说明：与 T 的温度或热流边界分别配置；G 的单位为 W/m²，不是温度。
官方依据：https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/src/thermophysicalModels/radiation/derivedFvPatchFields/MarshakRadiation/MarshakRadiationFvPatchScalarField.H
