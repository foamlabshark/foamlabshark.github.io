OpenFOAM v2512
本包保存本页的边界子字典示例。将 boundaryField.foam 中的内容放入 0/U 的 boundaryField，并将边界名称改为实际网格 patch。
它是配套配置片段，不包含独立求解所需的网格、物性和数值字典。
类型：rotatingWallVelocity
说明：例如半径 0.1 m、角速度 10 rad/s 的圆柱，其壁面切向速度为 1 m/s。600 rpm 应换算为 20π≈62.832 rad/s。该条件计算旋转速度后会去掉壁面法向分量；网格本身的旋转应另用动网格或旋转参考系配置。静止不可压缩算例的压力壁面可用 zeroGradient；存在重力或特定通量约束时按求解器配置压力条件。
官方依据：https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/src/finiteVolume/fields/fvPatchFields/derived/rotatingWallVelocity/rotatingWallVelocityFvPatchVectorField.H
