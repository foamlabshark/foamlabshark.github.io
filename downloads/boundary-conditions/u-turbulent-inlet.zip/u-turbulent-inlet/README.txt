OpenFOAM v2512
本包保存本页的边界子字典示例。将 boundaryField.foam 中的内容放入 0/U 的 boundaryField，并将边界名称改为实际网格 patch。
它是配套配置片段，不包含独立求解所需的网格、物性和数值字典。
类型：turbulentInlet
说明：该条件提供随机扰动，不能直接保证指定的湍流能谱、空间相关或无散度。需要受控湍流结构时查看 DFSEM 或数字滤波入口。
官方依据：https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/src/finiteVolume/fields/fvPatchFields/derived/turbulentInlet/turbulentInletFvPatchField.H
