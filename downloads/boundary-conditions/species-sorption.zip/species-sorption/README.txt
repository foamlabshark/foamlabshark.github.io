OpenFOAM v2512
本包包含本页展示的原始字段文件及已收录的包含文件。
先复制完整官方算例，再按这些文件的位置对照和修改。
官方算例：https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/combustion/rhoReactingFoam/groundAbsorption
检查壁面吸附量与流体中组分总量的变化。
