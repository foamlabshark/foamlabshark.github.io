OpenFOAM v2512
本包保存本页的边界子字典示例。将 boundaryField.foam 中的内容放入 0/标量 / 矢量 的 boundaryField，并将边界名称改为实际网格 patch。
它是配套配置片段，不包含独立求解所需的网格、物性和数值字典。
类型：calculated
说明：常见于 nut 等由模型计算的场。它本身不提供独立输运方程的物理边界闭合；需要求解边界系数的主变量通常不能随意改成 calculated。
官方依据：https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/src/finiteVolume/fields/fvPatchFields/basic/calculated/calculatedFvPatchField.H
