OpenFOAM v2512
本包包含本页展示的原始字段文件及已收录的包含文件。
先复制完整官方算例，再按这些文件的位置对照和修改。
官方算例：https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/incompressible/pimpleFoam/LES/planeChannel/setups.orig/DFSEM
复制完整算例中的 boundaryData，比较入口后的速度均值和 Reynolds 应力发展。
