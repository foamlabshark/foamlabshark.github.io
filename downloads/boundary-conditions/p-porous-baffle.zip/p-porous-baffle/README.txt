OpenFOAM v2512
本包包含本页展示的原始字段文件及已收录的包含文件。
先复制完整官方算例，再按这些文件的位置对照和修改。
官方算例：https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/damBreakLeakage
与体积多孔源项相比，该条件把压降集中在薄面上，适合不解析厚度的滤网。
