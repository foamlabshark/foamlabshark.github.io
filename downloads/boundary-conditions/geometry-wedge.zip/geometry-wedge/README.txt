OpenFOAM v2512
本包保存本页的边界子字典示例。将 boundaryField.foam 中的内容放入 0/各场 的 boundaryField，并将边界名称改为实际网格 patch。
它是配套配置片段，不包含独立求解所需的网格、物性和数值字典。
类型：wedge
说明：网格的两侧 wedge 面和各字段的 wedge 条件必须配套；轴向、夹角和单元层数需要满足 wedge 网格要求。
官方依据：https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/src/finiteVolume/fields/fvPatchFields/constraint/wedge/wedgeFvPatchField.H
