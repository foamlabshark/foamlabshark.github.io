OpenFOAM v2512
本包保存本页的边界子字典示例。将 boundaryField.foam 中的内容放入 0/p / 标量 的 boundaryField，并将边界名称改为实际网格 patch。
它是配套配置片段，不包含独立求解所需的网格、物性和数值字典。
类型：advective
说明：本例展示运动学压力初始化。advective 使用对流速度；可压缩声波出口还应考虑波速，通常进一步查看 waveTransmissive。
官方依据：https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/src/finiteVolume/fields/fvPatchFields/derived/advective/advectiveFvPatchField.H
