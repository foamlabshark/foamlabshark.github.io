OpenFOAM v2512
本包保存本页的边界子字典示例。将 boundaryField.foam 中的内容放入 0/U 的 boundaryField，并将边界名称改为实际网格 patch。
它是配套配置片段，不包含独立求解所需的网格、物性和数值字典。
类型：fixedNormalSlip
说明：若壁面外法向沿 x，则法向速度为 1 m/s；切向 y、z 分量仍由内部场决定。不可把它等同于完整向量 fixedValue。
官方依据：https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/src/finiteVolume/fields/fvPatchFields/derived/fixedNormalSlip/fixedNormalSlipFvPatchField.H
