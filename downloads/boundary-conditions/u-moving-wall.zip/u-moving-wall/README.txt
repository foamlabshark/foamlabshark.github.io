OpenFOAM v2512
每个 example-N 都是独立的完整算例。加载 OpenFOAM 环境后进入目录并运行 sh Allrun。
reference-logs 保存虚拟机实测记录。这是短时配置检查，不代表工程计算收敛。
