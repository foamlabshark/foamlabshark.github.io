OpenFOAM v2512
本包包含本页展示的原始字段文件及已收录的包含文件。
先复制完整官方算例，再按这些文件的位置对照和修改。
官方算例：https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/incompressible/simpleFoam/turbineSiting
用于求解 epsilon 的湍流模型，入口和地面应共同维持目标剖面。
