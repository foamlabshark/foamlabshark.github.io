OpenFOAM v2512
本包保存本页的边界子字典示例。将 boundaryField.foam 中的内容放入 0/标量 / 矢量 的 boundaryField，并将边界名称改为实际网格 patch。
它是配套配置片段，不包含独立求解所需的网格、物性和数值字典。
类型：mixed
说明：本示例用于温度 T。混合的是离散边界关系；0.5 不意味着整个流场温度是两种独立计算结果的算术平均。
官方依据：https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/src/finiteVolume/fields/fvPatchFields/basic/mixed/mixedFvPatchField.H
