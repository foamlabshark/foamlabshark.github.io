OpenFOAM v2512
本包保存本页的边界子字典示例。将 boundaryField.foam 中的内容放入 0/U 的 boundaryField，并将边界名称改为实际网格 patch。
它是配套配置片段，不包含独立求解所需的网格、物性和数值字典。
类型：swirlFlowRateInletVelocity
说明：体积通量算例中 0.01 表示 0.01 m³/s。先检查 phi 的量纲，再判断流量单位；不能直接把质量流量写入体积通量算例。
官方依据：https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/src/finiteVolume/fields/fvPatchFields/derived/swirlFlowRateInletVelocity/swirlFlowRateInletVelocityFvPatchVectorField.H
