OpenFOAM v2512
本包包含本页展示的原始字段文件及已收录的包含文件。
先复制完整官方算例，再按这些文件的位置对照和修改。
官方算例：https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/combustion/fireFoam/LES/compartmentFire
分别检查导热与辐射贡献，再按两侧相反的外法向比较总热流。
