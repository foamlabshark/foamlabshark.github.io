OpenFOAM v2512
本包包含本页展示的原始字段文件及已收录的包含文件。
先复制完整官方算例，再按这些文件的位置对照和修改。
官方算例：https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/combustion/reactingFoam/RAS/membrane
所有参与热力学混合物的组分均须使用 semiPermeableBaffleMassFraction。速度由各组分通量之和除以密度和面积得到，并沿面法向设置。
