求解器运行后，操作系统把它作为进程管理。进程具有自己的编号 PID、内存和 CPU 使用量。掌握进程查看和后台运行后，可以判断计算是否仍在进行、资源是否充足，以及终端断开后怎样继续查看任务。

## 用一个短任务理解后台运行

```bash
mkdir -p "$HOME/foamlab-linux-lab/06-processes"
cd "$HOME/foamlab-linux-lab/06-processes"
sleep 60 &
job_pid=$!
printf 'PID=%s\n' "$job_pid"
jobs
```

`sleep 60` 等待 60 秒后退出，适合练习进程管理。行末的 `&` 让命令在后台运行，终端立即返回提示符。`$!` 是最近启动的后台任务 PID，保存后可以准确查看这个任务。`jobs` 列出当前 shell 管理的作业。

查看它的状态：

```bash
ps -p "$job_pid" -o pid,etime,stat,comm
```

`-p` 按 PID 选择，`-o` 指定输出列：进程编号、已运行时间、状态和命令名。`sleep` 经常处于睡眠状态 `S`。任务正常结束后，`ps` 不再显示该进程。

## 前台、后台与暂停

后台任务可用 `fg %1` 调回前台，`%1` 是 `jobs` 中显示的作业号。前台运行期间按 `Ctrl+Z` 会暂停任务，随后 `bg %1` 让它在后台继续。暂停的任务停止推进，重新继续后才恢复计算。

`Ctrl+C` 向当前前台程序发送中断信号。对于本课的 `sleep`，可以直接结束练习；对求解器则需要考虑结果写出。运行较长案例时，可采用求解器支持的写出后停止方式，或在结束前保存必要时间状态。

当前终端中的作业号和操作系统 PID 是两套编号：`jobs` 用 `%1` 这类作业标识，`ps` 用整数 PID。在不同终端查看任务时使用 PID 或命令名更方便。

## 查看求解器与机器资源

```bash
pgrep -a icoFoam
ps -u "$USER" -o pid,%cpu,%mem,etime,comm
free -h
df -h .
du -sh .
```

`pgrep -a` 查找名称匹配的进程并显示命令，`ps -u` 列出自己的进程。`free -h` 查看内存，重点留意可用内存 `available`；Linux 会利用空闲内存缓存文件，因此单独看 `free` 一列容易低估可用空间。

`df -h .` 查看当前目录所在文件系统的容量，`du -sh .` 统计当前目录占用。OpenFOAM 多进程和多时间输出会增大文件数量与磁盘用量，运行前可根据已有案例估计空间。

`top` 提供动态进程视图，按 `q` 退出。某些系统中单进程 CPU 百分比以一个逻辑核为 100% 统计，多线程程序可能超过 100%。并行 OpenFOAM 常表现为多个 MPI 进程共同工作。

![多个进程协同计算](/assets/diagrams/core-parallel.svg)

## 后台写日志

```bash
nohup bash -c 'for i in 1 2 3 4 5; do printf "step %s\n" "$i"; sleep 2; done' > log.background 2>&1 &
background_pid=$!
tail -f log.background
```

这个示例每两秒输出一条记录，共五条。`nohup` 使程序忽略常见的终端挂断信号，`&` 放到后台，输出全部保存到日志。`tail -f` 持续显示新增内容；五条记录结束后，按 `Ctrl+C` 退出日志查看。

在同一个 shell 中可以用 `wait "$background_pid"` 等待后台任务结束，并读取它的退出状态。`nohup` 的实际持续运行还受服务器会话策略影响；需要方便地重新连接和查看终端，通常可采用 `tmux`。

## 使用 tmux 保留计算会话

安装 `tmux` 后执行：

```bash
tmux new -s foam-study
```

它创建名为 `foam-study` 的会话。在其中进入算例目录、加载 OpenFOAM 环境并启动求解器。按 `Ctrl+B`，松开后再按 `D`，可以脱离会话，程序继续运行。

稍后连接回来：

```bash
tmux ls
tmux attach -t foam-study
```

`ls` 列出会话，`attach` 重新进入指定会话。一个会话中还可以创建多个窗口，分别用于求解、日志和资源查看。远程计算时先 SSH 登录服务器，再创建 `tmux` 会话，任务就在服务器上运行。

集群通常要求通过 Slurm 等调度器提交计算，`tmux` 可用于维持交互操作，但资源分配由调度器控制。记录作业号后，通过平台提供的查询命令观察状态。

## 怎样让 OpenFOAM 写出后停止

支持运行中读取控制字典的案例，可在另一个终端进入同一算例并执行：

```bash
foamDictionary system/controlDict -entry stopAt -set writeNow
```

`stopAt writeNow` 请求求解器在处理到相应控制状态后写出并结束。该过程需要当前求解器支持并启用相应的运行时读取；设置后继续查看日志，确认写出完成。下一次续算前把 `stopAt` 改回 `endTime`，并根据需要设置 `startFrom latestTime`。

对于普通系统任务，`kill -TERM PID` 发送终止请求。这里的 PID 应来自自己刚检查的目标进程。终止 MPI 计算通常使用相应启动器或调度器管理整个作业，避免只结束其中一个进程而留下其他部分。

## 怎样判断任务卡在哪里

日志时间仍在增加且 CPU 活跃，通常说明计算持续推进。CPU 很低但磁盘繁忙，可能正在写出结果或等待 I/O；内存压力很高且频繁换页，会显著降低速度。日志不再更新时，还需检查进程是否已退出、是否在等待输入，以及是否查看了正确文件。

计算日志、资源占用和退出状态可以结合使用。例如 `No space left on device` 对应磁盘空间或文件数限制，`Killed` 可能与内存限制相关，需要查看系统或调度器记录；具体原因以对应记录为准。

## 练习

启动本课五步后台任务，一边用 `tail -f` 查看日志，一边在第二个终端用 `ps` 查看 PID。随后在 `tmux` 中运行同一任务，脱离并重新连接，确认日志仍完整。最后比较练习目录的 `du -sh` 与文件系统的 `df -h .`，理解目录占用和磁盘剩余容量的区别。
