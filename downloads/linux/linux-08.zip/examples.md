Bash 脚本可以按顺序执行命令，也可以根据条件决定下一步，或对多个目录重复同样操作。OpenFOAM 的 `Allrun` 就采用这种方式组织计算。本课先运行独立的小例子，再编写用于方腔算例的批处理脚本。

## 变量和命令行参数

```bash
mkdir -p "$HOME/foamlab-linux-lab/08-automation"
cd "$HOME/foamlab-linux-lab/08-automation"
cat > describe.sh <<'EOF'
#!/usr/bin/env bash
printf '脚本名称：%s\n' "$0"
printf '参数个数：%s\n' "$#"
for item in "$@"; do
    printf '收到参数：%s\n' "$item"
done
EOF
bash describe.sh cavity 'mesh study'
```

`$0` 是脚本名，`$#` 是参数数量，`"$@"` 按原有边界展开每一个参数。这个例子应显示两个参数：`cavity` 和 `mesh study`。`for` 逐个取值赋给 `item`，`do` 与 `done` 包围循环体。

处理文件路径时，保留 `"$@"` 与 `"$item"` 的引号，带空格的名称就可以作为一个完整路径使用。

## 条件判断

```bash
cat > check-dir.sh <<'EOF'
#!/usr/bin/env bash
if [[ $# -ne 1 ]]; then
    printf '用法：bash check-dir.sh 目录\n' >&2
    exit 2
fi
if [[ -d "$1" ]]; then
    printf '目录存在：%s\n' "$1"
else
    printf '目录不存在：%s\n' "$1" >&2
    exit 1
fi
EOF
bash check-dir.sh .
```

`[[ ... ]]` 是 Bash 的条件表达式，`-ne` 比较整数是否不等，`-d` 检查目录是否存在。`then` 后写条件成立时的命令，`else` 后写另一种情况，`fi` 结束判断。错误提示通过 `>&2` 写入标准错误，`exit` 给调用者返回状态。

还常用 `-f` 检查普通文件，`-r` 检查可读，`-s` 检查文件是否非空。判断实际算例时，可以检查 `system/controlDict`，而不是仅依赖目录名称。

## 用函数整理重复操作

```bash
cat > make-study.sh <<'EOF'
#!/usr/bin/env bash
create_case_tree()
{
    local target=$1
    mkdir -p "$target/0" "$target/constant" "$target/system"
    printf '已创建：%s\n' "$target"
}
create_case_tree practice-a
create_case_tree practice-b
EOF
bash make-study.sh
```

函数 `create_case_tree` 接收目标路径，`local` 将变量限定在函数内部。两次调用产生相同目录结构。函数适合封装网格生成、日志统计或归档等重复步骤，使主流程保持清楚。

这里创建的是空练习目录。运行方腔时需要完整教程文件，下面从已加载的 OpenFOAM 环境复制一份。

![脚本组织网格、求解与结果](/assets/diagrams/core-reproducibility.svg)

## 准备两个完整方腔副本

```bash
mkdir -p cases
cp -a "$FOAM_TUTORIALS/incompressible/icoFoam/cavity/cavity" cases/cavity-a
cp -a "$FOAM_TUTORIALS/incompressible/icoFoam/cavity/cavity" cases/cavity-b
```

`FOAM_TUTORIALS` 指向当前安装的教程目录。这两条命令用于目标 `cavity-a`、`cavity-b` 尚未存在的练习目录，分别保留完整的 `0`、`constant`、`system`。已有同名副本时，可另取名称，保持输入和历史结果清楚分开。

可以修改 `cavity-b/system/controlDict` 的时间步，形成两组输入。每个副本独立保存日志，便于之后比较。

## 批量运行脚本

将下面内容保存为 `run-cases.sh`：

```bash
#!/usr/bin/env bash
set -euo pipefail

if (( $# == 0 )); then
    printf '用法：bash run-cases.sh 算例目录...\n' >&2
    exit 2
fi

: "${WM_PROJECT_DIR:?请先加载 OpenFOAM 环境}"

for case_dir in "$@"; do
    if [[ ! -f "$case_dir/system/controlDict" ]]; then
        printf '缺少 controlDict：%s\n' "$case_dir" >&2
        exit 1
    fi

    (
        cd "$case_dir"
        printf '开始计算：%s\n' "$PWD"
        blockMesh > log.blockMesh 2>&1
        checkMesh > log.checkMesh 2>&1
        if grep -Eq 'Failed [1-9][0-9]* mesh checks' log.checkMesh; then
            printf '网格检查失败：%s\n' "$PWD" >&2
            exit 1
        fi
        icoFoam > log.icoFoam 2>&1
        printf '计算结束：%s\n' "$PWD"
    )
done
```

`set -e` 使未处理的命令失败中止脚本，`-u` 检查未定义变量，`pipefail` 保留管道失败状态。`${WM_PROJECT_DIR:?...}` 提供明确的环境缺失提示。`for` 接收任意数量的案例目录，逐一处理。

小括号建立子 shell，每次循环在里面切换目录。子 shell 结束后，外部脚本仍位于原来的 `08-automation`，因此下一份相对路径能正确解析。

网格、检查和求解各自写日志。`grep` 检查 `checkMesh` 的失败汇总，命中时停止当前批次。完整日志还可以查看单元数量、质量指标和具体错误。这个脚本按顺序运行两份案例，适合控制本机资源使用。

执行：

```bash
bash -n run-cases.sh
bash run-cases.sh cases/cavity-a cases/cavity-b
```

第一条检查 Bash 语法，第二条实际运行。成功完成后，每个案例目录中有各自的日志和时间结果。若第二个案例失败，第一个已完成的结果仍保留，查看第二个目录中的对应日志即可定位步骤。

## 自动整理日志

计算后可用循环汇总时间信息：

```bash
for case_dir in cases/cavity-a cases/cavity-b; do
    printf '\n%s\n' "$case_dir"
    grep 'ExecutionTime' "$case_dir/log.icoFoam" | tail -n 1
done
```

每个目录输出一行名称，再输出最后一次计时。`ExecutionTime` 与 `ClockTime` 的含义要按日志和平台计时方式解释，比较工况时保持计时范围和写出频率一致。

进一步可以把结果写入 CSV，调用 Python 绘制中心线；脚本只负责组织步骤，物理参数保存在各算例字典中。这样查看某次计算时，可以直接对应到完整输入。

## 调试与扩展

`bash -x run-cases.sh cases/cavity-a` 会显示命令展开后的执行过程，适合定位路径与参数问题。出现文件不存在时，先查看打印的当前目录；出现环境变量缺失时，在启动脚本的同一个终端加载环境。

要支持多个求解器，可以增加参数，或用 `foamDictionary system/controlDict -entry application -value` 读取案例选择的应用。不同物理案例还可能需要 `setFields`、`topoSet`、区域拆分等预处理，按照各自流程封装为函数。

## 练习

给脚本增加一个日志汇总步骤：每个案例结束后，记录目录名和最后一条 `ExecutionTime`。然后创建第三个方腔副本，改变网格数，比较三组计算的耗时与中心线结果。最后将运行脚本和输入一起归档，在新目录解压后重新执行。
