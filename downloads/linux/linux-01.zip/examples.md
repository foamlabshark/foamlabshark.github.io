Linux 终端可以输入命令、运行程序并查看结果。运行 OpenFOAM 时，常在终端中复制算例、生成网格、启动求解器和读取日志。本课从一个独立练习目录开始，文件操作都在这个目录内完成。

## 打开终端并输入第一条命令

在 Ubuntu 的应用菜单中搜索“终端”，或使用桌面支持的 `Ctrl+Alt+T` 快捷键。Windows 用户在 VMware 中打开 Ubuntu 终端，或从开始菜单启动已安装的 WSL Ubuntu。本文命令采用 Linux Bash 语法。

输入下面一行，按 Enter 执行：

```bash
pwd
```

`pwd` 显示当前工作目录。例如 `/home/student` 表示当前位于 `student` 用户的家目录。终端通常在行首显示 `student@ubuntu:~$` 一类提示符，它告诉你用户名、主机和当前位置；复制本文代码时只复制命令本身。

终端是显示与输入命令的窗口，Bash 是解释命令的程序，`pwd`、`ls`、`blockMesh` 等则是具体操作。Bash 也支持变量和循环，后面的课程会把重复计算写成脚本。

## 命令由哪些部分组成

```bash
ls -lh /tmp
```

`ls` 是命令名，`-lh` 是选项，`/tmp` 是要查看的目录。`-l` 输出详细列表，`-h` 把文件大小写成便于阅读的单位。命令和参数之间用空格分开，选项通常以短横线开头。

多数文件操作成功后会直接回到提示符。需要确认结果时，再使用 `ls` 或查看相应文件。终端中的上下方向键可以调出历史命令，Tab 可以补全文件名；很多终端用 `Ctrl+Shift+C`、`Ctrl+Shift+V` 复制和粘贴。

## 建立自己的练习目录

```bash
mkdir -p "$HOME/foamlab-linux-lab/01-paths/case/0"
mkdir -p "$HOME/foamlab-linux-lab/01-paths/case/constant"
mkdir -p "$HOME/foamlab-linux-lab/01-paths/case/system"
cd "$HOME/foamlab-linux-lab/01-paths"
ls
```

`mkdir` 创建目录，`-p` 会同时创建尚不存在的父目录。`$HOME` 展开为当前用户家目录，双引号将完整路径作为一个参数。`cd` 改变当前目录，最后的 `ls` 应列出 `case`。

下面是刚创建的结构；这些空目录用于学习文件操作，完整算例还需要网格字典、物性和场文件。

```text
foamlab-linux-lab/
└── 01-paths/
    └── case/
        ├── 0/
        ├── constant/
        └── system/
```

`0` 保存初始场，`constant` 保存物性和网格等输入，`system` 保存运行控制和数值设置。之后执行 OpenFOAM 工具时，通常进入同时包含这三个子目录的算例根目录。

![OpenFOAM 算例目录与文件位置](/assets/diagrams/core-case-tree.svg)

## 绝对路径与相对路径

绝对路径从 `/` 开始，例如 `/home/student/foamlab-linux-lab`，不依赖当前所在位置。相对路径从当前目录开始，例如 `case/system`。下面几条命令演示目录切换：

```bash
cd case/system
pwd
cd ..
ls
cd ../..
pwd
```

第一条进入 `system`。`..` 表示上一级目录，执行一次回到 `case`；`../..` 连续返回两层。`.` 表示当前目录，`~` 通常表示用户家目录。随时执行不带参数的 `cd`，可以返回家目录。

Linux 路径使用正斜线 `/`。Windows 的 `F:\UbuntuShareFolder` 在虚拟机或 WSL 中会有自己的挂载路径，需要在 Linux 中查看实际位置。文件名区分大小写，`U` 和 `u` 是两个不同名称。

## 创建、复制和改名

回到练习目录，写入一个文本文件：

```bash
cd "$HOME/foamlab-linux-lab/01-paths"
printf 'Case: cavity\nVersion: v2512\n' > notes.txt
cat notes.txt
```

`printf` 输出指定文本，`\n` 表示换行；`>` 将输出保存到文件。`cat` 显示内容，应该看到两行记录。已有同名文件时，`>` 会写入新的完整内容；需要在末尾追加时使用 `>>`，下一课会进一步介绍。

复制文件并为副本改名：

```bash
cp -i notes.txt notes.backup.txt
mv -i notes.backup.txt notes.saved.txt
ls -lh notes.txt notes.saved.txt
```

`cp` 保留原文件并建立副本，`mv` 改名或移动文件。`-i` 在目标已存在、将被覆盖时询问是否继续。最后会看到原文件和改名后的副本，大小应该相同。

复制整个目录可以使用：

```bash
cp -a case case-copy
ls case-copy
```

`-a` 递归复制，并尽量保留权限、时间和符号链接。第一次执行时，新的 `case-copy` 中应有 `0`、`constant`、`system`。目标已存在时，复制结果的层级会受目标目录状态影响，因此每次练习前先查看目标名称。

## 带空格的名称和通配符

```bash
mkdir -p 'case notes'
cp notes.txt 'case notes/'
ls -l 'case notes'
ls *.txt
```

单引号使 `case notes` 作为一个完整名称传递。`*.txt` 匹配当前目录中以 `.txt` 结尾的名称，星号由 Bash 展开后再交给 `ls`。双引号允许 `$HOME` 等变量展开，单引号保留文字原样；路径使用变量时常采用双引号。

隐藏文件以点开头，例如 `.bashrc`。`ls -a` 会将它们列出。`ls -lah` 可以同时查看隐藏文件、权限和易读大小。

## 删除一个练习文件

```bash
touch disposable.txt
ls -l disposable.txt
rm -i disposable.txt
```

`touch` 在文件不存在时创建空文件。`rm -i` 询问后删除这个明确命名的练习文件；输入 `y` 确认。空目录可以使用 `rmdir 目录名` 删除。正式算例的历史结果可先归档，再按需要清理。

## 查帮助和处理常见错误

`ls --help` 显示简要用法，`man ls` 打开手册；手册中按 `/` 搜索，按 `q` 退出。Bash 内建命令可以用 `help cd` 查看帮助。

| 提示 | 含义与处理 |
| --- | --- |
| `No such file or directory` | 路径不存在，检查当前目录、大小写和空格 |
| `Not a directory` | 试图进入普通文件，先用 `ls -l` 查看类型 |
| `File exists` | 创建的目标已存在，查看它是否是本次练习的目录 |
| `Permission denied` | 当前用户没有所需权限，在自己的练习目录操作并检查权限 |

## 练习

在 `01-paths` 中创建 `study-a`，其中放入 `input` 和 `output` 两个子目录。将 `notes.txt` 复制到 `input`，然后复制整个 `study-a` 得到 `study-b`。分别使用绝对路径和相对路径进入两份副本，确认其中的文件内容相同。
