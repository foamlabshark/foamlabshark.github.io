05 · 环境变量、软件安装与 OpenFOAM 环境

对应课程：https://foamlabshark.github.io/read/?slug=linux-05

examples.md 保存本课全部示例及说明。Python 文件可独立运行；Linux 命令按正文顺序逐段练习，先创建自己的练习目录。
