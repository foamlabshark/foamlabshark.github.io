环境变量把一些配置传给程序，例如家目录、程序搜索路径和 OpenFOAM 安装位置。软件已经安装但终端找不到命令时，通常需要检查程序位置和当前环境。本课先用自己创建的变量练习，再加载 OpenFOAM 环境。

## 创建和读取变量

```bash
mkdir -p "$HOME/foamlab-linux-lab/05-environment"
cd "$HOME/foamlab-linux-lab/05-environment"
case_name=cavity
printf '当前算例：%s\n' "$case_name"
```

`case_name=cavity` 创建 Bash 变量，等号两侧没有空格。读取变量时加 `$`，双引号保留展开后的完整值。变量名可包含字母、数字和下划线，开头使用字母或下划线；自定义变量采用具体名称，便于看出用途。

`HOME`、`PATH` 等是已有环境变量。`printf '%s\n' "$HOME"` 显示家目录，`printf '%s\n' "$SHELL"` 通常显示账号的登录 shell 路径。当前正在执行的 shell 也可能由用户另行启动，因此查看实际进程可用 `ps -p $$ -o comm=`。

## export 怎样传给子程序

```bash
FOAMLAB_CASE=cavity
bash -c 'printf "子进程读取：%s\n" "${FOAMLAB_CASE:-未设置}"'
export FOAMLAB_CASE
bash -c 'printf "子进程读取：%s\n" "$FOAMLAB_CASE"'
```

第一次启动的 Bash 子进程通常读不到这个新建的局部变量；`export` 将它标记为环境变量，第二次子进程会继承 `cavity`。`${变量:-默认值}` 在变量未设置或为空时提供默认文字。

子程序可以继承父进程的环境，子程序退出后，它自己的变量修改不会自动写回父进程。这个特点解释了为什么加载环境要使用 `source`。

## source 与执行脚本的区别

```bash
printf 'FOAMLAB_TOPIC=mesh\nexport FOAMLAB_TOPIC\n' > lesson-env.sh
bash lesson-env.sh
printf '%s\n' "${FOAMLAB_TOPIC:-当前终端未设置}"
source lesson-env.sh
printf '%s\n' "$FOAMLAB_TOPIC"
```

`bash lesson-env.sh` 在子 shell 中执行，结束后当前终端仍没有该新变量。`source lesson-env.sh` 在当前 shell 中读取命令，因此最后会输出 `mesh`。`.` 也是 Bash 中读取脚本的写法，例如 `. ./lesson-env.sh`。

OpenFOAM 的环境脚本设置版本、程序目录和动态库目录。使用 `source` 后，这些配置才会保留在当前终端，并被随后运行的 `blockMesh`、`icoFoam` 等程序继承。

![OpenFOAM 程序、库和工作目录](/assets/diagrams/core-architecture.svg)

## PATH 怎样找到命令

```bash
printf '%s\n' "$PATH"
command -v bash
command -v blockMesh
```

`PATH` 是一组以冒号分隔的目录，Bash 按顺序查找外部程序。`command -v` 显示当前会使用的命令位置。已安装多个同名程序时，排在前面的目录通常先被选中。

可以为自己的脚本建立一个独立目录：

```bash
mkdir -p "$HOME/foamlab-linux-lab/bin"
printf '#!/usr/bin/env bash\nprintf "FoamLab tools\\n"\n' > "$HOME/foamlab-linux-lab/bin/foam-lab-hello"
chmod u+x "$HOME/foamlab-linux-lab/bin/foam-lab-hello"
export PATH="$HOME/foamlab-linux-lab/bin:$PATH"
foam-lab-hello
```

脚本写入后添加执行权限，再把它的目录放到 `PATH` 前面。最后应输出 `FoamLab tools`。`$PATH` 保留原有搜索路径，新的目录只是在其前面增加一项。

## 查找并加载 OpenFOAM

Ubuntu 软件包安装可能位于 `/usr/lib/openfoam/openfoam2512`，源码安装则可能位于用户自己的目录。先找到实际安装根目录中的 `etc/bashrc`，再执行，例如：

```bash
foam_root=/usr/lib/openfoam/openfoam2512
ls "$foam_root/etc/bashrc"
source "$foam_root/etc/bashrc"
foamVersion
command -v blockMesh
printf '%s\n' "$FOAM_TUTORIALS"
```

`foam_root` 按实际位置修改。`ls` 确认脚本存在，`source` 加载，随后查看版本、工具路径和教程目录。`FOAM_TUTORIALS` 指向安装中的案例库，复制案例时可直接使用这个变量。

同一电脑使用多个 OpenFOAM 安装时，可以为每个版本分别开终端并加载对应环境。编译与运行采用一致的头文件、库和程序路径，能减少动态库加载和接口不匹配的问题。

## 打开终端时自动配置

Bash 交互式非登录 shell 通常读取 `~/.bashrc`。需要长期保留的简单别名或环境设置，可以用编辑器加入这个文件末尾。例如 `alias ll='ls -lah'` 为常用列表命令建立简称。

编辑后先用 `bash -n ~/.bashrc` 检查语法，再打开新终端观察效果。仅希望临时使用某套环境时，在当前终端执行对应 `source` 即可。登录 shell、图形桌面和远程服务的启动文件规则不同，排查自动加载时应确认具体启动方式。

## Ubuntu 中安装常用工具

先查看系统信息和软件包状态：

```bash
cat /etc/os-release
apt-cache policy tree
```

`os-release` 标明发行版，`apt-cache policy` 显示软件包的已安装和候选版本。在 Ubuntu 中安装 `tree`、`nano`、`tmux` 可使用：

```bash
sudo apt update
sudo apt install tree nano tmux
```

`apt update` 刷新软件包索引，`apt install` 安装指定工具及依赖。`sudo` 让当前命令使用管理权限，输入密码时终端通常不显示字符。软件安装使用管理权限，自己的算例运行和日常编辑使用普通用户即可。

OpenFOAM v2512 的软件源与安装方法见系统课程的安装章节。这里的软件管理命令介绍通用操作，包名和可用版本由已配置的软件源决定。

## 常见问题与练习

| 现象 | 检查方法 |
| --- | --- |
| `command not found` | `command -v`、实际安装目录和 `PATH` |
| `source` 提示文件不存在 | 安装根目录、路径大小写和是否完成安装 |
| 程序找不到共享库 | 重新加载匹配的 OpenFOAM 环境，检查程序是否来自同一安装 |
| 新终端变量消失 | 将需要长期使用的设置放入适用的启动文件 |

练习：创建变量 `FOAMLAB_RUN` 指向练习目录，在当前 shell 和新启动的 `bash -c` 中分别读取它，观察 `export` 前后的差别。然后为自己的 `foam-lab-hello` 增加一个参数，重新运行并查看 `command -v` 指向的位置。
