Linux 文件权限决定哪些用户可以读取、修改或执行文件。普通配置文件通常需要读写权限，`Allrun` 等脚本还需要执行方式。本课先读懂权限，再写一个能够接收算例名称的小脚本。

## 查看文件权限

```bash
mkdir -p "$HOME/foamlab-linux-lab/04-scripts"
cd "$HOME/foamlab-linux-lab/04-scripts"
printf 'learning Bash\n' > note.txt
ls -l note.txt
```

输出中可能出现 `-rw-r--r--`。第一个字符 `-` 表示普通文件，目录用 `d`，符号链接用 `l`。后面九个字符分三组，分别对应所有者、所属组和其他用户。

| 字母 | 普通文件中的含义 | 目录中的含义 |
| --- | --- | --- |
| `r` | 读取内容 | 列出目录项 |
| `w` | 修改内容 | 配合相应访问权限创建、改名或删除目录项 |
| `x` | 执行程序或脚本 | 进入目录并访问其中已知路径 |

`rw-r--r--` 表示所有者可读写，组和其他用户可读。目录能否访问还与路径上各级目录的权限有关。`ls -ld 目录名` 查看目录本身的权限，`ls -l 目录名` 列出其中内容。

## 创建一个脚本文件

```bash
cat > show-case.sh <<'EOF'
#!/usr/bin/env bash
case_name=${1:-cavity}
printf 'Case: %s\n' "$case_name"
printf 'Directory: %s\n' "$PWD"
EOF
bash show-case.sh
bash show-case.sh pitzDaily
```

第一行指定 Bash 解释器。`$1` 是第一个命令行参数，`${1:-cavity}` 表示参数为空或未提供时使用 `cavity`。赋值时等号两侧紧接变量名和值。`$PWD` 保存当前工作目录，`printf` 中的 `%s` 由后续参数替换。

第一次调用输出 `Case: cavity`，第二次输出 `Case: pitzDaily`。`bash 文件名` 由 Bash 读取脚本文件并执行其中命令，因此脚本需要可读权限。

## 使用执行权限直接运行

```bash
chmod u+x show-case.sh
./show-case.sh motorBike
ls -l show-case.sh
```

`chmod u+x` 为文件所有者增加执行权限。`./` 表示当前目录，直接运行时由首行指定的解释器处理文件。此时权限中所有者那一组会包含 `x`。

系统通常按 `PATH` 中的目录查找命令。当前目录的脚本写成 `./show-case.sh`，明确了程序位置。脚本位于别处时，也可以使用完整路径。

## 符号权限与数字权限

```bash
chmod u=rw,go=r note.txt
chmod 644 note.txt
chmod 700 show-case.sh
```

第一条设置所有者读写、组和其他用户只读；第二条用数字表示同样的权限。读、写、执行的数值分别为 4、2、1，相加得到某组权限。`700` 表示仅所有者可读写执行，适合自己的练习脚本。

共享项目通常按团队需求设置所属组和相应权限。查看当前用户与组可以用 `id`。修改文件所有权需要相应系统权限，日常算例保存在自己的工作目录，文件可由当前用户直接维护。

![脚本、输入与结果目录](/assets/diagrams/core-reproducibility.svg)

## 给参数加双引号

```bash
./show-case.sh 'case with spaces'
```

引号把带空格的名称作为一个参数传入。脚本中的 `"$case_name"` 也保持这个整体。如果后续改为复制某个路径，双引号同样能让带空格或特殊字符的路径正确传递。

`$#` 表示参数个数，`$0` 表示脚本调用名称，`"$@"` 逐个保留全部参数。批量处理多个算例时，可以使用 `for case_name in "$@"` 依次处理，第八课会给出完整例子。

## 从任意位置运行时固定目录

如果脚本需要读取自己目录中的文件，可在开头加入：

```bash
script_dir=$(cd "$(dirname "$0")" && pwd)
cd "$script_dir"
```

`dirname "$0"` 取得脚本路径的目录部分，`$(...)` 将命令输出保存为变量。内部 `cd` 与 `pwd` 在命令替换的子环境中执行，得到绝对目录；第二行让脚本进入该位置。这样从不同工作目录调用，输入文件的相对路径也保持一致。

只有前一个命令成功时，`&&` 后面的命令才执行。这常用于目录切换等有依赖的步骤；多条无依赖命令也可以各占一行，更便于阅读。

## 检查脚本语法和换行格式

```bash
bash -n show-case.sh
file show-case.sh
```

`bash -n` 检查语法并报告错误位置，不执行脚本内容。`file` 可显示是否采用 CRLF 换行。从 Windows 复制的脚本如果出现 `/usr/bin/env: 'bash\r': No such file or directory`，可在编辑器中将换行转换为 LF 后保存。

也可以为自己的脚本生成一个转换后的副本：

```bash
sed 's/\r$//' show-case.sh > show-case.lf.sh
bash -n show-case.lf.sh
bash show-case.lf.sh
```

`\r$` 匹配行末的回车，替换为空后保留正常换行。新文件保留原稿作为比较。如果脚本来自压缩包，重新解压时注意文件权限和符号链接是否被正确保存。

## 返回状态与错误退出

脚本可用 `exit 0` 表示正常结束，`exit 1` 表示遇到自定义错误。调用脚本后立即执行 `printf '%s\n' "$?"`，可以查看它的退出状态。后续命令可以据此决定继续运行还是处理错误。

调试时可运行 `bash -x show-case.sh` 查看每条命令展开后的执行过程。脚本中若包含认证信息，调试输出会显示相应参数，因此调试前把这类输入移到受保护的认证配置中。

## 常见问题与练习

`Permission denied` 时查看脚本读/执行权限以及上级目录权限。`command not found` 时检查是否使用了 `./` 或正确路径。`syntax error near unexpected token` 时检查括号、引号和 `if`、`for` 的结束关键字。

练习：将脚本扩展为接收第二个参数 `solver_name`，默认值为 `icoFoam`，同时打印算例名与求解器名。分别运行零参数、一个参数和两个参数的形式，再用带空格的算例名称检查引号是否正确。
