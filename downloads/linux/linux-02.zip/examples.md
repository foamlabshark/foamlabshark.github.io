OpenFOAM 的字典、场文件和运行日志大多是文本。日常操作主要包括查看某几行、修改参数、搜索关键字和比较两份文件。本课使用一份简化配置练习，先掌握文本工具，再把相同方法用于真实算例。

## 建立示例文件

```bash
mkdir -p "$HOME/foamlab-linux-lab/02-text"
cd "$HOME/foamlab-linux-lab/02-text"
cat > settings.txt <<'EOF'
application icoFoam;
startTime 0;
endTime 0.5;
deltaT 0.005;
writeInterval 20;
EOF
```

`cat` 将后续输入写入文件；`<<'EOF'` 表示一直读到单独一行的 `EOF`。给结束标记加引号后，正文中的 `$` 等符号按原样保存。执行后得到五行配置，`settings.txt` 是文本练习文件。

## 短文件、长文件分别怎样看

```bash
cat settings.txt
nl -ba settings.txt
head -n 2 settings.txt
tail -n 2 settings.txt
```

`cat` 显示全部内容，`nl -ba` 显示行号，`head -n 2` 查看前两行，`tail -n 2` 查看最后两行。处理大日志时，只查看相关部分会更快，也更容易发现最早的异常。

长文件使用 `less settings.txt` 打开。方向键逐行移动，空格向下翻页，`b` 向上翻页，`/deltaT` 搜索时间步条目，`n` 跳到下一个匹配，`q` 返回终端。`less` 用于阅读，文件内容保持原样。

![配置文件在算例中的位置](/assets/diagrams/core-case-tree.svg)

## 用 nano 修改参数

```bash
nano settings.txt
```

打开后可直接移动光标并输入文字。把 `endTime 0.5;` 改成 `endTime 1;`。按 `Ctrl+O` 保存，按 Enter 确认文件名，再按 `Ctrl+X` 退出。底部提示中的 `^O` 表示 `Ctrl+O`。

返回终端后运行 `cat settings.txt`，确认修改已保存。OpenFOAM 字典中的分号、大括号和字段名称都属于语法，编辑时保留它们的结构。需要比较修改前后的文件，可以先用 `cp -i settings.txt settings.before.txt` 保存一份副本。

## Vim 的基本操作

服务器上常见 `vi` 或 `vim`。执行 `vim settings.txt` 后进入普通模式，按 `i` 进入插入模式，再输入文本；按 Esc 返回普通模式。输入 `:wq` 并回车，保存后退出。

| 操作 | 普通模式中的按键 |
| --- | --- |
| 保存 | `:w` 后回车 |
| 退出 | `:q` 后回车 |
| 放弃本次未保存修改 | `:q!` 后回车 |
| 搜索 `deltaT` | `/deltaT` 后回车 |
| 撤销上一步 | `u` |
| 跳到第 4 行 | `:4` 后回车 |

Vim 中输入文字没有出现时，先按 `i` 进入插入模式；文字被误当作命令时，可按 Esc 回到明确的模式后再操作。开始学习时选用熟悉的编辑器即可，字典本身与编辑器无关。

## 在文件中搜索关键字

```bash
grep -n 'deltaT' settings.txt
grep -nE 'endTime|writeInterval' settings.txt
grep -nF 'application icoFoam;' settings.txt
```

`-n` 显示匹配行的行号。`-E` 启用扩展正则表达式，竖线表示“匹配其中任一项”；`-F` 按固定文字搜索，适合含有括号、点号等字符的原文。

第一条应定位时间步所在行。搜索命中后，可用 `sed -n '2,5p' settings.txt` 查看第 2 到 5 行的上下文。这里 `-n` 关闭默认逐行输出，`p` 只打印指定范围。

## 搜索目录内的多个文件

```bash
mkdir -p cases/a cases/b
cp settings.txt cases/a/controlDict
cp settings.txt cases/b/controlDict
find cases -type f -name 'controlDict'
grep -rn --include='controlDict' 'deltaT' cases
```

`find` 按文件名搜索，`-type f` 只选择普通文件，`-name` 后的模式加引号以交给 `find` 处理。`grep -r` 递归搜索内容，`--include` 将范围限制为指定文件名。输出中的路径说明是哪一个算例，行号说明条目位置。

安装了 `rg` 时，也可以用 `rg -n 'deltaT' cases` 进行内容搜索。对于 OpenFOAM 安装目录，缩小到某类求解器教程通常比从整个文件系统开始搜索更有效。

## 生成修改版并比较差异

```bash
sed 's/^deltaT .*/deltaT 0.0025;/' settings.txt > settings.fine.txt
diff -u settings.txt settings.fine.txt
```

`sed` 中 `s/旧模式/新文字/` 进行替换，`^` 表示行首，`.*` 匹配这一行的其余内容。输出写入新文件，原文件保留。`diff -u` 用 `-` 标记旧行、`+` 标记新行，便于确认只有时间步改变。

这里的文本结构非常简单。对包含嵌套字典、变量引用的 OpenFOAM 文件，可以使用 `foamDictionary` 精确修改条目，例如在完整算例中执行 `foamDictionary system/controlDict -entry deltaT -set 0.0025`。文本替换和字典工具适合不同复杂程度的输入。

## 查看编码、换行和文件类型

```bash
file settings.txt
wc -l settings.txt
```

`file` 判断文本或二进制类型，并可能报告换行格式；`wc -l` 统计换行数。Linux 脚本通常采用 LF 换行，从 Windows 编辑器保存时可选择 UTF-8 和 LF，避免解释器路径末尾出现额外的回车字符。

终端显示乱码时，检查文件编码和终端使用的字符集。复制命令时，选项前使用普通 ASCII 短横线 `-`，参数引号使用代码中的直引号。

## 常见问题与练习

`grep` 没有输出，表示当前模式没有匹配行，可先用 `cat` 查看关键字拼写。`find` 找到的是错误目录中的同名文件时，重新限定起始路径。`diff` 有差异时通常返回状态码 1，这是“文件不同”的结果，读取其差异内容即可。

练习：为 `cases/a` 和 `cases/b` 设置不同的 `deltaT`，递归搜索并列出两份设置。随后将两份文件比较，定位时间步变化，最后把带行号的配置保存为一份阅读记录。
