02 · 查看、编辑和搜索文本

对应课程：https://foamlabshark.github.io/read/?slug=linux-02

examples.md 保存本课全部示例及说明。Python 文件可独立运行；Linux 命令按正文顺序逐段练习，先创建自己的练习目录。
