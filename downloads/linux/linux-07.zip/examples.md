算例在本机、虚拟机和服务器之间传输时，常用压缩包保存完整目录，用 SSH 连接远程终端，用 `scp` 或 `rsync` 传输文件。本课先在本地完成归档和同步练习，再介绍远程命令的写法。

## 准备一个独立目录

```bash
mkdir -p "$HOME/foamlab-linux-lab/07-transfer/case/system"
mkdir -p "$HOME/foamlab-linux-lab/07-transfer/case/0"
mkdir -p "$HOME/foamlab-linux-lab/07-transfer/case/constant"
cd "$HOME/foamlab-linux-lab/07-transfer"
printf 'archive practice\n' > case/README.txt
```

这份小目录用于练习传输结构。实际算例还需要相应字典、字段、几何和脚本。进入工程的外层目录归档，可以使压缩包内自然保留一个顶层 `case`。

## 创建并查看 tar.gz

```bash
tar -czf case-inputs.tar.gz case
tar -tzf case-inputs.tar.gz
ls -lh case-inputs.tar.gz
```

`-c` 创建归档，`-z` 使用 gzip 压缩，`-f` 后面紧跟压缩包文件名。第二条中 `-t` 表示列出内容，可以看到 `case/` 及其子目录。`tar` 能保存目录结构、权限和符号链接，适合 Linux 算例。

解压到一个新目录：

```bash
mkdir -p restored
tar -xzf case-inputs.tar.gz -C restored
ls restored/case
```

`-x` 解包，`-C` 指定目标目录。结果应位于 `restored/case`，而原来的 `case` 保留。收到别人提供的压缩包时，先列出内容，再在独立目录解压，便于检查结构和依赖。

## ZIP 与归档内容选择

```bash
zip -r case-inputs.zip case
unzip -l case-inputs.zip
```

`zip -r` 递归打包目录，`unzip -l` 查看包内文件。ZIP 便于跨平台交换；涉及 Linux 执行权限和符号链接时，需要确认打包和解包工具是否保留这些属性。

大规模 OpenFOAM 计算通常把输入与全场结果分别打包。生成输入包时，可明确选择 `0`、`constant`、`system` 和必要脚本；CAD、`#include` 文件和自定义源码也要包含。结果包中保留需要共享的时间、采样 CSV 和图，下载体积会更容易控制。

![输入与结果的归档组织](/assets/diagrams/core-reproducibility.svg)

## 检查传输前后文件是否一致

```bash
sha256sum case-inputs.tar.gz
```

命令输出文件摘要。发送方和接收方对同一个压缩包计算摘要，结果一致时，可以确认传输后的文件内容与原件一致。这对较大的下载、共享盘复制和归档保存有帮助。

摘要用于检查文件字节的一致性；具体算例参数仍通过文件内容和说明阅读。日常使用中，可以把摘要保存在归档目录中，而课程正文主要展示操作与结果。

## SSH 连接远程 Linux

假设自己的服务器地址为 `server.example.org`，用户名为 `cfd`，SSH 端口为 22，连接形式是：

```bash
ssh cfd@server.example.org
```

这里的域名是写法示例，使用时替换为实际服务器地址和用户名。首次连接会显示服务器主机密钥指纹，可以与服务器管理者提供的值核对后保存。完成认证后，终端中的命令运行在服务器上。

使用自定义端口时：

```bash
ssh -p 2222 cfd@server.example.org
```

`-p` 指定端口。登录后用 `hostname` 查看主机名，`pwd` 查看远程目录，`exit` 结束这次连接。服务器上的 OpenFOAM 安装与本机环境分别管理，需要在远程终端加载服务器的环境脚本。

## 使用 scp 上传和下载

下面两条命令在本机终端执行，假定远程用户的 `cases` 目录已建立：

```bash
scp case-inputs.tar.gz cfd@server.example.org:cases/
scp cfd@server.example.org:cases/log.icoFoam ./log.remote.icoFoam
```

冒号左侧是用户与服务器，右侧是远程路径；相对路径通常从远程用户家目录开始。第一条上传压缩包，第二条下载日志并在本机改名。带空格的本地文件路径使用引号。

`scp` 的自定义端口参数是大写 `-P`，例如 `scp -P 2222 文件 用户@服务器:目录/`。小写 `-p` 另有保留时间和权限的含义，注意大小写。

## 使用 rsync 增量同步

先在本地练习：

```bash
mkdir -p synced-case
rsync -av --dry-run case/ synced-case/
rsync -av case/ synced-case/
```

`-a` 采用归档模式，保留常用文件属性并递归处理；`-v` 显示过程，`--dry-run` 只预览将发生的复制。确认路径后，第二条执行同步。再次运行时，工具主要处理新增或变化的文件。

源路径 `case/` 的末尾斜线表示同步目录里的内容，因此 `synced-case` 下直接得到 `0`、`constant`、`system`。源路径写成 `case` 时，结果可能额外保留一层目录名；先用预览查看层级最直观。

同步到远程的形式是：

```bash
rsync -av --dry-run case/ cfd@server.example.org:cases/case-a/
```

确认服务器和目标目录正确后，去掉 `--dry-run` 执行。自定义 SSH 端口可加入 `-e 'ssh -p 2222'`。这里的同步保留目标已有的其他文件，适合学习增量复制。

## 排除自动生成的大文件

上传输入时可按实际需求增加 `--exclude='processor*/'` 或 `--exclude='postProcessing/'`。这些模式交给 `rsync` 处理，使用引号保留星号。已有结果需要继续计算时，保留必要时间目录和分区信息，单独确定本次传输包含哪些数据。

符号链接指向包外文件时，传过去的链接可能失效。归档前用 `ls -l` 查看重要链接，将必须共享的目标文件纳入资料包，或在说明中给出可取得的依赖位置。

## 常见问题与练习

`Connection refused` 通常与地址、端口或 SSH 服务有关；`Permission denied` 查看账号与认证方式；`No such file or directory` 检查远程目标目录是否存在。大文件传输中断后，`rsync` 可以再次比较并继续传输变化部分。

练习：为本地 `case/README.txt` 追加一行，先预览同步，再实际同步到 `synced-case`。比较两份文件内容。随后归档 `synced-case`，在第三个独立目录解压，检查目录层级和文件内容。
