07 · 压缩归档、SSH 与文件同步

对应课程：https://foamlabshark.github.io/read/?slug=linux-07

examples.md 保存本课全部示例及说明。Python 文件可独立运行；Linux 命令按正文顺序逐段练习，先创建自己的练习目录。
