程序运行时会向终端写出正常信息和错误信息。重定向可以把这些内容保存到文件，管道可以把一个程序的输出交给另一个程序处理。OpenFOAM 的日志采集、残差搜索和批量统计都经常用到这两种功能。

## 标准输入、输出和错误

Linux 程序通常有三个默认通道：标准输入编号为 0，标准输出为 1，标准错误为 2。键盘常作为标准输入，终端常同时显示标准输出与标准错误。

先建立练习目录：

```bash
mkdir -p "$HOME/foamlab-linux-lab/03-logs"
cd "$HOME/foamlab-linux-lab/03-logs"
printf 'Time = 0\nTime = 0.1\n' > log.practice
cat log.practice
```

`>` 把标准输出写入文件，原有同名内容会被替换。`log.practice` 中现在有两行时间记录，这是一份手工构造的练习日志。

追加一条记录：

```bash
printf 'Time = 0.2\n' >> log.practice
cat log.practice
```

`>>` 在文件末尾追加，原来的两行保留。日志记录需要连续保存时使用追加，独立工况通常使用独立文件名，便于区分每次运行。

## 正常输出与错误分别保存

```bash
bash -c 'printf "normal output\n"; printf "example error\n" >&2' > output.txt 2> error.txt
cat output.txt
cat error.txt
```

`bash -c` 执行引号中的小程序。第一条 `printf` 写标准输出，第二条用 `>&2` 写标准错误。外层 `>` 和 `2>` 分别接收两个通道，因此两个文件各有一行。

运行 OpenFOAM 时，通常把两个通道放在同一份日志中：

```bash
icoFoam > log.icoFoam 2>&1
```

这条命令在已经准备好的方腔算例目录中执行。`>` 先把标准输出指向日志，`2>&1` 再把标准错误指向当前的标准输出位置，因此求解信息和报错都保存在 `log.icoFoam`。重定向从左到右生效，保持这个顺序。

## 同时在终端显示并保存

```bash
printf 'step 1\nstep 2\n' | tee log.steps
```

竖线 `|` 把左侧标准输出交给右侧标准输入。`tee` 一边显示内容，一边写入 `log.steps`。需要追加时用 `tee -a 文件名`。

对于求解器，可使用：

```bash
set -o pipefail
icoFoam 2>&1 | tee log.icoFoam
status=$?
printf '退出状态：%s\n' "$status"
```

`pipefail` 使管道中前面的命令失败也能影响整条管道状态。`$?` 是上一条命令的退出码，立即保存到 `status`，可以避免被后面的命令覆盖。常见约定中 0 表示程序正常退出，非零表示发生某种错误；物理结果还通过残差、守恒和观测量分析。

![求解日志与结果数据的关系](/assets/diagrams/core-residual.svg)

## 用管道筛选日志

先增加几条示例残差：

```bash
cat >> log.practice <<'EOF'
Solving for p, Initial residual = 0.1, Final residual = 0.001
Solving for Ux, Initial residual = 0.02, Final residual = 0.0001
Solving for p, Initial residual = 0.01, Final residual = 0.00001
EOF
grep 'Solving for p,' log.practice | tail -n 1
```

`grep` 选择压力求解行，`tail -n 1` 保留最后一条，输出应为第三条残差记录。两个命令各处理一部分任务，组合后可以直接定位最新压力残差。

更常见的查看方式是：

```bash
grep -nE 'FOAM FATAL|Courant Number|continuity errors' log.practice
```

它寻找三个常用关键字并显示行号。当前练习日志没有这些行，因此结果为空；在真实日志中，用行号向前后查看即可定位时间和上下文。变量名中带点号而希望完全按原文匹配时，可以采用 `grep -F`。

## 从简单表格提取列

```bash
printf 'time Ux\n0.0 0.0\n0.1 0.25\n0.2 0.40\n' > probe.txt
awk 'NR > 1 {print $1, $2*2}' probe.txt > doubled.txt
cat doubled.txt
```

`awk` 默认按空白分列，`NR` 是当前行号，`NR > 1` 跳过标题。`$1` 是第一列，`$2*2` 将第二列乘二，结果写到新文件。这适合学习纯数值表的处理。

OpenFOAM 向量探针包含括号和多个分量，读取前先查看文件头及一行数据，确认分列方式。复杂格式可以用 Python 解析，避免把向量括号或重复表头当成数字。

## 实时查看日志

在另一个终端进入同一算例，执行 `tail -f log.icoFoam`。`-f` 持续显示文件新增内容，按 `Ctrl+C` 结束当前的日志跟踪。求解器若在另一个终端运行，会继续计算。

搜索 `Time =` 可以查看计算推进到的时间；已保存的结果时刻可用 `foamListTimes` 查看。查错误应从最早一条明确异常开始。MPI 计算结束时常有多个进程的终止信息，最先出现的字段、网格或数值报错通常更接近原因。

## 管道与文件名的区别

管道传递程序输出的内容。`grep 'Time' log.practice` 接收的是日志路径，`cat log.practice | grep 'Time'` 则让 `grep` 接收管道中的文本，两者在这里能得到相同内容。简单文件搜索直接提供文件名更清楚；需要前一步转换结果时，再使用管道连接。

`wc -l` 可以统计输入行数，例如 `grep 'Solving for p,' log.practice | wc -l` 统计练习日志中的压力求解记录。结果应为 2。

## 常见问题与练习

| 现象 | 原因与处理 |
| --- | --- |
| 日志中没有错误信息 | 只重定向了标准输出，增加 `2>&1` |
| 再运行后旧日志消失 | `>` 重写了文件，按工况命名或按需要使用追加 |
| 管道显示成功，但求解器失败 | 启用 `pipefail` 并记录退出状态 |
| `tail -f` 没有新内容 | 程序暂无输出、已经结束，或正在跟踪另一个文件 |

练习：创建一份同时含时间和残差的日志，只保留 `Time =` 行到 `times.txt`，再统计其中的行数。使用 `tee` 在终端显示筛选结果并保存，最后故意搜索一个不存在的关键字，观察“没有匹配”和“命令错误”在输出上的区别。
