from paraview.simple import *
import os
import sys
root=os.path.abspath(sys.argv[1] if len(sys.argv)>1 else 'cavity')
output=os.path.abspath(sys.argv[2] if len(sys.argv)>2 else '.')
open(root+'/cavity.foam','a').close()
reader=OpenFOAMReader(FileName=root+'/cavity.foam')
reader.MeshRegions=['internalMesh'];reader.CellArrays=['U','p']
reader.UpdatePipelineInformation()
times=list(reader.TimestepValues);last=max(times)
view=CreateView('RenderView');view.ViewSize=[1600,1100];view.Background=[0.96,0.975,0.99]
view.UseColorPaletteForBackground=0;view.OrientationAxesVisibility=0;view.ViewTime=last
reader.UpdatePipeline(last)
display=Show(reader,view);display.Representation='Surface'
ColorBy(display,('CELLS','U','Magnitude'));display.RescaleTransferFunctionToDataRange(False,True)
lut=GetColorTransferFunction('U');lut.ApplyPreset('Cool to Warm',True)
display.SetScalarBarVisibility(view,True)
bar=GetScalarBar(lut,view);bar.Title='Velocity';bar.ComponentTitle='m/s';bar.TitleColor=[0.1,0.2,0.3];bar.LabelColor=[0.1,0.2,0.3]
view.CameraPosition=[0.05,0.05,1];view.CameraFocalPoint=[0.05,0.05,0.005];view.CameraViewUp=[0,1,0];view.CameraParallelProjection=1;view.CameraParallelScale=0.065
label=Text();label.Text='OpenFOAM v2512 | Lid-driven cavity | t = '+str(last)+' s'
ld=Show(label,view);ld.Color=[0.1,0.2,0.3];ld.FontSize=17;ld.WindowLocation='Upper Left Corner'
Render(view);SaveScreenshot(output+'/cavity-velocity.png',view,ImageResolution=[1600,1100])
display.Representation='Surface With Edges';display.EdgeColor=[0.08,0.18,0.3]
ColorBy(display,None);display.DiffuseColor=[0.69,0.82,0.91];display.SetScalarBarVisibility(view,False)
label.Text='OpenFOAM v2512 | Computational mesh | Lid-driven cavity'
Render(view);SaveScreenshot(output+'/cavity-mesh.png',view,ImageResolution=[1600,1100])
print('Rendered cavity at',last,'seconds')
