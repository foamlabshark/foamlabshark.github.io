OpenFOAM OpenCFD v2512 cavity; icoFoam; 20x20x1; t=0.5 s; Re=10.
Reproduce from $FOAM_TUTORIALS/incompressible/icoFoam/cavity/cavity.
Use: pvpython --force-offscreen-rendering render-cavity.py /path/to/cavity /path/to/output
Run logs demonstrate execution, not mesh independence.
