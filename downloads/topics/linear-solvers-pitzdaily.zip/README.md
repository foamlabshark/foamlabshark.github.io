# 后台阶线性求解设置

进入 pitzDaily，执行 bash Allrun。system/fvSolution 对应正文压力 GAMG 与速度 smoothSolver 配置。原始来源：OpenCFD OpenFOAM v2512 simpleFoam/pitzDaily。
