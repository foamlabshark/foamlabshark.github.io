# 网格质量检查

进入 cavity-quality，执行 bash Allrun。system/meshQualityDict 采用 v2512 motorBike 的质量设置，并通过 #includeEtc 使用当前 v2512 的默认阈值。网格和质量场由程序生成。
