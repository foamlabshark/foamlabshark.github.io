# MRF 配置模板

对应正文 MRF 字典段。此模板要求已有名为 rotor 的 cellZone，并采用支持 MRF 的求解器；不能与动网格算例的 dynamicMeshDict 同时启用同一旋转运动。按几何设置 origin、axis、omega 后，将文件放在目标算例的 constant/。运动网格与 AMI 的完整输入见同页另一附件。
