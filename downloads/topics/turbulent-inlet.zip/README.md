# 合成湍流入口

OpenCFD OpenFOAM v2512 原生 planeChannel 输入，包含 DFSEM、DFM、FSM 及共用 U、R、L 边界数据。

先进入 tutorials/incompressible/pimpleFoam/LES/planeChannel。正文引用的 U 位于 setups.orig/DFSEM/0.orig/U；映射数据位于 setups.orig/common/constant/boundaryData/inlet。Allrun 会组合 common 与各方法的设置，生成 setups/、results/。原脚本默认并行运行三种方法；仅阅读配置时无需启动计算。若只运行 DFSEM，将 Allrun 的 setups 列表改为 DFSEM，按本机配置设置 parallel。
