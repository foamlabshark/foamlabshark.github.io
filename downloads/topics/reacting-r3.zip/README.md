# 03 · reactingFoam：甲烷空气对冲火焰

采用 OpenCFD OpenFOAM v2512。

- `cases/opposed-psi/`：完整输入；进入后执行 `sh Allrun`。

`0.orig` 保存初始场模板，Allrun 在运行前建立 `0`。阅读或修改未运行算例的初场时，应打开 `0.orig`。Sandia 算例可用 `sh Allrun --check` 检查启动；已有 Sandia 记录仅为 8 次局部时间迭代。其余记录的结束时间见 verification/report.json。

`source/` 保留正文所指求解器路径；`src/`（如有）保留库实现路径。源码用于对照阅读，编译仍需要完整 v2512 开发环境。`verification/report.json` 与日志只保留本课相关的基准记录；这些是已有记录，不是重新运行的结果。

chemFoam 的初始组成、温度和压力由 cases/h2-ignition/constant/initialConditions（本课含该算例时）给出。带 0.orig 的算例在首次 Allrun 时复制为 0，修改初场应在首次运行前完成。
