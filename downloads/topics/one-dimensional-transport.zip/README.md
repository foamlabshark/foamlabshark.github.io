# 一维对流与扩散

OpenCFD OpenFOAM v2512。进入 exercises/one-dimensional-advection 或 exercises/one-dimensional-diffusion，执行 bash Allrun。每个目录包含初始场、物性、网格与数值字典、比较脚本。verification/ 保留原算例的运行记录。
