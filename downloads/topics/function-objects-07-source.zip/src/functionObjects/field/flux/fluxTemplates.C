/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | www.openfoam.com
     \\/     M anipulation  |
-------------------------------------------------------------------------------
    Copyright (C) 2016-2019 OpenCFD Ltd.
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "fvcFlux.H"
#include "surfaceInterpolate.H"

// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

template<class FieldType,  class RhoFieldType>
bool Foam::functionObjects::flux::calcVolFlux(const RhoFieldType& rho)
{
    if (foundObject<FieldType>(fieldName_, false))
    {
        return store
        (
            resultName_,
            fvc::flux(rho*lookupObject<FieldType>(fieldName_))
        );
    }

    return false;
}


template<class FieldType,  class RhoFieldType>
bool Foam::functionObjects::flux::calcSurFlux(const RhoFieldType& rho)
{
    if (foundObject<FieldType>(fieldName_, false))
    {
        return store
        (
            resultName_,
            (
                fvc::interpolate(rho)
               *lookupObject<FieldType>(fieldName_)
            ) & mesh_.Sf()
        );
    }

    return false;
}


// ************************************************************************* //
