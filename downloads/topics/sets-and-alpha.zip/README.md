# 选区与界面初始化

在各目录执行 bash Allrun。centre-box 对应 64 单元方腔选区；porous-zone 对应减去圆柱后的多孔区；cylinder-alpha 对应溃坝网格中的圆柱水域初始化。最后一例默认执行 setAlphaField，另有 system/setFieldsDict 可用 setFields 初始化，以比较两种离散方法。这里只生成网格与初场，不执行瞬态溃坝计算。

方腔的 mapFields 练习仍使用同页原生方腔附件中的外层 Allrun、cavityClipped 和 cavityGrade 配置。
