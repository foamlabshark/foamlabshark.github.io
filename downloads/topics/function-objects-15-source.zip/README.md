# 15 · runTimeControl：按条件结束或切换阶段：源码对照

来源：OpenCFD OpenFOAM v2512。目录保留原生源码路径，与正文中 applications/、src/ 开头的路径一致。

这些文件用于阅读库实现；编译时使用已安装的完整 v2512 开发环境。课程自编程序和运行算例见同页的其他附件。
