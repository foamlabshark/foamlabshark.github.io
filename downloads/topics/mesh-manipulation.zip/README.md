# 网格导入与修改

采用 OpenCFD OpenFOAM v2512。各操作放在独立目录，避免在同一网格上连续叠加无关变换。

- channel：自带 ASCII MSH 2.2 网格，100×50×1 mm、200 个六面体；bash Allrun 依次转换、修改壁面/二维边界类型、合并上下壁面并检查。
- mirror-cavity：400 单元方腔；bash Allrun 沿 x=0.1 m 镜像。
- refine-cavity：bash Allrun 选 centreBox 对应的 c0 后沿 x、y 加密。
- templates/system/extrudeMeshDict：正文拉伸模板；先将 sourceCase 的 <case> 替换为用户的源算例，源网格必须含 back、front 两个 patch，不能直接套入这里合并前后面的方腔。wedge 版本同理。

这些工具示例用于网格操作；镜像、重命名等操作后，应按新的 patch 与物理问题重新配置场边界，再启动流动求解。
