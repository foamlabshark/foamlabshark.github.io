耦合煤颗粒转化与气相燃烧，计算受限空间内的热释放和压力变化。

## 工程场景与计算目标

煤颗粒受热后经历水分蒸发、挥发分析出和焦炭反应，各阶段向气体释放的组分和能量不同。受限空间中，气体质量与温度的变化进一步转化为压力变化。理解这一过程需要同时跟踪颗粒转化、气相反应和外部加热。

算例采用 `simplifiedSiwek` 二维分区模型，计算煤粒、惰性颗粒与反应气体之间的交换。通过颗粒组分质量、热释放率和容器平均压力的时间关系，解释升压开始的条件及主要能量来源。

## 几何、尺寸与基准工况

![煤粉受热、挥发与受限空间燃烧：配套模型与基准输入](/assets/engineering/dust-explosion-geometry.webp)

主腔宽、高均为 0.5 m，上部延伸段宽 0.05 m，总高度 1 m。展向厚度为 0.1 m，采用 `empty` 边界。煤粒与惰性颗粒分别由位置文件装填，局部加热区域通过 `topoSet` 定义。

模型与配置来源：[OpenFOAM v2512 · lagrangian/coalChemistryFoam/simplifiedSiwek](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/lagrangian/coalChemistryFoam/simplifiedSiwek)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 气体初态 | 400 K、100000 Pa | `0.orig/T`、`p` |
| 气相燃烧模型 | PaSR | `constant/combustionProperties` |
| 煤材料参数 | 密度 2010 kg/m³、比热 710 J/(kg·K) | `constant/thermophysicalProperties/solids/C` |
| 计算终点 | 0.5 s | `system/controlDict` |

## 求解方法与物理模型

单颗粒质量按组分分解为 $m_p=m_{\mathrm{water}}+m_{\mathrm{volatile}}+m_{\mathrm{char}}+m_{\mathrm{ash}}$。受热改变温度并驱动组分转化，气相反应热源为 $\dot q=-\sum_k h_{f,k}\dot\omega_k$。容器压力随气体质量和温度变化，可用 $pV=m_gR_{\mathrm{mix}}T$ 检查整体变化方向。

本例使用 `coalChemistryFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/dust-explosion.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip dust-explosion.zip
cd dust-explosion
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `topoSet` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 气相燃烧闭合

文件：`constant/combustionProperties`。本段设置气相燃烧闭合。

```foam
combustionModel  PaSR;

active  true;

PaSRCoeffs
{
    Cmix                1.0;
```

PaSR 将湍流混合时间与化学反应时间结合，计算气相反应速率。颗粒内部转化由煤粒模型完成，二者通过气相组分和能量源耦合。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/coalChemistryFoam/simplifiedSiwek/constant/combustionProperties)。

### 2. 煤颗粒热物性

文件：`constant/thermophysicalProperties`。本段设置煤颗粒热物性。

```foam
solids
{
    C
    {
        rho             2010;
        Cp              710;
        kappa           0.04;
        Hf              0;
        emissivity      1.0;
    }

    ash;
}
```

固体密度、比热和导热系数决定颗粒受热响应，生成焓参与反应能量计算。释放到气相的物种通过同名热物性和反应数据继续参与燃烧。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/coalChemistryFoam/simplifiedSiwek/constant/thermophysicalProperties)。

### 3. 颗粒受热与转化

文件：`constant/coalCloud1Properties`。本段设置颗粒受热与转化。

```foam
subModels
{
    particleForces
    {
        sphereDrag;
        gravity;
    }

    injectionModels
    {
        model1
        {
            type            manualInjection;
            massTotal       0.0001;
            parcelBasisType mass;
            SOI             0;
            positionsFile   "coalCloud1Positions";
            U0              (0 -10 0);
            sizeDistribution
            {
                type        RosinRammler;
                RosinRammlerDistribution
```

`subModels` 按受力、注入、换热、挥发及表面反应组织颗粒过程。沿这些模型核对质量去向，可将煤粒减少量与气相产物和灰分联系起来。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/coalChemistryFoam/simplifiedSiwek/constant/coalCloud1Properties)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.coalChemistryFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `coalChemistryFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `latestTime` |
| `startTime` | `0` |
| `endTime` | `0.5` |
| `deltaT` | `0.0001` |
| `writeControl` | `adjustable` |
| `writeInterval` | `0.0025` |
| `adjustTimeStep` | `yes` |
| `maxCo` | `1.0` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选气相内部与煤粉粒子，点击 **Apply**。先选择最后一个已写出的时刻，以 `T` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

输出煤粒总质量及水分、挥发分、焦炭等组分质量，与气相生成物的变化对应。同步绘制平均压力、温度和热释放率，分析颗粒升温、挥发和压力增长的先后关系。

保持输出间隔一致，比较不同粒径的升温与转化时间。计算压力变化率时使用足够密集的时间序列，并分别计入外部热源、化学放热和壁面散热，以解释压力增长的能量来源。

> **熊猫说：** 颗粒释放的挥发分通过组分名称进入气相反应机理。两侧名称对应后，质量与能量源才能沿同一转化路径传递。

## 文件与来源

- [完整算例包](/downloads/engineering/dust-explosion.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/lagrangian/coalChemistryFoam/simplifiedSiwek)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
