#!/usr/bin/env python3
"""Collect monitored engineering quantities without third-party dependencies."""
from pathlib import Path
import csv,json,re
ROOT=Path(__file__).resolve().parent
NUMBER=r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?'

def last_table(path):
    rows=[]
    for line in path.read_text(errors='replace').splitlines():
        if not line.strip() or line.lstrip().startswith('#'):continue
        values=[float(v) for v in re.findall(NUMBER,line)]
        if values:rows.append(values)
    return rows

def internal_range(path):
    s=path.read_text(errors='replace')
    m=re.search(r'internalField\s+uniform\s+('+NUMBER+r')\s*;',s)
    if m:return {'minimum':float(m[1]),'maximum':float(m[1])}
    m=re.search(r'internalField\s+nonuniform\s+List<scalar>\s+\d+\s*\((.*?)\)\s*;',s,re.S)
    if not m:return None
    v=[float(x) for x in re.findall(NUMBER,m[1])]
    return dict(minimum=min(v),maximum=max(v)) if v else None

def main():
    design=json.loads((ROOT/'design.json').read_text(encoding='utf8'));tables={};latest={}
    for file in sorted((ROOT/'postProcessing').rglob('*.dat')) if (ROOT/'postProcessing').exists() else []:
        data=last_table(file)
        if not data:continue
        name=file.relative_to(ROOT/'postProcessing').as_posix();tables[name]=data
        obj=file.relative_to(ROOT/'postProcessing').parts[0]
        if obj not in latest or data[-1][0]>=latest[obj][0]:latest[obj]=data[-1]
    report={'case':design['key'],'iteration_or_time':max((v[0] for v in latest.values()),default=None),'monitors':{},'notes':[]}
    flux=[]
    for name,v in latest.items():
        if len(v)<2:continue
        if name.startswith('flow_'):
            q=v[1]/design['rho'] if design['kind']=='cht' else v[1]
            report['monitors'][name]={'value':q,'unit':'m3/s','sign':'outward-positive','quantity':'mixture volume flux' if design['kind']=='vof' else 'volume flux'};flux.append(q)
        elif name.startswith('pressure_'):
            value=v[1] if design['kind'] in ['cht','vof'] else v[1]*design['rho']
            report['monitors'][name]={'value':value,'unit':'Pa','quantity':'p_rgh' if design['kind']=='vof' else 'p'}
        elif name.startswith('temperature_'):report['monitors'][name]={'value':v[1],'unit':'K'}
        elif name=='liquidVolume':report['monitors'][name]={'value':v[1],'unit':'m3'}
    if flux:
        incoming=-sum(q for q in flux if q<0);outgoing=sum(q for q in flux if q>0)
        report['net_boundary_flux_m3_s']=sum(flux)
        if incoming>1e-15:report['relative_flux_imbalance']=abs(outgoing-incoming)/incoming
    outputs=[v['value'] for k,v in report['monitors'].items() if k.startswith('flow_') and v['value']>0]
    if len(outputs)>1:
        mean=sum(outputs)/len(outputs)
        report['outlet_flow_coefficient_of_variation']=(sum((q-mean)**2 for q in outputs)/len(outputs))**.5/mean
    times=[]
    for p in ROOT.iterdir():
        if not p.is_dir():continue
        try:times.append((float(p.name),p))
        except ValueError:pass
    if times:
        folder=max(times,key=lambda x:x[0])[1]
        for rel in (['solid/T','fluid/T'] if design['kind']=='cht' else ['alpha.water'] if design['kind']=='vof' else ['p','tracer']):
            if (folder/rel).exists():
                value=internal_range(folder/rel)
                if value:report['monitors'][rel]=value
        if design['kind']=='cht' and 'solid/T' in report['monitors']:
            report['thermal_resistance_K_W']=(report['monitors']['solid/T']['maximum']-design['Tin'])/design['power']
    target=ROOT/'analysis';target.mkdir(exist_ok=True)
    with (target/'monitor-history.csv').open('w',encoding='utf8',newline='') as out:
        writer=csv.writer(out);writer.writerow(['source','time_or_iteration','values_in_original_column_order'])
        for name,values in tables.items():
            for row in values:writer.writerow([name,row[0],json.dumps(row[1:])])
    (target/'metrics.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if not tables:raise SystemExit('No monitoring outputs found; run the solver first.')

if __name__=='__main__':main()
