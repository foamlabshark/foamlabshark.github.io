#!/usr/bin/env python3
"""Generate a self-contained OpenCFD v2512 case from SI design parameters.

Only Python's standard library is required. Geometry and all dictionaries are
constructed here; no OpenFOAM tutorial files are read or copied.
"""
from pathlib import Path
from collections import defaultdict
import argparse,json,math

def header(name,cls='dictionary'):
    return 'FoamFile\n{\n    version 2.0;\n    format ascii;\n    class '+cls+';\n    object '+name+';\n}\n\n'
def vec(v):return '('+' '.join(f'{x:.12g}' for x in v)+')'
def write(root,name,text):
    p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding='utf8',newline='\n')
def dictionary(root,name,text):write(root,name,header(Path(name).name)+text+'\n')
def inside(p,b,tol=1e-10):return all(b[2*i]-tol<=p[i]<=b[2*i+1]+tol for i in range(3))
def bounds_of(boxes):return [f(b[2*i+offset] for b in boxes) for i in range(3) for f,offset in [(min,0),(max,1)]]
FACES=[(0,-1,[0,4,7,3]),(0,1,[1,2,6,5]),(1,-1,[0,1,5,4]),(1,1,[3,7,6,2]),(2,-1,[0,3,2,1]),(2,1,[4,5,6,7])]
OFFSETS=[(0,0,0),(1,0,0),(1,1,0),(0,1,0),(0,0,1),(1,0,1),(1,1,1),(0,1,1)]

def geometry(c,refine):
    if c['kind']=='rotor':return radial_geometry(c,refine)
    fluids=c['fluid_boxes'];solids=c['solids'];holes=[o['bounds'] if isinstance(o,dict) else o for o in c['obstacles']]
    extent=bounds_of(fluids+solids)
    pieces=fluids+solids+holes+[p['bounds'] for p in c['ports']]
    # Inlet divisions are mesh planes, so different ports never share one face.
    axes=[sorted({round(b[j],12) for b in pieces for j in [2*i,2*i+1] if extent[2*i]-1e-10<=b[j]<=extent[2*i+1]+1e-10}) for i in range(3)]
    types={};blocks={};points=[];lookup={};faces=defaultdict(list);cell_count=0
    counts=[[max(2,math.ceil((b-a)/(extent[2*i+1]-extent[2*i])*c['cells'][i]))*refine for a,b in zip(axes[i],axes[i][1:])] for i in range(3)]
    for i in range(len(axes[0])-1):
      for j in range(len(axes[1])-1):
       for k in range(len(axes[2])-1):
        ijk=(i,j,k);mid=[(axes[d][ijk[d]]+axes[d][ijk[d]+1])/2 for d in range(3)]
        if any(inside(mid,b) for b in holes):continue
        kind='solid' if any(inside(mid,b) for b in solids) else 'fluid'
        if kind=='fluid' and not any(inside(mid,b) for b in fluids):continue
        idx=[]
        for off in OFFSETS:
            p=tuple(axes[d][ijk[d]+off[d]] for d in range(3))
            if p not in lookup:lookup[p]=len(points);points.append(p)
            idx.append(lookup[p])
        n=[counts[d][ijk[d]] for d in range(3)];zone=kind if c['kind']=='cht' else ''
        blocks[ijk]=(idx,n,zone);types[ijk]=kind;cell_count+=math.prod(n)
    for ijk,(ids,n,zone) in blocks.items():
      for axis,sign,order in FACES:
        other=list(ijk);other[axis]+=sign;other=tuple(other)
        if other in blocks:continue
        vertices=[ids[q] for q in order];mid=[sum(points[q][d] for q in vertices)/4 for d in range(3)]
        name='walls'
        if types[ijk]=='fluid':
          for hole,original in zip(holes,c['obstacles']):
            if inside(mid,hole) and isinstance(original,dict):name=original.get('patch','walls')
          if c.get('top_slip') and axis==2 and sign==1 and abs(mid[2]-extent[5])<1e-9:name='lid'
          if c['kind']=='vof' and axis==2 and sign==1 and abs(mid[2]-extent[5])<1e-9:name='atmosphere'
          for port in c['ports']:
            if axis==port['axis'] and abs(mid[axis]-port['value'])<1e-9 and inside(mid,port['bounds']):name=port['name'];break
        faces[name].append(vertices)
    geo={'points':points,'blocks':list(blocks.values()),'faces':dict(faces),'cells':cell_count,'extent':extent,'edges':[]}
    for port in c['ports']:
        if not faces.get(port['name']):raise ValueError('Port has no faces: '+port['name'])
    return geo

def radial_geometry(c,refine):
    r=[c['inner_radius'],c['outer_radius']];a=[-c['sector_angle']/2,c['sector_angle']/2];h=c['bounds'][5]
    points=[(r[i]*math.cos(a[j]),r[i]*math.sin(a[j]),h*k) for i,j,k in OFFSETS]
    edges=[]
    for start,end,radius,z in [(0,3,r[0],0),(1,2,r[1],0),(4,7,r[0],h),(5,6,r[1],h)]:
        edges.append(f'arc {start} {end} {vec([radius,0,z])}')
    n=[36*refine,12*refine,8*refine]
    return dict(points=points,blocks=[(list(range(8)),n,'rotating')],faces={'inlet':[[0,4,7,3]],'outlet':[[1,2,6,5]],'rotor':[[0,1,5,4],[3,7,6,2],[0,3,2,1],[4,5,6,7]]},cells=math.prod(n),extent=[r[0]*math.cos(a[1]),r[1],-r[1]*math.sin(a[1]),r[1]*math.sin(a[1]),0,h],edges=edges)

def export_geometry(root,c,g):
    patches={p['name'] for p in c['ports']}|{'atmosphere','lid','inlet','outlet'}
    body='scale 1;\nvertices\n(\n'+''.join('    '+vec(p)+'\n' for p in g['points'])+');\nblocks\n(\n'
    for ids,n,zone in g['blocks']:body+='    hex ('+' '.join(map(str,ids))+') '+zone+' '+vec(n)+' simpleGrading (1 1 1)\n'
    body+=');\nedges\n(\n'+'\n'.join(g['edges'])+'\n);\nboundary\n(\n'
    for name,faces in g['faces'].items():
        typ='patch' if name in patches else 'wall'
        body+=f'    {name}\n    {{ type {typ}; faces\n      (\n'+''.join('        ('+' '.join(map(str,face))+')\n' for face in faces)+'      );\n    }\n'
    body+=');\nmergePatchPairs ();\n'
    dictionary(root,'system/blockMeshDict',body)
    # Boundary OBJ is a viewing aid. The curved rotor is represented exactly by
    # blockMesh arc edges; its OBJ consists of the corner polygons only.
    obj='\n'.join('v '+' '.join(map(str,p)) for p in g['points'])+'\n'
    for name,faces in g['faces'].items():
        obj+='g '+name+'\n'+''.join('f '+' '.join(str(v+1) for v in face)+'\n' for face in faces)
    write(root,'geometry/model.obj',obj)
    info=dict(design='FoamLab parameterized engineering design',units='m',cells=g['cells'],extent=g['extent'],patches={k:len(v) for k,v in g['faces'].items()},solid_boxes=c['solids'],obstacles=c['obstacles'],fluid_boxes=c['fluid_boxes'])
    write(root,'geometry/mesh-design.json',json.dumps(info,ensure_ascii=False,indent=2))
    # Input grid blocks also permit precise reconstruction of region interfaces.
    write(root,'geometry/preview.json',json.dumps(g,separators=(',',':')))

def scalar_field(root,path,dimensions,value,boundaries,vector=False):
    b='dimensions ['+dimensions+'];\ninternalField uniform '+(vec(value) if vector else str(value))+';\nboundaryField\n{\n'
    for name,definition in boundaries.items():b+='    '+name+' { '+definition+' }\n'
    b+='}\n';write(root,path,header(Path(path).name,'volVectorField' if vector else 'volScalarField')+b)

def schemes(root,region='',unsteady=False,cht=False):
    path='system/'+(region+'/' if region else '')
    divs='''    default none;
    div(phi,U) bounded Gauss upwind;
    div(phi,k) bounded Gauss upwind;
    div(phi,omega) bounded Gauss upwind;
    div(phi,epsilon) bounded Gauss upwind;
    div(phi,tracer) bounded Gauss upwind;
    div(phi,h) bounded Gauss upwind;
    div(phi,K) bounded Gauss upwind;
    div(phid,p) bounded Gauss upwind;
    div((nuEff*dev2(T(grad(U))))) Gauss linear;
    div(((rho*nuEff)*dev2(T(grad(U))))) Gauss linear;
    div((muEff*dev2(T(grad(U))))) Gauss linear;
    div(rhoPhi,U) Gauss upwind;
    div(phi,alpha) Gauss vanLeer;
    div(phirb,alpha) Gauss interfaceCompression;
'''
    text='ddtSchemes { default '+('Euler' if unsteady else 'steadyState')+'; }\ngradSchemes { default Gauss linear; }\ndivSchemes\n{\n'+divs+'}\nlaplacianSchemes { default Gauss linear corrected; }\ninterpolationSchemes { default linear; }\nsnGradSchemes { default corrected; }\nfluxRequired { default no; p; p_rgh; pcorr; alpha.water; }\nwallDist { method meshWave; }\n'
    dictionary(root,path+'fvSchemes',text)
    pressure='p_rgh' if unsteady or cht else 'p'
    text='solvers\n{\n'+f'''    {pressure}
    {{ solver GAMG; tolerance 1e-8; relTol 0.05; smoother GaussSeidel; }}
    {pressure}Final
    {{ ${pressure}; relTol 0; }}
    "pcorr.*" {{ solver PCG; preconditioner DIC; tolerance 1e-9; relTol 0; }}
    "(U|k|omega|epsilon|h|tracer|rho)" {{ solver smoothSolver; smoother symGaussSeidel; tolerance 1e-8; relTol 0.05; }}
    "(U|k|omega|epsilon|h)Final" {{ solver smoothSolver; smoother symGaussSeidel; tolerance 1e-8; relTol 0; }}
    "alpha.water.*" {{ nAlphaCorr 2; nAlphaSubCycles 2; cAlpha 1; MULESCorr yes; nLimiterIter 3; solver smoothSolver; smoother symGaussSeidel; tolerance 1e-9; relTol 0; }}
}}
'''
    if unsteady:text+='PIMPLE { momentumPredictor yes; nOuterCorrectors 2; nCorrectors 2; nNonOrthogonalCorrectors 0; pRefCell 0; pRefValue 0; }\n'
    else:text+='SIMPLE { nNonOrthogonalCorrectors 0; pRefCell 0; pRefValue '+('101325' if cht else '0')+'; momentumPredictor yes; }\n'
    text+='relaxationFactors { fields { p 0.3; p_rgh 0.3; rho 1; } equations { U 0.6; h 0.7; k 0.6; omega 0.6; epsilon 0.6; tracer 0.8; } }\n'
    dictionary(root,path+'fvSolution',text)

def controls(root,c,regions=False):
    solver={'cht':'chtMultiRegionSimpleFoam','vof':'interFoam'}.get(c['kind'],'simpleFoam')
    unsteady=c['kind']=='vof';end=c.get('end_time',1500);dt=.0005 if unsteady else 1
    functions=''
    region='fluid' if regions else ''
    regionline='region fluid;' if regions else ''
    monitor_ports=c['ports']+([{'name':'atmosphere'}] if unsteady else [])
    for p in monitor_ports:
        name=p['name']
        functions+=f'''    flow_{name}
    {{ type surfaceFieldValue; libs (fieldFunctionObjects); {regionline} regionType patch; name {name}; operation sum; fields (phi); writeFields false; writeControl timeStep; writeInterval 1; }}
    pressure_{name}
    {{ type surfaceFieldValue; libs (fieldFunctionObjects); {regionline} regionType patch; name {name}; operation areaAverage; fields ({'p_rgh' if unsteady else 'p'}); writeFields false; writeControl timeStep; writeInterval 1; }}
'''
    functions+=f'''    ranges
    {{ type fieldMinMax; libs (fieldFunctionObjects); {regionline} fields (U {'T' if regions else 'alpha.water' if unsteady else 'p'}); location true; writeControl timeStep; writeInterval 1; }}
'''
    if regions:
        functions+='''    solidTemperature
    { type fieldMinMax; libs (fieldFunctionObjects); region solid; fields (T); location true; writeControl timeStep; writeInterval 1; }
    solidAverage
    { type volFieldValue; libs (fieldFunctionObjects); region solid; regionType all; operation volAverage; fields (T); writeFields false; writeControl timeStep; writeInterval 1; }
'''
        for p in c['ports']:
            functions+=f'''    temperature_{p['name']}
    {{ type surfaceFieldValue; libs (fieldFunctionObjects); region fluid; regionType patch; name {p['name']}; operation weightedAverage; weightField phi; fields (T); writeFields false; writeControl timeStep; writeInterval 1; }}
'''
    if c.get('tracer'):
        diffusion=f"alphaD {c.get('tracerD',1e-8)/c['nu']}; alphaDt {1/.7};" if c.get('turbulent') else f"D {c.get('tracerD',1e-8)};"
        functions+=f'''    tracerTransport
    {{ type scalarTransport; libs (solverFunctionObjects); field tracer; {diffusion} nCorr 1; resetOnStartUp false; writeControl writeTime; }}
    tracerRange
    {{ type fieldMinMax; libs (fieldFunctionObjects); fields (tracer); writeControl timeStep; writeInterval 1; }}
'''
    if c['kind'] in ['rotor','mrf','vof']:
        patch='rotor' if c['kind']!='vof' else 'walls';origin=c.get('rotation_origin',[0,0,0])
        functions+=f'''    loads
    {{ type forces; libs (forces); patches ({patch}); rho {'rho' if unsteady else 'rhoInf'}; rhoInf {c['rho']}; CofR {vec(origin)}; writeControl timeStep; writeInterval 1; }}
'''
    if unsteady:
        functions+='''    liquidVolume
    { type volFieldValue; libs (fieldFunctionObjects); regionType all; operation volIntegrate; fields (alpha.water); writeFields false; writeControl timeStep; writeInterval 1; }
'''
    text=f'''application {solver};
startFrom startTime;
startTime 0;
stopAt endTime;
endTime {end};
deltaT {dt};
writeControl {'adjustableRunTime' if unsteady else 'timeStep'};
writeInterval {end/100 if unsteady else 100};
purgeWrite 0;
writeFormat ascii;
writePrecision 10;
writeCompression off;
timeFormat general;
timePrecision 10;
runTimeModifiable true;
'''
    if unsteady:text+='adjustTimeStep yes; maxCo 0.3; maxAlphaCo 0.2; maxDeltaT 0.005;\n'
    text+='functions\n{\n'+functions+'}\n'
    dictionary(root,'system/controlDict',text)
    dictionary(root,'system/decomposeParDict','numberOfSubdomains 4;\nmethod scotch;')
    return solver

def fields(root,c,g,region=''):
    cht=c['kind']=='cht';vof=c['kind']=='vof';solid=region=='solid';prefix='0.orig/'+(region+'/' if region else '')
    portmap={p['name']:p for p in c['ports']}
    names=list(g['faces'])
    if cht:names+=['solid_to_fluid' if solid else 'fluid_to_solid']
    b={key:{} for key in ['U','p','p_rgh','T','k','omega','nut','alphat','alpha.water','tracer']}
    k=max(1e-8,1.5*(.05*max(c['speed'],.01))**2);omega=max(1,k**.5/(.09**.25*.01))
    for name in names:
        p=portmap.get(name);inlet=p is not None and p['kind']=='inlet';outlet=p is not None and p['kind']=='outlet'
        interface='_to_' in name
        openair=name=='atmosphere';slip=name=='lid'
        u='type noSlip;';press='type zeroGradient;';pr='type fixedFluxPressure; value uniform '+('101325;' if cht else '0;')
        t='type zeroGradient;';a='type zeroGradient;';tracer='type zeroGradient;'
        if slip:u='type slip;'
        if inlet:
            u='type fixedValue; value uniform '+vec(p['velocity'])+';'
            if vof and not p.get('liquid_jet'):u='type variableHeightFlowRateInletVelocity; alpha alpha.water; flowRate constant '+str(p['flow_rate'])+'; value uniform '+vec(p['velocity'])+';'
            t=f"type fixedValue; value uniform {p.get('temperature',c['Tin'])};"
            a='type variableHeightFlowRate; lowerBound 0; upperBound 1; value uniform 1;'
            if p.get('liquid_jet'):a='type fixedValue; value uniform 1;'
            tracer=f"type fixedValue; value uniform {p.get('tracer',0)};"
        if outlet:
            u='type pressureInletOutletVelocity; value uniform (0 0 0);'
            press='type fixedValue; value uniform '+('101325;' if cht else '0;')
            pr='type fixedValue; value uniform '+('101325;' if cht else '0;')
            if vof:pr='type prghPressure; rho rho; p uniform 0; value uniform 0;'
            t=f"type inletOutlet; inletValue uniform {c['Tin']}; value uniform {c['Tin']};"
            a='type inletOutlet; inletValue uniform 1; value uniform 1;';tracer='type inletOutlet; inletValue uniform 0; value uniform 0;'
        if openair:
            u='type pressureInletOutletVelocity; value uniform (0 0 0);';pr='type prghTotalPressure; p0 uniform 0; value uniform 0;'
            a='type inletOutlet; inletValue uniform 0; value uniform 0;'
        if interface:t=f"type compressible::turbulentTemperatureRadCoupledMixed; Tnbr T; qr none; qrNbr none; kappaMethod {'solidThermo' if solid else 'fluidThermo'}; value uniform {c['Tin']};"
        b['U'][name]=u;b['p'][name]='type calculated; value uniform 101325;' if cht else press;b['p_rgh'][name]=pr;b['T'][name]=t;b['alpha.water'][name]=a;b['tracer'][name]=tracer
        wall=not inlet and not outlet and not openair and not slip
        for field,val,walltype in [('k',k,'kqRWallFunction'),('omega',omega,'omegaWallFunction')]:
            b[field][name]=f'type {walltype}; value uniform {val};' if wall else (f'type fixedValue; value uniform {val};' if inlet else f'type inletOutlet; inletValue uniform {val}; value uniform {val};')
            if slip:b[field][name]='type zeroGradient;'
        b['nut'][name]='type nutkWallFunction; value uniform 0;' if wall else 'type calculated; value uniform 0;'
        b['alphat'][name]='type compressible::alphatWallFunction; Prt 0.85; value uniform 0;' if cht and wall and c.get('turbulent') else 'type calculated; value uniform 0;'
    if solid:
        scalar_field(root,prefix+'T','0 0 0 1 0 0 0',c['Tin'],b['T'])
        scalar_field(root,prefix+'p','1 -1 -2 0 0 0 0',101325,{name:'type zeroGradient;' for name in names})
        return
    scalar_field(root,prefix+'U','0 1 -1 0 0 0 0',[0,0,0],b['U'],True)
    if cht:
        scalar_field(root,prefix+'p','1 -1 -2 0 0 0 0',101325,b['p'])
        scalar_field(root,prefix+'p_rgh','1 -1 -2 0 0 0 0',101325,b['p_rgh'])
        scalar_field(root,prefix+'T','0 0 0 1 0 0 0',c['Tin'],b['T'])
        scalar_field(root,prefix+'alphat','1 -1 -1 0 0 0 0',0,b['alphat'])
    elif vof:
        scalar_field(root,prefix+'p_rgh','1 -1 -2 0 0 0 0',0,b['p_rgh'])
        scalar_field(root,prefix+'alpha.water','0 0 0 0 0 0 0',0,b['alpha.water'])
    else:scalar_field(root,prefix+'p','0 2 -2 0 0 0 0',0,b['p'])
    if c.get('turbulent'):
        scalar_field(root,prefix+'k','0 2 -2 0 0 0 0',k,b['k'])
        scalar_field(root,prefix+'omega','0 0 -1 0 0 0 0',omega,b['omega'])
        scalar_field(root,prefix+'nut','0 2 -1 0 0 0 0',0,b['nut'])
    if c.get('tracer'):scalar_field(root,prefix+'tracer','0 0 0 0 0 0 0',0,b['tracer'])

def material(root,c):
    cht=c['kind']=='cht';pre='constant/fluid/' if cht else 'constant/'
    turbulence='simulationType RAS;\nRAS { RASModel kOmegaSST; turbulence on; printCoeffs on; }' if c.get('turbulent') else 'simulationType laminar;'
    dictionary(root,pre+'turbulenceProperties',turbulence)
    if cht:
        mu=c['rho']*c['nu'];pr=mu*c['Cp']/c['kappa']
        dictionary(root,pre+'thermophysicalProperties',f'''thermoType {{ type heRhoThermo; mixture pureMixture; transport const; thermo hConst; equationOfState rhoConst; specie specie; energy sensibleEnthalpy; }}
mixture {{ specie {{ molWeight 28.97; }} equationOfState {{ rho {c['rho']}; }} thermodynamics {{ Cp {c['Cp']}; Hf 0; }} transport {{ mu {mu}; Pr {pr}; }} }}''')
        rho,cp,kappa=c['solid_properties']
        dictionary(root,'constant/solid/thermophysicalProperties',f'''thermoType {{ type heSolidThermo; mixture pureMixture; transport constIso; thermo hConst; equationOfState rhoConst; specie specie; energy sensibleEnthalpy; }}
mixture {{ specie {{ molWeight 26.98; }} equationOfState {{ rho {rho}; }} thermodynamics {{ Cp {cp}; Hf 0; }} transport {{ kappa {kappa}; }} }}''')
        dictionary(root,'constant/fluid/radiationProperties','radiationModel none;')
        dictionary(root,'constant/regionProperties','regions (fluid (fluid) solid (solid));')
        write(root,'constant/g',header('g','uniformDimensionedVectorField')+'dimensions [0 1 -2 0 0 0 0];\nvalue (0 0 0);\n')
        hs=c['solids'] if c['key'] in ['battery-module-airgap','transformer-oil-winding','food-heating-channel'] else [c['solids'][0]]
        if c['key']=='busbar-joint-cooling':hs=[[.09,.13,.035,.065,.02,.036]]
        actions=[]
        for i,bb in enumerate(hs):actions.append(f'{{ name heatingCells; type cellSet; action {"new" if i==0 else "add"}; source boxToCell; box {vec(bb[::2])} {vec(bb[1::2])}; }}')
        dictionary(root,'system/solid/topoSetDict','actions\n(\n'+'\n'.join(actions)+'\n);')
        dictionary(root,'constant/solid/fvOptions',f'''heatInput
{{ type scalarSemiImplicitSource; active true; selectionMode cellSet; cellSet heatingCells; volumeMode absolute; injectionRateSuSp {{ h ({c['power']} 0); }} }}''')
    elif c['kind']=='vof':
        dictionary(root,'constant/transportProperties',f'''phases (water air);
water {{ transportModel Newtonian; nu {c['nu']}; rho {c['rho']}; }}
air {{ transportModel Newtonian; nu 1.5e-5; rho 1.2; }}
sigma {0.03 if 'sump' in c['key'] else 0.072};''')
        write(root,'constant/g',header('g','uniformDimensionedVectorField')+'dimensions [0 1 -2 0 0 0 0];\nvalue (0 0 -9.81);\n')
    else:dictionary(root,'constant/transportProperties',f'transportModel Newtonian;\nnu [0 2 -1 0 0 0 0] {c["nu"]};')

def motion(root,c):
    if c['kind'] not in ['rotor','mrf']:return
    origin=c.get('rotation_origin',[0,0,0])
    dictionary(root,'constant/MRFProperties',f'''rotatingFrame
{{ active true; cellZone rotating; origin {vec(origin)}; axis (0 0 1); omega {c['omega']}; nonRotatingPatches (walls lid inlet outlet); }}''')
    if c['kind']=='mrf':
        z0,z1=c['rotation_z'];o=origin
        dictionary(root,'system/topoSetDict',f'''actions
(
 {{ name rotationCells; type cellSet; action new; source cylinderToCell; p1 ({o[0]} {o[1]} {z0}); p2 ({o[0]} {o[1]} {z1}); radius {c['rotation_radius']}; }}
 {{ name rotating; type cellZoneSet; action new; source setToCellZone; set rotationCells; }}
);''')

def initialization(root,c,g):
    if c['kind']!='vof':return
    x0,x1,y0,y1,z0,z1=g['extent'];level=c['water_level']
    regions=[]
    for i in range(40 if c.get('tilt') else 1):
        left=x0+(x1-x0)*i/(40 if c.get('tilt') else 1);right=x0+(x1-x0)*(i+1)/(40 if c.get('tilt') else 1)
        h=level+c.get('tilt',0)*((left+right)/2-(x0+x1)/2)
        regions.append(f'boxToCell {{ box ({left-1e-10} {y0-1} {z0-1}) ({right+1e-10} {y1+1} {h}); fieldValues (volScalarFieldValue alpha.water 1); }}')
    dictionary(root,'system/setFieldsDict','defaultFieldValues (volScalarFieldValue alpha.water 0);\nregions\n(\n'+'\n'.join(regions)+'\n);')

def scripts(root,c,solver):
    common='''#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
: "${WM_PROJECT_DIR:?Load the OpenCFD OpenFOAM v2512 environment first}"
if [ "${WM_PROJECT_VERSION:-}" != v2512 ]; then echo "Requires OpenCFD v2512" >&2; exit 2; fi
run() { local name="$1"; shift; "$@" > "log.$name" 2>&1 || { tail -n 60 "log.$name"; return 1; }; }
'''
    mesh=common+'''if [ -d constant/polyMesh ] || [ -d constant/fluid/polyMesh ]; then
    echo "Mesh exists. Use a fresh copy to change geometry or refinement." >&2; exit 3
fi
python3 build_case.py --refine "${MESH_REFINE:-2}"
mkdir -p 0
cp -a 0.orig/. 0/
run blockMesh blockMesh
'''
    if c['kind']=='cht':mesh+='run splitMeshRegions splitMeshRegions -cellZonesOnly -overwrite\nrun heatSelection topoSet -region solid\n'
    if c['kind']=='mrf':mesh+='run topoSet topoSet\n'
    if c['kind']=='vof':mesh+='run setFields setFields\n'
    mesh+='run checkMesh checkMesh'+(' -allRegions' if c['kind']=='cht' else '')+' -allGeometry -allTopology\n'
    mesh+='grep -q "Mesh OK" log.checkMesh || { tail -n 60 log.checkMesh; exit 4; }\n'
    mesh+='if grep -Eq "Failed [1-9][0-9]* mesh checks" log.checkMesh; then tail -n 60 log.checkMesh; exit 4; fi\n'
    mesh+='touch .mesh-ready\n'
    solve=common+f'[ -f .mesh-ready ] || {{ echo "Run bash Allmesh first" >&2; exit 3; }}\nrun {solver} {solver}\npython3 analyse.py\n'
    write(root,'Allmesh',mesh);write(root,'Allsolve',solve);write(root,'Allrun',common+'bash Allmesh\nbash Allsolve\n');write(root,'case.foam','')

def build(root,refine=2):
    c=json.loads((root/'design.json').read_text(encoding='utf8'))
    if c['kind']=='rotor':c['ports']=[dict(name='inlet',kind='outlet',velocity=[0,0,0]),dict(name='outlet',kind='outlet',velocity=[0,0,0])]
    g=geometry(c,refine)
    if c['kind']=='vof':
        for p in c['ports']:
            if p['kind']!='inlet':continue
            # Q is based on the initial wetted opening, not the air above it.
            b=p['bounds'];axis=p['axis'];area=1
            for d in range(3):
                if d==axis:continue
                area*=max(0,min(b[2*d+1],c['water_level'])-b[2*d]) if d==2 else b[2*d+1]-b[2*d]
            p['flow_rate']=area*abs(p['velocity'][axis])
    export_geometry(root,c,g);material(root,c);motion(root,c);initialization(root,c,g)
    if c['kind']=='cht':
        schemes(root,cht=True)
        for region in ['fluid','solid']:schemes(root,region,cht=True);fields(root,c,g,region)
    else:schemes(root,unsteady=c['kind']=='vof');fields(root,c,g)
    solver=controls(root,c,c['kind']=='cht');scripts(root,c,solver)
    write(root,'geometry/run-settings.json',json.dumps(dict(solver=solver,cells=g['cells'],ports=c['ports']),ensure_ascii=False,indent=2))
    return dict(key=c['key'],solver=solver,cells=g['cells'],blocks=len(g['blocks']))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--refine',type=int,default=2);args=parser.parse_args()
    if args.refine<1:parser.error('--refine must be a positive integer')
    print(json.dumps(build(Path(__file__).resolve().parent,args.refine),ensure_ascii=False))
