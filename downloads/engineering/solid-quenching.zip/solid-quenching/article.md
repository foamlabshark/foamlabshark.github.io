耦合金属导热与水—蒸气两流体流动，计算水淬冷却曲线及壁面沸腾换热。

## 工程场景与计算目标

高温工件进入水中后，表面气液分布和沸腾状态随温度变化，局部换热能力随之改变。表面降温与内部导热具有不同时间尺度，形成随时间发展的温差。完整的温度历程是后续材料组织和热应力分析的重要输入。

算例将金属与冷却液分区，固体求解导热，流体分别求解水和蒸气的速度、温度及体积分数。壁面沸腾提供相变质量和能量交换，区域耦合将工件内能传入冷却液。通过中心与表面温度、界面热流和汽相分布解释冷却阶段。

## 几何、尺寸与基准工况

![金属工件水淬的沸腾换热：配套模型与基准输入](/assets/engineering/solid-quenching-geometry.webp)

二维域宽 70 mm、高 140 mm、展向厚 2 mm。固体选区为 x = 0～4.77 mm、y = 29～70 mm，x = 0 为对称面，其余单元为流体。背景网格为 140 × 170 × 1，固体边界按单元中心选区离散。

模型与配置来源：[OpenFOAM v2512 · heatTransfer/chtMultiRegionTwoPhaseEulerFoam/solidQuenching2D](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionTwoPhaseEulerFoam/solidQuenching2D)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 金属初始温度 | 1123 K | `0.orig/solid/T` |
| 水初始温度 | 333 K | `0.orig/water/T.liquid` |
| 金属物性 | ρ = 8000 kg/m³，Cp = 450 J/(kg·K)，k = 60 W/(m·K) | `constant/solid/thermophysicalProperties` |
| 初始时间步、最大时间步 | 1 μs、1 ms | `system/controlDict` |
| 区域求解器 | chtMultiRegionTwoPhaseEulerFoam | 两流体能量与固体导热耦合 |

## 求解方法与物理模型

固体温度满足 $\rho_s c_{p,s}\partial T_s/\partial t=\nabla\cdot(k_s\nabla T_s)$。水和蒸气体积分数满足 $\alpha_l+\alpha_g=1$，壁面相变吸收热量 $\dot Q_{\mathrm{evap}}=\dot m L_v$。冷却速率 $-dT/dt$ 随局部汽相覆盖和壁温变化，因此表面与中心温度曲线需要分别观察。

本例使用 `chtMultiRegionTwoPhaseEulerFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/solid-quenching.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip solid-quenching.zip
cd solid-quenching
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `topoSet` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `splitMeshRegions -cellZonesOnly -overwrite` | 按区域标记分离流体与固体网格，建立配对界面。 |
| `setFields -region water` | 按几何区域设置初始相分数、组分或温度。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 固体—两相流体热耦合

文件：`0.orig/solid/T`。本段设置固体—两相流体热耦合。

```foam
solid_to_water
{
    type            compressible::turbulentTemperatureTwoPhaseRadCoupledMixed;
    value           uniform 1123;
    Tnbr            T.liquid;
    kappaMethod     solidThermo;
    region          solid;
    // Name of the other phase in the flid region mixing with 'liquid' phase
    otherPhase      gas;
    qrNbr           none;
    qr              none;
}
```

固体侧连接 `T.liquid` 并识别气相 `gas`，使气液状态共同参与界面换热。`splitMeshRegions` 生成配对边界名称。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionTwoPhaseEulerFoam/solidQuenching2D/0.orig/solid/T)。

### 2. 壁面沸腾

文件：`0.orig/water/alphat.liquid`。本段设置壁面沸腾。

```foam
water_to_solid
{
    type            compressible::alphatWallBoilingWallFunction;
    otherPhase      gas;
    phaseType       liquid;
    Prt             0.85;
    Cmu             0.09;
    kappa           0.41;
    E               9.8;
    relax           constant 1;
    dmdt            uniform 0;
    partitioningModel
    {
        type        Lavieville;
        alphaCrit   0.2;
    }
    nucleationSiteModel
    {
        type        LemmertChawla;
        Cn          185;
    }
    departureDiamModel
    {
        type        TolubinskiKostanchuk;
    }
    departureFreqModel
    {
        type        Cole;
    }
    LeidenfrostModel
    {
        type        Spiegler;
        Tcrit       647;
    }
    CHFModel
    {
        type        Zuber;
    }
    CHFSubCoolModel
    {
        type        HuaXu;
        Kburn       0.5;
    }
    MHFModel
    {
        type        Jeschar;
        Kmhf        1;
    }
    TDNBModel
    {
        type        Schroeder;
    }
    filmBoilingModel
    {
        type        Bromley;
        L           1e-3;
    }
    value           uniform 1e-8;
}
```

水侧边界按壁面沸腾关联式分配对流、汽泡作用和蒸发热流。壁温及局部相态通过这些关系决定工件放热。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionTwoPhaseEulerFoam/solidQuenching2D/0.orig/water/alphat.liquid)。

### 3. 两流体相变设置

文件：`constant/water/phaseProperties`。本段设置两流体相变设置。

```foam
type    thermalPhaseChangeTwoPhaseSystem;

phases (gas liquid);

// phase change in the bulk of the fluid.
phaseChange off;

//populationBalances (bubbles);

gas
{
    type            purePhaseModel;
    diameterModel   isothermal;

    isothermalCoeffs
    {
```

`gas` 与 `liquid` 构成流体区域。体相相变与壁面沸腾分别设置，当前壁面模型通过边界质量和热量来源描述工件表面的相变冷却。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionTwoPhaseEulerFoam/solidQuenching2D/constant/water/phaseProperties)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.chtMultiRegionTwoPhaseEulerFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `chtMultiRegionTwoPhaseEulerFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `0` |
| `endTime` | `5` |
| `deltaT` | `1e-6` |
| `writeControl` | `adjustable` |
| `writeInterval` | `0.1` |
| `adjustTimeStep` | `yes` |
| `maxCo` | `0.5` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选solid 与 water，点击 **Apply**。先选择最后一个已写出的时刻，以 `T` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

在固体中心和表面设置温度探针，绘制温度与冷却速率，同时显示邻近汽相体积分数。将温降阶段与蒸气覆盖变化对应，输出界面平均热流，并用固体内能下降核对流体吸热。

分别改变初始水温和固体导热系数，区分界面换热与内部导热对温差的影响。加密网格时同步重建固体选区，使离散后的工件尺寸保持一致。

> **熊猫说：** 向材料或热应力模型传递结果时，导出同一空间位置的完整温度时序，保留表面与内部的差异。

## 文件与来源

- [完整算例包](/downloads/engineering/solid-quenching.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionTwoPhaseEulerFoam/solidQuenching2D)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
