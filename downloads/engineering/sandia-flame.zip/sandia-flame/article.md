模拟 Sandia D 伴流稳定射流火焰，并利用公开测量剖面分析空气卷吸、燃料消耗和温度分布。

## 工程场景与计算目标

燃料射流进入空气后，剪切层不断卷吸周围气体，反应在具备适宜组分和温度的区域发生。混合速率、反应速率与热量输运共同决定火焰长度和产物分布。温度峰值只能反映局部状态，沿程速度及组分剖面才能进一步说明混合和燃烧过程。

Sandia D 由中央甲烷—空气射流、环形高温引燃气流和外侧空气伴流构成，公开资料包含入口条件与测量数据。本例采用轴对称网格、GRI 化学机理和 `reactingFoam`，通过局部时间步迭代获得稳态平均流场，再与相同位置的实验剖面比较。

## 几何、尺寸与基准工况

![Sandia D 射流火焰的湍流燃烧：配套模型与基准输入](/assets/engineering/sandia-flame-geometry.webp)

中央喷管内径为 7.2 mm，外侧依次为引燃环和空气伴流。三个入口分别命名为 `inletCH4`、`inletPilot`、`inletAir`。楔形网格表示轴对称平均流动，喷口尺寸及入口组成以 TNF 的 Sandia Piloted CH4/Air Flames 数据说明为依据。

模型与配置来源：[OpenFOAM v2512 · combustion/reactingFoam/RAS/SandiaD_LTS](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/combustion/reactingFoam/RAS/SandiaD_LTS)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 主射流速度 | 49.6 m/s | `0.orig/U/inletCH4` |
| 引燃气流速度 | 11.4 m/s | `0.orig/U/inletPilot` |
| 空气伴流速度 | 0.9 m/s | `0.orig/U/inletAir` |
| 主射流与引燃温度 | 294 K、1880 K | `0.orig/T` |
| 计算阶段 | 冷流至 1500，反应至 5000 | LTS 迭代推进，见 `Allsolve` |

## 求解方法与物理模型

第 $k$ 种组分的质量分数满足 $\partial(\rho Y_k)/\partial t+\nabla\cdot(\rho\mathbf UY_k)=\nabla\cdot(\rho D_{k,\mathrm{eff}}\nabla Y_k)+\dot\omega_k$。对流项描述组分随射流输运，扩散项描述分子与湍流混合，反应源 $\dot\omega_k$ 描述该组分的生成或消耗。

化学反应通过 $\dot q=-\sum_k h_{f,k}\dot\omega_k$ 向能量方程提供热源，其中 $h_{f,k}$ 为组分生成焓。温升改变密度和速度，新的流场又改变混合，因此组分、能量与动量方程需要耦合迭代。

本例使用 `reactingFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/sandia-flame.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip sandia-flame.zip
cd sandia-flame
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `chemkinToFoam chemkin/grimech30.dat chemkin/thermo30.dat chemkin/transportProperties constant/reactionsGRI constant/thermo.compressibleGasGRI` | 把随包 CHEMKIN 反应机理、热物性和输运数据转换为求解器字典。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `setFields` | 按几何区域设置初始相分数、组分或温度。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 三路入口的速度分配

文件：`0.orig/U`。本段设置三路入口的速度分配。

```foam
inletPilot
{
    type            fixedValue;
    value           uniform (0 0 11.4);
}
```

主射流、引燃环和外侧伴流的速度分别为 49.6、11.4、0.9 m/s。三者之间的速度差形成剪切层，决定卷吸与混合的发展位置，因此需要保留三个独立入口。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/combustion/reactingFoam/RAS/SandiaD_LTS/0.orig/U)。

### 2. 湍流燃烧与化学机理

文件：`constant/combustionProperties`。本段设置湍流燃烧与化学机理。

```foam
combustionModel  EDC;

active  true;

EDCCoeffs
{
    version v2005;
}
```

燃烧模型根据湍流混合与化学反应计算反应源。完整机理由 CHEMKIN 文件转换生成；机理中的物种名称同时用于组分初始场、热物性和输运数据。更换燃料时，这些文件共同确定新的反应体系。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/combustion/reactingFoam/RAS/SandiaD_LTS/constant/combustionProperties)。

### 3. 引燃环的热边界

文件：`0.orig/T`。本段设置引燃环的热边界。

```foam
inletPilot
{
    type            fixedValue;
    value           uniform 1880;
}
```

引燃环维持 1880 K，持续向中央射流边缘供热；主射流温度为 294 K。这一温度分布使火焰在喷口附近得到稳定，是基准燃烧条件的一部分。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/combustion/reactingFoam/RAS/SandiaD_LTS/0.orig/T)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.reactingFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `reactingFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。本例采用局部时间步向稳态推进，Time 不作为真实瞬态时间解释。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `latestTime` |
| `startTime` | `0` |
| `endTime` | `1500` |
| `deltaT` | `1` |
| `writeControl` | `runTime` |
| `writeInterval` | `1500` |

运行脚本先关闭化学反应推进冷态混合场至 1500，再从最新场开启反应推进至 5000。这个过程把入口流动的建立与反应场的形成分开，两个阶段的日志分别保存。

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选燃料射流，点击 **Apply**。先选择最后一个已写出的时刻，以 `T` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

沿中心线提取轴向速度、温度和甲烷质量分数，辨认射流衰减、升温和燃料消耗的轴向位置。再按实验给出的无量纲距离设置径向采样线，比较温度峰值所在半径以及 CO、CO₂ 等组分的分布。坐标以喷口直径归一化，采样位置与实验一致。

喷口和反应带的网格加密用于检查剖面的空间分辨率；湍流燃烧闭合参数的比较用于分析模型影响。局部时间步计算中的迭代坐标表示收敛进程，火焰传播速度和瞬态频率需要另设物理时间推进计算。

> **熊猫说：** 组分场采用质量分数。将甲烷与空气的体积配比换算为质量分数后，再填写 `CH4`、`O2`、`N2` 等入口值，并使其总和为 1。

## 文件与来源

- [完整算例包](/downloads/engineering/sandia-flame.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/combustion/reactingFoam/RAS/SandiaD_LTS)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
- [Sandia 射流火焰实验说明](https://tnfworkshop.org/wp-content/uploads/2019/02/SandiaPilotDoc21.pdf)。
