建立集热风道强化换热收益与送风耗能模型，分析肋高与集热风量对出口焓增、吸热板最高温度及压降的影响。

## 工程场景与计算目标

太阳能空气集热器将吸热板上的热量传给流经风道的空气。平直通道中的近壁流体受热后形成温度梯度，横向肋可以打断其发展并增强壁面与主流之间的交换。肋后回流也会增加压力损失，使鼓风机耗能上升。

本例在 800 mm 长的吸热板上设置六条横肋，用 180 W 固体热源表示吸收的太阳辐射功率。采用共轭传热与 SST 湍流模型，计算板内温度、肋间回流和空气焓增。参数比较保持吸收功率相同，考察肋高与供风量对出口温度和流阻的综合影响。

## 几何、尺寸与基准工况

几何由 `design.json` 中的尺寸和位置生成，采用吸热板与六条横向矩形强化肋。坐标与尺寸均使用 m，流向由边界速度向量确定。

![太阳能空气集热器的肋化吸热板的结构分区与流动方向](/assets/engineering/solar-air-ribbed-absorber-geometry.webp)

| 参数 | 基准值 | 含义 |
| --- | --- | --- |
| 计算域外包尺寸 | 0.8 × 0.24 × 0.05 m | 实际计算空间由流体块体并集确定 |
| 流体密度 | 1.184 kg/m³ | 惯性、压差换算和质量流量 |
| 运动黏度 | 1.56e-05 m²/s | 分子黏性输运 |
| 基础网格 | 443,520 单元 | 默认 MESH_REFINE=2 的设计网格 |
| 入口温度 | 298.15 K | 冷却或被加热流体 |
| 总热功率 | 180 W | 由 solid/fvOptions 指定 |
| 固体导热系数 | 16 W/(m·K) | 固体 thermophysicalProperties |

几何各部分的坐标范围如下。流体块体先合并，再从中划分导热固体或扣除障碍物；因此相邻、相交块体不会重复占据体积。

| 部件 | x 范围 / m | y 范围 / m | z 范围 / m |
| --- | --- | --- | --- |
| 流体区域1 | 0～0.8 | 0～0.24 | 0～0.05 |
| 导热固体1 | 0～0.8 | 0～0.24 | 0～0.003 |
| 导热固体2 | 0.12～0.128 | 0～0.24 | 0.003～0.012 |
| 导热固体3 | 0.24～0.248 | 0～0.24 | 0.003～0.012 |
| 导热固体4 | 0.36～0.368 | 0～0.24 | 0.003～0.012 |
| 导热固体5 | 0.48～0.488 | 0～0.24 | 0.003～0.012 |
| 导热固体6 | 0.6～0.608 | 0～0.24 | 0.003～0.012 |
| 导热固体7 | 0.72～0.728 | 0～0.24 | 0.003～0.012 |

| 边界名称 | 作用 | 基准条件 |
| --- | --- | --- |
| `inlet` | 入口 | U = (1.2 0 0) m/s |
| `outlet` | 出口 | 压力参考值 101325 Pa |

## 物理模型与求解方法

不可压缩流动满足质量守恒与动量守恒：

\[
\nabla\cdot\mathbf U=0,\qquad
\rho\left(\frac{\partial\mathbf U}{\partial t}+\mathbf U\cdot\nabla\mathbf U\right)
=-\nabla p+\nabla\cdot\boldsymbol\tau+\mathbf f.
\]

其中，\(\mathbf U\) 为速度，\(p\) 为物理压力，\(\boldsymbol\tau\) 为黏性应力，\(\mathbf f\) 为单位体积外力。连续性方程约束各截面的流量收支；动量方程描述压力、黏性作用和外力如何改变速度。

流体中的热量由流动输运并通过导热扩散，固体内部则由导热和热源共同决定温度。稳态形式为

\[
\rho_f c_{p,f}\mathbf U\cdot\nabla T_f=\nabla\cdot(k_f\nabla T_f),\qquad
\nabla\cdot(k_s\nabla T_s)+q_v=0.
\]

界面上温度连续，两侧法向热流大小相等。固体发热功率按选定单元体积分配，外表面采用绝热条件，热量经流固界面进入冷却流体。模型使用规定入口条件研究强制对流，重力项设为零。

本例使用 `chtMultiRegionSimpleFoam`，通过稳态迭代求解，日志中的 `Time` 表示迭代序号。湍流采用 `kOmegaSST`，同时求解湍动能与比耗散率；近壁分辨率通过 y⁺ 和网格比较评价。

## 配置文件与网格建立

[下载完整算例与配置代码](/downloads/engineering/solar-air-ribbed-absorber.zip)。解压目录中已提供 `0.orig/`、`constant/`、`system/` 和几何数据，`build_case.py` 根据 `design.json` 重建相同输入；生成程序只使用 Python 标准库。

| 文件或目录 | 操作与用途 |
| --- | --- |
| `design.json` | 修改部件坐标、流体物性、速度或热功率；随后重新生成字典 |
| `geometry/model.obj` | 查看几何分区；曲线叶道以 blockMesh 圆弧为准 |
| `system/blockMeshDict` | 多块六面体网格的顶点、单元数与边界面 |
| `0.orig/` | 初始场和边界条件；建网格时复制到 `0/` |
| `constant/` | 物性、物理模型与区域设置 |
| `system/fvSchemes`、`system/fvSolution` | 离散格式、线性求解和耦合控制 |
| `Allmesh`、`Allsolve` | 分别完成网格准备与求解、结果提取 |

多块网格在肋片边缘、支路开口和分区界面处共享坐标平面，使边界与几何位置一致。默认加密级别为 2，薄通道与窄缝另外保留最低单元层数。共轭传热案例先建立包含流固单元区的整体网格，再按 `fluid`、`solid` 拆分；配对界面用于交换热量，`topoSet` 选出固体发热区。

## 关键配置与解读

以下条目取自本页下载包的同名文件，几何和边界名称与上表对应。

### `constant/fluid/thermophysicalProperties`

```foam
thermoType { type heRhoThermo; mixture pureMixture; transport const; thermo hConst; equationOfState rhoConst; specie specie; energy sensibleEnthalpy; }
mixture { specie { molWeight 28.97; } equationOfState { rho 1.184; } thermodynamics { Cp 1006; Hf 0; } transport { mu 1.84704e-05; Pr 0.7065103574144487; } }
```

`rhoConst` 使用给定密度，`Cp` 控制单位质量流体升温所需的热量，`mu` 为动力黏度。`Pr` 由黏度、比热和导热系数计算，使传热模型采用与物性表一致的导热能力。

### `constant/solid/fvOptions`

```foam
heatInput
{ type scalarSemiImplicitSource; active true; selectionMode cellSet; cellSet heatingCells; volumeMode absolute; injectionRateSuSp { h (180 0); } }
```

`heatingCells` 由固体区域的 `topoSetDict` 选出；`volumeMode absolute` 把 `h` 条目中的 180 作为该选区的总热功率，单位 W。改变选区体积时，总功率保持不变，体积发热率随之变化。

### `0.orig/fluid/T`

```foam
boundaryField
{
    walls { type zeroGradient; }
    inlet { type fixedValue; value uniform 298.15; }
    outlet { type inletOutlet; inletValue uniform 298.15; value uniform 298.15; }
    fluid_to_solid { type compressible::turbulentTemperatureRadCoupledMixed; Tnbr T; qr none; qrNbr none; kappaMethod fluidThermo; value uniform 298.15; }
}
```

入口温度规定冷却介质的供给状态。`fluid_to_solid` 与固体侧界面配对，耦合边界通过两侧导热能力求取界面温度和热流。出口回流时采用入口温度作为回流初值。


## 运行与计算检查

在 Linux 中加载 OpenCFD OpenFOAM v2512，然后进入解压目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
cd solar-air-ribbed-absorber
bash Allmesh
bash Allsolve
```

安装位置不同，只需调整第一行环境路径。`Allmesh` 生成输入和网格，复制初始场并检查网格质量；`Allsolve` 调用 `chtMultiRegionSimpleFoam`，运行后将监测记录整理到 `analysis/`。各阶段的详细信息分别写入 `log.blockMesh`、`log.checkMesh` 和 `log.chtMultiRegionSimpleFoam`，遇到错误时脚本会停止并显示对应日志末尾。

修改工况时，先在新解压目录中编辑 `design.json`，再执行 `Allmesh`。网格生成以后，边界调整应写入 `0/`；如果重新生成网格，程序会再次使用参数文件和 `0.orig/`。保留各工况独立目录，便于核对尺寸、物性与结果。

先检查残差是否持续下降，再查看流量、压差和温度或转矩是否趋于稳定。不同方程的残差尺度不同，采用工程监测量的稳定性判断迭代是否足够。

## 结果提取与工程分析

沿吸热板中心线绘制壁温，观察各肋上游、顶部和下游的变化。提高风量通常使出口温升减小，因此应同时计算空气质量流量与比焓增的乘积，不能单独用温升评价集热量。再用体积流量与压降的乘积衡量送风功耗。

在 ParaView 中打开 `case.foam`，选择最后一个已写出时刻。用 **Slice** 建立上述截面，用 **Plot Over Line** 提取沿线变化；流量计算使用速度的截面法向分量，配合 **Integrate Variables** 积分。输出表格时使用 **Save Data**，工况比较保持截面位置、色标和平均方式相同。

`analysis/monitor-history.csv` 保存监测对象的时间或迭代历史，`analysis/metrics.json` 整理边界流量、压力和温度等可用指标。内部通道分流、局部方差或单个壁面载荷按本节给出的选区继续提取。边界流量采用外法向为正，入口一般为负，出口一般为正。

热阻可写为

\[
R_\theta=\frac{T_{s,\max}-T_{\mathrm{in}}}{P},\qquad
\dot Q_f=\dot m c_p(T_{\mathrm{out}}-T_{\mathrm{in}}).
\]

\(R_\theta\) 将热点温升与总热功率联系起来；\(\dot Q_f\) 是流体携走的显热，采用流量加权温度计算。绝热外边界下，收敛后的流体携热应与固体热源相平衡。共轭求解器的 `phi` 为质量通量，随包分析程序按密度换算体积流量。

## 参数比较与网格收敛

固定 180 W 等效吸收功率，比较 0.6、1.2、1.8 m/s；将肋高从 9 mm 改为 5 mm，比较温升与流动阻力。

先完成基准工况，再每次改变一个设计因素。记录几何尺寸、入口总流量、出口焓增、吸热板最高温度及压降，将性能变化与流场结构对应。对选定方案再做网格比较：

```bash
MESH_REFINE=4 bash Allmesh
bash Allsolve
```

在新的解压目录执行上述命令，各方向相对默认级别增加一倍单元数。比较时使用相同物性、边界条件及结果提取位置，检查主要工程量随网格变化的幅度。自由液面案例还需减小 `maxDeltaT`，比较水位幅值和相位；示踪混合案例需同时检查浓度界面的数值扩散。

> **熊猫说：** 固体热源的总功率、入口焓流和出口焓流构成同一个能量收支。先核对热量，再解释热点的位置。

## 配套代码与资料

- [下载几何、完整配置、运行及分析代码](/downloads/engineering/solar-air-ribbed-absorber.zip)。`VALIDATION.json` 和 `validation/` 保存 v2512 网格检查与短程启动记录，`files.sha256` 可用于核对文件完整性。
- [OpenFOAM 用户指南](https://www.openfoam.com/documentation/user-guide)：算例结构、网格与求解流程。
- [OpenFOAM v2512 源码文档](https://api.openfoam.com/2512/)：字段、边界和模型实现。

[返回实际工程应用](/topics/engineering/)
