# 太阳能空气集热器的肋化吸热板

集热风道强化换热收益与送风耗能。几何、尺寸和工况由 FoamLab 为本设计问题独立构造，全部参数使用 SI 单位，见 design.json。

## 运行

需要 Linux、Python 3 标准库及 OpenCFD OpenFOAM v2512。先加载安装环境：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
bash Allmesh
bash Allsolve
```

安装位置不同时，修改第一行路径。Allmesh 生成几何与网格并执行完整网格检查；Allsolve 运行 chtMultiRegionSimpleFoam，再提取监测量到 analysis/metrics.json 和 analysis/monitor-history.csv。用 ParaView 打开 case.foam 查看完整场。

## 工况与网格比较

固定 180 W 等效吸收功率，比较 0.6、1.2、1.8 m/s；将肋高从 9 mm 改为 5 mm，比较温升与流动阻力。

在新解压目录编辑 design.json，再运行 Allmesh。初始场、物性和求解设置都已随包提供。生成后直接修改 0/ 中的边界，或在运行前通过 design.json 修改并重新生成；Allmesh 会重建由参数控制的字典。网格加密可在新目录执行 `MESH_REFINE=4 bash Allmesh`，各方向单元数均加倍。

评价量：出口焓增、吸热板最高温度及压降。

VALIDATION.json 与 validation/ 保存本配置的实际网格检查、启动运行及输出提取记录。完整运行采用 system/controlDict 给出的计算范围；收敛判断同时使用质量收支、监测曲线和网格比较。

完整指南：https://foamlabshark.github.io/topics/engineering/solar-air-ribbed-absorber/

本站生成程序与配置按 GPL-3.0-or-later 提供，许可证见 COPYING。参考资料及几何来源说明见 SOURCE.json。
