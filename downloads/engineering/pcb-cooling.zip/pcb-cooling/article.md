求解发热电路板周围的低速通风与浮力流动，比较不同板件导热模型对温度分布的影响。

## 工程场景与计算目标

电子机柜内多块电路板共用冷却气流，上游板件释放的热量会提高下游来流温度。低风速条件下，受热空气上浮又会改变通道内的流量分配。器件布置、板内导热和空气侧换热因而共同决定热点位置。

算例在通风通道中设置发热板，采用一维和三维热挡板描述固体传热，并耦合空气流动、能量输运及浮力。分析内容包括板面温度分布、出口温升和相邻热源间的热影响，以区分板厚方向热阻与板内热扩散的作用。

## 几何、尺寸与基准工况

![电路板多热源的浮力散热：配套模型与基准输入](/assets/engineering/pcb-cooling-geometry.webp)

通道长 1 m、高 0.5 m、展向厚 0.1 m，展向采用单层网格和 `empty` 边界。板件位置由 `baffle1D.stl.gz`、`baffle3D.stl.gz` 给出，一维热挡板厚度为 5 mm。几何和位置参数取自 `circuitBoardCooling`。

模型与配置来源：[OpenFOAM v2512 · heatTransfer/buoyantSimpleFoam/circuitBoardCooling](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/buoyantSimpleFoam/circuitBoardCooling)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 入口空气 | 0.1 m/s，300 K | `0.orig/U` 和 `0.orig/T` 的 `inlet` |
| 一维板厚 | 0.005 m | `0.orig/include/1DBaffle/1DTemperatureMasterBafflePatches` |
| 一维板热流 | 100 W/m² | 同一文件中的 `qs` |
| 通道网格 | 50 × 40 × 1 | `system/blockMeshDict` |

## 求解方法与物理模型

空气采用理想气体关系 $\rho=p/(RT)$，温度变化引起的密度差通过重力项驱动浮力流动。流动改变板面换热，板面加热又反过来影响流量分配。

板厚方向单位面积导热热阻为 $R^{\prime\prime}=\delta/k_s$。在一维导热近似下，热流密度 $q^{\prime\prime}$ 对应的温差为 $\Delta T=q^{\prime\prime}R^{\prime\prime}$。三维热挡板还计算板内横向热扩散，可据此分析热量从局部发热位置向周围区域传播的程度。

本例使用 `buoyantSimpleFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/pcb-cooling.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip pcb-cooling.zip
cd pcb-cooling
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `createBaffles -overwrite` | 把指定内部面转成成对边界，形成挡板或叶片表面。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 通道入口速度

文件：`0.orig/U`。本段设置通道入口速度。

```foam
inlet
{
    type            fixedValue;
    value           uniform (0.1 0 0);
}
```

入口施加固定速度向量，壁面采用无滑移条件。0.1 m/s 的低速来流允许浮力明显参与流量分配；调整风速后，应按相应流动状态检查入口湍流参数。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/buoyantSimpleFoam/circuitBoardCooling/0.orig/U)。

### 2. 一维板件的热阻与热源

文件：`0.orig/include/1DBaffle/1DTemperatureMasterBafflePatches`。本段设置一维板件的热阻与热源。

```foam
T
{
    type   compressible::thermalBaffle1D<hConstSolidThermoPhysics>;

    thickness       uniform 0.005;  // thickness [m]
    qs              uniform 100;    // heat flux [W/m2]

    # include "1DbaffleSolidThermo"

    value               uniform 300;
}
```

`thickness` 与固体导热系数共同确定厚度热阻，`qs` 为板面热源。固体物性由相邻 include 文件引入，热边界与物性文件共同组成完整的板件传热设置。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/buoyantSimpleFoam/circuitBoardCooling/0.orig/include/1DBaffle/1DTemperatureMasterBafflePatches)。

### 3. 板面边界生成

文件：`system/createBafflesDict`。本段设置板面边界生成。

```foam
baffles
{
    baffleFacesThermoBaffle1D
    {
        //- Use predefined faceZone to select faces and orientation.
        type        searchableSurface;
        surface     triSurfaceMesh;
        name        baffle1D.stl;

        patchPairs
        {
            type            wall;
            patchFields
            {
                #include "<case>/0/include/wallBafflePatches"
                #include "<case>/0/include/1DBaffle/1DTemperatureMasterBafflePatches"
            }
        }
    }

    #include "<case>/0/include/baffle3DSetup"

    baffleFacesThermoBaffle3D
    {
        type        searchableSurface;
        surface     triSurfaceMesh;
        name        baffle3D.stl;

        patchPairs
        {
            type            mappedWall;
            sampleMode      nearestPatchFace;
            // Put master and slave patch in same group (default on)
            // Otherwise makeup group names xxx_master and xxx_slave
            sameGroup       off;
            patchFields
            {
                #include "<case>/0/include/wallBafflePatches"
                #include "<case>/0/include/3DBaffle/3DTemperatureMasterBafflePatches"
            }
        }
    }
}
```

`createBaffles` 根据曲面选区建立成对板面，并赋予速度和温度边界。该操作将内部板件转化为实际网格边界，完成后再由相应热模型计算板内导热。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/buoyantSimpleFoam/circuitBoardCooling/system/createBafflesDict)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.buoyantSimpleFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `buoyantSimpleFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。本求解器采用稳态迭代，日志中的 Time 用作迭代序号。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `0` |
| `endTime` | `2500` |
| `deltaT` | `1` |
| `writeControl` | `timeStep` |
| `writeInterval` | `500` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选流体与板面，点击 **Apply**。先选择最后一个已写出的时刻，以 `T` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

提取两类板面沿长度方向的温度曲线，并结合空气温度和速度分布判断热点成因。板后回流对应空气侧换热不足，板内明显温度梯度则反映固体导热限制。出口温度采用质量流量加权平均，用空气带出的热量与板件总发热量核对能量平衡。

第一组比较将入口速度由 0.1 m/s 提高至 0.2 m/s，保持板厚与热流不变；第二组保持风速不变，改变板厚。分别比较最高温度和沿板温差，可区分通风能力与固体热阻对散热的影响。

> **熊猫说：** 展向 `empty` 边界将流动限定为二维。研究板侧绕流或离散芯片布置时，需要建立三维网格，并相应修改前后边界类型。

## 文件与来源

- [完整算例包](/downloads/engineering/pcb-cooling.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/buoyantSimpleFoam/circuitBoardCooling)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
