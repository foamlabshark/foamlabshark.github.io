建立制动盘自身转动驱动的冷却空气输运模型，分析转速与通风间隙对自泵送流量、径向压力分布与壁面力矩的影响。

## 工程场景与计算目标

通风制动盘在旋转时可以驱动空气由内缘流向外缘，为制动热量提供携带通道。径向叶道的几何尺寸和转速决定自泵送能力，外部风速为零时也可能形成通流。评价散热设计前，需要先明确这种转动驱动的空气流量。

本例采用内半径 45 mm、外半径 150 mm 的单个扇形叶道，上下盘面与两侧径向壁面共同转动。使用旋转参考系求解相对稳定流动，入口和出口给定相同压力。计算比较转速与叶道高度，提取自泵送流量、径向压力和壁面力矩。

## 几何、尺寸与基准工况

叶道采用内半径 0.045 m、外半径 0.15 m、夹角 0.4 rad 和高度 0.01 m。`blockMeshDict` 的圆弧边描述内外半径，叶道两侧为径向旋转壁面。

![通风制动盘径向叶道的旋转泵送的结构分区与流动方向](/assets/engineering/brake-rotor-radial-passage-geometry.webp)

| 参数 | 基准值 | 含义 |
| --- | --- | --- |
| 流体密度 | 1.184 kg/m³ | 惯性、压差换算和质量流量 |
| 运动黏度 | 1.56e-05 m²/s | 分子黏性输运 |
| 基础网格 | 27,648 单元 | 默认 MESH_REFINE=2 的设计网格 |
| 角速度 | 100 rad/s | MRFProperties 中的 omega |

| 边界名称 | 作用 | 基准条件 |
| --- | --- | --- |
| `inlet` | 出口 | 压力参考值 0 |
| `outlet` | 出口 | 压力参考值 0 |

## 物理模型与求解方法

不可压缩流动满足质量守恒与动量守恒：

\[
\nabla\cdot\mathbf U=0,\qquad
\rho\left(\frac{\partial\mathbf U}{\partial t}+\mathbf U\cdot\nabla\mathbf U\right)
=-\nabla p+\nabla\cdot\boldsymbol\tau+\mathbf f.
\]

其中，\(\mathbf U\) 为速度，\(p\) 为物理压力，\(\boldsymbol\tau\) 为黏性应力，\(\mathbf f\) 为单位体积外力。连续性方程约束各截面的流量收支；动量方程描述压力、黏性作用和外力如何改变速度。

旋转区域采用 MRF 方法。相对速度与绝对速度满足

\[
\mathbf U_{\mathrm{rel}}=\mathbf U-\boldsymbol\Omega\times(\mathbf x-\mathbf x_0).
\]

在旋转坐标描述中，科里奥利作用与离心作用分别对应 \(2\boldsymbol\Omega\times\mathbf U_{\mathrm{rel}}\) 和 \(\boldsymbol\Omega\times[\boldsymbol\Omega\times(\mathbf x-\mathbf x_0)]\)。MRF 在固定网格中计算给定相对位置的平均流动，旋转区域与静止壁面由单元区和边界名称区分。

本例使用 `simpleFoam`，通过稳态迭代求解，日志中的 `Time` 表示迭代序号。湍流采用 `kOmegaSST`，同时求解湍动能与比耗散率；近壁分辨率通过 y⁺ 和网格比较评价。

## 配置文件与网格建立

[下载完整算例与配置代码](/downloads/engineering/brake-rotor-radial-passage.zip)。解压目录中已提供 `0.orig/`、`constant/`、`system/` 和几何数据，`build_case.py` 根据 `design.json` 重建相同输入；生成程序只使用 Python 标准库。

| 文件或目录 | 操作与用途 |
| --- | --- |
| `design.json` | 修改部件坐标、流体物性、速度或热功率；随后重新生成字典 |
| `geometry/model.obj` | 查看几何分区；曲线叶道以 blockMesh 圆弧为准 |
| `system/blockMeshDict` | 多块六面体网格的顶点、单元数与边界面 |
| `0.orig/` | 初始场和边界条件；建网格时复制到 `0/` |
| `constant/` | 物性、物理模型与区域设置 |
| `system/fvSchemes`、`system/fvSolution` | 离散格式、线性求解和耦合控制 |
| `Allmesh`、`Allsolve` | 分别完成网格准备与求解、结果提取 |

多块网格在肋片边缘、支路开口和分区界面处共享坐标平面，使边界与几何位置一致。默认加密级别为 2，薄通道与窄缝另外保留最低单元层数。

## 关键配置与解读

以下条目取自本页下载包的同名文件，几何和边界名称与上表对应。

### `0.orig/U`

```foam
boundaryField
{
    inlet { type pressureInletOutletVelocity; value uniform (0 0 0); }
    outlet { type pressureInletOutletVelocity; value uniform (0 0 0); }
    rotor { type noSlip; }
}
```

固定速度入口与已知截面积共同确定流量。出口采用 `pressureInletOutletVelocity`，使速度与边界通量协调；实体表面为无滑移壁面。MRF 中的旋转壁面速度由旋转区处理。

### `0.orig/p`

```foam
boundaryField
{
    inlet { type fixedValue; value uniform 0; }
    outlet { type fixedValue; value uniform 0; }
    rotor { type zeroGradient; }
}
```

`simpleFoam` 中该字段是运动学压力，量纲为 m²/s²。出口参考值为 0，物理压差应乘以流体密度；速度入口使用零法向梯度，让压力由流量约束形成。

### `constant/MRFProperties`

```foam
rotatingFrame
{ active true; cellZone rotating; origin (0 0 0); axis (0 0 1); omega 100; nonRotatingPatches (walls lid inlet outlet); }
```

`cellZone` 指定旋转单元区，`origin` 和 `axis` 共同定义转轴，`omega` 的单位为 rad/s。`nonRotatingPatches` 列出需要保持静止的边界；旋转叶片表面不放入该列表。


## 运行与计算检查

在 Linux 中加载 OpenCFD OpenFOAM v2512，然后进入解压目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
cd brake-rotor-radial-passage
bash Allmesh
bash Allsolve
```

安装位置不同，只需调整第一行环境路径。`Allmesh` 生成输入和网格，复制初始场并检查网格质量；`Allsolve` 调用 `simpleFoam`，运行后将监测记录整理到 `analysis/`。各阶段的详细信息分别写入 `log.blockMesh`、`log.checkMesh` 和 `log.simpleFoam`，遇到错误时脚本会停止并显示对应日志末尾。

修改工况时，先在新解压目录中编辑 `design.json`，再执行 `Allmesh`。网格生成以后，边界调整应写入 `0/`；如果重新生成网格，程序会再次使用参数文件和 `0.orig/`。保留各工况独立目录，便于核对尺寸、物性与结果。

先检查残差是否持续下降，再查看流量、压差和温度或转矩是否趋于稳定。不同方程的残差尺度不同，采用工程监测量的稳定性判断迭代是否足够。

## 结果提取与工程分析

入口和出口流量应大小相等、方向相反；两端压力相同时的通流由旋转壁面提供能量。沿叶道径向绘制压力与速度，将叶道流量按实际叶道数量换算为整盘通风量。基准不求解制动发热，分析温度时需进一步加入盘体导热与热源。

在 ParaView 中打开 `case.foam`，选择最后一个已写出时刻。用 **Slice** 建立上述截面，用 **Plot Over Line** 提取沿线变化；流量计算使用速度的截面法向分量，配合 **Integrate Variables** 积分。输出表格时使用 **Save Data**，工况比较保持截面位置、色标和平均方式相同。

`analysis/monitor-history.csv` 保存监测对象的时间或迭代历史，`analysis/metrics.json` 整理边界流量、压力和温度等可用指标。内部通道分流、局部方差或单个壁面载荷按本节给出的选区继续提取。边界流量采用外法向为正，入口一般为负，出口一般为正。

## 参数比较与网格收敛

入口和出口压力相同，比较 50、100、150 rad/s；再将叶道高度设为 8、10、12 mm，比较自泵送流量。

先完成基准工况，再每次改变一个设计因素。记录几何尺寸、入口总流量、自泵送流量、径向压力分布与壁面力矩，将性能变化与流场结构对应。对选定方案再做网格比较：

```bash
MESH_REFINE=4 bash Allmesh
bash Allsolve
```

在新的解压目录执行上述命令，各方向相对默认级别增加一倍单元数。比较时使用相同物性、边界条件及结果提取位置，检查主要工程量随网格变化的幅度。自由液面案例还需减小 `maxDeltaT`，比较水位幅值和相位；示踪混合案例需同时检查浓度界面的数值扩散。

> **熊猫说：** 角速度使用 rad/s，旋转区、转轴原点和旋转壁面要共同对应实际运动。

## 配套代码与资料

- [下载几何、完整配置、运行及分析代码](/downloads/engineering/brake-rotor-radial-passage.zip)。`VALIDATION.json` 和 `validation/` 保存 v2512 网格检查与短程启动记录，`files.sha256` 可用于核对文件完整性。
- [OpenFOAM 用户指南](https://www.openfoam.com/documentation/user-guide)：算例结构、网格与求解流程。
- [OpenFOAM v2512 源码文档](https://api.openfoam.com/2512/)：字段、边界和模型实现。

[返回实际工程应用](/topics/engineering/)
