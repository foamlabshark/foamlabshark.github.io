# Goldschmidt 流化床的颗粒膨胀

重建 Goldschmidt 颗粒床的通气膨胀过程，分析气固曳力、床层高度和压力降。

完整指南：https://foamlabshark.github.io/topics/engineering/fluidised-bed/

OpenCFD OpenFOAM v2512，Linux。加载安装环境后，按顺序执行：

```bash
bash Allmesh
bash Allsolve
```

Allmesh 包含全部网格与初始化步骤，并在网格检查失败时停止；各命令输出保存在 log.*。Allsolve 使用下载包原有完整时间控制。VALIDATION.json 记录独立进行的网格检查与短步运行；结果分析和工况比较见指南。

本例的起始场位于 `0/`，修改初始场时直接编辑该目录。

模型或网格改变后，在新目录重新解压运行。ParaView 打开 case.foam 查看各区域场量。

上游：https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/lagrangian/MPPICFoam/Goldschmidt

原始 OpenFOAM 文件遵循随附 COPYING；本站改动见 SOURCE.json。
