模拟 Goldschmidt 准二维颗粒床的通气膨胀，计算床层高度、压降和颗粒混合。

## 工程场景与计算目标

向上的气流通过颗粒床时，曳力逐渐抵消颗粒有效重量。达到流化条件后，床层膨胀并出现随时间变化的稀疏区和致密区，改变颗粒混合、停留时间及相间交换。床高与压降因此是理解流态化过程的两个基本量。

算例按给定位置装填玻璃颗粒，以 `MPPICFoam` 求解气流和颗粒团运动，颗粒应力模型限制高浓度区域的过度堆积。在相同装料条件下改变入口表观气速，比较床层膨胀、波动与压力支撑。

## 几何、尺寸与基准工况

![Goldschmidt 流化床的颗粒膨胀：配套模型与基准输入](/assets/engineering/fluidised-bed-geometry.webp)

床体宽 150 mm、高 450 mm、厚 15 mm，厚度方向为单层单元和对称边界。颗粒直径 2.5 mm、密度 2526 kg/m³。`kinematicCloudPositions` 给出初始装料位置，手动注入模型在 t = 0 读取该文件。

模型与配置来源：[OpenFOAM v2512 · lagrangian/MPPICFoam/Goldschmidt](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/lagrangian/MPPICFoam/Goldschmidt)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 入口表观速度 | 1.875 m/s | `0/U.air/bottom/inletVelocity` |
| 颗粒直径、密度 | 2.5 mm、2526 kg/m³ | `constant/kinematicCloudProperties` |
| 初始速度 | 颗粒与域内气体均为零 | 初始场及 `manualInjection/U0` |
| 曳力模型 | PlessisMasliyahDrag | 颗粒受力配置 |

## 求解方法与物理模型

气固体积分数满足 $\alpha_g+\alpha_s=1$。床层达到近似悬浮平衡时，压降可与单位截面颗粒有效重量比较：$\Delta p\approx(\rho_s-\rho_g)(1-\varepsilon)gH$。入口边界将表观速度 $U_s$ 转为孔隙内速度 $U_g=U_s/\alpha_g$，因此床层固相比例变化会影响局部气速。

本例使用 `MPPICFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/fluidised-bed.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip fluidised-bed.zip
cd fluidised-bed
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |

本例的起始场位于 `0/`，修改初始场时直接编辑该目录。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 表观气速边界

文件：`0/U.air`。本段设置表观气速边界。

```foam
bottom
{
    type            interstitialInletVelocity;
    inletVelocity   uniform (0 0 1.875);
    value           uniform (0 0 1.875);
    phi             phi.air;
    alpha           alpha.air;
}
```

`interstitialInletVelocity` 将 1.875 m/s 的表观速度除以局部气相体积分数，得到孔隙内速度，从而维持所需气体流量。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/MPPICFoam/Goldschmidt/0/U.air)。

### 2. 初始颗粒装填

文件：`constant/kinematicCloudProperties`。本段设置初始颗粒装填。

```foam
model1
{
    type            manualInjection;
    massTotal       0;
    parcelBasisType fixed;
    nParticle       1;
    SOI             0;
    positionsFile   "kinematicCloudPositions";
    U0              (0 0 0);
    sizeDistribution
    {
        type        fixedValue;
        fixedValueDistribution
        {
            value   0.0025;
        }
    }
}
```

初始粒子位置、粒径、材料密度与 `nParticle 1` 共同确定装料质量。`parcelBasisType fixed` 固定粒子团权重，此时 `massTotal 0` 不承担装料量定义。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/MPPICFoam/Goldschmidt/constant/kinematicCloudProperties)。

### 3. 高浓度颗粒应力

文件：`constant/kinematicCloudProperties`。本段设置高浓度颗粒应力。

```foam
packingModel explicit;

explicitCoeffs
{
    particleStressModel
    {
        type HarrisCrighton;
        alphaPacked 0.65;
        pSolid 10.0;
        beta 2.0;
        eps 1.0e-7;
    }
    correctionLimitingMethod
    {
        type absolute;
        e 0.9;
    }
}

implicitCoeffs
```

颗粒应力随固相浓度上升而加强，抵抗局部过度压缩。`alphaPacked` 规定堆积相关尺度，会影响致密区和床层膨胀。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/MPPICFoam/Goldschmidt/constant/kinematicCloudProperties)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.MPPICFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `MPPICFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `0` |
| `endTime` | `5` |
| `deltaT` | `2e-4` |
| `writeControl` | `runTime` |
| `writeInterval` | `0.01` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选气相内部与颗粒，点击 **Apply**。先选择最后一个已写出的时刻，以 `alpha.air` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

由气相体积分数得到固相分布，结合粒子位置观察床面和内部稀疏区的演化。以统一阈值识别床面，统计平均床高及波动幅度，并输出床底与床上方压差。

在相同装料下逐级调整入口气速，覆盖多个床层波动周期后比较平均结果。网格、计算粒子数量和颗粒应力参数分别变化，用于分析空间分辨率、统计分辨率和闭合模型的影响。

> **熊猫说：** 入口设置为表观气速，即体积流量除以空床截面积。与实验比较时采用同一速度定义。

## 文件与来源

- [完整算例包](/downloads/engineering/fluidised-bed.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/lagrangian/MPPICFoam/Goldschmidt)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
