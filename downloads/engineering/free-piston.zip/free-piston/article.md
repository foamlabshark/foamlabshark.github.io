按照活塞位移表求解冷态气缸压缩，分析容积变化、气体升温与压缩功。

## 工程场景与计算目标

自由活塞装置的位移规律可由直线电机、气体弹簧或外部机构决定。活塞运动改变气缸容积并对气体做功，气体压力、温度和缸内速度随之变化。壁面换热进一步影响实际压缩路径。

算例采用无燃烧的冷态压缩工况，以时间—位置表驱动活塞，由分层动网格跟随气缸容积变化。计算先建立气体质量、压力和温度随时间的关系，再通过 p–V 曲线评价压缩功及压缩速率的影响。

## 几何、尺寸与基准工况

![自由活塞发动机的压缩与膨胀：配套模型与基准输入](/assets/engineering/free-piston-geometry.webp)

气缸半径为 50 mm，初始气柱高度为 130 mm。轴对称楔形网格在径向、轴向分别划分 50、130 个单元。`pistonPositionTime` 规定气柱高度由 t = 0 时的 0.13 m 降至 t = 0.020 s 时的 0.013 m；几何与运动数据取自 `freePiston`。

模型与配置来源：[OpenFOAM v2512 · combustion/coldEngineFoam/freePiston](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/combustion/coldEngineFoam/freePiston)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 初始气体 | 350 K，100000 Pa | `0/include/caseSettings` |
| 缸径 | 0.1 m | `system/blockMeshDict` 的径向坐标 |
| 位移终点 | 0.020 s、0.013 m | `constant/engineGeometry` |
| 网格类型 | layered | 活塞移动时调整轴向网格层 |

## 求解方法与物理模型

封闭气缸满足质量守恒 $m=\rho V=\mathrm{const}$。气体内能变化由壁面换热和活塞功共同决定：$d(mu)/dt=\dot Q-p\,dV/dt$。压缩时 $dV/dt<0$，活塞向气体输入能量。

理想绝热准静态过程满足 $pV^\gamma=\mathrm{const}$，可据此比较压力变化趋势。数值计算进一步求解缸内速度和壁面传热，以反映有限压缩速率下的流动与热交换。

本例使用 `coldEngineFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/free-piston.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip free-piston.zip
cd free-piston
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |

本例的起始场位于 `0/`，修改初始场时直接编辑该目录。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 活塞运动规律

文件：`constant/engineGeometry`。本段设置活塞运动规律。

```foam
engineMesh      layered;

engineType  freePiston;

pistonPositionTime  table
(
    (0 0.13)
    (0.020 0.013)
);
```

`engineType freePiston` 从时间—位置表插值得到活塞运动。表中位置对应气柱高度；最小位置保持为正值，使压缩终点仍具有有限气体体积。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/combustion/coldEngineFoam/freePiston/constant/engineGeometry)。

### 2. 气体初始状态

文件：`0/include/caseSettings`。本段设置气体初始状态。

```foam
internalField
{
    U               (0 0 0);
    epsilon         5.70e-5;
    k               2.40e-5;
    T               350;
    p               1e5;
}
```

初始压力 100000 Pa 和温度 350 K 与气缸容积共同确定气体质量。初始速度为零，随后由活塞运动建立缸内流动。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/combustion/coldEngineFoam/freePiston/0/include/caseSettings)。

### 3. 移动活塞边界

文件：`0/U`。本段设置移动活塞边界。

```foam
piston
{
    $/piston/U;
}
```

活塞速度边界继承公共边界设置，并与网格运动保持一致。这样，移动壁面对气体的压缩作用通过边界速度和控制体积变化同时进入求解。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/combustion/coldEngineFoam/freePiston/0/U)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.coldEngineFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `coldEngineFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `0` |
| `endTime` | `0.03` |
| `deltaT` | `5.0e-7` |
| `writeControl` | `adjustable` |
| `writeInterval` | `0.001` |
| `adjustTimeStep` | `yes` |
| `maxCo` | `0.25` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选气缸内部，点击 **Apply**。先选择最后一个已写出的时刻，以 `p` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

输出体积平均压力、温度和总质量，并由各时刻网格体积得到 $V(t)$。以体积为横坐标绘制 p–V 曲线，通过 $W=-\int p\,dV$ 计算压缩功。总质量变化可用于检查动网格条件下的守恒性。

保持终点位置不变，将压缩时间延长一倍，比较峰值压力、峰值温度和压缩功。随后减小时间步检查这些量的稳定性。接近最小间隙时，轴向单元高度下降，应结合网格质量与局部 Courant 数判断时间分辨率。

> **熊猫说：** 活塞位移表的两列分别为时间和位置，单位是 s、m。终点位置决定最小气缸容积，时间间隔决定压缩速率，两者对压力历程的影响应分别分析。

## 文件与来源

- [完整算例包](/downloads/engineering/free-piston.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/combustion/coldEngineFoam/freePiston)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
