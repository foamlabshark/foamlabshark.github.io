# 自由活塞发动机的压缩与膨胀

用给定活塞位移驱动缸内气体压缩，分析移动网格、压力升高和压缩功之间的关系。

完整指南：https://foamlabshark.github.io/topics/engineering/free-piston/

OpenCFD OpenFOAM v2512，Linux。加载安装环境后，按顺序执行：

```bash
bash Allmesh
bash Allsolve
```

Allmesh 包含全部网格与初始化步骤，并在网格检查失败时停止；各命令输出保存在 log.*。Allsolve 使用下载包原有完整时间控制。VALIDATION.json 记录独立进行的网格检查与短步运行；结果分析和工况比较见指南。

本例的起始场位于 `0/`，修改初始场时直接编辑该目录。

模型或网格改变后，在新目录重新解压运行。ParaView 打开 case.foam 查看各区域场量。

上游：https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/combustion/coldEngineFoam/freePiston

原始 OpenFOAM 文件遵循随附 COPYING；本站改动见 SOURCE.json。
