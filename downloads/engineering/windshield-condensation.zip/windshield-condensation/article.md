求解湿空气输运与风挡导热，跟踪低温玻璃结露及干燥暖风除雾的过程。

## 工程场景与计算目标

湿空气接触低温风挡后，邻近表面的水蒸气可能达到饱和并凝结。除雾需要改变玻璃温度和附近水蒸气含量：加热提高饱和蒸气压，干燥送风降低水蒸气分压，两者共同决定水分迁移方向。流量分布则影响这些作用能够覆盖的风挡区域。

算例分别计算舱内空气与玻璃。`H2O` 场描述水蒸气质量分数，湿度耦合温度边界计算凝结、蒸发及潜热交换。前 60 s 建立结露状态，随后引入较热的干空气，观察表面水分消退和玻璃升温。

## 几何、尺寸与基准工况

![汽车风挡玻璃的结露与除雾：配套模型与基准输入](/assets/engineering/windshield-condensation-geometry.webp)

模型使用 `windshieldCondensation` 的风挡和送风通道，展向宽 0.7 m。玻璃区域为 `windshield`，密度 2400 kg/m³、比热 500 J/(kg·K)、导热系数 0.9 W/(m·K)。外侧通过对流换热边界与 260 K 环境交换热量。

模型与配置来源：[OpenFOAM v2512 · heatTransfer/chtMultiRegionFoam/windshieldCondensation](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionFoam/windshieldCondensation)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 舱内初始状态 | 300 K，H2O 质量分数 0.01 | `0.orig/cabin/T`、`H2O` |
| 玻璃与外界初温 | 260 K | `0.orig/windshield/T` |
| 送风切换时刻 | 60 s | 入口温度、速度及湿度函数 |
| 除雾送风温度 | 308 K | `0.orig/cabin/T` 的表达式 |
| 外侧换热系数 | 10 W/(m²·K) | 玻璃 `exterior` 热边界 |

## 求解方法与物理模型

结露条件可用水蒸气分压与饱和压力比较：$p_v>p_{\mathrm{sat}}(T_w)$ 时表面倾向凝结。水蒸气质量分数 $Y_v$ 通过输运方程随气流迁移。界面相变伴随潜热通量 $q_L^{\prime\prime}=\dot m^{\prime\prime}L_v$，因而水分迁移与玻璃温度必须同时求解。

本例使用 `chtMultiRegionFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/windshield-condensation.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip windshield-condensation.zip
cd windshield-condensation
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `topoSet` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| `subsetMesh c0 -patch walls -overwrite` | 从背景网格选出实际计算区域，并生成新的边界面。 |
| `splitMeshRegions -cellZones -overwrite` | 按区域标记分离流体与固体网格，建立配对界面。 |
| `topoSet -region cabin -dict system/topoSetDictRegister` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 界面的凝结与蒸发

文件：`0.orig/cabin/T`。本段设置界面的凝结与蒸发。

```foam
cabin_to_windshield
{
    type            humidityTemperatureCoupledMixed;
    kappaMethod     fluidThermo;
    kappa           none;

    // Mode of operation: inert, condensation, vaporization,
    // condensationAndEvaporation
    mode            condensationAndEvaporation;
    specie          H2O;
    carrierMolWeight  28.9 ;//Air from thermophysicalProperties
    L               0.1;
    Tvap            273;    //Minimum temperature for evaporation

    liquid
    {
        H2O
        {
            defaultCoeffs       yes;
        }
    }

    value           $internalField;
}
```

`humidityTemperatureCoupledMixed` 联立界面温度与相变通量。`mode condensationAndEvaporation` 同时允许凝结和蒸发，`specie H2O` 将相变过程连接到水蒸气输运场。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionFoam/windshieldCondensation/0.orig/cabin/T)。

### 2. 干燥送风切换

文件：`0.orig/cabin/H2O`。本段设置干燥送风切换。

```foam
inlet
{
    type            uniformFixedValue;
    uniformValue           table
    (
        (0   0.01)
        (60  0.01)
        (61  0.00)
        (100 0.00)
    );
}
```

入口 `H2O` 在 60～61 s 从 0.01 降至 0，表示湿空气切换为干空气。0.01 是质量分数，其对应相对湿度还取决于温度与压力。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionFoam/windshieldCondensation/0.orig/cabin/H2O)。

### 3. 玻璃外侧散热

文件：`0.orig/windshield/T`。本段设置玻璃外侧散热。

```foam
exterior
{
    type            externalWallHeatFluxTemperature;
    mode            coefficient;
    h               uniform 10;
    Ta              uniform 260;
    kappaMethod     solidThermo;
    kappa           none;
    value           uniform 260;
}
```

`h` 和 `Ta` 分别规定外部换热系数与环境温度。该边界持续与玻璃交换热量，影响结露初态和除雾后的最终温度。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionFoam/windshieldCondensation/0.orig/windshield/T)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.chtMultiRegionFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `chtMultiRegionFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `0` |
| `endTime` | `90` |
| `deltaT` | `0.01` |
| `writeControl` | `adjustable` |
| `writeInterval` | `1` |
| `adjustTimeStep` | `yes` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选cabin 与 windshield，点击 **Apply**。先选择最后一个已写出的时刻，以 `T` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

同步记录风挡温度、邻近水蒸气质量分数和壁面水分通量，比较干燥送风启动前后的变化。在底部直接吹拂区与上部远端设置相同类型的监测点，分析送风覆盖对除雾速度的影响。

保持速度不变，分别调整送风温度和水蒸气质量分数。壁温曲线反映加热作用，水分通量反映凝结与蒸发的变化。各组工况保留完整的结露阶段，使除雾比较具有对应的初始水分状态。

> **熊猫说：** 湿度计通常给出相对湿度，`H2O` 则需要质量分数。换算时同时使用空气温度和压力。

## 文件与来源

- [完整算例包](/downloads/engineering/windshield-condensation.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionFoam/windshieldCondensation)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
