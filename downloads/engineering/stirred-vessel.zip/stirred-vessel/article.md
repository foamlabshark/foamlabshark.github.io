计算通气搅拌釜内的水—空气分布、循环流和自由液面变形，评价转速与通气量的作用。

## 工程场景与计算目标

叶轮转动向液体输入动量，形成轴向和径向循环。通气后，气相分布改变叶轮附近密度和载荷，自由液面也随旋转流发生变形。循环死区、液面凹陷和局部积气共同影响有效混合范围及相间接触。

算例保留搅拌釜、转轴和叶轮曲面，采用旋转网格与 VOF 描述水—空气体系。初始水位为 0.74 m，底部持续通气。在固定通气量下比较转速，再固定转速比较通气量，将液面、循环结构和叶轮功率联系起来。

## 几何、尺寸与基准工况

![搅拌釜滑移网格与自由液面：配套模型与基准输入](/assets/engineering/stirred-vessel-geometry.webp)

模型采用 `mixerVesselAMI` 曲面，背景域尺寸为 0.6 m × 0.6 m × 1.55 m。转轴沿 z 方向，运动区为 `rotating`，初始水位 z = 0.74 m。叶轮与部分轴段随网格转动，其他圆柱轴面通过旋转壁面速度施加运动。

模型与配置来源：[OpenFOAM v2512 · multiphase/interFoam/RAS/mixerVesselAMI](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/mixerVesselAMI)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 水、空气密度 | 998.2、1.2 kg/m³ | 水—空气基准，`constant/transportProperties` |
| 转动角速度 | −5 rad/s | `constant/dynamicMeshDict` 与 `0.orig/U/shaft` |
| 初始水位 | z = 0.74 m | `system/setFieldsDict` |
| 通气入口速度 | 0.5 m/s，沿正 z | `0.orig/U/gasInlet` |
| 气体入口水相比例 | 0 | `0.orig/alpha.water/gasInlet` |

## 求解方法与物理模型

水相体积分数满足界面输运方程，混合密度为 $\rho=\alpha_w\rho_w+(1-\alpha_w)\rho_a$。转动惯性与重力的相对大小可用 $Fr_n=n^2D/g$ 表示。搅拌功率由叶轮转矩得到 $P=\omega Q$，再以 $N_P=P/(\rho n^3D^5)$ 组织不同工况的比较。

本例使用 `interFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/stirred-vessel.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip stirred-vessel.zip
cd stirred-vessel
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `surfaceFeatureExtract` | 提取曲面棱边，供贴体网格捕捉结构特征。 |
| `snappyHexMesh -overwrite` | 依据随包曲面裁切、贴合背景网格，并执行局部加密。 |
| `createBaffles -overwrite` | 把指定内部面转成成对边界，形成挡板或叶片表面。 |
| `mergeOrSplitBaffles -split -overwrite` | 整理挡板两侧拓扑，使相邻计算区域具有独立的面连接。 |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `setFields` | 按几何区域设置初始相分数、组分或温度。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 初始水位与相分布

文件：`system/setFieldsDict`。本段设置初始水位与相分布。

```foam
defaultFieldValues
(
    volScalarFieldValue alpha.water 0
);

regions
(
    boxToCell
    {
        box (-4 -4 -1) (4 4 0.74);
        fieldValues
        (
            volScalarFieldValue alpha.water 1
        );
    }
);
```

初始化以空气为背景，将 0.74 m 以下单元设置为水。`alpha.water` 的 1 与 0 分别表示水和空气，入口相分数沿用同一约定。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/mixerVesselAMI/system/setFieldsDict)。

### 2. 叶轮和轴面转动

文件：`constant/dynamicMeshDict`。本段设置叶轮和轴面转动。

```foam
dynamicFvMesh   dynamicMotionSolverFvMesh;

motionSolverLibs (fvMotionSolvers);

motionSolver    solidBody;

cellZone        rotating;

solidBodyMotionFunction  rotatingMotion;
```

角速度 −5 rad/s 表示相对给定 z 轴的负向转动。运动单元区与轴面边界分别读取转速，参数比较时同步修改两处。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/mixerVesselAMI/constant/dynamicMeshDict)。

### 3. 底部通气

文件：`0.orig/U`。本段设置底部通气。

```foam
gasInlet
{
    type           fixedValue;
    value          uniform (0 0 0.5);
}
```

通气速度沿正 z，气相组成由入口 `alpha.water = 0` 给定。速度确定动量和流量，相分数确定流入物质，两项共同构成通气条件。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/mixerVesselAMI/0.orig/U)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.interFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `interFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `0` |
| `endTime` | `1` |
| `deltaT` | `1e-4` |
| `writeControl` | `adjustable` |
| `writeInterval` | `0.025` |
| `adjustTimeStep` | `yes` |
| `maxCo` | `1.5` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选釜内流体，点击 **Apply**。先选择最后一个已写出的时刻，以 `alpha.water` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

用水相等值面显示液面和气体进入路径，结合叶轮上下方的速度截面识别主循环与低速区。统计液体总体积，并与边界通量核对相质量收支。

进入可统计状态后，比较不同转速下的液面凹陷、叶轮转矩和循环范围。通气研究保持转速固定，由入口面积与速度计算流量；转矩与角速度给出输入功率，可据此比较单位功率产生的循环改善。

> **熊猫说：** 替换工作液体时，同时更新密度、黏度和表面张力，并重新计算反映惯性、重力与黏性关系的无量纲数。

## 文件与来源

- [完整算例包](/downloads/engineering/stirred-vessel.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/mixerVesselAMI)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
