计算 25°–55° 双锥上的高超声速激波干扰，分析分离、再附着及壁面热流。

## 工程场景与计算目标

高超声速气流经过压缩折角时，激波与边界层相互作用可引起分离，并在下游再附着。再附着区的压力与热流集中，是热防护分析的重要载荷。双锥将这一过程限定在明确的轴对称几何中，便于比较激波结构与壁面测量。

算例使用 Run 35 双锥网格和氮气物性，由 `rhoCentralFoam` 求解可压缩流动。低压工况采用速度滑移和温度跳跃边界，分析依次联系激波位置、分离长度及壁面压力与热流峰值。

## 几何、尺寸与基准工况

![25°–55° 双锥的高超声速激波干扰：配套模型与基准输入](/assets/engineering/hypersonic-biconic-geometry.webp)

前后锥半角为 25° 和 55°。`blockMesh` 建立初始拓扑，随后导入 `grid256.dat` 中的最终曲线坐标。配套非均匀初始场与该网格对应，默认从已发展的流场继续计算。

模型与配置来源：[OpenFOAM v2512 · compressible/rhoCentralFoam/biconic25-55Run35](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/compressible/rhoCentralFoam/biconic25-55Run35)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 来流速度 | 2713 m/s | `0.orig/U.gz` 的 `freestream` |
| 来流温度 | 138.9 K | `0.orig/T.gz` |
| 来流静压 | 22.74 Pa | `0.orig/p.gz` |
| 壁面温度 | 296.1 K | `smoluchowskiJumpT/Twall` |
| 适应系数 | 0.85 | 速度滑移和温度跳跃边界 |

## 求解方法与物理模型

来流马赫数为 $Ma=U_\infty/\sqrt{\gamma RT_\infty}$。激波同时改变压力、密度与温度，能量方程必须与质量和动量守恒耦合。壁面热流为 $q_w=-k\partial T/\partial n$；当稀薄效应不可忽略时，气体在壁面处的切向速度和温度分别通过滑移与跳跃关系确定。

本例使用 `rhoCentralFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/hypersonic-biconic.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip hypersonic-biconic.zip
cd hypersonic-biconic
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `datToFoam grid256.dat` | 导入双锥试验计算网格的坐标与连接关系。 |
| `collapseEdges -overwrite` | 合并退化短边，整理轴线附近的网格拓扑。 |
| 设置 wedge 边界 | 将轴对称扇区两侧设为 wedge 边界。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 低压高速来流

文件：`0.orig/U.gz`。本段设置低压高速来流。

```foam
freestream
{
    type            fixedValue;
    value           uniform (2713 0 0);
}
```

速度、静压和静温共同确定来流密度与马赫数。Run 35 的低压条件通过这三项输入进入计算。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/compressible/rhoCentralFoam/biconic25-55Run35/0.orig/U.gz)。

### 2. 壁面温度跳跃

文件：`0.orig/T.gz`。本段设置壁面温度跳跃。

```foam
    cone
    {
        type            smoluchowskiJumpT;
        accommodationCoeff 0.85;
        Twall           uniform 296.1;
        gamma           1.4;
        value           nonuniform List<scalar>
255
```

`smoluchowskiJumpT` 描述气体壁温相对固体壁温的跳跃，`Twall` 给定固体温度，`value` 保存与当前网格对应的气体初值。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/compressible/rhoCentralFoam/biconic25-55Run35/0.orig/T.gz)。

### 3. 氮气热物性

文件：`constant/thermophysicalProperties`。本段设置氮气热物性。

```foam
thermoType
{
    type            hePsiThermo;
    mixture         pureMixture;
    transport       sutherland;
    thermo          janaf;
    equationOfState perfectGas;
    specie          specie;
    energy          sensibleInternalEnergy;
}
```

氮气采用 JANAF 热力学数据与 Sutherland 输运关系，以显内能为能量变量。激波温升通过这些物性关系反馈到压力、密度和输运过程。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/compressible/rhoCentralFoam/biconic25-55Run35/constant/thermophysicalProperties)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.rhoCentralFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `rhoCentralFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `latestTime` |
| `startTime` | `0` |
| `endTime` | `1e-3` |
| `deltaT` | `1e-7` |
| `writeControl` | `adjustable` |
| `writeInterval` | `5e-5` |
| `adjustTimeStep` | `yes` |
| `maxCo` | `0.5` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选双锥附近流场，点击 **Apply**。先选择最后一个已写出的时刻，以 `p` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

以密度或压力梯度识别前锥激波、折角压缩及再附着结构。沿锥面提取压力和热流，用统一轴向坐标与同工况试验比较，关注峰值及其位置。

加密近壁和折角区域，检查分离长度和热流峰值变化。重建网格后，将初始场映射到新网格或重新初始化，再比较收敛结果。

> **熊猫说：** 最终模型坐标由 `grid256.dat` 给出。检查双锥尺寸和近壁分辨率时，以导入后的网格为准。

## 文件与来源

- [完整算例包](/downloads/engineering/hypersonic-biconic.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/compressible/rhoCentralFoam/biconic25-55Run35)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
