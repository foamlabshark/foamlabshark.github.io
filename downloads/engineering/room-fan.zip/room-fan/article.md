解析室内吊扇叶片运动，计算家具和墙面对送风范围、回流及活动区风速的影响。

## 工程场景与计算目标

吊扇推动空气后，射流受到地面、家具和墙面约束，形成室内循环。活动区风速既取决于转速，也取决于射流扩散和回流路径。循环气流与门窗之间的净换气具有不同来源，需要分别评价。

算例保留风扇、房间和桌面几何，用旋转网格解析叶片运动。房门施加缓慢来流，另一开口排气，`pimpleFoam` 求解瞬态不可压缩流动。计算通过活动区速度分布和进出口流量，比较转速对送风和净通风的影响。

## 几何、尺寸与基准工况

![室内旋转风扇的送风与回流：配套模型与基准输入](/assets/engineering/room-fan-geometry.webp)

背景域约为 6.5 m × 5.5 m × 3 m。风扇轴心位于 `(−3 2 2.6)` m，转轴沿 z 方向。`rotatingZone` 包含运动网格，通过 `AMI1`、`AMI2` 与静止房间网格连接。

模型与配置来源：[OpenFOAM v2512 · incompressible/pimpleFoam/RAS/rotatingFanInRoom](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/incompressible/pimpleFoam/RAS/rotatingFanInRoom)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 风扇角速度 | 10 rad/s | `constant/dynamicMeshDict` |
| 房门入口 | 0.1 m/s，沿负 x | `0.orig/U/door` |
| 运动黏度 | 10⁻⁵ m²/s | `constant/transportProperties` |
| 初始时间步 | 2 × 10⁻⁴ s | `system/controlDict` |

## 求解方法与物理模型

叶片点的速度为 $\mathbf U_w=\boldsymbol\omega\times(\mathbf r-\mathbf r_0)$。AMI 将转动网格上的通量传递到静止室内网格。工程比较可使用时间平均速度 $\overline{\mathbf U}=\frac1{T_s}\int_{t_0}^{t_0+T_s}\mathbf U\,dt$，而流量通过 $Q=\int_A\mathbf U\cdot\mathbf n\,dA$ 统计。

本例使用 `pimpleFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/room-fan.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip room-fan.zip
cd room-fan
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `surfaceFeatureExtract` | 提取曲面棱边，供贴体网格捕捉结构特征。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `snappyHexMesh -overwrite` | 依据随包曲面裁切、贴合背景网格，并执行局部加密。 |
| `renumberMesh -overwrite` | 重新编号，改善矩阵存储和求解访问顺序。 |
| `createPatch -overwrite` | 重建边界集合及周期、AMI 等边界类型。 |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 风扇旋转轴

文件：`constant/dynamicMeshDict`。本段设置风扇旋转轴。

```foam
dynamicFvMesh   dynamicMotionSolverFvMesh;

motionSolverLibs (fvMotionSolvers);

motionSolver    solidBody;

cellZone        rotatingZone;

solidBodyMotionFunction  rotatingMotion;
```

`origin`、`axis` 和角速度确定叶片转动轨迹。移动风扇时同步移动几何、旋转区域和轴心，使其空间关系保持一致。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/incompressible/pimpleFoam/RAS/rotatingFanInRoom/constant/dynamicMeshDict)。

### 2. 叶片与房门边界

文件：`0.orig/U`。本段设置叶片与房门边界。

```foam
fan
{
    type            movingWallVelocity;
    value           uniform (0 0 0);
}
```

风扇表面使用运动壁面速度，房门使用固定来流速度。前者组织室内循环，后者与出口共同确定外界空气的净交换。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/incompressible/pimpleFoam/RAS/rotatingFanInRoom/0.orig/U)。

### 3. 运行与统计时间

文件：`system/controlDict`。本段设置运行与统计时间。

```foam
stopAt          endTime;

endTime         1;

deltaT          0.0002;

writeControl    adjustable;

writeInterval   0.02;

purgeWrite      0;
```

1 s 的终点用于观察启动过程。计算平均风速时，延长运行至回流建立，再对完整的多个转动周期进行统计。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/incompressible/pimpleFoam/RAS/rotatingFanInRoom/system/controlDict)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.pimpleFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `pimpleFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `latestTime` |
| `startTime` | `0` |
| `endTime` | `1` |
| `deltaT` | `0.0002` |
| `writeControl` | `adjustable` |
| `writeInterval` | `0.02` |
| `adjustTimeStep` | `yes` |
| `maxCo` | `1` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选房间内部，点击 **Apply**。先选择最后一个已写出的时刻，以 `U` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

在人员活动高度建立水平截面，输出平均风速，并观察桌后、墙角和风扇周围的回流。以进出口净流量描述换气，以室内速度和流线描述循环，两组结果共同说明风扇作用。

比较半转速、基准转速和较高转速下的活动区平均风速、最高风速及低速区面积。先延长计算至这些统计量不再持续漂移，再使用相同长度、覆盖多个旋转周期的时间窗取平均。

> **熊猫说：** 吊扇主要加强室内循环。评价新风供给时，另行统计房门与出口的净流量。

## 文件与来源

- [完整算例包](/downloads/engineering/room-fan.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/incompressible/pimpleFoam/RAS/rotatingFanInRoom)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
