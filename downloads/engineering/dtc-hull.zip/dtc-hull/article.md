采用 DTC 缩尺船体计算定常航行的兴波与阻力，建立自由液面、液位和水动力积分设置。

## 工程场景与计算目标

水面船舶航行时同时产生壁面黏性阻力、压力阻力和自由液面波动。船首与船尾波系随航速变化并相互作用，使阻力与速度之间的关系受到船型、吃水和重力波尺度的共同影响。缩尺船模的比较因此需要统一几何尺度、吃水和 Froude 数。

算例采用公开的 Duisburg Test Case 集装箱船型，在固定船体周围施加来流。VOF 方法追踪水—空气界面，船体表面应力积分给出压力力与黏性力；局部时间步用于加速建立定常航行平均流场。

## 几何、尺寸与基准工况

![DTC 集装箱船模的自由液面阻力：配套模型与基准输入](/assets/engineering/dtc-hull-geometry.webp)

`DTC-scaled.stl.gz` 给出缩尺船体。计算使用 y ≤ 0 的半船域，中纵面采用对称条件。背景域为 x = −26～16 m、y = −19～0 m、z = −16～4 m，初始液位由 `setFieldsDict` 给定，与船体位置共同确定吃水。

模型与配置来源：[OpenFOAM v2512 · multiphase/interFoam/RAS/DTCHull](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/DTCHull)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 航速 | 1.668 m/s，来流沿负 x | `0.orig/U` |
| 水密度与运动黏度 | 998.8 kg/m³、1.09 × 10⁻⁶ m²/s | `constant/transportProperties` |
| 重力 | −9.81 m/s²，沿 z | `constant/g` |
| 表面张力 | 0 N/m | 基准侧重大尺度重力波 |
| 时间离散 | localEuler | `system/fvSchemes`，迭代坐标不作为物理航行时间 |

## 求解方法与物理模型

VOF 变量 $\alpha_w$ 表示水的体积分数，混合密度为 $\rho=\alpha_w\rho_w+(1-\alpha_w)\rho_a$。兴波尺度以 $Fr=U/\sqrt{gL}$ 组织，阻力系数为 $C_T=R/(\tfrac12\rho_wU^2S)$，其中 $S$ 是浸湿面积。半船结果与整船试验比较时，应将力和参考面积按同一种对称约定处理。

本例使用 `interFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/dtc-hull.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip dtc-hull.zip
cd dtc-hull
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `surfaceFeatureExtract` | 提取曲面棱边，供贴体网格捕捉结构特征。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `topoSet -dict system/topoSetDict.1` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| `refineMesh -dict system/refineMeshDict -overwrite` | 细化指定单元选区，提高关键位置的空间分辨率。 |
| `topoSet -dict system/topoSetDict.2` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| `refineMesh -dict system/refineMeshDict -overwrite` | 细化指定单元选区，提高关键位置的空间分辨率。 |
| `topoSet -dict system/topoSetDict.3` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| `refineMesh -dict system/refineMeshDict -overwrite` | 细化指定单元选区，提高关键位置的空间分辨率。 |
| `topoSet -dict system/topoSetDict.4` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| `refineMesh -dict system/refineMeshDict -overwrite` | 细化指定单元选区，提高关键位置的空间分辨率。 |
| `topoSet -dict system/topoSetDict.5` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| `refineMesh -dict system/refineMeshDict -overwrite` | 细化指定单元选区，提高关键位置的空间分辨率。 |
| `topoSet -dict system/topoSetDict.6` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| `refineMesh -dict system/refineMeshDict -overwrite` | 细化指定单元选区，提高关键位置的空间分辨率。 |
| `snappyHexMesh -overwrite` | 依据随包曲面裁切、贴合背景网格，并执行局部加密。 |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `setFields` | 按几何区域设置初始相分数、组分或温度。 |
| `renumberMesh -overwrite` | 重新编号，改善矩阵存储和求解访问顺序。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 航速与流向

文件：`0.orig/U`。本段设置航速与流向。

```foam
Umean 1.668;
mUmean -1.668;

dimensions      [0 1 -1 0 0 0 0];

internalField   uniform ($mUmean 0 0);

boundaryField
{
    #includeEtc "caseDicts/setConstraintTypes"

    inlet
    {
        type            fixedValue;
        value           $internalField;
    }

    outlet
    {
        type            outletPhaseMeanVelocity;
        alpha           alpha.water;
        Umean           $Umean;
        value           $internalField;
    }
```

来流沿负 x，速度为 1.668 m/s，出口根据水相平均速度控制流出。分析 x 向船体力时，以来流方向明确阻力符号。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/DTCHull/0.orig/U)。

### 2. 初始水位

文件：`system/setFieldsDict`。本段设置初始水位。

```foam
defaultFieldValues
(
    volScalarFieldValue alpha.water 0
);

regions
(
    // Set cell values
    // (does zerogradient on boundaries)
    boxToCell
    {
        box (-999 -999 -999) (999 999 0.244);

        fieldValues
        (
            volScalarFieldValue alpha.water 1
        );
    }

    // Set patch values (using ==)
    boxToFace
    {
        box (-999 -999 -999) (999 999 0.244);
```

初始化先将计算域设为空气，再将指定液位以下单元设为水。该液位与船体曲面共同决定吃水，改变液位后重新执行相分数初始化。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/DTCHull/system/setFieldsDict)。

### 3. 船体水动力积分

文件：`system/controlDict`。本段设置船体水动力积分。

```foam
forces
{
    type            forces;
    libs            (forces);
    patches         (hull);
    rhoInf          998.8;
    log             on;
    writeControl    timeStep;
    writeInterval   1;
    CofR            (2.929541 0 0.2);
}
```

`hull` 限定船体受力表面，`CofR` 定义力矩参考点。修改参考点会改变力矩分量，合力保持相同。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/DTCHull/system/controlDict)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.interFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `interFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `0` |
| `endTime` | `4000` |
| `deltaT` | `1` |
| `writeControl` | `timeStep` |
| `writeInterval` | `100` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选船体周围水域，点击 **Apply**。先选择最后一个已写出的时刻，以 `alpha.water` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

提取 `alpha.water = 0.5` 水面，观察船首波、舷侧波和尾波。在与试验对应的纵向或横向测线上输出波高，并分别绘制压力阻力、黏性阻力和总阻力的迭代曲线。

航速比较保持船模尺度和液位不变，同时报告 Froude 数。网格比较兼顾船体边界层与自由液面传播区域，分别检查阻力和波高的变化；半船力与整船试验按一致的对称约定换算。

> **熊猫说：** 局部时间步用于求取定常流场。研究船体运动或真实波浪时序时，采用物理时间推进，并按运动周期确定时间步和统计长度。

## 文件与来源

- [完整算例包](/downloads/engineering/dtc-hull.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/DTCHull)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
- [DTC 船型基准论文](https://doi.org/10.1179/str.2012.59.3.004)。
