由室内流动和温度场计算热舒适与空气龄，分析送风条件对人员活动区的影响。

## 工程场景与计算目标

室内平均温度相同，送风口附近和回流区的局部感受仍可能不同。较高风速增强人体散热，墙面温度与空气温度影响热平衡，衣着和活动强度则改变人体需求。空气更新速度还需由通风输运单独评价。

算例在暖壁房间内引入冷空气，求解带浮力的流动与温度，并输出 PMV、PPD、吹风感和空气龄。分析分别联系局部冷热感、射流吹拂与空气更新，说明提高送风量可能带来的多方面变化。

## 几何、尺寸与基准工况

![供暖房间的温度分层与热舒适：配套模型与基准输入](/assets/engineering/thermal-comfort-geometry.webp)

空间尺寸为 4 m × 3 m × 1.6 m。`topoSet` 与 `createPatch` 从边界选出送、排风口，墙温为 302 K，入口温度为 290 K。进出口位置与网格定义随算例提供。

模型与配置来源：[OpenFOAM v2512 · heatTransfer/buoyantSimpleFoam/comfortHotRoom](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/buoyantSimpleFoam/comfortHotRoom)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 入口速度、温度 | 0.2 m/s、290 K | `0.orig/U`、`T` |
| 墙面温度 | 302 K | `0.orig/T/walls` |
| 着衣量 | 0.5 clo | `system/FOcomfort/clothing` |
| 活动强度 | 1.2 met | `metabolicRate` |
| 相对湿度 | 60% | `relHumidity` |

## 求解方法与物理模型

浮力采用 Boussinesq 状态关系 $\rho\approx\rho_0[1-\beta(T-T_0)]$，以温差驱动空气运动。PMV 表示人体热平衡对应的平均冷热感，PPD 表示预计不满意比例，二者关系为 $PPD=100-95\exp(-0.03353PMV^4-0.2179PMV^2)$。空气龄 $\tau$ 描述空气从入口进入后在局部停留的时间，其空间分布用于识别更新较慢的区域。

本例使用 `buoyantSimpleFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/thermal-comfort.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip thermal-comfort.zip
cd thermal-comfort
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `topoSet` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| `createPatch -overwrite` | 重建边界集合及周期、AMI 等边界类型。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 人员与湿度参数

文件：`system/FOcomfort`。本段设置人员与湿度参数。

```foam
comfort
{
    // Mandatory entries
    type            comfort;
    libs            (fieldFunctionObjects);

    // Optional entries
    clothing        0.5;
    metabolicRate   1.2;
    extWork         0.0;
    // Trad            0.0;
    relHumidity     60.0;
    pSat            0.0;
    tolerance       1e-4;
    maxClothIter    100;
    meanVelocity    false;

    // Inherited entries
    region          region0;
    enabled         true;
    log             true;
    timeStart       0;
    timeEnd         10000;
    executeControl  writeTime;
    executeInterval -1;
    writeControl    writeTime;
    writeInterval   -1;
}
```

着衣量、代谢率和相对湿度描述人员及环境条件，参与热舒适计算。比较送风方案时保持这些输入一致，才能将 PMV 变化归因于流动与温度变化。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/buoyantSimpleFoam/comfortHotRoom/system/FOcomfort)。

### 2. 送风和墙面温度

文件：`0.orig/T`。本段设置送风和墙面温度。

```foam
boundaryField
{
    walls
    {
        type            fixedValue;
        value           $internalField;
    }

    inlet
    {
        type            fixedValue;
        value           uniform 290;
    }

    outlet
    {
        type            zeroGradient;
    }
}
```

290 K 的入口空气与 302 K 的墙面形成温差，浮力和送风共同组织室内流动。出口温度零梯度条件使空气携带内部求得的温度流出。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/buoyantSimpleFoam/comfortHotRoom/0.orig/T)。

### 3. 空气龄计算

文件：`system/FOage`。本段设置空气龄计算。

```foam
ageOfAir
{
    // Mandatory entries
    type            age;
    libs            (fieldFunctionObjects);

    // Optional entries
    phi             phi;
    rho             rho;
    schemesField    age;
    tolerance       1e-5;
    nCorr           5;
    diffusion       on;

    // Inherited entries
    region          region0;
    enabled         true;
    log             true;
    timeStart       0;
    timeEnd         10000;
    executeControl  writeTime;
    executeInterval -1;
    writeControl    writeTime;
    writeInterval   -1;
}
```

空气龄函数对象利用已求得的流场计算空气停留时间。局部值较高时，结合流线判断是否存在回流或较弱的空气交换。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/buoyantSimpleFoam/comfortHotRoom/system/FOage)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.buoyantSimpleFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `buoyantSimpleFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。本求解器采用稳态迭代，日志中的 Time 用作迭代序号。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `latestTime` |
| `startTime` | `0` |
| `endTime` | `3000` |
| `deltaT` | `1` |
| `writeControl` | `timeStep` |
| `writeInterval` | `100` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选房间内部，点击 **Apply**。先选择最后一个已写出的时刻，以 `T` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

在模型范围内选取人员活动高度截面，统一色标比较温度、速度、PMV 和 PPD。高吹风感区域与入口射流对照，高空气龄区域与回流对照，从空间分布解释各指标来源。

改变送风速度时，同时记录风量、空气龄和活动区舒适分布。再保持流场不变，改变着衣量，区分通风方案与人体参数对舒适评价的影响。

> **熊猫说：** PPD 表示热平衡模型预测的不满意比例。空气更新程度通过空气龄和新风量评价。

## 文件与来源

- [完整算例包](/downloads/engineering/thermal-comfort.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/buoyantSimpleFoam/comfortHotRoom)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
