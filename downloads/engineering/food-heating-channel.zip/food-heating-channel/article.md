建立等效乳状食品的连续加热温度均匀性模型，分析处理流量与加热功率对出口平均温度、截面温差、壁温和停留时间的影响。

## 工程场景与计算目标

连续加热设备需要将液态食品加热至要求温度，同时限制壁面过热和截面温差。流速增大可以提高处理量，却会缩短停留时间；靠壁液体与通道中心液体经历的温度过程也不同。出口平均温度相同，温度均匀性仍可能不同。

本例构造双面不锈钢加热通道，液体层厚 12 mm，两侧钢板共同提供 100 W 热量。流体采用给定密度、黏度、比热和导热系数的等效牛顿液体。计算分析处理流量、钢板温度和出口截面分布，为连续加热通道的长度与功率选择提供依据。

## 几何、尺寸与基准工况

几何由 `design.json` 中的尺寸和位置生成，采用双面不锈钢加热板与 12 mm 液体通道。坐标与尺寸均使用 m，流向由边界速度向量确定。

![液态食品夹层加热通道的结构分区与流动方向](/assets/engineering/food-heating-channel-geometry.webp)

| 参数 | 基准值 | 含义 |
| --- | --- | --- |
| 计算域外包尺寸 | 0.5 × 0.05 × 0.018 m | 实际计算空间由流体块体并集确定 |
| 流体密度 | 1030 kg/m³ | 惯性、压差换算和质量流量 |
| 运动黏度 | 2e-06 m²/s | 分子黏性输运 |
| 基础网格 | 26,880 单元 | 默认 MESH_REFINE=2 的设计网格 |
| 入口温度 | 323.15 K | 冷却或被加热流体 |
| 总热功率 | 100 W | 由 solid/fvOptions 指定 |
| 固体导热系数 | 16 W/(m·K) | 固体 thermophysicalProperties |

几何各部分的坐标范围如下。流体块体先合并，再从中划分导热固体或扣除障碍物；因此相邻、相交块体不会重复占据体积。

| 部件 | x 范围 / m | y 范围 / m | z 范围 / m |
| --- | --- | --- | --- |
| 流体区域1 | 0～0.5 | 0～0.05 | 0～0.018 |
| 导热固体1 | 0～0.5 | 0～0.05 | 0～0.003 |
| 导热固体2 | 0～0.5 | 0～0.05 | 0.015～0.018 |

| 边界名称 | 作用 | 基准条件 |
| --- | --- | --- |
| `inlet` | 入口 | U = (0.06 0 0) m/s |
| `outlet` | 出口 | 压力参考值 101325 Pa |

## 物理模型与求解方法

不可压缩流动满足质量守恒与动量守恒：

\[
\nabla\cdot\mathbf U=0,\qquad
\rho\left(\frac{\partial\mathbf U}{\partial t}+\mathbf U\cdot\nabla\mathbf U\right)
=-\nabla p+\nabla\cdot\boldsymbol\tau+\mathbf f.
\]

其中，\(\mathbf U\) 为速度，\(p\) 为物理压力，\(\boldsymbol\tau\) 为黏性应力，\(\mathbf f\) 为单位体积外力。连续性方程约束各截面的流量收支；动量方程描述压力、黏性作用和外力如何改变速度。

流体中的热量由流动输运并通过导热扩散，固体内部则由导热和热源共同决定温度。稳态形式为

\[
\rho_f c_{p,f}\mathbf U\cdot\nabla T_f=\nabla\cdot(k_f\nabla T_f),\qquad
\nabla\cdot(k_s\nabla T_s)+q_v=0.
\]

界面上温度连续，两侧法向热流大小相等。固体发热功率按选定单元体积分配，外表面采用绝热条件，热量经流固界面进入冷却流体。模型使用规定入口条件研究强制对流，重力项设为零。

本例使用 `chtMultiRegionSimpleFoam`，通过稳态迭代求解，日志中的 `Time` 表示迭代序号。基准采用层流模型，黏性应力由分子黏度确定。

## 配置文件与网格建立

[下载完整算例与配置代码](/downloads/engineering/food-heating-channel.zip)。解压目录中已提供 `0.orig/`、`constant/`、`system/` 和几何数据，`build_case.py` 根据 `design.json` 重建相同输入；生成程序只使用 Python 标准库。

| 文件或目录 | 操作与用途 |
| --- | --- |
| `design.json` | 修改部件坐标、流体物性、速度或热功率；随后重新生成字典 |
| `geometry/model.obj` | 查看几何分区；曲线叶道以 blockMesh 圆弧为准 |
| `system/blockMeshDict` | 多块六面体网格的顶点、单元数与边界面 |
| `0.orig/` | 初始场和边界条件；建网格时复制到 `0/` |
| `constant/` | 物性、物理模型与区域设置 |
| `system/fvSchemes`、`system/fvSolution` | 离散格式、线性求解和耦合控制 |
| `Allmesh`、`Allsolve` | 分别完成网格准备与求解、结果提取 |

多块网格在肋片边缘、支路开口和分区界面处共享坐标平面，使边界与几何位置一致。默认加密级别为 2，薄通道与窄缝另外保留最低单元层数。共轭传热案例先建立包含流固单元区的整体网格，再按 `fluid`、`solid` 拆分；配对界面用于交换热量，`topoSet` 选出固体发热区。

## 关键配置与解读

以下条目取自本页下载包的同名文件，几何和边界名称与上表对应。

### `constant/fluid/thermophysicalProperties`

```foam
thermoType { type heRhoThermo; mixture pureMixture; transport const; thermo hConst; equationOfState rhoConst; specie specie; energy sensibleEnthalpy; }
mixture { specie { molWeight 28.97; } equationOfState { rho 1030; } thermodynamics { Cp 3900; Hf 0; } transport { mu 0.0020599999999999998; Pr 14.607272727272724; } }
```

`rhoConst` 使用给定密度，`Cp` 控制单位质量流体升温所需的热量，`mu` 为动力黏度。`Pr` 由黏度、比热和导热系数计算，使传热模型采用与物性表一致的导热能力。

### `constant/solid/fvOptions`

```foam
heatInput
{ type scalarSemiImplicitSource; active true; selectionMode cellSet; cellSet heatingCells; volumeMode absolute; injectionRateSuSp { h (100 0); } }
```

`heatingCells` 由固体区域的 `topoSetDict` 选出；`volumeMode absolute` 把 `h` 条目中的 100 作为该选区的总热功率，单位 W。改变选区体积时，总功率保持不变，体积发热率随之变化。

### `0.orig/fluid/T`

```foam
boundaryField
{
    walls { type zeroGradient; }
    inlet { type fixedValue; value uniform 323.15; }
    outlet { type inletOutlet; inletValue uniform 323.15; value uniform 323.15; }
    fluid_to_solid { type compressible::turbulentTemperatureRadCoupledMixed; Tnbr T; qr none; qrNbr none; kappaMethod fluidThermo; value uniform 323.15; }
}
```

入口温度规定冷却介质的供给状态。`fluid_to_solid` 与固体侧界面配对，耦合边界通过两侧导热能力求取界面温度和热流。出口回流时采用入口温度作为回流初值。


## 运行与计算检查

在 Linux 中加载 OpenCFD OpenFOAM v2512，然后进入解压目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
cd food-heating-channel
bash Allmesh
bash Allsolve
```

安装位置不同，只需调整第一行环境路径。`Allmesh` 生成输入和网格，复制初始场并检查网格质量；`Allsolve` 调用 `chtMultiRegionSimpleFoam`，运行后将监测记录整理到 `analysis/`。各阶段的详细信息分别写入 `log.blockMesh`、`log.checkMesh` 和 `log.chtMultiRegionSimpleFoam`，遇到错误时脚本会停止并显示对应日志末尾。

修改工况时，先在新解压目录中编辑 `design.json`，再执行 `Allmesh`。网格生成以后，边界调整应写入 `0/`；如果重新生成网格，程序会再次使用参数文件和 `0.orig/`。保留各工况独立目录，便于核对尺寸、物性与结果。

先检查残差是否持续下降，再查看流量、压差和温度或转矩是否趋于稳定。不同方程的残差尺度不同，采用工程监测量的稳定性判断迭代是否足够。

## 结果提取与工程分析

在出口绘制温度等值线并提取流量加权温度，随后沿通道中心线和近壁线比较升温过程。以流体体积除以体积流量估算名义停留时间；该值与局部流线停留时间不同，可用于比较整体处理强度。温度分布与功率收支明确后，再分析增大通量是否仍满足目标出口温度。

在 ParaView 中打开 `case.foam`，选择最后一个已写出时刻。用 **Slice** 建立上述截面，用 **Plot Over Line** 提取沿线变化；流量计算使用速度的截面法向分量，配合 **Integrate Variables** 积分。输出表格时使用 **Save Data**，工况比较保持截面位置、色标和平均方式相同。

`analysis/monitor-history.csv` 保存监测对象的时间或迭代历史，`analysis/metrics.json` 整理边界流量、压力和温度等可用指标。内部通道分流、局部方差或单个壁面载荷按本节给出的选区继续提取。边界流量采用外法向为正，入口一般为负，出口一般为正。

热阻可写为

\[
R_\theta=\frac{T_{s,\max}-T_{\mathrm{in}}}{P},\qquad
\dot Q_f=\dot m c_p(T_{\mathrm{out}}-T_{\mathrm{in}}).
\]

\(R_\theta\) 将热点温升与总热功率联系起来；\(\dot Q_f\) 是流体携走的显热，采用流量加权温度计算。绝热外边界下，收敛后的流体携热应与固体热源相平衡。共轭求解器的 `phi` 为质量通量，随包分析程序按密度换算体积流量。

## 参数比较与网格收敛

比较 0.03、0.06、0.09 m/s，记录出口温度和名义停留时间；固定流量后将总功率设为 75、100、125 W。

先完成基准工况，再每次改变一个设计因素。记录几何尺寸、入口总流量、出口平均温度、截面温差、壁温和停留时间，将性能变化与流场结构对应。对选定方案再做网格比较：

```bash
MESH_REFINE=4 bash Allmesh
bash Allsolve
```

在新的解压目录执行上述命令，各方向相对默认级别增加一倍单元数。比较时使用相同物性、边界条件及结果提取位置，检查主要工程量随网格变化的幅度。自由液面案例还需减小 `maxDeltaT`，比较水位幅值和相位；示踪混合案例需同时检查浓度界面的数值扩散。

> **熊猫说：** 固体热源的总功率、入口焓流和出口焓流构成同一个能量收支。先核对热量，再解释热点的位置。

## 配套代码与资料

- [下载几何、完整配置、运行及分析代码](/downloads/engineering/food-heating-channel.zip)。`VALIDATION.json` 和 `validation/` 保存 v2512 网格检查与短程启动记录，`files.sha256` 可用于核对文件完整性。
- [OpenFOAM 用户指南](https://www.openfoam.com/documentation/user-guide)：算例结构、网格与求解流程。
- [OpenFOAM v2512 源码文档](https://api.openfoam.com/2512/)：字段、边界和模型实现。

[返回实际工程应用](/topics/engineering/)
