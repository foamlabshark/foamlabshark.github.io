计算旋风筒内气固两相运动，比较颗粒滞留、出口携带和设备压降。

## 工程场景与计算目标

旋风分离器使含尘气流旋转，利用颗粒对转弯流动的惯性响应促使其向外壁迁移。粗颗粒与气流的跟随性较弱，细颗粒则更容易随中心上升流离开设备。入口速度、粒径分布和旋涡结构共同影响分离趋势，同时决定气流通过设备所需的压力差。

算例使用公开旋风筒曲面，以 `MPPICFoam` 计算气固耦合，并通过颗粒应力描述高浓度堆积。颗粒按给定时段注入，筒壁反弹，顶部允许逃逸，筒底封闭。由注入质量、筒内存量与出口携带量建立收支，评价指定时间内的颗粒滞留。

## 几何、尺寸与基准工况

![旋风分离器的气固输运：配套模型与基准输入](/assets/engineering/cyclone-separator-geometry.webp)

`cyclone.stl.gz` 定义筒壁和锥段，背景外包盒尺寸为 1.1 m × 1.1 m × 2.1 m。气流从侧面进入、顶部离开。`blockMesh` 建立背景网格，`snappyHexMesh` 贴合筒体曲面并加密。

模型与配置来源：[OpenFOAM v2512 · lagrangian/MPPICFoam/cyclone](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/lagrangian/MPPICFoam/cyclone)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 连续相 | 空气，1.2 kg/m³ | `constant/transportProperties` |
| 颗粒密度 | 1000 kg/m³ | `constant/kinematicCloudProperties` |
| 注入粒径 | 均值 100 μm、标准差 25 μm，截断于 20～180 μm | 正态粒径分布 |
| 注入阶段 | 1～5 s，总质量 40 kg | `SOI`、`duration`、`massTotal` |
| 壁面处理 | 反弹 | 恢复系数与摩擦参数见 `localInteractionCoeffs` |

## 求解方法与物理模型

颗粒响应时间在 Stokes 极限下为 $\tau_p=\rho_p d_p^2/(18\mu)$，Stokes 数为 $St=\tau_pU/L$。较大的 $St$ 表示颗粒不容易紧随气流转弯。旋转气流的特征径向加速度为 $U_\theta^2/r$；MPPIC 进一步用颗粒应力约束高浓度区域的堆积。

本例使用 `MPPICFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/cyclone-separator.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip cyclone-separator.zip
cd cyclone-separator
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `snappyHexMesh -overwrite` | 依据随包曲面裁切、贴合背景网格，并执行局部加密。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 颗粒注入与粒径

文件：`constant/kinematicCloudProperties`。本段设置颗粒注入与粒径。

```foam
model1
{
    type            patchInjection;
    massTotal       40;
    SOI             1;
    parcelBasisType mass;
    patch           inlet;
    duration        4;
    parcelsPerSecond 100644;
    U0              (-10 0 0);
    flowRateProfile constant 1;
    sizeDistribution
    {
        type            normal;
        normalDistribution
        {
            mu              100e-6;
            sigma           25e-6;
            minValue        20e-6;
            maxValue        180e-6;
        }
    }
}
```

`patchInjection` 从入口面注入颗粒，`massTotal` 为完整注入时段的总质量。正态粒径分布具有上下限，出口统计使用相同粒径分档，以便比较不同颗粒的携带趋势。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/MPPICFoam/cyclone/constant/kinematicCloudProperties)。

### 2. 壁面碰撞和出口逃逸

文件：`constant/kinematicCloudProperties`。本段设置壁面碰撞和出口逃逸。

```foam
localInteractionCoeffs
{
    patches
    (
        "(walls|inlet)"
        {
            type rebound;
            e    0.97;
            mu   0.09;
        }
        outlet
        {
            type escape;
        }
    );
}
```

筒壁和入口采用反弹，顶部采用逃逸。封闭筒底保留颗粒存量，该存量与顶部流出量共同组成质量收支。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/MPPICFoam/cyclone/constant/kinematicCloudProperties)。

### 3. 连续相名称与场量

文件：`constant/transportProperties`。本段设置连续相名称与场量。

```foam
continuousPhase air;

rho.air         1.2;

transportModel  Newtonian;
```

连续相名为 `air`，速度和湍流变量采用相应后缀。后处理中选择 `U.air` 查看气流，选择粒子云查看颗粒轨迹。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/MPPICFoam/cyclone/constant/transportProperties)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.MPPICFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `MPPICFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `latestTime` |
| `startTime` | `0` |
| `endTime` | `7` |
| `deltaT` | `2e-4` |
| `writeControl` | `runTime` |
| `writeInterval` | `0.1` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选气相内部与颗粒，点击 **Apply**。先选择最后一个已写出的时刻，以 `U.air` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

在轴向截面显示 `U.air`，识别外侧下行流与中心上行流。按相同粒径区间统计累计注入、出口携带和筒内存量，使用各粒子团的质量权重核对收支。

改变入口速度，联合比较出口携带比例与压降。封闭底部的结果表示筒内滞留；研究连续排料时，增加实际排料口及颗粒逃逸条件，另行统计底部回收质量。

> **熊猫说：** 一个计算粒子团代表一定数量的真实颗粒。质量统计采用粒子团权重和单粒质量。

## 文件与来源

- [完整算例包](/downloads/engineering/cyclone-separator.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/lagrangian/MPPICFoam/cyclone)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
