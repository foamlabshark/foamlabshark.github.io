模拟多孔过滤通道中的空气压降、液滴输运与蒸发，建立气液质量收支。

## 工程场景与计算目标

含湿气流经过过滤段时，气体受到多孔阻力，液滴则受惯性、壁面碰撞与传热传质影响。气相压降、液滴蒸发和表面捕集属于不同过程，各自需要对应的模型和统计量。仅凭出口液滴减少，尚不能确定其中多少来自蒸发或沉积。

算例在扩张通道内设置等效多孔区，通过查表方式注入水滴，并计算液滴升温与蒸发。基准壁面采用反弹，分析内容为输运和穿透；研究捕集时，对指定滤面施加黏附条件并单独输出沉积质量。

## 几何、尺寸与基准工况

![多孔过滤段中的液滴输运与蒸发：配套模型与基准输入](/assets/engineering/particle-filter-geometry.webp)

通道长 4 m，进出口高度 0.5 m，扩张段高度 1 m，展向厚度 0.1 m，采用二维边界。`topoSet` 建立 `filter` 单元区，`createBaffles` 构造循环挡板连接。

模型与配置来源：[OpenFOAM v2512 · lagrangian/reactingParcelFoam/filter](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/lagrangian/reactingParcelFoam/filter)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 空气入口 | 5 m/s、350 K | `0.orig/U`、`T` |
| 壁面温度 | 400 K | `0.orig/T/walls` |
| 轴向黏性阻力系数 | 500000 m⁻² | `constant/fvOptions/filter1` |
| 液滴注入 | 0.5 s 开始、持续 1 s、总质量 0.01 kg | `constant/reactingCloud1Properties` |
| 注入状态 | 由 `parcelInjectionProperties` 读取 | 位置、速度、温度与粒径统一在查表文件中 |

## 求解方法与物理模型

过滤区动量损失采用 Darcy–Forchheimer 形式，沿主流方向可写为 $\Delta p/L=\mu D U+\tfrac12\rho F|U|U$。液滴惯性以 $St=\tau_pU/L_c$ 衡量，蒸发则改变液滴质量与气相水分。若配置沉积边界，捕集效率由 $\eta=m_{\mathrm{deposit}}/m_{\mathrm{in}}$ 定义，并与蒸发损失分别统计。

本例使用 `reactingParcelFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/particle-filter.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip particle-filter.zip
cd particle-filter
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `topoSet` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| `createBaffles -overwrite` | 把指定内部面转成成对边界，形成挡板或叶片表面。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 过滤区阻力

文件：`constant/fvOptions`。本段设置过滤区阻力。

```foam
filter1
{
    type            explicitPorositySource;

    explicitPorositySourceCoeffs
    {
        selectionMode   cellZone;
        cellZone        filter;

        type            DarcyForchheimer;

        d   (500000 -1000 -1000);
        f   (0 0 0);

        coordinateSystem
        {
            origin  (0 0 0);
            e1      (1 0 0);
            e2      (0 1 0);
        }
    }
}
```

`cellZone filter` 指定阻力区域，`d` 和局部坐标系共同规定各方向黏性阻力。检查选区范围和方向后，才能将压差变化归因于阻力系数。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/reactingParcelFoam/filter/constant/fvOptions)。

### 2. 液滴注入状态

文件：`constant/reactingCloud1Properties`。本段设置液滴注入状态。

```foam
model1
{
    type            reactingMultiphaseLookupTableInjection;
    massTotal       1e-2;
    parcelBasisType mass;
    SOI             0.5;
    inputFile       "parcelInjectionProperties";
    duration        1.0;
    parcelsPerSecond 250;
    randomise       true;
}
```

查表注入文件逐项给出位置、速度、温度和粒径，`massTotal` 规定整个注入阶段的质量。该方式可组织多个入口或不同液滴状态。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/reactingParcelFoam/filter/constant/reactingCloud1Properties)。

### 3. 反弹、流出与沉积

文件：`constant/reactingCloud1Properties`。本段设置反弹、流出与沉积。

```foam
localInteractionCoeffs
{
    patches
    (
        "(walls|cyc.*)"
        {
            type        rebound;
        }

        "(inlet|outlet)"
        {
            type escape;
        }
    );

    writeToFile     yes;
}
```

壁面 `rebound` 计算反弹，进出口 `escape` 记录离开。研究沉积时将目标滤面设为 `stick`，并保留其他壁面的独立统计。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/reactingParcelFoam/filter/constant/reactingCloud1Properties)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.reactingParcelFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `reactingParcelFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `0` |
| `endTime` | `5` |
| `deltaT` | `0.001` |
| `writeControl` | `adjustable` |
| `writeInterval` | `0.1` |
| `adjustTimeStep` | `yes` |
| `maxCo` | `1.0` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选流体内部与液滴，点击 **Apply**。先选择最后一个已写出的时刻，以 `T` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

利用 `pressureDifference` 读取过滤段压差，观察扩张段内液滴轨迹、温度和直径。统计入口质量、出口液滴质量、域内存量及进入气相的蒸发水分，使各项质量去向闭合。

先改变多孔阻力系数，分析压降与流量分布；再保持流场参数一致，比较初始粒径和壁温对蒸发的影响。采用黏附边界后，增加沉积质量曲线，将捕集与蒸发分别计入收支。

> **熊猫说：** 多孔阻力作用于气相动量，液滴捕集由颗粒相互作用模型定义。评价过滤效率时，使用明确的沉积质量统计。

## 文件与来源

- [完整算例包](/downloads/engineering/particle-filter.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/lagrangian/reactingParcelFoam/filter)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
