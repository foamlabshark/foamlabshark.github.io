计算给定流量下的过堰水位和流速，分析堰顶加速及下游自由液面。

## 工程场景与计算目标

溢流堰依靠上游水头输送来水，流体越过堰顶后加速并在下游重新分配动能。上游壅水、堰顶压力和下游高速区分别关系到防洪水位、结构受力与冲刷。评价过流能力需要将流量与这些局部过程联系起来。

算例用结构网格描述堰体纵断面，以 VOF 追踪自由液面。入口直接规定体积流量，速度随入口水相覆盖面积调整，水位由来水量、堰体及下游条件共同形成。通过工况比较建立水头—流量关系。

## 几何、尺寸与基准工况

![溢流堰的水面与过流能力：配套模型与基准输入](/assets/engineering/weir-overflow-geometry.webp)

计算域沿 x 从 −18 m 延伸至 90 m，高 54 m、展向宽 1 m。堰顶高 30 m，水平段位于 x = 0～15 m，下游斜坡在 x = 30 m 接到底部。几何直接写入分块网格。

模型与配置来源：[OpenFOAM v2512 · multiphase/interFoam/RAS/weirOverflow](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/weirOverflow)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 入口流量 | 75 m³/s，对应 1 m 模型宽度 | `0.orig/include/initialConditions` |
| 水密度、运动黏度 | 1000 kg/m³、10⁻⁶ m²/s | `constant/transportProperties` |
| 重力方向 | 负 y | `constant/g` |
| 界面时间步约束 | maxAlphaCo = 0.2 | `system/controlDict` |

## 求解方法与物理模型

入口流量满足 $Q=\int_A\alpha_w\mathbf U\cdot\mathbf n\,dA$。以局部水深 $h$ 定义的 Froude 数为 $Fr=U/\sqrt{gh}$，它区分重力波能够向上游传播的亚临界流与超临界流。过堰能力可通过 $Q=C\,b\sqrt{g}\,H^{3/2}$ 的量纲形式整理，其中系数随堰型和水头定义而变化。

本例使用 `interFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/weir-overflow.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip weir-overflow.zip
cd weir-overflow
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `setFields` | 按几何区域设置初始相分数、组分或温度。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 给定流量入口

文件：`0.orig/U`。本段设置给定流量入口。

```foam
inlet
{
    type            variableHeightFlowRateInletVelocity;
    flowRate        $inletFlowRate;
    alpha           alpha.water;
    value           uniform (0 0 0);
}
```

`variableHeightFlowRateInletVelocity` 读取 `alpha.water`，按实际水相覆盖面积分配速度，使水流量满足设定值。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/weirOverflow/0.orig/U)。

### 2. 入口水相与大气开口

文件：`0.orig/alpha.water`。本段设置入口水相与大气开口。

```foam
inlet
{
    type            variableHeightFlowRate;
    lowerBound      0;
    upperBound      1;
    value           uniform 0;
}
```

入口相分数随液位状态确定，取值限制在 0～1。顶部大气开口允许空气进出，使水面能够升降。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/weirOverflow/0.orig/alpha.water)。

### 3. 起始水体分布

文件：`system/setFieldsDict`。本段设置起始水体分布。

```foam
defaultFieldValues
(
    volScalarFieldValue alpha.water 0
);

regions
(
    boxToCell
    {
        box (-100 0 -100) (0 20 100);

        fieldValues
        (
            volScalarFieldValue alpha.water 1
        );
    }
);
```

`setFields` 定义上、下游起始水体，控制启动过程。达到稳定后，水位由持续流量和边界条件决定。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/weirOverflow/system/setFieldsDict)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.interFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `interFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `latestTime` |
| `startTime` | `0` |
| `endTime` | `60` |
| `deltaT` | `0.001` |
| `writeControl` | `adjustable` |
| `writeInterval` | `2` |
| `adjustTimeStep` | `on` |
| `maxCo` | `0.2` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选堰前和堰后水域，点击 **Apply**。先选择最后一个已写出的时刻，以 `alpha.water` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

提取 `alpha.water = 0.5` 水面，在纵断面输出水位、速度和 Froude 数。上游水头在远离堰顶加速区的位置测量，与流量配对形成过流曲线；下游重点记录水舌落点及高速区。

比较 0.8、1 和 1.2 倍基准流量下的壅水与下游速度。改变下游水位时重新区分自由出流和淹没出流，模型宽度变化则按相同单宽流量换算总流量。

> **熊猫说：** 1 m 宽模型中的 75 m³/s 对应单宽流量 75 m²/s。保持断面水力条件时，总流量与模型宽度同比变化。

## 文件与来源

- [完整算例包](/downloads/engineering/weir-overflow.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/multiphase/interFoam/RAS/weirOverflow)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
