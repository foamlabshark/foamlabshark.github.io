建立低压医用供气歧管的支路平衡模型，分析末端支路阻力与入口流量对支路供气偏差和总管压降的影响。

## 工程场景与计算目标

多支路医用供气部件需要在有限压差下稳定分配气体。分流点附近的局部损失与末端管路阻力共同影响供气量，几何对称并不总能抵消总管沿程压力变化。设计阶段可先用低速单相模型比较部件自身的水力特性。

本例设置一个供气总管和三条出口支路，采用氧气等效密度与黏度。各出口压力相同，入口流量由速度和截面积确定。计算比较中间支路收窄前后的流量偏差，再改变总体积流量，观察分配是否随流量发生变化。

## 几何、尺寸与基准工况

几何由 `design.json` 中的尺寸和位置生成，采用低压供气总管与三路终端接口。坐标与尺寸均使用 m，流向由边界速度向量确定。

![医用气体多支路供气分配的结构分区与流动方向](/assets/engineering/medical-oxygen-splitter-geometry.webp)

| 参数 | 基准值 | 含义 |
| --- | --- | --- |
| 计算域外包尺寸 | 0.1 × 0.052 × 0.012 m | 实际计算空间由流体块体并集确定 |
| 流体密度 | 1.3 kg/m³ | 惯性、压差换算和质量流量 |
| 运动黏度 | 1.59e-05 m²/s | 分子黏性输运 |
| 基础网格 | 12,096 单元 | 默认 MESH_REFINE=2 的设计网格 |

几何各部分的坐标范围如下。流体块体先合并，再从中划分导热固体或扣除障碍物；因此相邻、相交块体不会重复占据体积。

| 部件 | x 范围 / m | y 范围 / m | z 范围 / m |
| --- | --- | --- | --- |
| 流体区域1 | 0～0.1 | 0～0.012 | 0～0.012 |
| 流体区域2 | 0.02～0.028 | 0.012～0.052 | 0～0.012 |
| 流体区域3 | 0.046～0.054 | 0.012～0.052 | 0～0.012 |
| 流体区域4 | 0.072～0.08 | 0.012～0.052 | 0～0.012 |

| 边界名称 | 作用 | 基准条件 |
| --- | --- | --- |
| `inlet` | 入口 | U = (0.5 0 0) m/s |
| `branch1` | 出口 | 压力参考值 0 |
| `branch2` | 出口 | 压力参考值 0 |
| `branch3` | 出口 | 压力参考值 0 |

## 物理模型与求解方法

不可压缩流动满足质量守恒与动量守恒：

\[
\nabla\cdot\mathbf U=0,\qquad
\rho\left(\frac{\partial\mathbf U}{\partial t}+\mathbf U\cdot\nabla\mathbf U\right)
=-\nabla p+\nabla\cdot\boldsymbol\tau+\mathbf f.
\]

其中，\(\mathbf U\) 为速度，\(p\) 为物理压力，\(\boldsymbol\tau\) 为黏性应力，\(\mathbf f\) 为单位体积外力。连续性方程约束各截面的流量收支；动量方程描述压力、黏性作用和外力如何改变速度。

本例使用 `simpleFoam`，通过稳态迭代求解，日志中的 `Time` 表示迭代序号。基准采用层流模型，黏性应力由分子黏度确定。

## 配置文件与网格建立

[下载完整算例与配置代码](/downloads/engineering/medical-oxygen-splitter.zip)。解压目录中已提供 `0.orig/`、`constant/`、`system/` 和几何数据，`build_case.py` 根据 `design.json` 重建相同输入；生成程序只使用 Python 标准库。

| 文件或目录 | 操作与用途 |
| --- | --- |
| `design.json` | 修改部件坐标、流体物性、速度或热功率；随后重新生成字典 |
| `geometry/model.obj` | 查看几何分区；曲线叶道以 blockMesh 圆弧为准 |
| `system/blockMeshDict` | 多块六面体网格的顶点、单元数与边界面 |
| `0.orig/` | 初始场和边界条件；建网格时复制到 `0/` |
| `constant/` | 物性、物理模型与区域设置 |
| `system/fvSchemes`、`system/fvSolution` | 离散格式、线性求解和耦合控制 |
| `Allmesh`、`Allsolve` | 分别完成网格准备与求解、结果提取 |

多块网格在肋片边缘、支路开口和分区界面处共享坐标平面，使边界与几何位置一致。默认加密级别为 2，薄通道与窄缝另外保留最低单元层数。

## 关键配置与解读

以下条目取自本页下载包的同名文件，几何和边界名称与上表对应。

### `0.orig/U`

```foam
boundaryField
{
    inlet { type fixedValue; value uniform (0.5 0 0); }
    walls { type noSlip; }
    branch1 { type pressureInletOutletVelocity; value uniform (0 0 0); }
    branch2 { type pressureInletOutletVelocity; value uniform (0 0 0); }
    branch3 { type pressureInletOutletVelocity; value uniform (0 0 0); }
}
```

固定速度入口与已知截面积共同确定流量。出口采用 `pressureInletOutletVelocity`，使速度与边界通量协调；实体表面为无滑移壁面。MRF 中的旋转壁面速度由旋转区处理。

### `0.orig/p`

```foam
boundaryField
{
    inlet { type zeroGradient; }
    walls { type zeroGradient; }
    branch1 { type fixedValue; value uniform 0; }
    branch2 { type fixedValue; value uniform 0; }
    branch3 { type fixedValue; value uniform 0; }
}
```

`simpleFoam` 中该字段是运动学压力，量纲为 m²/s²。出口参考值为 0，物理压差应乘以流体密度；速度入口使用零法向梯度，让压力由流量约束形成。

### `constant/turbulenceProperties`

```foam
simulationType laminar;
```

`simulationType` 决定是否求解湍流闭合模型。`RAS` 工况使用 SST 模型及随包的 `k`、`omega`、`nut` 字段；`laminar` 工况只使用物性文件中的分子黏度。


## 运行与计算检查

在 Linux 中加载 OpenCFD OpenFOAM v2512，然后进入解压目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
cd medical-oxygen-splitter
bash Allmesh
bash Allsolve
```

安装位置不同，只需调整第一行环境路径。`Allmesh` 生成输入和网格，复制初始场并检查网格质量；`Allsolve` 调用 `simpleFoam`，运行后将监测记录整理到 `analysis/`。各阶段的详细信息分别写入 `log.blockMesh`、`log.checkMesh` 和 `log.simpleFoam`，遇到错误时脚本会停止并显示对应日志末尾。

修改工况时，先在新解压目录中编辑 `design.json`，再执行 `Allmesh`。网格生成以后，边界调整应写入 `0/`；如果重新生成网格，程序会再次使用参数文件和 `0.orig/`。保留各工况独立目录，便于核对尺寸、物性与结果。

先检查残差是否持续下降，再查看流量、压差和温度或转矩是否趋于稳定。不同方程的残差尺度不同，采用工程监测量的稳定性判断迭代是否足够。

## 结果提取与工程分析

先核对三个出口流量之和，再比较每支路相对平均值的偏差。局部收窄后查看该支路入口与出口之间的压力损失，区分几何阻力和总管分配的作用。最后将入口流量与供气压差整理为曲线，作为连接末端管路后计算支路平衡的部件数据。

在 ParaView 中打开 `case.foam`，选择最后一个已写出时刻。用 **Slice** 建立上述截面，用 **Plot Over Line** 提取沿线变化；流量计算使用速度的截面法向分量，配合 **Integrate Variables** 积分。输出表格时使用 **Save Data**，工况比较保持截面位置、色标和平均方式相同。

`analysis/monitor-history.csv` 保存监测对象的时间或迭代历史，`analysis/metrics.json` 整理边界流量、压力和温度等可用指标。内部通道分流、局部方差或单个壁面载荷按本节给出的选区继续提取。边界流量采用外法向为正，入口一般为负，出口一般为正。

多个出口的流量均匀性可以用离散系数评价：

\[
\bar Q=\frac{1}{N}\sum_{i=1}^{N}Q_i,\qquad
C_V=\frac{\sqrt{N^{-1}\sum_{i=1}^{N}(Q_i-\bar Q)^2}}{\bar Q}.
\]

\(C_V\) 越小，所选各支路的流量越接近。只有面积与任务相当的支路才适合直接用相同目标流量比较；截面积或需求不同的支路，应分别采用其设计流量作为参照。

## 参数比较与网格收敛

缩小中间支路至 6 mm 宽，比较各支路流量；将入口速度设为 0.25、0.50、0.75 m/s，分析分配随流量的变化。

先完成基准工况，再每次改变一个设计因素。记录几何尺寸、入口总流量、支路供气偏差和总管压降，将性能变化与流场结构对应。对选定方案再做网格比较：

```bash
MESH_REFINE=4 bash Allmesh
bash Allsolve
```

在新的解压目录执行上述命令，各方向相对默认级别增加一倍单元数。比较时使用相同物性、边界条件及结果提取位置，检查主要工程量随网格变化的幅度。自由液面案例还需减小 `maxDeltaT`，比较水位幅值和相位；示踪混合案例需同时检查浓度界面的数值扩散。

> **熊猫说：** 流量由法向速度积分得到。比较方案时保持所要求的流量或压差一致，才能解释阻力变化。

## 配套代码与资料

- [下载几何、完整配置、运行及分析代码](/downloads/engineering/medical-oxygen-splitter.zip)。`VALIDATION.json` 和 `validation/` 保存 v2512 网格检查与短程启动记录，`files.sha256` 可用于核对文件完整性。
- [OpenFOAM 用户指南](https://www.openfoam.com/documentation/user-guide)：算例结构、网格与求解流程。
- [OpenFOAM v2512 源码文档](https://api.openfoam.com/2512/)：字段、边界和模型实现。

[返回实际工程应用](/topics/engineering/)
