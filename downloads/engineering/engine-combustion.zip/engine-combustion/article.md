采用 KIVA 气缸网格计算活塞运动和预混火焰传播，分析点火、壁面换热与缸压变化。

## 工程场景与计算目标

发动机压缩冲程改变混合气的密度和温度，点火后的热释放进一步抬高缸压。燃烧速率与活塞运动的相位关系决定压力峰值出现的转角，并影响循环做功。缸盖、缸套和活塞的散热又会改变气体能量收支。

算例将 KIVA 网格转换为 OpenFOAM 网格，使用 `XiEngineFoam` 求解预混燃烧。未燃气体和燃烧产物由燃烧进度变量区分，火焰褶皱模型描述湍流对传播速度的影响。主要评价量为缸压—曲轴转角曲线、燃烧进度和 p–V 循环功。

## 几何、尺寸与基准工况

![KIVA 发动机的活塞运动与预混燃烧：配套模型与基准输入](/assets/engineering/engine-combustion-geometry.webp)

原始网格保存在 `otape17`，通过 `kivaToFoam` 导入。发动机缸径为 92 mm，行程为 84.23 mm，连杆长度为 147 mm，余隙为 1.15 mm，转速为 1500 r/min。初始场目录 `-180` 对应起始曲轴转角。

模型与配置来源：[OpenFOAM v2512 · combustion/XiEngineFoam/kivaTest](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/combustion/XiEngineFoam/kivaTest)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 转速 | 1500 r/min | `constant/engineGeometry` 的 `rpm` |
| 初始气体温度 | 373 K | `-180/T` |
| 活塞温度 | 433 K | `-180/T` 的 `piston` |
| 缸盖温度 | 383 K | `-180/T` 的 `cylinderHead` |

## 求解方法与物理模型

转角与物理时间满足 $d\theta/dt=6n$，其中 $\theta$ 的单位为度，$n$ 的单位为 r/min。转速越高，同一转角间隔对应的燃烧时间越短。

火焰褶皱因子 $\Xi$ 表征湍流引起的火焰面积增加，有效传播速度可表示为 $S_T=\Xi S_u$。燃烧热释放与压力功共同影响气体能量，循环指示功由 $W_i=\oint p\,dV$ 得到。

本例使用 `XiEngineFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/engine-combustion.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip engine-combustion.zip
cd engine-combustion
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `kivaToFoam -file otape17` | 将随包 KIVA 发动机网格转换为 OpenFOAM 网格。 |

本例的起始场位于 `-180/`，修改初始场时直接编辑该目录。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 发动机尺寸与运动

文件：`constant/engineGeometry`。本段设置发动机尺寸与运动。

```foam
engineMesh      layered;

conRodLength    conRodLength [0 1 0 0 0 0 0] 0.147;

bore            bore [0 1 0 0 0 0 0] 0.092;

stroke          stroke [0 1 0 0 0 0 0] 0.08423;

clearance       clearance [0 1 0 0 0 0 0] 0.00115;

rpm             rpm [0 0 -1 0 0 0 0] 1500;
```

缸径、行程和连杆长度规定瞬时容积与活塞运动。修改发动机尺寸时，运动参数与 KIVA 网格几何应同时更新，以保持壁面位置和容积计算一致。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/combustion/XiEngineFoam/kivaTest/constant/engineGeometry)。

### 2. 各部件壁温

文件：`-180/T`。本段设置各部件壁温。

```foam
boundaryField
{
    piston
    {
        type            fixedValue;
        value           uniform 433;
    }

    liner
    {
        type            fixedValue;
        value           uniform 373;
    }

    cylinderHead
    {
        type            fixedValue;
        value           uniform 383;
    }
}
```

活塞、缸套和缸盖分别设置壁温，以描述各部件不同的散热条件。比较点火相位或转速时，保持同一壁面模型，可将缸压差异归因于目标工况。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/combustion/XiEngineFoam/kivaTest/-180/T)。

### 3. 点火与火焰传播

文件：`constant/combustionProperties`。本段设置点火与火焰传播。

```foam
ignite          yes;

ignitionSites
(
    {
        location        (0.03 0 0.091);
        diameter        0.002;
        start           -15;
        duration        20;
        strength        4;
    }
);

ignitionSphereFraction 1;

ignitionThickness ignitionThickness [0 1 0 0 0 0 0] 0;

ignitionCircleFraction 1;

ignitionKernelArea ignitionKernelArea [0 2 0 0 0 0 0] 0;
```

点火区和作用时间确定火焰起始过程，`XiModel`、层流燃烧速度关联式及燃料组分控制后续传播。点火区应落在气体单元内，其位置与作用时间共同决定初始火焰范围。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/combustion/XiEngineFoam/kivaTest/constant/combustionProperties)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.XiEngineFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `XiEngineFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。发动机时间控制使用曲轴转角；日志中的转角与物理秒数通过转速换算。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `-180` |
| `endTime` | `60` |
| `deltaT` | `0.25` |
| `writeControl` | `runTime` |
| `writeInterval` | `5` |
| `adjustTimeStep` | `no` |
| `maxCo` | `0.2` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选气缸内部，点击 **Apply**。先选择最后一个已写出的时刻，以 `p` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

以曲轴转角为横坐标绘制平均缸压、温度和燃烧进度，确定峰值压力相对于上止点的位置。结合活塞运动与火焰面动画，分析压缩和燃烧的相位关系；积分 p–V 回线获得指示功，并与燃料热输入比较。

工况比较分为点火时刻和转速两组。点火研究保持转速及混合气组成不变，转速研究保持点火角不变。后者同时改变每度曲轴转角所对应的物理时间，应据此解释燃烧持续期和压力峰值的移动。

> **熊猫说：** 缸压采用热力学压力，单位为 Pa。绘制压力曲线和积分 p–V 功时，直接使用这一压力及对应气缸体积。

## 文件与来源

- [完整算例包](/downloads/engineering/engine-combustion.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/combustion/XiEngineFoam/kivaTest)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
