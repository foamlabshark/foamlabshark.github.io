模拟欠膨胀气体射流，计算喷口外膨胀、激波胞与中心线压力变化。

## 工程场景与计算目标

气体离开喷口时若静压仍高于环境压力，将继续向外膨胀。膨胀与压缩过程交替形成激波胞，使速度、温度和压力沿轴向振荡。该结构关系到高速喷吹、推进和泄放设备的流动载荷及下游作用范围。

算例采用 Ladenburg 喷流的公开条件，在喷口出口截面给定静压、静温和速度，由 `rhoCentralFoam` 计算外部射流。配套初始场已包含发展后的流动，可据此检查边界、激波位置和压力恢复，再研究压比与网格影响。

## 几何、尺寸与基准工况

![Ladenburg 喷口的欠膨胀射流：配套模型与基准输入](/assets/engineering/ladenburg-jet-geometry.webp)

轴对称楔形域长 30 mm、外半径 10 mm，喷口半径为 5 mm。轴向 60 个单元，径向共 20 个单元。字典中的毫米坐标统一转换为米，喷口、外围环境和下游出口分别设置边界。

模型与配置来源：[OpenFOAM v2512 · compressible/rhoCentralFoam/LadenburgJet60psi](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/compressible/rhoCentralFoam/LadenburgJet60psi)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 喷口速度 | 315.6 m/s | `0.orig/U.gz/inlet` |
| 喷口静压、静温 | 271724 Pa、247.1 K | `0.orig/p.gz`、`T.gz` |
| 环境压力、温度 | 101325 Pa、297 K | 外围边界 |
| 喷口直径 | 10 mm | `system/blockMeshDict` |
| 气体模型 | 理想空气，Cp = 1004.5 J/(kg·K) | `constant/thermophysicalProperties` |

## 求解方法与物理模型

欠膨胀程度首先由喷口静压与环境压力之比 $p_e/p_\infty$ 描述。气流在膨胀中将焓转化为动能，满足总焓关系 $h_0=h+U^2/2$。局部马赫数 $Ma=U/\sqrt{\gamma RT}$ 随压力和温度变化，激波区域则出现动能向内能的不可逆转化。

本例使用 `rhoCentralFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/ladenburg-jet.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip ladenburg-jet.zip
cd ladenburg-jet
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 喷口静压

文件：`0.orig/p.gz`。本段设置喷口静压。

```foam
inlet
{
    type            fixedValue;
    value           uniform 271724;
}
```

该入口位于喷口出口截面，固定值为截面静压。上游气罐总压需通过喷管膨胀关系转换后，才能与此处速度和温度配套。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/compressible/rhoCentralFoam/LadenburgJet60psi/0.orig/p.gz)。

### 2. 喷口温度与总焓

文件：`0.orig/T.gz`。本段设置喷口温度与总焓。

```foam
inlet
{
    type            fixedValue;
    value           uniform 247.1;
}
```

247.1 K 为喷口静温，与速度共同确定总焓。其低于环境温度反映气体在上游加速时的膨胀降温。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/compressible/rhoCentralFoam/LadenburgJet60psi/0.orig/T.gz)。

### 3. 下游透射边界

文件：`0.orig/p.gz`。本段设置下游透射边界。

```foam
    outlet
    {
        type            waveTransmissive;
        field           p;
        psi             thermo:psi;
        gamma           1.4;
        fieldInf        101325;
        lInf            0.025;
        value           nonuniform List<scalar>
20
(
36562.2300054432
37796.3395360008
38604.5885832062
40282.1012142189
43735.7987076211
50011.3827879648
59398.8682675419
68240.1422235396
76860.7301618588
83575.1015338783
90186.4734188025
93586.7407655955
98259.2964252222
99393.6110290325
101021.715576502
101089.698393948
101353.834392321
101333.992212855
101507.234628921
101271.59983682
)
;
    }
```

`waveTransmissive` 减小下游压力波反射，`fieldInf` 给出远场压力，`lInf` 给出恢复长度尺度。结合出口附近梯度判断主要射流结构是否完整包含在域内。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/compressible/rhoCentralFoam/LadenburgJet60psi/0.orig/p.gz)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.rhoCentralFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `rhoCentralFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `latestTime` |
| `startTime` | `0` |
| `endTime` | `2e-05` |
| `deltaT` | `1e-10` |
| `writeControl` | `adjustable` |
| `writeInterval` | `2e-05` |
| `adjustTimeStep` | `yes` |
| `maxCo` | `0.5` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选喷口与外部空间，点击 **Apply**。先选择最后一个已写出的时刻，以 `p` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

沿中心线输出压力、密度、温度与马赫数，将压力峰谷与激波胞位置对应。密度梯度用于显示膨胀和压缩结构，并检查外围和出口附近的反射。

压比研究从一致的总态或喷口出口状态确定速度、静压、静温。轴向和径向加密后比较主要压力峰的位置与幅值，评价对激波结构的空间分辨率。

> **熊猫说：** 工况名称中的 60 psi 为原始标识。边界文件采用换算后的静态量，单位分别为 Pa、K 和 m/s。

## 文件与来源

- [完整算例包](/downloads/engineering/ladenburg-jet.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/compressible/rhoCentralFoam/LadenburgJet60psi)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
