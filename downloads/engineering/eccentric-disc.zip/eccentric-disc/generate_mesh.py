"""Analytic eccentric seal/back-cavity mesh, sliding cylindrical AMI."""
from pathlib import Path
from collections import defaultdict
import math,json,re,shutil
from build_case import dictionary,write,vec,scalar_field,schemes
from case_helpers import common,fieldset
ROOT=Path(__file__).resolve().parent
N=64;E=.0005;R=.1495;RI=.15025;RC=.1505;RO=.0475
def rd(a):return E*math.cos(a)+math.sqrt(R*R-E*E*math.sin(a)**2)
def ringmesh(root,rotor):
    points=[];index={};blocks=[];edges={};patches=defaultdict(list)
    def radius(k,a):return [RO,rd(a),RI,RC][k]
    def point(k,j,z):
        j%=N;t=2*math.pi*j/N;r=radius(k,t);p=(r*math.cos(t),r*math.sin(t),z)
        key=(k,j,z)
        if key not in index:index[key]=len(points);points.append(p)
        return index[key]
    configs=[(1,2,-.01,0,8,16),(0,1,0,.004,40,8),(1,2,0,.004,8,8)] if rotor else [(2,3,-.01,0,6,16),(2,3,0,.004,6,8)]
    for ka,kb,z0,z1,nr,nz in configs:
      for j in range(N):
        ids=[point(ka,j,z0),point(kb,j,z0),point(kb,j+1,z0),point(ka,j+1,z0),point(ka,j,z1),point(kb,j,z1),point(kb,j+1,z1),point(ka,j+1,z1)]
        blocks.append('hex '+vec(ids)+(' rotating ' if rotor else ' ')+vec([nr,3,nz])+' simpleGrading ('+('0.025' if ka==0 else '1')+' 1 1)')
        for k,z,a,b in [(ka,z0,ids[0],ids[3]),(kb,z0,ids[1],ids[2]),(ka,z1,ids[4],ids[7]),(kb,z1,ids[5],ids[6])]:
            angle=2*math.pi*(j+.5)/N;r=radius(k,angle)
            edges[tuple(sorted([a,b]))]=f'arc {a} {b} '+vec([r*math.cos(angle),r*math.sin(angle),z])
        if rotor and ka==0:patches['outlet'].append([ids[i] for i in [0,4,7,3]])
        if rotor and ka==1 and z0<0:patches['disc'].append([ids[i] for i in [0,4,7,3]])
        if not rotor:patches['backgroundCut'].append([ids[i] for i in [0,4,7,3]])
        if rotor and kb==2:patches['rotorCut'].append([ids[i] for i in [1,2,6,5]])
        if not rotor:patches['casing'].append([ids[i] for i in [1,2,6,5]])
        if z0<0:patches['inlet'].append([ids[i] for i in [0,3,2,1]])
        if rotor and ka==0:patches['disc'].append([ids[i] for i in [0,3,2,1]])
        if z1>0:patches['casing'].append([ids[i] for i in [4,5,6,7]])
    body='scale 1;\nvertices (\n'+'\n'.join(vec(p) for p in points)+'\n);\nblocks (\n'+'\n'.join(blocks)+'\n);\nedges (\n'+'\n'.join(edges.values())+'\n);\nboundary (\n'
    for name,faces in patches.items():body+=name+' { type '+('wall' if name in ['disc','casing'] else 'patch')+'; faces (\n'+'\n'.join(vec(f) for f in faces)+'\n); }\n'
    dictionary(root,'system/blockMeshDict',body+');\nmergePatchPairs ();')

def main():
    ringmesh(ROOT,True);ringmesh(ROOT/'background',False)
    fieldset(ROOT,{'inlet':'inlet','outlet':'outlet','disc':'wall','casing':'wall','rotorAMI':'slip','backgroundAMI':'slip'},[0,0,1.060825],.01688,100)
    for f in ['U','p','k','omega','nut']:
        p=ROOT/'0.orig'/f;s=p.read_text()
        for name in ['rotorAMI','backgroundAMI']:s=re.sub(name+r'\s*\{[^}]+\}',name+' { type cyclicAMI; }',s)
        if f=='U':s=s.replace('disc { type noSlip; }','disc { type movingWallVelocity; value uniform (0 0 0); }')
        p.write_text(s,newline='\n')
    dictionary(ROOT,'constant/transportProperties','transportModel Newtonian; nu [0 2 -1 0 0 0 0] 1e-6;')
    dictionary(ROOT,'system/createPatchDict','pointSync false;\npatches (\n'+'\n'.join(f'{{ name {a}; patchInfo {{ type cyclicAMI; neighbourPatch {b}; transform noOrdering; matchTolerance 0.0001; }} constructFrom patches; patches ({a.replace("AMI","Cut")}); }}' for a,b in [('rotorAMI','backgroundAMI'),('backgroundAMI','rotorAMI')])+'\n);')
    dictionary(ROOT,'constant/dynamicMeshDict','''dynamicFvMesh dynamicMotionSolverFvMesh;
motionSolverLibs (fvMotionSolvers);
motionSolver solidBody;
cellZone rotating;
solidBodyMotionFunction rotatingMotion;
origin (0 0 0);
axis (0 0 1);
omega 41.88790205;''')
    schemes(ROOT,unsteady=True)
    p=ROOT/'system/fvSolution';s=p.read_text().replace('p_rgh','p');s=s.replace('PIMPLE {','PIMPLE { correctPhi true; checkMeshCourantNo true;');p.write_text(s,newline='\n')
    dictionary(ROOT,'system/controlDict','''application pimpleFoam;
startFrom startTime; startTime 0; stopAt endTime; endTime 0.45;
deltaT 1e-5; adjustTimeStep yes; maxCo 0.3; maxDeltaT 1e-5;
writeControl adjustableRunTime; writeInterval 0.00125;
purgeWrite 0; writeFormat ascii; writePrecision 10; writeCompression off;
timeFormat general; timePrecision 10; runTimeModifiable true;
functions
{
discLoads { type forces; libs (forces); patches (disc); rho rhoInf; rhoInf 997.07; CofR (0 0 0); writeControl timeStep; writeInterval 1; }
inflow { type surfaceFieldValue; libs (fieldFunctionObjects); regionType patch; name inlet; operation sum; fields (phi); writeFields false; }
outflow { type surfaceFieldValue; libs (fieldFunctionObjects); regionType patch; name outlet; operation sum; fields (phi); writeFields false; }
}''')
    for f in ['controlDict','fvSchemes','fvSolution']:shutil.copyfile(ROOT/'system'/f,ROOT/'background/system'/f)
    common(ROOT,'pimpleFoam','run background blockMesh -case background\nrun mergeMeshes mergeMeshes . background -overwrite\nrun createPatch createPatch -overwrite\n')
    dictionary(ROOT,'system/meshQualityDict','#includeEtc "caseDicts/meshQualityDict"\nminDeterminant 1e-6; minFaceWeight 0.05; maxNonOrtho 65;')
    write(ROOT,'mesh-design.json',json.dumps(dict(segments=N,angular_cells=3,radial_back_cavity_cells=40,radial_rotor_gap_cells=8,radial_background_gap_cells=6,axis=[0,0,0],initial_centre=[E,0,0],interface_radius=RI),indent=2))
    print('Prepared eccentric AMI case')
if __name__=='__main__':main()
