按公开水轮机背腔试验尺寸建立偏心圆盘模型，求解圆盘绕偏离圆心的固定轴旋转时的窄间隙流动、力矩和周期载荷。

## 工程场景：很小的偏心为什么会改变转子载荷

水轮机转轮、泵叶轮和密封腔中的旋转部件，与静止壳体之间通常存在间隙。间隙中的液体一方面受转动壁面拖曳，另一方面受到泄漏压差驱动。当转子偏心时，周向间隙不再均匀，局部流动阻力和压力随位置变化，形成作用于转子的非对称载荷。

载荷不仅包括绕主轴的阻力矩，还包括径向力和使转子倾斜的力矩。这些量与转子振动相互作用：流体可能消耗振动能量，也可能在某些运动相位向振动输入能量。因此，电机所需的平均转矩和转子的动态稳定性是两个相关但不同的问题。

本案例以 Song 等开展的 Francis 水轮机背腔转子试验为几何依据。原装置以圆盘表示转轮背部，水从外周间隙进入背腔，再向内侧流出；试验分别控制圆盘自转与圆心绕行。公开论文给出了圆盘、壳体、间隙、偏心距及转速，能够建立带实际尺度的三维流动模型。

这里选取自转角速度与圆心绕行角速度相等的同步工况。圆盘上每一点都等效为绕同一条固定偏心轴作刚体旋转，正是本案例所需的运动。圆心会绕轴走一圈，而不是停在容器内某个偏置位置原地自转。

![偏心圆盘、圆心轨迹与水轮机背腔间隙](/assets/engineering/eccentric-disc-geometry.webp)

尺寸依据：[Song 等，International Journal of Fluid Machinery and Systems 3(1), 67–79，2010，第 2 节及图 3](https://www.jstage.jst.go.jp/article/ijfms/3/1/3_1_67/_article)。圆盘厚度和详细试验说明见 [Journal of Fluids Engineering 132, 071102](https://doi.org/10.1115/1.4001802)。

## 尺寸、计算范围与边界

| 参数 | 取值 | 用途 |
| --- | --- | --- |
| 圆盘半径 R | 149.5 mm | 外径为 299 mm |
| 圆盘厚度 | 10 mm | 保留三维端面和外圆柱面 |
| 平均径向间隙 c₁ | 1 mm | 静止壳体内半径 150.5 mm |
| 轴向背腔间隙 c₂ | 4 mm | 基准工况；再比较 2 mm 与 6 mm |
| 内侧流出半径 | 47.5 mm | 背腔内侧截断边界 |
| 偏心距 e | 0.5 mm | 圆心相对固定旋转轴的距离 |
| 转速 n | 400 r/min | 自转和圆心绕行同速、同向 |
| 工作介质 | 水 | 本节取 ρ=997.07 kg/m³、ν=1.0×10⁻⁶ m²/s |

计算域取外周密封间隙与盘后径向背腔。外部供水管路用入口条件代替，内侧在 47.5 mm 半径处设置压力出口。这样可以保留决定背腔压力分布的两段窄间隙，同时把计算资源集中在圆盘附近。模型资料包分别给出圆盘表面、截面尺寸和边界位置。

基准工况采用论文中的无预旋输入，并以名义间隙流速与叶尖速度之比 \(v_l/U_T=0.170\) 设定泄漏流量。这里

\[
U_T=\omega R,\qquad
Q=2\pi R c_1 v_l.
\]

400 r/min 对应 \(\omega=41.8879\ {\rm rad/s}\)，叶尖速度约 6.262 m/s。由此计算的名义流量约为 1.00×10⁻³ m³/s，即约 60 L/min。该流量施加在外周供水截面，背腔内侧由压力条件决定流出。

## 运动学：转轴必须放在正确位置

取固定旋转轴经过 O=(0,0,0)，方向为 z；初始圆心 C₀=(0.0005,0,0)。角速度恒定时，圆心轨迹为

\[
\mathbf C(t)=
\begin{pmatrix}e\cos\omega t\\e\sin\omega t\\0\end{pmatrix}.
\]

圆盘表面任意一点的速度为

\[
\mathbf U_w(\mathbf x,t)=\boldsymbol\omega\times(\mathbf x-\mathbf O).
\]

如果把旋转原点误填成 C₀，圆心将保持静止，得到的就是另一种运动。资料包的 `motion_check.csv` 给出四分之一转等时刻的圆心坐标，可用于对照网格动画。400 r/min 时周期 T=0.15 s，经过 0.0375 s，圆心应到达 (0,0.0005,0)。

最小径向间隙为 \(c_{\min}=c_1-e=0.5\ {\rm mm}\)，最大间隙为 1.5 mm。一个周期内，窄间隙的位置沿圆周移动，这也是压力峰值和径向载荷随时间变化的来源。

## 为什么选择重叠网格

圆盘附近的贴体网格随圆盘作刚体旋转，壳体附近网格保持静止。两套网格通过重叠区域传递场量，避免将整圈偏心运动持续压缩进同一层变形网格。本节采用 OpenCFD v2512 的 `overPimpleDyMFoam` 与 `dynamicOversetFvMesh`。

重叠网格必须在最窄处仍有足够的有效单元。若以 0.5 mm 间隙内至少 10 个单元作为首轮目标，局部尺度约为 0.05 mm；随转子移动，供体和受体单元都需要维持相近尺度。外部粗网格不能一直延伸到细小间隙，再希望插值自动补回局部流动。

对本节固定偏心轴的同步刚体运动，也可以设计包住完整扫掠区域的旋转区并使用 AMI。旋转接口应绕 O 同轴，且全程不穿过圆盘或壳体。本节选择重叠网格，是为了后续进一步研究自转与绕行不同速的运动；两者不同速时，需要改写运动组合，不能继续只用一条 `rotatingMotion`。

## OpenFOAM 配置与运行顺序

### 1. 建立转子和背景网格

运行 `build_disc.py`，生成中心位于 (0.5,0,0) mm、半径 149.5 mm、厚度 10 mm 的圆盘 STL。转子附近建立独立网格，外表面命名为 `overset`，圆盘壁面命名为 `disc`；固定背景网格包含 `casing`、`inlet` 和 `outlet`。

```bash
python3 build_disc.py
surfaceCheck geometry/disc.stl
```

圆盘 STL 的 z 范围为 −0.01 至 0 m，轴向背腔位于盘后 z=0 至 0.004 m。圆盘和流体域应使用同一原点。背景域与转子网格合并后，建立 `movingZone`，只包含转子网格的单元；同时用 `zoneID` 区分背景网格与转子网格。

先分别划分和检查两套网格，再用 `mergeMeshes` 合并，并确认合并后 patch 名称没有被自动改名。`zoneID` 在背景区域设为 0，在转子区域设为 1；该标量字段用于重叠插值分区，与 `cellZone` 不是同一个对象。

### 2. 写入偏心轴运动

以下 `constant/dynamicMeshDict` 采用官方 `overPimpleDyMFoam/simpleRotor` 的结构，运动原点和角速度按本案例修改：

```foam
dynamicFvMesh dynamicOversetFvMesh;
solver multiSolidBodyMotionSolver;
multiSolidBodyMotionSolverCoeffs
{
    movingZone
    {
        solidBodyMotionFunction rotatingMotion;
        rotatingMotionCoeffs
        {
            origin  (0 0 0);
            axis    (0 0 1);
            omega   41.88790205;
        }
    }
}
```

`movingZone` 必须与网格中的区域同名。这里的 `omega` 单位为 rad/s，不能直接填 400。偏心距已经写进几何位置，不能再将 `origin` 也偏移 0.5 mm，否则会改变圆心轨迹。

### 3. 让壁面速度跟随网格运动

`0/U` 中圆盘和重叠边界采用：

```foam
disc
{
    type    movingWallVelocity;
    value   uniform (0 0 0);
}
overset
{
    type    overset;
}
```

`movingWallVelocity` 根据网格运动确定圆盘壁面速度，并保持壁面通量的一致性。此处的 `value` 是初始化值。对于发生法向位移的偏心转子，仅在固定网格上设置 `rotatingWallVelocity` 不能替代几何运动。

固定壳体用 `noSlip`；入口按 Q 使用 `flowRateInletVelocity`，无预旋时不给切向速度；出口速度用 `inletOutlet`，压力固定为 0。`p` 为运动学压力，壳体和圆盘可采用与移动通量相配的 `fixedFluxPressure`。k、ω、nut 和 p 的重叠 patch 同样需要 `overset` 类型。

### 4. 设置重叠插值、湍流和压力修正

在 `fvSchemes` 中设置：

```foam
oversetInterpolation
{
    method inverseDistance;
}
```

该方法从有效供体单元插值得到受体场量。重叠耦合使线性系统一般不再对称，压力求解器应选用适合非对称系统的配置，例如 `PBiCGStab` 配合 `DILU`；不能直接沿用针对对称压力矩阵的设置。

以 \(Re_\omega=\omega R^2/\nu\) 估算，本工况约为 9.36×10⁵，不能仅因为间隙窄就把整个背腔视为层流。首轮采用 `kOmegaSST`，在窄间隙壁面解析边界层，并检查 y⁺。重叠网格中壁距计算还需采用能够跨越重叠连接的处理，按官方 overset 配置选用 `Poisson` 等方法后检查壁距场。

初始时间步可取 10⁻⁵ s，随局部 Courant 数控制；输出间隔取一个转动周期的 1/120，即 0.00125 s。时间步既要限制流体穿越单元的距离，也要限制移动网格每步扫过的间隙尺度，二者取更严格者。

### 5. 先检查一圈网格，再求解流动

```bash
checkMesh -allTopology -allGeometry
overPimpleDyMFoam
```

正式统计前，先保存足够密集的早期网格，查看转过 90°、180°、270°、360° 时的圆心位置、最小间隙和重叠插值带。检查日志中供体搜索、空洞单元和网格质量的变化。几何周期运动正确后，再延长计算至流体载荷形成重复周期。

串行流程通过后可使用 `decomposePar` 与并行运行。并行分区后应再次检查重叠连接和载荷，尤其关注非常薄的间隙是否被分区边界切成少量单元。

## 力矩、周期载荷与功率

在 `controlDict` 的 `functions` 中记录圆盘载荷：

```foam
discLoads
{
    type            forces;
    libs            (forces);
    patches         (disc);
    rho             rhoInf;
    rhoInf          997.07;
    CofR            (0 0 0);
    writeControl    timeStep;
    writeInterval   1;
}
```

这里积分的是流体作用于圆盘的力和关于固定轴 O 的力矩。主轴所需驱动功率由 \(-M_{O,z}\omega\) 估算；符号取决于流体力矩方向，输出时保留原始符号并注明正方向。

需要与关于瞬时圆心 C 的试验力矩比较时，先变换力矩参考点：

\[
\mathbf M_C=\mathbf M_O-(\mathbf C-\mathbf O)\times\mathbf F.
\]

不能将固定轴的力矩直接当成圆心力矩，偏心力产生的附加力臂会进入结果。进一步定义随圆心运动的径向、切向单位向量：

\[
\mathbf e_r=(\cos\omega t,\sin\omega t,0),\qquad
\mathbf e_t=(-\sin\omega t,\cos\omega t,0).
\]

将 F 投影到这两个方向，可得到径向与切向载荷；对横向力矩也作相同坐标变换。资料包的 `analyse_loads.py` 读取明确列名的载荷 CSV，计算参考点转换、周期平均、峰峰值以及第一谐波。

检查结果时，先看入口出口质量平衡，再看圆周压力分布。随窄间隙旋转的压力高低区应与径向载荷相位对应。然后比较 2、4、6 mm 轴向间隙下的平均阻力矩和载荷幅值，解释间隙改变如何影响泄漏阻力与流体动量交换。

网格和时间步独立性分别检查最小间隙单元数、重叠带宽度与时间步长。比较指标采用平均转矩、径向载荷幅值及相位，不能只比较某一瞬间的最大速度。原论文还研究转子结构与流体力矩的耦合；要判断振动是否增长，需要进一步输入轴刚度、质量和阻尼，单独一条流体力矩曲线不能给出结构稳定性结论。

> **熊猫说：**
>
> 偏心运动有三个位置需要统一：几何中的初始圆心、运动字典中的旋转轴、后处理中的力矩参考点。先用圆心轨迹检查运动，再用力矩平移公式对齐载荷，能排除一类很难从流场云图发现的错误。

## 模型与配置资料

- [下载圆盘 STL 生成、运动校核、载荷分析和配置资料包](/downloads/engineering/eccentric-disc.zip)。几何按公开尺寸重建，背腔入口、出口截断位置在图中标出。
- [原始试验与动力学分析论文](https://www.jstage.jst.go.jp/article/ijfms/3/1/3_1_67/_article)。
- [圆盘厚度及绕行试验说明](https://doi.org/10.1115/1.4001802)。
- [v2512 simpleRotor 运动字典](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/incompressible/overPimpleDyMFoam/simpleRotor/constant/dynamicMeshDict)：本文运动配置的出处。
- [v2512 overPimpleDyMFoam 源码](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/applications/solvers/incompressible/overPimpleDyMFoam)。

[返回实际工程应用](/topics/engineering/)
