依据水轮机背腔试验尺寸建立偏心圆盘，计算固定偏心轴旋转引起的间隙流动、力矩与周期载荷。

## 工程场景与计算目标

转轮、泵叶轮与密封壳体之间的间隙流动同时受到旋转壁面和泄漏压差驱动。偏心使周向间隙不均，局部阻力与压力随位置变化，形成非对称载荷。研究这些变化有助于解释转子耗功和流体激励。

流体载荷包括阻力矩、径向力和倾覆力矩。载荷与转子运动的相位关系决定流体向振动输入或吸收能量，因此平均驱动转矩与动态载荷需要分别提取。

几何依据为 Song 等的 Francis 水轮机背腔转子试验。水从圆盘外周间隙进入，沿背腔向内流出；装置分别控制圆盘自转与圆心绕行。公开尺寸和转速用于重建三维间隙模型。

本例采用自转与圆心绕行同速、同向的同步工况。此时圆盘等效为绕固定偏心轴作刚体旋转，圆心相对该轴运动形成圆轨迹。

![偏心圆盘、圆心轨迹与水轮机背腔间隙](/assets/engineering/eccentric-disc-geometry.webp)

尺寸依据：[Song 等，International Journal of Fluid Machinery and Systems 3(1), 67–79，2010，第 2 节及图 3](https://www.jstage.jst.go.jp/article/ijfms/3/1/3_1_67/_article)。圆盘厚度和详细试验说明见 [Journal of Fluids Engineering 132, 071102](https://doi.org/10.1115/1.4001802)。

## 几何、尺寸与基准工况

| 参数 | 取值 | 用途 |
| --- | --- | --- |
| 圆盘半径 R | 149.5 mm | 外径为 299 mm |
| 圆盘厚度 | 10 mm | 保留三维端面和外圆柱面 |
| 平均径向间隙 c₁ | 1 mm | 静止壳体内半径 150.5 mm |
| 轴向背腔间隙 c₂ | 4 mm | 基准工况；再比较 2 mm 与 6 mm |
| 内侧流出半径 | 47.5 mm | 背腔内侧截断边界 |
| 偏心距 e | 0.5 mm | 圆心相对固定旋转轴的距离 |
| 转速 n | 400 r/min | 自转和圆心绕行同速、同向 |
| 工作介质 | 水 | 本节取 ρ=997.07 kg/m³、ν=1.0×10⁻⁶ m²/s |

计算域包含外周密封间隙和盘后背腔，外部供水以入口条件表示，内侧在 47.5 mm 半径处设置压力出口。两段间隙保留压力分配与泄漏的主要流动路径，模型图给出截断边界和尺寸。

基准工况采用论文中的无预旋输入，并以名义间隙流速与叶尖速度之比 \(v_l/U_T=0.170\) 设定泄漏流量。这里

\[
U_T=\omega R,\qquad
Q=2\pi R c_1 v_l.
\]

400 r/min 对应 \(\omega=41.8879\ {\rm rad/s}\)，叶尖速度约 6.262 m/s。由此计算的名义流量约为 1.00×10⁻³ m³/s，即约 60 L/min。该流量施加在外周供水截面，背腔内侧由压力条件决定流出。

## 运动学：转轴必须放在正确位置

取固定旋转轴经过 O=(0,0,0)，方向为 z；初始圆心 C₀=(0.0005,0,0)。角速度恒定时，圆心轨迹为

\[
\mathbf C(t)=
\begin{pmatrix}e\cos\omega t\\e\sin\omega t\\0\end{pmatrix}.
\]

圆盘表面任意一点的速度为

\[
\mathbf U_w(\mathbf x,t)=\boldsymbol\omega\times(\mathbf x-\mathbf O).
\]

`motion_check.csv` 提供四分之一转等相位的圆心坐标，用于核对网格动画。400 r/min 对应周期 0.15 s，经过 0.0375 s 后圆心位于 (0,0.0005,0)；运动原点 O 保持固定。

最小径向间隙为 \(c_{\min}=c_1-e=0.5\ {\rm mm}\)，最大间隙为 1.5 mm。一个周期内，窄间隙的位置沿圆周移动，这也是压力峰值和径向载荷随时间变化的来源。

## 配置文件与网格建立

同步偏心旋转采用绕固定轴 O 的滑移网格。转子区包含圆盘外周密封间隙及盘后背腔，随圆盘作刚体旋转；壳体附近的外环网格保持静止。两区通过半径 150.25 mm 的圆柱形 AMI 界面交换通量和场量。

该界面位于圆盘最大扫掠半径 150 mm 与壳体半径 150.5 mm 之间。转子与壳体网格分别由随包的两个 `blockMeshDict` 建立，使用圆弧描述圆周；合并后由 `createPatch` 建立 `rotorAMI`、`backgroundAMI` 配对边界。圆盘轴向范围为 −10～0 mm，背腔为 0～4 mm，内侧流出半径为 47.5 mm。

本例采用不可压缩瞬态流动与 `kOmegaSST` 模型；按角速度、半径和运动黏度估算的旋转雷诺数约为 9.36×10⁵。每圈设 192 个周向单元。转子侧外周间隙有 8 层径向单元，壳体侧有 6 层；背腔沿半径分为 40 层，并向圆盘外缘加密。窄间隙单元沿壁面呈各向异性，网格质量字典保留相应行列式阈值，同时检查非正交性、面插值权重和体积比。加密比较同时关注最小间隙和 AMI 两侧分辨率。

## 关键配置与解读

以下配置来自下载包的同名文件。

### `constant/dynamicMeshDict`

```foam
dynamicFvMesh dynamicMotionSolverFvMesh;
motionSolverLibs (fvMotionSolvers);
motionSolver solidBody;
cellZone rotating;
solidBodyMotionFunction rotatingMotion;
origin (0 0 0);
axis (0 0 1);
omega 41.88790205;
```

`rotating` 单元区随圆盘转动，固定轴经过原点并沿 z 方向。初始几何已包含 0.5 mm 偏心，运动原点保持为 O；因此圆心在计算过程中绕 O 运动。

### `0.orig/U`

```foam
boundaryField
{
    inlet { type fixedValue; value uniform (0 0 1.060825); }
    outlet { type pressureInletOutletVelocity; value uniform (0 0 0); }
    disc { type movingWallVelocity; value uniform (0 0 0); }
    casing { type noSlip; }
    rotorAMI { type cyclicAMI; }
    backgroundAMI { type cyclicAMI; }
}
```

`movingWallVelocity` 使圆盘壁面速度跟随网格，固定壳体为无滑移。入口沿 z 正方向供水，速度 1.060825 m/s 对应约 60 L/min；AMI 两侧使用配对耦合边界。出口在背腔内圆处由压力约束流出。

### `system/fvSolution`

```foam
solvers
{
    p
    { solver GAMG; tolerance 1e-8; relTol 0.05; smoother GaussSeidel; }
    pFinal
    { $p; relTol 0; }
    "pcorr.*" { solver PCG; preconditioner DIC; tolerance 1e-9; relTol 0; }
    "(U|k|omega|epsilon|h|tracer|rho)" { solver smoothSolver; smoother symGaussSeidel; tolerance 1e-8; relTol 0.05; }
    "(U|k|omega|epsilon|h)Final" { solver smoothSolver; smoother symGaussSeidel; tolerance 1e-8; relTol 0; }
    "alpha.water.*" { nAlphaCorr 2; nAlphaSubCycles 2; cAlpha 1; MULESCorr yes; nLimiterIter 3; solver smoothSolver; smoother symGaussSeidel; tolerance 1e-9; relTol 0; }
}
PIMPLE { correctPhi true; checkMeshCourantNo true; momentumPredictor yes; nOuterCorrectors 2; nCorrectors 2; nNonOrthogonalCorrectors 0; pRefCell 0; pRefValue 0; }
relaxationFactors { fields { p 0.3; p 0.3; rho 1; } equations { U 0.6; h 0.7; k 0.6; omega 0.6; epsilon 0.6; tracer 0.8; } }
```

`PIMPLE` 每个时间步执行两次外迭代、两次压力修正，`correctPhi` 在网格运动后修正通量。压力使用运动学量纲，参考值为零；SST 模型的 k 和 omega 与速度一起更新。

## 运行与计算检查

[下载完整算例与配置代码](/downloads/engineering/eccentric-disc.zip)，解压后进入 `eccentric-disc` 目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
bash Allmesh
bash Allsolve
```

第一行加载 OpenCFD OpenFOAM v2512，安装位置不同则调整路径。`Allmesh` 完成网格建立、区域处理和质量检查，再将 `0.orig/` 复制为运行所用初始场。`Allsolve` 运行 `pimpleFoam` 并将最新监测记录整理到 `analysis/last-monitors.json`。在 ParaView 中打开 `case.foam` 查看场文件。

网格修改在新解压目录进行，保留基准算例便于比较。建网格前修改 `0.orig/`，网格完成后修改 `0/`；求解范围与输出频率在 `system/controlDict` 中调整。详细记录保存在 `log.*`，运行脚本遇到错误会停止并显示对应日志。

默认计算到 0.45 s，即三个旋转周期，场输出间隔为 0.00125 s。检查初始阶段的 AMI 权重、流量收支和圆心轨迹，再根据载荷周期重复性延长计算。分析多个完整周期时，将结束时间延长到所选统计窗口之后。

## 结果提取与工程分析

程序同时输出 `analysis/loads.csv`，包含时间或迭代序号、三向总力以及关于转轴原点的三向总力矩。分别从 `force.dat` 和 `moment.dat` 按相同时间对齐，后续功率和周期统计使用这一文件。

在 `controlDict` 的 `functions` 中记录圆盘载荷：

```foam
discLoads
{
    type            forces;
    libs            (forces);
    patches         (disc);
    rho             rhoInf;
    rhoInf          997.07;
    CofR            (0 0 0);
    writeControl    timeStep;
    writeInterval   1;
}
```

这里积分的是流体作用于圆盘的力和关于固定轴 O 的力矩。主轴所需驱动功率由 \(-M_{O,z}\omega\) 估算；符号取决于流体力矩方向，输出时保留原始符号并注明正方向。

需要与关于瞬时圆心 C 的试验力矩比较时，先变换力矩参考点：

\[
\mathbf M_C=\mathbf M_O-(\mathbf C-\mathbf O)\times\mathbf F.
\]

参考点变换计入偏心力臂产生的附加力矩。进一步定义随圆心运动的径向和切向单位向量：

\[
\mathbf e_r=(\cos\omega t,\sin\omega t,0),\qquad
\mathbf e_t=(-\sin\omega t,\cos\omega t,0).
\]

将 F 投影到这两个方向，可得到径向与切向载荷；对横向力矩也作相同坐标变换。资料包的 `analyse_loads.py` 读取明确列名的载荷 CSV，计算参考点转换、周期平均、峰峰值以及第一谐波。

将圆周压力分布与径向载荷相位对应，并核对边界质量收支。比较 2、4、6 mm 背腔间隙下的平均阻力矩和载荷幅值，解释泄漏阻力与动量交换的变化。

网格比较考察最小间隙单元数和 AMI 两侧网格尺度，时间步比较考察载荷幅值与相位。评价指标为平均转矩、径向载荷幅值和相位。进一步计算转子振动时，将流体载荷与轴系质量、刚度及阻尼耦合。

例如，将计算结束时间延长至 1.5 s，待启动影响减弱后，使用下列命令分析从 0.75 s 开始的五个完整周期：

```bash
python3 analyse_loads.py analysis/loads.csv --start 0.75 --cycles 5
```

该工具需要 NumPy，输出 `load-summary.json` 中的均值、峰峰值及第一谐波幅值和相位。

> **熊猫说：** 初始圆心、固定旋转轴和力矩参考点分别承担几何、运动和受力定义。用圆心轨迹核对运动，再将力矩换算到同一参考点。

## 模型与配置资料

- [下载完整偏心圆盘算例、模型与载荷分析程序](/downloads/engineering/eccentric-disc.zip)。几何按公开尺寸重建，背腔入口、出口截断位置在图中标出。
- [原始试验与动力学分析论文](https://www.jstage.jst.go.jp/article/ijfms/3/1/3_1_67/_article)。
- [圆盘厚度及绕行试验说明](https://doi.org/10.1115/1.4001802)。
- [v2512 rotatingFanInRoom 运动字典](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/incompressible/pimpleFoam/RAS/rotatingFanInRoom/constant/dynamicMeshDict)：本文运动配置的出处。
- [v2512 pimpleFoam 源码](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/applications/solvers/incompressible/pimpleFoam)。

配套 `VALIDATION.json` 与 `validation/` 保存本配置的网格检查和短程启动记录，`files.sha256` 用于核对文件完整性。

[返回实际工程应用](/topics/engineering/)
