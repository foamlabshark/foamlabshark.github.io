"""Analyse SI load CSV: time,Fx,Fy,Fz,Mx,My,Mz (total fluid loads about O).
Usage: python3 analyse_loads.py loads.csv --start 0.75 --cycles 5
Least-squares first harmonic handles nonuniform output times. No fabricated data.
"""
import argparse,csv,math,json
from pathlib import Path
import numpy as np
def analyse(file,start,cycles):
    rows=list(csv.DictReader(Path(file).open()));keys=['time','Fx','Fy','Fz','Mx','My','Mz']
    a=np.array([[float(r[k]) for k in keys] for r in rows]);a=a[np.argsort(a[:,0])]
    if len(a)<8 or not np.isfinite(a).all() or np.any(np.diff(a[:,0])<=0):raise ValueError('Need finite, distinct time records and all seven columns.')
    w=400*2*math.pi/60;T=60/400;end=start+cycles*T
    if cycles<1 or a[0,0]>start or a[-1,0]<end:raise ValueError('Input must cover the requested complete cycles.')
    # Interpolate endpoints so statistics cover exactly the requested duration.
    mid=a[(a[:,0]>start)&(a[:,0]<end)]
    edge=lambda t:np.array([t]+[np.interp(t,a[:,0],a[:,j]) for j in range(1,7)])
    a=np.vstack([edge(start),mid,edge(end)]);t=a[:,0];F=a[:,1:4];MO=a[:,4:7]
    r=np.column_stack([.0005*np.cos(w*t),.0005*np.sin(w*t),np.zeros(len(t))]);MC=MO-np.cross(r,F)
    er=np.column_stack([np.cos(w*t),np.sin(w*t),np.zeros(len(t))]);et=np.column_stack([-np.sin(w*t),np.cos(w*t),np.zeros(len(t))])
    series={'Fr_N':np.sum(F*er,axis=1),'Ft_N':np.sum(F*et,axis=1),'Mz_O_Nm':MO[:,2],'Mx_C_Nm':MC[:,0],'My_C_Nm':MC[:,1],'drive_power_W':-MO[:,2]*w}
    series.update({'Fx_N':F[:,0],'Fy_N':F[:,1],'Fz_N':F[:,2],'Mz_C_Nm':MC[:,2],'Mr_C_Nm':np.sum(MC*er,axis=1),'Mt_C_Nm':np.sum(MC*et,axis=1)})
    basis=np.column_stack([np.ones(len(t)),np.cos(w*t),np.sin(w*t)])
    weights=np.r_[np.diff(t)[0]/2,(t[2:]-t[:-2])/2,np.diff(t)[-1]/2];result={}
    for name,y in series.items():
        fit=np.linalg.lstsq(basis*np.sqrt(weights[:,None]),y*np.sqrt(weights),rcond=None)[0]
        result[name]={'mean':float((np.trapezoid(y,t) if hasattr(np,"trapezoid") else np.trapz(y,t))/(end-start)),'peak_to_peak':float(np.ptp(y)),'first_harmonic_amplitude':float(np.hypot(fit[1],fit[2])),'phase_rad_cos_convention':float(math.atan2(-fit[2],fit[1]))}
    return {'start_s':start,'end_s':end,'cycles':cycles,'reference':'O fixed axis; C instantaneous centre','statistics':result}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('file');p.add_argument('--start',type=float,required=True);p.add_argument('--cycles',type=int,default=5);a=p.parse_args();r=analyse(a.file,a.start,a.cycles);Path('load-summary.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
