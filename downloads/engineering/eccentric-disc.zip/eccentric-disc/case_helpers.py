"""Complete the two published external-aerodynamics cases using their sourced STLs."""
from pathlib import Path
import sys,shutil,json,csv
from build_case import dictionary,write,scalar_field,schemes,vec,header
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'.openfoam-work/engineering/kits'

def block(root,b,n,patches):
    x0,x1,y0,y1,z0,z1=b
    pts=[(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0),(x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)]
    order=[[0,4,7,3],[1,2,6,5],[0,1,5,4],[3,7,6,2],[0,3,2,1],[4,5,6,7]]
    text='scale 1;\nvertices (\n'+'\n'.join(vec(p) for p in pts)+'\n);\nblocks (hex (0 1 2 3 4 5 6 7) '+vec(n)+' simpleGrading (1 1 1));\nedges ();\nboundary (\n'
    for name,typ,ids in patches:
        text+=name+' { type '+typ+'; faces ('+' '.join(vec(order[i]) for i in ids)+'); }\n'
    dictionary(root,'system/blockMeshDict',text+');\nmergePatchPairs ();')

def common(root,solver='simpleFoam',meshsteps=''):
    pre='''#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
: "${WM_PROJECT_DIR:?Load OpenCFD OpenFOAM v2512 first}"
[ "${WM_PROJECT_VERSION:-}" = v2512 ] || { echo 'Requires v2512'; exit 2; }
run() { local n="$1"; shift; "$@" > "log.$n" 2>&1 || { tail -n 70 "log.$n"; return 1; }; }
'''
    write(root,'Allmesh',pre+'''[ ! -d constant/polyMesh ] || { echo 'Use a fresh copy to rebuild the mesh'; exit 3; }
mkdir -p 0
cp -a 0.orig/. 0/
run blockMesh blockMesh
'''+meshsteps+'''run checkMesh checkMesh -meshQuality
grep -q 'Mesh OK' log.checkMesh
if grep -Eq 'Failed [1-9][0-9]* mesh checks' log.checkMesh; then exit 4; fi
touch .mesh-ready
''')
    write(root,'Allsolve',pre+f'''[ -f .mesh-ready ] || {{ echo 'Run Allmesh first'; exit 3; }}
run {solver} {solver}
python3 analyse.py
''')
    write(root,'Allrun',pre+'bash Allmesh\nbash Allsolve\n');write(root,'case.foam','')
    dictionary(root,'system/decomposeParDict','numberOfSubdomains 4; method scotch;')
    if not (root/'analyse.py').exists():write(root,'analyse.py','''from pathlib import Path
import csv,re,json
r=Path(__file__).resolve().parent
out=r/'analysis';out.mkdir(exist_ok=True)
tables={}
for p in sorted((r/'postProcessing').rglob('*.dat')):
    rows=[s for s in p.read_text().splitlines() if s.strip() and not s.lstrip().startswith('#')]
    if rows:tables[p.relative_to(r).as_posix()]=rows[-1]
(out/'last-monitors.json').write_text(json.dumps(tables,indent=2))
print(json.dumps(tables,indent=2))
if not tables:raise SystemExit('No monitoring outputs')
''')

def snappy(root,surfaces,boxlo,boxhi,point,level):
    geo='';ref='';regions=''
    for name,file in surfaces:
        geo+=f'{file} {{ type triSurfaceMesh; name {name}; }}\n'
        ref+=f'{name} {{ level ({level} {level}); patchInfo {{ type wall; }} }}\n'
        if level>=5:regions+=f'{name} {{ mode distance; levels ((0.12 {level}) (0.5 {level-2}) (1.5 2)); }}\n'
    geo+=f'refinementBox {{ type searchableBox; min {vec(boxlo)}; max {vec(boxhi)}; }}'
    dictionary(root,'system/snappyHexMeshDict',f'''castellatedMesh true;
snap true;
addLayers false;
geometry {{ {geo} }}
castellatedMeshControls
{{
 maxLocalCells 1200000; maxGlobalCells 1200000; minRefinementCells 0;
 maxLoadUnbalance 0.1; nCellsBetweenLevels 3; features ();
 refinementSurfaces {{ {ref} }}
 resolveFeatureAngle 30;
 refinementRegions {{ refinementBox {{ mode inside; levels ((1e15 1)); }} {regions} }}
 locationInMesh {vec(point)}; allowFreeStandingZoneFaces true;
}}
snapControls {{ nSmoothPatch 5; tolerance 1.0; nSolveIter 100; nRelaxIter 8; nFeatureSnapIter 15; implicitFeatureSnap true; explicitFeatureSnap false; multiRegionFeatureSnap false; }}
addLayersControls {{ relativeSizes true; layers {{}} expansionRatio 1.2; finalLayerThickness 0.3; minThickness 0.1; nGrow 0; featureAngle 60; nRelaxIter 5; nSmoothSurfaceNormals 1; nSmoothNormals 3; nSmoothThickness 10; maxFaceThicknessRatio 0.5; maxThicknessToMedialRatio 0.3; minMedianAxisAngle 90; nBufferCellsNoExtrude 0; nLayerIter 50; }}
meshQualityControls
{{
 #includeEtc "caseDicts/meshQualityDict"
 maxNonOrtho 65; maxBoundarySkewness 3.5; maxInternalSkewness 3.5;
 minDeterminant 0.002; minFaceWeight 0.05; minVolRatio 0.02;
 nSmoothScale 4; errorReduction 0.75;
}}
mergeTolerance 1e-6;''')
    dictionary(root,'system/meshQualityDict','#includeEtc "caseDicts/meshQualityDict"\nmaxNonOrtho 65; maxBoundarySkewness 3.5; maxInternalSkewness 3.5; minDeterminant 0.002;')

def fieldset(root,patches,U,k,omega,city=False):
    b={f:{} for f in ['U','p','k','omega','epsilon','nut']}
    for name,kind in patches.items():
        b['U'][name]='type fixedValue; value uniform '+vec(U)+';' if kind=='inlet' else 'type pressureInletOutletVelocity; value uniform (0 0 0);' if kind=='outlet' else 'type slip;' if kind=='slip' else 'type noSlip;'
        b['p'][name]='type fixedValue; value uniform 0;' if kind=='outlet' else 'type zeroGradient;'
        for f,v,wall in [('k',k,'kqRWallFunction'),('omega',omega,'omegaWallFunction'),('epsilon',.01,'epsilonWallFunction')]:
            b[f][name]=f'type {wall}; value uniform {v};' if kind=='wall' else f'type fixedValue; value uniform {v};' if kind=='inlet' else f'type inletOutlet; inletValue uniform {v}; value uniform {v};' if kind=='outlet' else 'type zeroGradient;'
        b['nut'][name]='type nutkWallFunction; value uniform 0;' if kind=='wall' else 'type calculated; value uniform 0;'
    scalar_field(root,'0.orig/U','0 1 -1 0 0 0 0',U,b['U'],True)
    scalar_field(root,'0.orig/p','0 2 -2 0 0 0 0',0,b['p'])
    scalar_field(root,'0.orig/k','0 2 -2 0 0 0 0',k,b['k'])
    f='epsilon' if city else 'omega';scalar_field(root,'0.orig/'+f,'0 2 -3 0 0 0 0' if city else '0 0 -1 0 0 0 0',.01 if city else omega,b[f])
    scalar_field(root,'0.orig/nut','0 2 -1 0 0 0 0',0,b['nut'])
    dictionary(root,'constant/transportProperties','transportModel Newtonian; nu [0 2 -1 0 0 0 0] 1.5e-5;')
    dictionary(root,'constant/turbulenceProperties','simulationType RAS; RAS { RASModel '+('kEpsilon' if city else 'kOmegaSST')+'; turbulence on; printCoeffs on; }')
    schemes(root)
    return b

def control(root,functions):
    dictionary(root,'system/controlDict','''application simpleFoam;
startFrom startTime; startTime 0; stopAt endTime; endTime 2000;
deltaT 1; writeControl timeStep; writeInterval 100; purgeWrite 0;
writeFormat ascii; writePrecision 10; writeCompression off;
timeFormat general; timePrecision 8; runTimeModifiable true;
functions {\n'''+functions+'\n}')

