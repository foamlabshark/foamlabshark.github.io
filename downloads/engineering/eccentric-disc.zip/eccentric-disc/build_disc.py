"""Disc reconstructed from Song et al. (2010), DOI 10.5293/IJFMS.2010.3.1.067.
SI units. Initial centre (0.0005,0,0); axis through (0,0,0).
"""
from pathlib import Path
import math,struct,csv,json
ROOT=Path(__file__).resolve().parent
R=.1495; E=.0005; H=.01; RPM=400; N=720
def build():
    out=ROOT/'geometry';out.mkdir(exist_ok=True)
    rings=[[(E+R*math.cos(2*math.pi*j/N),R*math.sin(2*math.pi*j/N),z) for j in range(N)] for z in [-H,0]]
    faces=[]
    for j in range(N):
        k=(j+1)%N;a,b=rings
        faces.extend([(a[j],a[k],b[k]),(a[j],b[k],b[j]),((E,0,-H),a[k],a[j]),((E,0,0),b[j],b[k])])
    with (out/'disc.stl').open('wb') as f:
        f.write(b'FoamLab eccentric disc; metres'.ljust(80,b' '));f.write(struct.pack('<I',len(faces)))
        for a,b,c in faces:
            u=[b[i]-a[i] for i in range(3)];v=[c[i]-a[i] for i in range(3)]
            n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];norm=math.sqrt(sum(x*x for x in n));n=[x/norm for x in n]
            f.write(struct.pack('<12fH',*n,*a,*b,*c,0))
    w=RPM*2*math.pi/60;T=60/RPM
    with (ROOT/'motion_check.csv').open('w',newline='') as f:
        wr=csv.writer(f);wr.writerow(['time_s','centre_x_m','centre_y_m','centre_z_m'])
        for i in range(121):t=T*i/120;wr.writerow([t,E*math.cos(w*t),E*math.sin(w*t),0])
    report={'units':'m','R':R,'thickness':H,'e':E,'c1':.001,'c2':.004,'inner_radius':.0475,'omega_rad_s':w,'period_s':T,'minimum_radial_gap_m':.001-E,'tip_speed_m_s':w*R,'nominal_leakage_m3_s':2*math.pi*R*.001*.170*w*R}
    (out/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':build()
