checkMesh -allTopology -allGeometry
overPimpleDyMFoam
