python3 analyse_loads.py analysis/loads.csv --start 0.75 --cycles 5
