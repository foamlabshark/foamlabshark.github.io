python3 build_disc.py
surfaceCheck geometry/disc.stl
