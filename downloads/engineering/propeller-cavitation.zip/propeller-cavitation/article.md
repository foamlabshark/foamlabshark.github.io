耦合螺旋桨转动与液汽相变，分析吸力面低压、空化体积和叶片载荷的变化。

## 工程场景与计算目标

螺旋桨旋转向水流输入动量，并在叶片两侧形成压差。吸力面压力降低至饱和蒸气压附近时产生空化，汽相分布又会影响压力和推力。转速、来流速度及环境压力因而需要共同用于解释空化状态与载荷。

算例在圆柱流道中设置公开螺旋桨曲面，内侧网格随桨转动，外侧网格保持静止，两者通过 AMI 连接。入口速度和角速度按时间变化，Schnerr–Sauer 模型计算液汽质量交换。由启动、稳定转动和降速阶段的对应结果分析转速影响。

## 几何、尺寸与基准工况

![旋转螺旋桨的推力与空化：配套模型与基准输入](/assets/engineering/propeller-cavitation-geometry.webp)

模型使用官方 `propeller` 资源中的桨叶与圆柱边界，外包范围为 x、z = −0.3～0.3 m、y = −0.81～0.21 m。转轴沿 y 方向，旋转单元区为 `innerCylinderSmall`，桨叶轮廓由配套曲面确定。

模型与配置来源：[OpenFOAM v2512 · multiphase/interPhaseChangeDyMFoam/propeller](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/multiphase/interPhaseChangeDyMFoam/propeller)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 入口速度 | 0～0.01 s 增至 15 m/s | `0.orig/U`，方向为负 y |
| 角速度 | 先升至 628 rad/s，后降至 419 rad/s | `constant/dynamicMeshDict` |
| 饱和蒸气压 | 2300 Pa | `constant/transportProperties/pSat` |
| 空化模型 | SchnerrSauer | 同一物性文件 |
| 参考出口压力 | 100000 Pa | `0.orig/p_rgh`，本例重力为零 |

## 求解方法与物理模型

进速系数为 $J=U_\infty/(nD)$，推力和转矩可分别写为 $K_T=T/(\rho n^2D^4)$、$K_Q=Q/(\rho n^2D^5)$。空化模型依据局部压力与饱和压力的差异计算液汽质量交换；本例液相体积分数为 $\alpha_w$，汽相体积分数为 $1-\alpha_w$。

本例使用 `interPhaseChangeDyMFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/propeller-cavitation.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip propeller-cavitation.zip
cd propeller-cavitation
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `surfaceFeatureExtract` | 提取曲面棱边，供贴体网格捕捉结构特征。 |
| `snappyHexMesh -overwrite` | 依据随包曲面裁切、贴合背景网格，并执行局部加密。 |
| `renumberMesh -overwrite` | 重新编号，改善矩阵存储和求解访问顺序。 |
| `topoSet -dict system/createInletOutletSets.topoSetDict` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| `createPatch -overwrite` | 重建边界集合及周期、AMI 等边界类型。 |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 转速随时间变化

文件：`constant/dynamicMeshDict`。本段设置转速随时间变化。

```foam
omega       table
(
    (0    0)
    (0.01  628)
    (0.022  628)
    (0.03  419)
    (100   419)
);
```

角速度表按秒给定启动和降速过程，数值单位为 rad/s。转速变化同时改变进速系数，比较空化状态时需列出对应来流速度与转速。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/interPhaseChangeDyMFoam/propeller/constant/dynamicMeshDict)。

### 2. 液汽相变

文件：`constant/transportProperties`。本段设置液汽相变。

```foam
phaseChangeTwoPhaseMixture SchnerrSauer;

pSat            2300;   // Saturation pressure

sigma           0.07;

water
{
    transportModel  Newtonian;
    nu              9e-07;
    rho             1000;
}

vapour
{
    transportModel Newtonian;
    nu              4.273e-04;
    rho             0.02308;
}
```

`pSat` 给出汽化压力基准，各相密度和黏度规定混合物性质。`SchnerrSauerCoeffs` 中的气核参数参与汽化与凝结速率计算，影响空化起始和增长。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/interPhaseChangeDyMFoam/propeller/constant/transportProperties)。

### 3. 来流加载与桨叶速度

文件：`0.orig/U`。本段设置来流加载与桨叶速度。

```foam
inlet
{
    type            uniformFixedValue;
    value           $internalField;
    uniformValue    table
    (
        (0     (0 0 0))
        (0.01  (0 -15 0))
        (100   (0 -15 0))
    );
}
```

入口速度逐步加载，桨叶采用 `movingWallVelocity`，使固壁速度与运动网格一致。两项设置分别确定来流建立过程和旋转叶片对流体的作用。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/interPhaseChangeDyMFoam/propeller/0.orig/U)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.interPhaseChangeDyMFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `interPhaseChangeDyMFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `0` |
| `endTime` | `0.1` |
| `deltaT` | `1e-5` |
| `writeControl` | `adjustable` |
| `writeInterval` | `0.001` |
| `adjustTimeStep` | `yes` |
| `maxCo` | `2` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选螺旋桨与水域，点击 **Apply**。先选择最后一个已写出的时刻，以 `alpha.water` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

同时显示叶片压力和汽相体积分数，比较低压区与空化起始位置。积分汽相总体积，结合桨叶表面力及转矩的时间序列，按转数标注启动、稳定转动和降速阶段。

入口压力比较保持转速和来流一致，分析空化程度与载荷变化；转速比较同时报告进速系数。分别检查叶尖、吸力面和 AMI 邻域的网格分辨率，并通过减小时间步检查载荷波动与汽相体积。

> **熊猫说：** 运动字典采用 rad/s，性能系数中的转速采用 r/s，换算关系为 n = ω/(2π)。

## 文件与来源

- [完整算例包](/downloads/engineering/propeller-cavitation.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/multiphase/interPhaseChangeDyMFoam/propeller)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
