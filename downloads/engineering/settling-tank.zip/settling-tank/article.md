用漂移通量模型计算沉淀池浓度分层和出口携带，分析停留时间与相对沉降的竞争。

## 工程场景与计算目标

沉淀池中的污泥同时受到整体水流输运和相对沉降作用。入口射流、回流及底部高浓度流改变颗粒到达出口的路径；进水量和浓度又分别影响停留时间与沉降特性。由此，池内浓度分布需要与水力条件一起求解。

算例采用 Dahl 沉淀池的二维构型。混合物速度描述整体运动，相对速度模型描述污泥与水之间的滑移，浓度相关流变描述高浓度区域阻力。计算通过纵向浓度变化、出口质量流率和池内存量解释分层与输运。

## 几何、尺寸与基准工况

![Dahl 沉淀池中的污泥输运：配套模型与基准输入](/assets/engineering/settling-tank-geometry.webp)

池长 8.65 m、高 1 m、展向厚 0.2 m，采用二维边界。左侧进水，右下方设置高 0.1 m 的出口，右侧其余部分为壁面。顶部为滑移边界，表示充满水的计算区域。

模型与配置来源：[OpenFOAM v2512 · multiphase/driftFluxFoam/RAS/dahl](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/multiphase/driftFluxFoam/RAS/dahl)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 入口速度 | 0.0191 m/s | `0/U` |
| 入口污泥体积分数 | 0.001 | `0/alpha.sludge` |
| 污泥、水密度 | 1996、996 kg/m³ | `constant/transportProperties` |
| 漂移速度参数 | V0 = (0 −0.002198 0) m/s | `simple` 相对速度模型 |
| 污泥流变 | BinghamPlastic | 浓度相关黏度及屈服参数 |

## 求解方法与物理模型

污泥相速度可分解为混合物速度与相对漂移，$\mathbf U_s=\mathbf U_m+\mathbf U_{s,m}$。相体积分数输运同时包含整体对流和漂移通量。水力停留时间近似为 $t_H=V/Q$，静水沉降时间尺度为 $t_s=H/|U_{\mathrm{settle}}|$；二者的相对大小帮助判断颗粒能否在流出前下降到较低位置。

本例使用 `driftFluxFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/settling-tank.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip settling-tank.zip
cd settling-tank
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |

本例的起始场位于 `0/`，修改初始场时直接编辑该目录。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 污泥相对沉降

文件：`constant/transportProperties`。本段设置污泥相对沉降。

```foam
relativeVelocityModel simple;

"(simple|general)Coeffs"
{
    V0              (0 -0.002198 0);
    a               285.84;
    a1              0.1;
    residualAlpha   0;
}
```

`V0` 给出基准沉降速度与方向，浓度参数控制沉降随固相含量的变化。目标污泥的沉降试验用于确定这组关系。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/driftFluxFoam/RAS/dahl/constant/transportProperties)。

### 2. 入口与初始浓度

文件：`0/alpha.sludge`。本段设置入口与初始浓度。

```foam
internalField   uniform 0.001;

boundaryField
{
    inlet
    {
        type            fixedValue;
        value           $internalField;
    }

    outlet
    {
        type            inletOutlet;
        inletValue      $internalField;
    }
```

0.001 表示污泥体积分数。质量浓度数据需结合污泥密度换算，入口和初始场采用相同定义。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/driftFluxFoam/RAS/dahl/0/alpha.sludge)。

### 3. 底部出口条件

文件：`0/U`。本段设置底部出口条件。

```foam
outlet
{
    type            pressureInletOutletVelocity;
    value           uniform (0 0 0);
}
```

右下出口抽出该高度附近的流体与污泥，池底和端壁无滑移。出口位置直接影响底部浓缩区的排出，因此它是水力模型的一部分。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/driftFluxFoam/RAS/dahl/0/U)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.driftFluxFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `driftFluxFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `0` |
| `endTime` | `6400` |
| `deltaT` | `0.1` |
| `writeControl` | `adjustable` |
| `writeInterval` | `50` |
| `adjustTimeStep` | `on` |
| `maxCo` | `5` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选沉淀池，点击 **Apply**。先选择最后一个已写出的时刻，以 `alpha.sludge` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

叠加污泥体积分数和流线，观察入口射流、底部输运与短路流。在多个纵向位置提取垂向浓度剖面，统计入口和出口污泥质量流率，并与池内存量变化核对。

分别调整进水速度和入口浓度，比较高浓度区位置与出口携带。运行时间覆盖相应水力停留时间后，结合存量变化判断是否达到可比较的稳定状态。

> **熊猫说：** 漂移通量描述污泥相的平均滑移。改变颗粒性质时，通过沉降试验或相应关联式更新相对速度模型。

## 文件与来源

- [完整算例包](/downloads/engineering/settling-tank.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/multiphase/driftFluxFoam/RAS/dahl)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
