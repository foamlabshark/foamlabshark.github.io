以双流体区域和体积换热源模拟空气—热水换热器，计算换热量、芯体压降及风机作用。

## 工程场景与计算目标

紧凑换热器包含大量薄壁和细小流道，整机分析通常更关注两侧流量、出口温度和压力损失。采用等效换热面积及阻力系数描述芯体，可在保留风机和风道影响的同时，减少对细部流道的逐一划分。模型参数分别对应芯体的传热能力和通流能力。

算例设置空气区域 `air` 与水侧区域 `porous`，两者在重叠体积内交换热量。空气侧以 MRF 描述风机，以多孔阻力描述芯体压降。计算目标是建立两侧热量收支，并说明风量增加所带来的换热收益和压力负荷。

## 几何、尺寸与基准工况

![风机驱动换热器的双流体换热：配套模型与基准输入](/assets/engineering/heat-exchanger-geometry.webp)

空气域尺寸为 0.5 m × 0.5 m × 0.5 m，水侧区域尺寸为 0.7 m × 0.3 m × 0.05 m，局部重叠体积对应换热芯体。两个区域分别由各自的 `blockMeshDict` 生成。风机旋转中心为 `(0.25 0.25 0.25)` m。

模型与配置来源：[OpenFOAM v2512 · heatTransfer/chtMultiRegionSimpleFoam/heatExchanger](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionSimpleFoam/heatExchanger)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 空气入口 | 5 m/s，300 K | `0.orig/air/U`、`T` |
| 水侧入口 | 0.01 m/s，400 K | `0.orig/porous/U`、`T` |
| 风机角速度 | 47.7 rad/s | `constant/air/MRFProperties` |
| 换热系数与面积密度 | 使用 `htcConst`、`AoV` 场 | `0.orig/porous` |

## 求解方法与物理模型

单位体积换热量写为 $q_v=h,a_v(T_h-T_c)$，其中 $h$ 为换热系数，$a_v$ 为换热面积密度。冷热两侧分别得到符号相反的能量源，稳态下放热量与吸热量应满足 $Q_h\simeq Q_c$，并可由 $Q=\dot m c_p\Delta T$ 核算。

芯体阻力采用 Darcy–Forchheimer 形式 $\mathbf S=-\mu\mathbf D\mathbf U-\tfrac12\rho|\mathbf U|\mathbf F\mathbf U$。第一项为黏性阻力，第二项为随速度平方增长的惯性阻力。阻力改变流量分配，流量又影响对流换热，两者需要在同一流场中求解。

本例使用 `chtMultiRegionSimpleFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/heat-exchanger.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip heat-exchanger.zip
cd heat-exchanger
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `blockMesh -region air` | 按顶点、块结构和加密比例生成背景网格。 |
| `blockMesh -region porous` | 按顶点、块结构和加密比例生成背景网格。 |
| `topoSet -region air -dict system/topoSetDict.1` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| `createBaffles -region air -overwrite` | 把指定内部面转成成对边界，形成挡板或叶片表面。 |
| `topoSet -region air -dict system/topoSetDict.2` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 冷热区域的体积换热

文件：`constant/porous/fvOptions`。本段设置冷热区域的体积换热。

```foam
porousToair
{
    type            constantHeatTransfer;

    interpolationMethod cellVolumeWeight;
    nbrRegion       air;
    master          true;

    nbrModel        airToporous;
    fields          (h);
    semiImplicit    no;
}
```

`nbrRegion air` 选定另一侧区域，`nbrModel` 将两侧换热模型配对，`master` 确定主从关系。配对后的同一换热过程分别进入冷热侧能量方程，用于维持热量收支。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionSimpleFoam/heatExchanger/constant/porous/fvOptions)。

### 2. 芯体的等效流动阻力

文件：`constant/air/fvOptions`。本段设置芯体的等效流动阻力。

```foam
porosityBlockage
{
    type            interRegionExplicitPorositySource;

    interRegionExplicitPorositySourceCoeffs
    {
        interpolationMethod cellVolumeWeight;
        nbrRegion       porous;

        type            DarcyForchheimer;

        d   (-1000 -1000 1e4);
        f   (0 0 0);

        coordinateSystem
        {
            origin  (0 0 0);
            e1      (0 1 0);
            e2      (0 0 1);
        }
    }
}
```

多孔阻力仅作用于映射得到的芯体区域。`d` 的各方向分量结合局部坐标系确定黏性阻力，方向差异用于表示芯体沿流道和横穿流道时不同的通流能力。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionSimpleFoam/heatExchanger/constant/air/fvOptions)。

### 3. 水侧入口温度

文件：`0.orig/porous/T`。本段设置水侧入口温度。

```foam
inlet
{
    type            fixedValue;
    value           uniform 400;
}
```

水侧入口为 400 K，空气入口为 300 K，二者温差提供换热驱动力。水侧初始温度为 350 K；迭代初期储存的热状态逐步被入口条件替代，稳定后的出口温度用于计算换热量。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionSimpleFoam/heatExchanger/0.orig/porous/T)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.chtMultiRegionSimpleFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `chtMultiRegionSimpleFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。本求解器采用稳态迭代，日志中的 Time 用作迭代序号。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `latestTime` |
| `startTime` | `0` |
| `endTime` | `2000` |
| `deltaT` | `1` |
| `writeControl` | `timeStep` |
| `writeInterval` | `50` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选air 与 porous，点击 **Apply**。先选择最后一个已写出的时刻，以 `T` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

分别计算空气侧和水侧的质量流量加权进出口温度，据此得到吸热与放热功率，并列出两者的相对偏差。空气侧同时提取芯体总压损失和风机压升，判断热量传递与流动阻力的关系。

改变空气入口流量或风机转速，比较换热量、出口温度和压降。单独研究换热系数时保持 `AoV` 与几何不变；研究芯体结构时，根据新结构同时确定换热面积密度和阻力系数。

> **熊猫说：** `porous` 是水侧流体区域，其材料由 `thermophysicalProperties` 指定。它求解流动与能量方程，通过体积热源与空气交换热量。

## 文件与来源

- [完整算例包](/downloads/engineering/heat-exchanger.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionSimpleFoam/heatExchanger)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
