建立低速泄压通道在防直通与通流之间的权衡模型，分析挡板间距与泄流间隙对总压损失、局部峰值速度和回流范围的影响。

## 工程场景与计算目标

电池箱泄压通道常需要兼顾有限空间、液滴阻挡和气体排出。交替挡板延长通路并阻断直线路径，但急转弯和收缩也会增加阻力。设计需要明确几何造成的通流代价，再与泄压元件的开启特性组合。

本例建立四级迷宫通道，以低速等温空气计算压降和回流。先保持入口流量比较挡板间隙，再将入口改为压力驱动，得到通流量随压差的变化。基准用于部件水力特性分析，高温可压缩喷放需要另行设置温度、压力与气体物性。

## 几何、尺寸与基准工况

几何由 `design.json` 中的尺寸和位置生成，采用四级交替挡板与两侧泄流间隙。坐标与尺寸均使用 m，流向由边界速度向量确定。

![电池箱泄压通道的迷宫阻力的结构分区与流动方向](/assets/engineering/battery-pack-vent-labyrinth-geometry.webp)

| 参数 | 基准值 | 含义 |
| --- | --- | --- |
| 计算域外包尺寸 | 0.28 × 0.06 × 0.025 m | 实际计算空间由流体块体并集确定 |
| 流体密度 | 1.184 kg/m³ | 惯性、压差换算和质量流量 |
| 运动黏度 | 1.56e-05 m²/s | 分子黏性输运 |
| 基础网格 | 20,736 单元 | 默认 MESH_REFINE=2 的设计网格 |

几何各部分的坐标范围如下。流体块体先合并，再从中划分导热固体或扣除障碍物；因此相邻、相交块体不会重复占据体积。

| 部件 | x 范围 / m | y 范围 / m | z 范围 / m |
| --- | --- | --- | --- |
| 流体区域1 | 0～0.28 | 0～0.06 | 0～0.025 |
| 障碍物1 | 0.045～0.057 | 0～0.045 | 0～0.025 |
| 障碍物2 | 0.105～0.117 | 0.015～0.06 | 0～0.025 |
| 障碍物3 | 0.165～0.177 | 0～0.045 | 0～0.025 |
| 障碍物4 | 0.225～0.237 | 0.015～0.06 | 0～0.025 |

| 边界名称 | 作用 | 基准条件 |
| --- | --- | --- |
| `inlet` | 入口 | U = (2 0 0) m/s |
| `outlet` | 出口 | 压力参考值 0 |

## 物理模型与求解方法

不可压缩流动满足质量守恒与动量守恒：

\[
\nabla\cdot\mathbf U=0,\qquad
\rho\left(\frac{\partial\mathbf U}{\partial t}+\mathbf U\cdot\nabla\mathbf U\right)
=-\nabla p+\nabla\cdot\boldsymbol\tau+\mathbf f.
\]

其中，\(\mathbf U\) 为速度，\(p\) 为物理压力，\(\boldsymbol\tau\) 为黏性应力，\(\mathbf f\) 为单位体积外力。连续性方程约束各截面的流量收支；动量方程描述压力、黏性作用和外力如何改变速度。

本例使用 `simpleFoam`，通过稳态迭代求解，日志中的 `Time` 表示迭代序号。湍流采用 `kOmegaSST`，同时求解湍动能与比耗散率；近壁分辨率通过 y⁺ 和网格比较评价。

## 配置文件与网格建立

[下载完整算例与配置代码](/downloads/engineering/battery-pack-vent-labyrinth.zip)。解压目录中已提供 `0.orig/`、`constant/`、`system/` 和几何数据，`build_case.py` 根据 `design.json` 重建相同输入；生成程序只使用 Python 标准库。

| 文件或目录 | 操作与用途 |
| --- | --- |
| `design.json` | 修改部件坐标、流体物性、速度或热功率；随后重新生成字典 |
| `geometry/model.obj` | 查看几何分区；曲线叶道以 blockMesh 圆弧为准 |
| `system/blockMeshDict` | 多块六面体网格的顶点、单元数与边界面 |
| `0.orig/` | 初始场和边界条件；建网格时复制到 `0/` |
| `constant/` | 物性、物理模型与区域设置 |
| `system/fvSchemes`、`system/fvSolution` | 离散格式、线性求解和耦合控制 |
| `Allmesh`、`Allsolve` | 分别完成网格准备与求解、结果提取 |

多块网格在肋片边缘、支路开口和分区界面处共享坐标平面，使边界与几何位置一致。默认加密级别为 2，薄通道与窄缝另外保留最低单元层数。

## 关键配置与解读

以下条目取自本页下载包的同名文件，几何和边界名称与上表对应。

### `0.orig/U`

```foam
boundaryField
{
    inlet { type fixedValue; value uniform (2 0 0); }
    walls { type noSlip; }
    outlet { type pressureInletOutletVelocity; value uniform (0 0 0); }
}
```

固定速度入口与已知截面积共同确定流量。出口采用 `pressureInletOutletVelocity`，使速度与边界通量协调；实体表面为无滑移壁面。MRF 中的旋转壁面速度由旋转区处理。

### `0.orig/p`

```foam
boundaryField
{
    inlet { type zeroGradient; }
    walls { type zeroGradient; }
    outlet { type fixedValue; value uniform 0; }
}
```

`simpleFoam` 中该字段是运动学压力，量纲为 m²/s²。出口参考值为 0，物理压差应乘以流体密度；速度入口使用零法向梯度，让压力由流量约束形成。

### `constant/turbulenceProperties`

```foam
simulationType RAS;
RAS { RASModel kOmegaSST; turbulence on; printCoeffs on; }
```

`simulationType` 决定是否求解湍流闭合模型。`RAS` 工况使用 SST 模型及随包的 `k`、`omega`、`nut` 字段；`laminar` 工况只使用物性文件中的分子黏度。


## 运行与计算检查

在 Linux 中加载 OpenCFD OpenFOAM v2512，然后进入解压目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
cd battery-pack-vent-labyrinth
bash Allmesh
bash Allsolve
```

安装位置不同，只需调整第一行环境路径。`Allmesh` 生成输入和网格，复制初始场并检查网格质量；`Allsolve` 调用 `simpleFoam`，运行后将监测记录整理到 `analysis/`。各阶段的详细信息分别写入 `log.blockMesh`、`log.checkMesh` 和 `log.simpleFoam`，遇到错误时脚本会停止并显示对应日志末尾。

修改工况时，先在新解压目录中编辑 `design.json`，再执行 `Allmesh`。网格生成以后，边界调整应写入 `0/`；如果重新生成网格，程序会再次使用参数文件和 `0.orig/`。保留各工况独立目录，便于核对尺寸、物性与结果。

先检查残差是否持续下降，再查看流量、压差和温度或转矩是否趋于稳定。不同方程的残差尺度不同，采用工程监测量的稳定性判断迭代是否足够。

## 结果提取与工程分析

沿通道中心路径提取压力，识别每级挡板消耗的压差。局部峰值速度用于检查狭缝负担，整体压降用于建立部件阻力曲线。用多个流量点拟合关系时保留原始数据，检查损失是否随速度平方近似变化。

在 ParaView 中打开 `case.foam`，选择最后一个已写出时刻。用 **Slice** 建立上述截面，用 **Plot Over Line** 提取沿线变化；流量计算使用速度的截面法向分量，配合 **Integrate Variables** 积分。输出表格时使用 **Save Data**，工况比较保持截面位置、色标和平均方式相同。

`analysis/monitor-history.csv` 保存监测对象的时间或迭代历史，`analysis/metrics.json` 整理边界流量、压力和温度等可用指标。内部通道分流、局部方差或单个壁面载荷按本节给出的选区继续提取。边界流量采用外法向为正，入口一般为负，出口一般为正。

## 参数比较与网格收敛

保持挡板数量，分别将间隙设为 10、15、20 mm；以相同流量比较压差，再用相同压差比较通流能力。

先完成基准工况，再每次改变一个设计因素。记录几何尺寸、入口总流量、总压损失、局部峰值速度和回流范围，将性能变化与流场结构对应。对选定方案再做网格比较：

```bash
MESH_REFINE=4 bash Allmesh
bash Allsolve
```

在新的解压目录执行上述命令，各方向相对默认级别增加一倍单元数。比较时使用相同物性、边界条件及结果提取位置，检查主要工程量随网格变化的幅度。自由液面案例还需减小 `maxDeltaT`，比较水位幅值和相位；示踪混合案例需同时检查浓度界面的数值扩散。

> **熊猫说：** 流量由法向速度积分得到。比较方案时保持所要求的流量或压差一致，才能解释阻力变化。

## 配套代码与资料

- [下载几何、完整配置、运行及分析代码](/downloads/engineering/battery-pack-vent-labyrinth.zip)。`VALIDATION.json` 和 `validation/` 保存 v2512 网格检查与短程启动记录，`files.sha256` 可用于核对文件完整性。
- [OpenFOAM 用户指南](https://www.openfoam.com/documentation/user-guide)：算例结构、网格与求解流程。
- [OpenFOAM v2512 源码文档](https://api.openfoam.com/2512/)：字段、边界和模型实现。

[返回实际工程应用](/topics/engineering/)
