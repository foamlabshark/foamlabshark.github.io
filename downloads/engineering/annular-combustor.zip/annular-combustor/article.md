求解环形通道内的旋流预混燃烧及下游叶排运动，评价出口温度分布和总压损失。

## 工程场景与计算目标

燃气轮机燃烧室将燃料的化学能转化为高温气流的焓。下游叶片承受的热负荷既取决于平均温度，也取决于热点的位置和强度。入口旋流有助于组织混合与燃烧，同时会改变径向压力分布和出口流向，因此温度均匀性与压力损失需要结合评价。

算例选取包含燃烧通道和叶排的环形扇区。预混气体从上游进入，流经燃烧区后进入旋转叶排；静止区与旋转区通过 AMI 交换场量。计算围绕两项问题展开：入口旋流如何改变热气流分布，叶排转动如何影响出口热点与压力损失。

## 几何、尺寸与基准工况

![环形燃烧室与下游涡轮的耦合流动：配套模型与基准输入](/assets/engineering/annular-combustor-geometry.webp)

环形通道及叶片由配套曲面确定，背景半径参数为 34、39、61、66 cm。网格先按厘米构建，再用 `transformPoints -scale 0.01` 统一转换为米。旋转轴沿 x 方向，运动单元区为 `rotating`。

模型与配置来源：[OpenFOAM v2512 · combustion/XiDyMFoam/annularCombustorTurbine](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/combustion/XiDyMFoam/annularCombustorTurbine)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 入口温度 | 573 K | `0.orig/T` 的 `inletField` |
| 初始压力 | 1 MPa | `0.orig/p` |
| 入口轴向、径向速度 | 40、20 m/s | `0.orig/U` 的 `cylindricalInletVelocity` |
| 旋转区域角速度 | 10 rad/s | `constant/dynamicMeshDict` |
| 甲烷当量比 | 0.7 | `constant/combustionProperties` |

## 求解方法与物理模型

`XiDyMFoam` 求解可压缩预混燃烧和运动网格上的流动。火焰褶皱因子 $\Xi$ 将层流火焰速度 $S_u$ 与湍流传播速度 $S_T$ 联系起来，$S_T=\Xi S_u$；它描述湍流使火焰表面积增大后对整体传播的影响。

入口周向速度引入角动量，在近似径向平衡下有 $\partial p/\partial r=\rho U_\theta^2/r$。AMI 随叶排转动更新两侧插值关系，使通量跨越转静交界面。截面温度离散程度可用 $\sigma_T=\sqrt{\langle(T-\langle T\rangle)^2\rangle}$ 表示，并结合总压损失评价热气流品质。

本例使用 `XiDyMFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/annular-combustor.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip annular-combustor.zip
cd annular-combustor
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `createPatch -dict system/createPatchDict.cyclic -overwrite` | 重建边界集合及周期、AMI 等边界类型。 |
| `snappyHexMesh -overwrite` | 依据随包曲面裁切、贴合背景网格，并执行局部加密。 |
| `createPatch -dict system/createPatchDict.ami -overwrite` | 重建边界集合及周期、AMI 等边界类型。 |
| `transformPoints -scale 0.01` | 把网格坐标按指定比例换算为米。 |
| `mergeOrSplitBaffles -split -overwrite` | 整理挡板两侧拓扑，使相邻计算区域具有独立的面连接。 |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `potentialFoam -pName pPotential -initialiseUBCs` | 求解势流初始化问题，使速度与边界通量协调。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 入口旋流

文件：`0.orig/U`。本段设置入口旋流。

```foam
inlet
{
    type            cylindricalInletVelocity;
    origin          (-0.64 0.5 0);
    axis            (1 0 0);
    axialVelocity   40;
    radialVelocity  20;
    rpm             12732; // ut=40,r=3e-2,omega=ut/r,rpm=omega*60/(2*pi)
    value           uniform (0 0 0);
}
```

`cylindricalInletVelocity` 以给定轴线为基准组合轴向、径向和周向速度。`rpm` 规定入口气流的旋转强度；叶排运动由 `dynamicMeshDict` 中的 `omega` 规定。两个参数分别控制来流和固体转动。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/combustion/XiDyMFoam/annularCombustorTurbine/0.orig/U)。

### 2. 叶排运动与转静连接

文件：`constant/dynamicMeshDict`。本段设置叶排运动与转静连接。

```foam
dynamicFvMesh   dynamicMotionSolverFvMesh;

solver          solidBody;

solidBodyCoeffs
{
    cellZone        rotating;

    solidBodyMotionFunction  rotatingMotion;
    rotatingMotionCoeffs
    {
        origin        (0 0 0);
        axis          (1 0 0);
        omega         10;
    }
```

`rotating` 指定作刚体转动的单元区，外部通道保持静止。该区域的交界面采用 AMI；转动过程中，两侧面的重叠范围决定场量能否连续传递。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/combustion/XiDyMFoam/annularCombustorTurbine/constant/dynamicMeshDict)。

### 3. 预混燃烧参数

文件：`constant/combustionProperties`。本段设置预混燃烧参数。

```foam
laminarFlameSpeedCorrelation Gulders;

fuel            Methane;

Su              Su [ 0 1 -1 0 0 0 0 ] 0.434;

SuModel         unstrained;

equivalenceRatio equivalenceRatio [ 0 0 0 0 0 0 0 ] 0.7;

sigmaExt        sigmaExt [ 0 0 -1 0 0 0 0 ] 100000;

XiModel         transport;
```

燃料、当量比和层流火焰速度关联式确定未燃混合物的基础燃烧特性。`XiModel transport` 通过输运方程描述火焰褶皱，使湍流对传播速度的影响进入燃烧计算。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/combustion/XiDyMFoam/annularCombustorTurbine/constant/combustionProperties)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.XiDyMFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `XiDyMFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `latestTime` |
| `startTime` | `0` |
| `endTime` | `0.1` |
| `deltaT` | `1e-4` |
| `writeControl` | `adjustable` |
| `writeInterval` | `2e-3` |
| `adjustTimeStep` | `yes` |
| `maxCo` | `0.2` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选燃烧通道，点击 **Apply**。先选择最后一个已写出的时刻，以 `T` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

在叶排前后设置固定轴向截面，提取质量流量加权平均温度、温度标准差及总压。平均温度反映热量输运，标准差反映冷热分布，总压差反映流动损失。截面位置和平均方式在各工况中保持一致。

按转子周期保存温度场，跟踪热点随相位的变化。先固定叶排角速度、改变入口旋流，再固定旋流、改变叶排角速度，分别比较出口温度分布和总压损失。AMI 两侧通量及插值权重用于检查转静界面的传递质量。

> **熊猫说：** 网格缩放在准备流程中执行一次。完成厘米到米的转换后，旋转轴、点火位置和其他位置参数均按米填写。

## 文件与来源

- [完整算例包](/downloads/engineering/annular-combustor.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/combustion/XiDyMFoam/annularCombustorTurbine)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
