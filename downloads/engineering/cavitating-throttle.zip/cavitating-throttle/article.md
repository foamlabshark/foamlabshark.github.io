模拟高压液体流经毫米级节流口时的空化，计算蒸气分布、压力恢复及过流能力。

## 工程场景与计算目标

燃油喷射和液压节流元件中的急缩通道使液流迅速加速，局部静压随之降低。压力降至相应温度下的饱和蒸气压附近时，部分液体汽化；下游压力恢复后，蒸气又可能凝结。相变引起的密度和可压缩性变化会进一步影响流量与压力分布。

算例由入口总压与出口静压驱动液体通过急缩—急扩通道，采用 `cavitatingFoam` 计算均相液—蒸气混合物。分析从喉部压力下降开始，依次考察蒸气生成位置、空化区长度和流量系数，说明空化对节流特性的影响。

## 几何、尺寸与基准工况

![节流通道的压降与空化：配套模型与基准输入](/assets/engineering/cavitating-throttle-geometry.webp)

通道长 17 mm，上下游高度均为 5 mm。节流段位于 x = 5～7 mm，喉部高度 0.3 mm；展向厚度为 0.3 mm，采用 `empty` 边界。节流附近通过三轮局部加密提高分辨率，选区分别由 `topoSetDict.1`～`.3` 定义。

模型与配置来源：[OpenFOAM v2512 · multiphase/cavitatingFoam/RAS/throttle](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/multiphase/cavitatingFoam/RAS/throttle)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 入口总压 | 30 MPa | `0.orig/p/inlet` |
| 出口静压 | 10 MPa | `0.orig/p/outlet` |
| 液相密度 | 830 kg/m³ | `constant/transportProperties` |
| 初始时间步 | 10⁻⁸ s | `system/controlDict` |
| 喉部高度与长度 | 0.3 mm、2 mm | `system/blockMeshDict` |

## 求解方法与物理模型

均相模型以共同的速度和压力描述液体与蒸气，混合密度为 $\rho=\alpha_v\rho_v+(1-\alpha_v)\rho_l$。压力—密度关系及相变物性决定给定压力下的混合状态。蒸气体积分数 $\alpha_v$ 则表示局部汽化程度。

空化数 $\sigma_c=(p_{\mathrm{ref}}-p_v)/(\tfrac12\rho_lU_{\mathrm{ref}}^2)$ 比较压力裕量与动压，数值降低表示更容易接近汽化条件。流量系数 $C_d=Q/[A\sqrt{2\Delta p/\rho_l}]$ 比较实际流量与理想流量，用于量化收缩、损失及空化对过流能力的综合影响。

本例使用 `cavitatingFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/cavitating-throttle.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip cavitating-throttle.zip
cd cavitating-throttle
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `topoSet -dict system/topoSetDict.1` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| `refineMesh -dict system/refineMeshDict -overwrite` | 细化指定单元选区，提高关键位置的空间分辨率。 |
| `topoSet -dict system/topoSetDict.2` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| `refineMesh -dict system/refineMeshDict -overwrite` | 细化指定单元选区，提高关键位置的空间分辨率。 |
| `topoSet -dict system/topoSetDict.3` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| `refineMesh -dict system/refineMeshDict -overwrite` | 细化指定单元选区，提高关键位置的空间分辨率。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 压力驱动边界

文件：`0.orig/p`。本段设置压力驱动边界。

```foam
inlet
{
    type            totalPressure;
    p0              uniform 300e5;
}
```

入口总压与出口静压形成驱动压差。喉部静压还受局部加速和下游恢复影响，需由求解结果提取；它决定蒸气首先出现的位置。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/cavitatingFoam/RAS/throttle/0.orig/p)。

### 2. 均相混合物的热力学关系

文件：`constant/thermodynamicProperties`。本段设置均相混合物的热力学关系。

```foam
barotropicCompressibilityModel linear;

psiv            2.5e-06;

rholSat         830;

psil            5e-07;

pSat            4500;

rhoMin          0.001;
```

该文件规定压力—密度关系和相变物性。饱和蒸气压确定汽化的压力尺度，相密度和可压缩性参数共同决定液—蒸气混合物对压力的响应。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/cavitatingFoam/RAS/throttle/constant/thermodynamicProperties)。

### 3. 液相与蒸气的输运物性

文件：`constant/transportProperties`。本段设置液相与蒸气的输运物性。

```foam
phases (vapour water);

water
{
    transportModel  Newtonian;
    nu              7.831e-06;
    rho             830;
}

vapour
{
    transportModel  Newtonian;
    nu              4.252e-05;
    rho             0.14;
}
```

基准液相密度为 830 kg/m³，相名称沿用 `water`。解释计算结果时采用此处给定的物性；替换液体时，同时修改输运与热力学参数。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/cavitatingFoam/RAS/throttle/constant/transportProperties)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.cavitatingFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `cavitatingFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `latestTime` |
| `startTime` | `0` |
| `endTime` | `0.002` |
| `deltaT` | `1e-08` |
| `writeControl` | `adjustable` |
| `writeInterval` | `0.0001` |
| `adjustTimeStep` | `on` |
| `maxCo` | `0.5` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选节流通道，点击 **Apply**。先选择最后一个已写出的时刻，以 `p` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

沿喉部中心线输出压力和 `alpha.vapour`，观察低压区内的蒸气生成及下游压力恢复后的变化。对蒸气体积分数作体积积分，得到蒸气总体积；从入口流量计算流量系数，使空化范围与元件通流能力对应起来。

逐级调整出口压力，比较流量、最低压力和空化区长度。工况比较使用相同网格，随后单独加密喉部并减小时间步，分析空间和时间分辨率的影响。流动与声学 Courant 数用于控制压力变化较快时的时间推进。

> **熊猫说：** 压力场以 Pa 为单位。入口 30 MPa 对应 `3e7`，出口 10 MPa 对应 `1e7`。

## 文件与来源

- [完整算例包](/downloads/engineering/cavitating-throttle.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/multiphase/cavitatingFoam/RAS/throttle)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
