利用 NREL Phase VI 实体风力机的公开尺寸，建立叶片解析模型，分析转矩、轴向推力与失速对功率的影响。

## 工程场景：叶片为什么会在风速增大后失去效率

风力机的输出取决于叶片将气流动量转化为轴端转矩的能力。沿叶片半径方向，旋转线速度逐渐增大，来流与旋转运动合成后的相对速度、入流角和雷诺数随之变化。因此，实际叶片需要同时改变弦长和扭转角。把叶片替换成等宽平板，或只计算一个二维翼型，不能直接回答整台风轮能够产生多大功率。

叶片表面的压力差既产生驱动转矩，也产生轴向推力和弯曲载荷。风速升高后，局部迎角可能增大，吸力面发生分离。分离区扩展时，转矩增长可能放缓，载荷波动却继续增大。对工程设计而言，需要同时检查平均功率、轴承载荷和叶根载荷，不能只比较一张速度云图。

本案例选用在 NASA Ames 风洞开展试验的 NREL Phase VI 双叶片风力机。它具有公开的实体尺寸、翼型坐标、测试工况和压力测点，适合把几何重建、旋转参考系和试验对比放在同一条分析流程中。先计算 7 m/s 的零偏航工况，再增加到 10 m/s 和 15 m/s，观察叶片分离如何改变转矩和推力。

本节采用 Sequence S 的标准叶尖、上风向刚性风轮和 3° 叶尖桨距构型。尺寸来自 [NREL/TP-500-29955，第 21 页、附录 A](https://wdh.energy.gov/docs/projects/uae6/phase_vi_test_report.pdf)。配套模型按尺寸表重建；叶根过渡和叶尖封口的建模方法随模型一并提供。

![按公开尺寸重建的 Phase VI 双叶片风轮与叶片剖面](/assets/engineering/nrel-geometry.webp)

## 几何、坐标与工况

| 项目 | 本案例取值 | 设置依据 |
| --- | --- | --- |
| 风轮直径 | 10.058 m | 标准叶尖构型，半径 5.029 m |
| 叶片数 | 2 | 实体风轮 |
| 轮毂高度 | 12.192 m | 原试验尺寸；建塔架时使用 |
| 翼型 | S809 | 按报告表 A-2 的坐标重建 |
| 叶尖桨距 | 3° | Sequence S |
| 名义转速 | 71.63 r/min | 报告基本参数；对比某条记录时换成该记录的实测转速 |
| 入口风速 | 7、10、15 m/s | 本节选择的比较工况 |
| 空气密度、运动黏度 | 1.225 kg/m³、1.5×10⁻⁵ m²/s | 本节计算输入；正式试验对比按测得温压修正 |

取风轮中心为原点，来流沿正 x 方向，初始叶片沿正、负 z 方向展开。报告中的转向为从上游看逆时针，因此本坐标下角速度向量沿负 x 方向。对应角速度大小为

\[
\omega=\frac{2\pi n}{60}=7.5011\ {\rm rad/s}.
\]

7 m/s 时的叶尖速比约为 5.39，即叶尖旋转速度约为来流速度的 5.39 倍。这个量决定了叶片所见相对来流的方向，也是比较不同转速工况的基本参数。

### 从尺寸表重建叶片

资料包内的 `blade-stations.csv` 保存径向站位、弦长、扭转角、厚度和扭转轴位置；`s809.csv` 保存翼型坐标。运行 `build_geometry.py` 后生成以米为单位的两片叶片 STL 和几何检查记录。

报告表 A-1 的扭转角以 3.772 m 站位为零，而 3° 桨距以标准叶尖为参照。重建时先将表中扭转角换算到标准叶尖，再叠加桨距：

\[
\beta(r)=\beta_{\rm table}(r)-\beta_{\rm table}(5.029)+3^\circ.
\]

这一处理保证叶尖安装角为 3°。若直接在表中每个角度上加 3°，整片叶片的安装角会发生偏移。

叶根 0.508–0.883 m 为圆截面段，0.883–1.257 m 为圆截面到翼型的过渡段。模型保留这些长度，并按表中厚度和弦长连续过渡。标准叶尖终止于 5.029 m，不能把表中用于延长叶尖的 5.305 m 和 5.532 m 站位也加入本构型。

```bash
python3 build_geometry.py
surfaceCheck geometry/blade1.stl
surfaceCheck geometry/blade2.stl
```

第一条命令生成几何；后两条检查表面连通性、法向和包围盒。每片叶片应为封闭表面，风轮最大径向尺寸应与 5.029 m 一致。检查通过后再复制到 `constant/triSurface/`。

## 计算模型：先求平均载荷，再分析非定常分离

本节先使用 `simpleFoam`、MRF 旋转区域和 `kOmegaSST` 模型。MRF 在局部区域中引入旋转坐标系的作用，叶片网格保持不动，适合估计固定转速下的平均载荷。稳态解中，连续性与动量方程共同约束质量守恒、压力梯度、黏性应力和惯性作用。

用相对速度表示旋转区域中的方程时，还会出现科里奥利项和离心项：

\[
\frac{D\mathbf U_r}{Dt}+2\boldsymbol\Omega\times\mathbf U_r
+\boldsymbol\Omega\times(\boldsymbol\Omega\times\mathbf r)
=-\frac{1}{\rho}\nabla p+\nabla\cdot\boldsymbol\tau_{\rm eff}/\rho.
\]

其中，\(\mathbf U_r\) 是相对旋转区域的速度，\(\boldsymbol\tau_{\rm eff}\) 包含分子黏性和湍流模型给出的应力。MRF 中的旋转源项由求解器处理，不需要再在速度场中人为叠加一遍旋转速度。

如果高风速工况下转矩持续摆动、分离区无法形成稳定状态，应转为 `pimpleFoam` 配合旋转网格和 AMI，按时间平均获得载荷。此时需要重新建立旋转区与静止区之间的接口，并用时间步长控制叶片每步转角。

## 如何搭建 OpenFOAM 算例

### 1. 建立流体域和旋转区域

先建立叶片解析的孤立风轮计算域：入口位于风轮上游 5D，出口位于下游 10D，侧边界距轴线 5D；D 为 10.058 m。这些距离是本节的计算域初值，随后扩大计算域检查转矩变化。旋转区域采用围绕 x 轴的圆柱，半径 5.5 m、轴向范围 −1 至 1 m，并在 `snappyHexMesh` 中建立名为 `rotor` 的 `cellZone`。

进行风洞数据对比时，还需评估原试验段壁面和塔架的影响。原风洞截面为 24.4 m×36.6 m，不能把孤立风轮的远场边界解释为原风洞壁面。建议先完成孤立风轮的网格收敛，再建立同构型的风洞域对照，比较两种域下的推力和转矩。

叶片前缘、后缘、叶尖和近尾流需要局部细化。采用贴壁解析的 SST 设置时，以第一层网格的 y⁺ 接近 1 为目标；首轮计算后用 `yPlus` 输出反查层厚。层数、增长率和总厚度要共同保证边界层覆盖，单独减小第一层厚度并不能解决层网格过薄的问题。

### 2. 指定 MRF 和湍流模型

以下 `constant/MRFProperties` 按 v2512 的 MRF 字典结构设置，旋转区域名称与网格中的 `rotor` 对应。

```foam
rotorFrame
{
    active              yes;
    cellZone            rotor;
    nonRotatingPatches  ();
    origin              (0 0 0);
    axis                (-1 0 0);
    omega               7.50107606;
}
```

`origin` 是主轴经过的点，`axis` 同时确定轴向和旋转正方向。`nonRotatingPatches` 为空表示旋转区内的壁面随该参考系运动；若旋转区包进了静止塔架，必须把相应壁面列入这一项。

`constant/turbulenceProperties` 选择 SST 模型：

```foam
simulationType RAS;
RAS
{
    RASModel        kOmegaSST;
    turbulence      on;
    printCoeffs     on;
}
```

这里需要同时建立 `0/k`、`0/omega` 和 `0/nut`。入口湍动能可由测得的湍流强度估算，\(k=1.5(IU_\infty)^2\)；比耗散率可按 \(\omega=k^{1/2}/(C_\mu^{1/4}L)\) 给定，L 为湍流长度尺度。I 和 L 应作为独立输入记录，不能与转速共用一个名为 `omega` 的物理量。

### 3. 设置速度、压力和壁面

| 边界 | `U` | `p` | 说明 |
| --- | --- | --- | --- |
| 入口 | `fixedValue`，7 m/s 沿 x | `zeroGradient` | 高风速工况只改变入口速度和相应湍流量 |
| 出口 | `inletOutlet` | `fixedValue`，0 | 固定压力基准，允许合理处理局部回流 |
| 远侧边界 | `symmetryPlane` | `symmetryPlane` | 网格几何边界也使用对应类型 |
| 叶片 | `noSlip` | `zeroGradient` | MRF 在旋转壁面处施加与参考系一致的速度 |

`simpleFoam` 中的 `p` 是运动学压力，量纲为 m²/s²。后处理绝对压力差时乘以密度；使用 `forces` 时通过 `rhoInf` 完成这一换算。

### 4. 求解并记录载荷

在 `system/controlDict` 的 `functions` 中加入：

```foam
rotorLoads
{
    type            forces;
    libs            (forces);
    patches         (blade1 blade2);
    rho             rhoInf;
    rhoInf          1.225;
    CofR            (0 0 0);
    writeControl    timeStep;
    writeInterval   1;
}
```

该对象积分两片叶片上的压力力和黏性力。`CofR` 取风轮中心，得到关于主轴的力矩。按本节坐标，驱动方向为负 x，因此提取转矩时应同时保留力矩向量与角速度向量，用点积求功率，避免因坐标符号把输出功率写成耗功。

```bash
blockMesh
snappyHexMesh -overwrite
checkMesh -allTopology -allGeometry
decomposePar
mpirun -np 8 simpleFoam -parallel
reconstructPar -latestTime
```

这组命令依次生成背景网格、贴合叶片表面、检查网格并进行八分区计算。`decomposeParDict` 的分区数要与 `-np 8` 一致。监控内容除残差外，还包括入口出口通量、轴向推力和主轴转矩；残差降低而转矩仍持续漂移时，不应提前结束计算。

## 如何分析结果

首先计算风轮机械功率和功率系数：

\[
P=\mathbf M\cdot\boldsymbol\Omega,\qquad
C_P=\frac{P}{\tfrac12\rho\pi R^2U_\infty^3},\qquad
C_T=\frac{F_x}{\tfrac12\rho\pi R^2U_\infty^2}.
\]

这里的 P 是叶片空气动力产生的轴功率。发电机输出还受到机械和电气损失影响，两者应在结果表中分列。

其次，在约 30%、47%、63%、80% 和 95% 半径站位提取表面压力系数，沿弦长与同工况压力测量比较。报告的压力系数采用相应测站的动压处理；自行按 \(\tfrac12\rho[U_\infty^2+(\omega r)^2]\) 计算的几何相对动压应单独标注，比较前统一归一化方法。

最后，把三个风速下的吸力面分离位置、截面压力差与转矩变化对应起来。若叶根附近的压力分布偏差大而中外翼段较好，先检查叶根过渡形状和三维分离；若各站位压力差都偏小，优先检查桨距、转向、速度和压力单位。

建议输出一张工况表，至少列出风速、转速、网格数、叶片 y⁺ 分布、转矩、推力、功率和通量误差。分别加密叶片附近网格和延长尾流区域，观察载荷是否趋于稳定；非定常计算另列时间步长、统计起止时间和转矩标准差。

> **熊猫说：**
>
> 先确认叶片转向和桨距，再讨论湍流模型。几何安装角相差几度，就可能让附着流动变成大范围分离，随后得到的网格和模型比较会围绕错误工况展开。

## 模型、配置与资料

- [下载尺寸表、STL 重建程序和配置资料包](/downloads/engineering/nrel-phase-vi.zip)。包内记录叶根与叶尖处理、坐标变换和文件检查方法。
- [NREL Phase VI 原始技术报告](https://wdh.energy.gov/docs/projects/uae6/phase_vi_test_report.pdf)：构型、尺寸、测点和试验文件命名。
- [v2512 MRF 配置实例](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/incompressible/simpleFoam/rotatingCylinders/constant/MRFProperties)：本文 MRF 字典的配置依据。
- [v2512 simpleFoam 源码](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/applications/solvers/incompressible/simpleFoam)。

[返回实际工程应用](/topics/engineering/)
