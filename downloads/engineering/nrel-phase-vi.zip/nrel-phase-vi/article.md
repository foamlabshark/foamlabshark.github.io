依据 NREL Phase VI 风力机的公开尺寸重建叶片，计算转矩、推力及失速对功率的影响。

## 工程场景与计算目标

风力机通过叶片表面应力将气流动量转化为轴端转矩。沿半径增大的旋转速度与轴向来流叠加，使相对速度、入流角和雷诺数具有径向差异。弦长与扭转角的分布由此影响各翼段载荷，也决定整副风轮的功率与推力。

风速上升会改变局部迎角，使吸力面分离范围扩大。此时转矩增长可能减缓，载荷波动仍可能增加。因此，结果分析同时考察平均功率、轴向推力和叶根载荷，将效率变化与结构载荷联系起来。

NREL Phase VI 双叶片风力机曾在 NASA Ames 风洞开展试验，公开资料包含尺寸、翼型、工况与压力测点。本例先计算 7 m/s 零偏航来流，再比较 10 m/s 和 15 m/s，借助表面压力与分离位置解释转矩和推力变化。

本节采用 Sequence S 的标准叶尖、上风向刚性风轮和 3° 叶尖桨距构型。尺寸来自 [NREL/TP-500-29955，第 21 页、附录 A](https://wdh.energy.gov/docs/projects/uae6/phase_vi_test_report.pdf)。配套模型按尺寸表重建；叶根过渡和叶尖封口的建模方法随模型一并提供。

![按公开尺寸重建的 Phase VI 双叶片风轮与叶片剖面](/assets/engineering/nrel-geometry.webp)

## 几何、尺寸与基准工况

| 项目 | 本案例取值 | 设置依据 |
| --- | --- | --- |
| 风轮直径 | 10.058 m | 标准叶尖构型，半径 5.029 m |
| 叶片数 | 2 | 实体风轮 |
| 轮毂高度 | 12.192 m | 原试验尺寸；建塔架时使用 |
| 翼型 | S809 | 按报告表 A-2 的坐标重建 |
| 叶尖桨距 | 3° | Sequence S |
| 名义转速 | 71.63 r/min | 报告基本参数；对比某条记录时换成该记录的实测转速 |
| 入口风速 | 7、10、15 m/s | 本节选择的比较工况 |
| 空气密度、运动黏度 | 1.225 kg/m³、1.5×10⁻⁵ m²/s | 本节计算输入；正式试验对比按测得温压修正 |

取风轮中心为原点，来流沿正 x 方向，初始叶片沿正、负 z 方向展开。报告中的转向为从上游看逆时针，因此本坐标下角速度向量沿负 x 方向。对应角速度大小为

\[
\omega=\frac{2\pi n}{60}=7.5011\ {\rm rad/s}.
\]

7 m/s 来流下，叶尖速比约为 5.39。它表示叶尖旋转速度与来流速度的比值，影响叶片所见相对流向，是比较不同转速工况的基本尺度。

### 从尺寸表重建叶片

`blade-stations.csv` 保存径向站位、弦长、扭转角、厚度及扭转轴位置，`s809.csv` 保存翼型坐标。`build_geometry.py` 将这些截面连接为米制叶片 STL，并输出几何检查记录。

报告表 A-1 的扭转角以 3.772 m 站位为零，而 3° 桨距以标准叶尖为参照。重建时先将表中扭转角换算到标准叶尖，再叠加桨距：

\[
\beta(r)=\beta_{\rm table}(r)-\beta_{\rm table}(5.029)+3^\circ.
\]

换算后标准叶尖的安装角为 3°，各径向截面相对叶尖保持表中给定的扭转差。

叶根 0.508～0.883 m 为圆截面，0.883～1.257 m 连续过渡到翼型。标准叶尖终止于 5.029 m；表中的 5.305 m、5.532 m 站位属于延长叶尖构型。

```bash
python3 build_geometry.py
surfaceCheck geometry/blade1.stl
surfaceCheck geometry/blade2.stl
```

生成程序建立两片叶片，`surfaceCheck` 检查连通性、法向和包围盒。随包已将生成的 STL 放入 `constant/triSurface/`。修改叶片尺寸并重新生成后，再将更新的曲面复制到该目录。

## 计算模型：先求平均载荷，再分析非定常分离

平均载荷采用 `simpleFoam`、MRF 和 `kOmegaSST` 计算。MRF 在固定网格的局部区域中计入旋转参考系效应，连续性与动量方程共同求得满足质量守恒的压力和速度。

用相对速度表示旋转区域中的方程时，还会出现科里奥利项和离心项：

\[
\frac{D\mathbf U_r}{Dt}+2\boldsymbol\Omega\times\mathbf U_r
+\boldsymbol\Omega\times(\boldsymbol\Omega\times\mathbf r)
=-\frac{1}{\rho}\nabla p+\nabla\cdot\boldsymbol\tau_{\rm eff}/\rho.
\]

其中，\(\mathbf U_r\) 是相对旋转区域的速度，\(\boldsymbol\tau_{\rm eff}\) 包含分子黏性和湍流模型给出的应力。MRF 中的旋转源项由求解器处理，不需要再在速度场中人为叠加一遍旋转速度。

高风速下若分离结构和转矩持续周期变化，可采用 `pimpleFoam`、运动网格与 AMI 计算，再统计平均载荷和波动。旋转区与静止区需建立配对接口，时间步按每步叶片转角及局部 Courant 数控制。

## 配置文件与网格建立

配套算例使用尺寸表重建的两片叶片。流体域为 x=−25～75 m、y 和 z=−25～25 m，来流沿 x 正方向。旋转区为 x=−2～2 m、半径 5.8 m 的圆柱，围绕负 x 轴以 7.501076059 rad/s 旋转。计算域与旋转区分别由 `blockMeshDict` 和 `topoSetDict` 定义。

`Allmesh` 先建立背景网格，再用 `snappyHexMesh` 捕捉叶片并进行距离加密，随后建立 `rotating` 单元区。检查日志中 `blade1`、`blade2` 的边界面数，确认两片叶片均进入体积网格。叶片最细表面单元尺度约 0.039 m，基准网格用于启动和网格比较；载荷比较需继续加密前缘、后缘及近壁方向，并通过 y⁺ 选择相应壁面分辨率。

本例计算孤立风轮的平均载荷。与风洞记录比较时，继续建立 24.4 m×36.6 m 试验段边界及相应塔架，分别评价来流、壁面约束和塔架的影响。

## 关键配置与解读

以下配置来自下载包的同名文件。

### `constant/MRFProperties`

```foam
rotor { active true; cellZone rotating; origin (0 0 0); axis (-1 0 0); omega 7.501076059; nonRotatingPatches (inlet outlet farfield); }
```

`rotating` 与 `topoSet` 建立的单元区一致，`axis (-1 0 0)` 同时定义主轴方向和正旋转方向。两片叶片位于旋转区内，远场边界保持静止。

### `0.orig/U`

```foam
boundaryField
{
    inlet { type fixedValue; value uniform (7 0 0); }
    outlet { type pressureInletOutletVelocity; value uniform (0 0 0); }
    farfield { type slip; }
    "blade.*" { type noSlip; }
}
```

入口速度为 7 m/s，侧边界采用滑移条件。叶片壁面由 MRF 处理旋转速度，不能再将整个流场叠加一次刚体旋转速度。改变风速后同步核对入口湍流量。

### `constant/turbulenceProperties`

```foam
simulationType RAS; RAS { RASModel kOmegaSST; turbulence on; printCoeffs on; }
```

SST 模型通过 k 和 omega 描述湍动能与时间尺度。随包初始场使用 1% 入口湍流强度对应的 k，具体试验对比应按该组风洞记录设置入口湍流。

## 运行与计算检查

[下载完整算例与配置代码](/downloads/engineering/nrel-phase-vi.zip)，解压后进入 `nrel-phase-vi` 目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
bash Allmesh
bash Allsolve
```

第一行加载 OpenCFD OpenFOAM v2512，安装位置不同则调整路径。`Allmesh` 完成网格建立、区域处理和质量检查，再将 `0.orig/` 复制为运行所用初始场。`Allsolve` 运行 `simpleFoam` 并将最新监测记录整理到 `analysis/last-monitors.json`。在 ParaView 中打开 `case.foam` 查看场文件。

网格修改在新解压目录进行，保留基准算例便于比较。建网格前修改 `0.orig/`，网格完成后修改 `0/`；求解范围与输出频率在 `system/controlDict` 中调整。详细记录保存在 `log.*`，运行脚本遇到错误会停止并显示对应日志。

## 结果提取与工程分析

程序同时输出 `analysis/loads.csv`，包含时间或迭代序号、三向总力以及关于转轴原点的三向总力矩。分别从 `force.dat` 和 `moment.dat` 按相同时间对齐，后续功率和周期统计使用这一文件。

机械功率与功率、推力系数定义为：

\[
P=\mathbf M\cdot\boldsymbol\Omega,\qquad
C_P=\frac{P}{\tfrac12\rho\pi R^2U_\infty^3},\qquad
C_T=\frac{F_x}{\tfrac12\rho\pi R^2U_\infty^2}.
\]

P 表示叶片产生的轴功率。与发电功率比较时，再计入机械传动和电气转换效率。

其次，在约 30%、47%、63%、80% 和 95% 半径站位提取表面压力系数，沿弦长与同工况压力测量比较。报告的压力系数采用相应测站的动压处理；自行按 \(\tfrac12\rho[U_\infty^2+(\omega r)^2]\) 计算的几何相对动压应单独标注，比较前统一归一化方法。

将三个风速下的截面压差、吸力面分离位置与转矩变化对应。叶根偏差集中时，检查过渡几何和三维分离；各翼段压差整体偏低时，检查安装角、转向及来流和压力的单位。

结果表列出风速、转速、网格数、y⁺、转矩、推力、功率和通量误差。分别加密叶片网格与扩展尾流区域，考察载荷变化；瞬态结果另列时间步、统计区间与转矩标准差。

> **熊猫说：** 叶片转向和安装角直接决定相对迎角。建立模型后先核对桨距与转向，再开展网格及湍流模型比较。

## 模型、配置与资料

- [下载完整风力机算例、尺寸表与 STL 重建程序](/downloads/engineering/nrel-phase-vi.zip)。包内记录叶根与叶尖处理、坐标变换和文件检查方法。
- [NREL Phase VI 原始技术报告](https://wdh.energy.gov/docs/projects/uae6/phase_vi_test_report.pdf)：构型、尺寸、测点和试验文件命名。
- [v2512 MRF 配置实例](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/incompressible/simpleFoam/rotatingCylinders/constant/MRFProperties)：本文 MRF 字典的配置依据。
- [v2512 simpleFoam 源码](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/applications/solvers/incompressible/simpleFoam)。

配套 `VALIDATION.json` 与 `validation/` 保存本配置的网格检查和短程启动记录，`files.sha256` 用于核对文件完整性。

[返回实际工程应用](/topics/engineering/)
