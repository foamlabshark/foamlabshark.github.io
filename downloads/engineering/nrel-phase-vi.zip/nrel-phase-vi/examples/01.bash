python3 build_geometry.py
surfaceCheck geometry/blade1.stl
surfaceCheck geometry/blade2.stl
