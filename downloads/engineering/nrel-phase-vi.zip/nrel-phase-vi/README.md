# NREL Phase VI 风力机：功率、推力与失速

完整的 OpenCFD OpenFOAM v2512 算例。详细工程场景、尺寸、配置和结果分析见 article.md。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
bash Allmesh
bash Allsolve
```

Allmesh 建网格并检查，Allsolve 运行 simpleFoam 并提取监测结果。打开 case.foam 查看流场；analysis/last-monitors.json 保存最新监测值。Python 3 标准库用于结果汇总。

建网格前修改 0.orig，完成网格后修改 0。不同网格与工况使用独立解压目录。system/controlDict 设置完整运行范围，validation/ 保存网格检查和短程启动记录。

几何与物性资料来源见 SOURCE.json，文件校验值见 files.sha256。本站程序和配置许可证见 COPYING；公开几何与测量数据保留各自来源许可。
