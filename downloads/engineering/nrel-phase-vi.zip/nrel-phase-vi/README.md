# NREL Phase VI 风力机：功率、推力与失速

OpenCFD OpenFOAM v2512；本文配套的模型与配置资料。

请先阅读 article.md，其中说明计算对象、几何尺度、文件位置与每个示例的作用。examples/ 保存正文代码片段，须按正文放入对应算例文件；它不是一套已经完成网格的独立算例。

运行 python3 build_geometry.py 生成米制双叶片 STL。坐标来自 NREL/TP-500-29955 表 A-1/A-2；叶根按表中尺度插值，标准叶尖外推到 5.029 m 并封口。原始报告：https://wdh.energy.gov/docs/projects/uae6/phase_vi_test_report.pdf

验证记录：模型生成、文件解析、单位及解析运动校核通过；尚未在 OpenFOAM 中完成网格与流场求解，不包含数值仿真结果。
