"""Reconstruct the Phase VI nominal blade from NREL/TP-500-29955 Tables A-1/A-2.
Python 3, standard library only. Coordinates and STL output are in metres.
Root transition interpolates an ellipse to S809; standard tip is linearly extrapolated
from the last two inboard stations and capped at R=5.029 m.
"""
from pathlib import Path
import csv, math, struct, json

ROOT=Path(__file__).resolve().parent

def interp(x, data):
    for a,b in zip(data,data[1:]):
        if x<=b[0]:
            f=(x-a[0])/(b[0]-a[0]);return a[1]+f*(b[1]-a[1])
    a,b=data[-2:];return b[1]+(x-b[0])*(b[1]-a[1])/(b[0]-a[0])

def stl(path, triangles):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('wb') as out:
        out.write(b'FoamLab nominal reconstruction; metres'.ljust(80,b' '));out.write(struct.pack('<I',len(triangles)))
        for a,b,c in triangles:
            u=[b[i]-a[i] for i in range(3)];v=[c[i]-a[i] for i in range(3)]
            n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
            d=math.sqrt(sum(q*q for q in n));n=[q/d if d else 0 for q in n]
            out.write(struct.pack('<12fH',*n,*a,*b,*c,0))

def build():
    with (ROOT/'blade-stations.csv').open() as f: rows=[{k:float(v) for k,v in r.items()} for r in csv.DictReader(f)]
    with (ROOT/'s809.csv').open() as f: air=list(csv.DictReader(f))
    upper=sorted([(0.,0.)]+[(float(r['upper_x']),float(r['upper_y'])) for r in air])
    lower=sorted([(float(r['lower_x']),float(r['lower_y'])) for r in air])
    # Closed profile, LE -> upper -> TE -> lower -> LE.
    profile=[]
    for j in range(96):
        t=2*math.pi*j/96;x=(1-math.cos(t))/2
        profile.append((x,interp(x,upper if j<=48 else lower),math.sin(t)))
    def value(r,k):return interp(r,[(s['r'],s[k]) for s in rows])
    tip_twist=value(5.029,'twist');sections=[]
    radii=sorted(set([r['r'] for r in rows]+[5.029]+[0.508+(5.029-.508)*i/180 for i in range(181)]))
    for r in radii:
        c=value(r,'chord');th=value(r,'thickness');axis=value(r,'axis')/100
        beta=math.radians(value(r,'twist')-tip_twist+3)
        fraction=max(0,min(1,(r-.883)/(1.257-.883)))
        coords=[]
        for x,y,s in profile:
            q=c*(x-axis);normal=(1-fraction)*th*.5*s+fraction*c*y
            coords.append((q*math.sin(beta)+normal*math.cos(beta),-q*math.cos(beta)+normal*math.sin(beta),r))
        sections.append(coords)
    faces=[]
    for lo,hi in zip(sections,sections[1:]):
        for j in range(96):
            k=(j+1)%96;faces.extend([(lo[j],hi[j],hi[k]),(lo[j],hi[k],lo[k])])
    for end,reverse in [(sections[0],True),(sections[-1],False)]:
        mid=tuple(sum(p[k] for p in end)/len(end) for k in range(3))
        for j in range(96):
            tri=(mid,end[j],end[(j+1)%96]);faces.append(tri if reverse else tri[::-1])
    # Ensure outward winding independently of loft convention.
    volume=sum(sum(a[i]*(b[(i+1)%3]*c[(i+2)%3]-b[(i+2)%3]*c[(i+1)%3]) for i in range(3)) for a,b,c in faces)/6
    if volume<0:faces=[t[::-1] for t in faces]
    stl(ROOT/'geometry/blade1.stl',faces)
    stl(ROOT/'geometry/blade2.stl',[tuple((p[0],-p[1],-p[2]) for p in t) for t in faces])
    report={'units':'m','radius_m':5.029,'tip_pitch_deg':3,'tip_table_twist_deg':tip_twist,'rotation_axis':[-1,0,0],'rpm':71.63,'omega_rad_s':71.63*2*math.pi/60,'triangles_per_blade':len(faces),'root_transition':'ellipse-to-S809 interpolation','tip':'linear extension to 5.029 m; flat cap'}
    (ROOT/'geometry/report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':build()
