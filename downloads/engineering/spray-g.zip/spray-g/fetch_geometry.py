"""Retrieve ECN Gen1 3mm cap geometry without redistributing the upstream CAD."""
from pathlib import Path
import urllib.request,hashlib
URL='https://ecn.sandia.gov/wp-content/uploads/2016/08/3mm.stl'
SHA='f1a1578777858223d020c3635252dfb4e7af7adcb6b1d00aa7d6fc8ca8cc4cc7'
if __name__=='__main__':
    p=Path(__file__).resolve().parent/'geometry/3mm.stl';p.parent.mkdir(exist_ok=True)
    data=p.read_bytes() if p.exists() else urllib.request.urlopen(URL,timeout=60).read()
    if hashlib.sha256(data).hexdigest()!=SHA:raise SystemExit('Upstream CAD differs from the reviewed Gen1 file. Check the ECN geometry page before using it.')
    p.write_bytes(data);print(p,'SHA256',SHA)
