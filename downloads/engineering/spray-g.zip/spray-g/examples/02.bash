cp -r "$FOAM_TUTORIALS/lagrangian/sprayFoam/aachenBomb" sprayG-G1
cd sprayG-G1
