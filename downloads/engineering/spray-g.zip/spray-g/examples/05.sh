source /usr/lib/openfoam/openfoam2512/etc/bashrc
bash Allmesh
bash Allsolve
