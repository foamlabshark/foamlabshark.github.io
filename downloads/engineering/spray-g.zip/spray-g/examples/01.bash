python3 fetch_geometry.py
surfaceTransformPoints -scale '(0.001 0.001 0.001)' geometry/3mm.stl geometry/3mm-metres.stl
surfaceCheck geometry/3mm-metres.stl
