blockMesh
checkMesh
decomposePar
mpirun -np 8 sprayFoam -parallel
reconstructPar
