"""Validate measured rate/positions and prepare eight coneNozzleInjection entries.
Usage: python3 prepare_injection.py --positions hole_centres.csv --rate rate.csv
Positions: hole,x_m,y_m,z_m,azimuth_deg. Rate: time_s,mass_flow_kg_s (whole injector).
Requires an explicit Cd and local half-angle; no invented measurement defaults.
"""
import argparse,csv,math,json
from pathlib import Path
def mixture():
    x={'N2':.8971,'CO2':.0652,'H2O':.0377};M={'N2':28.0134,'CO2':44.0095,'H2O':18.01528};mw=sum(x[k]*M[k] for k in x)
    return {'molecular_weight_g_mol':mw,'mass_fractions':{k:x[k]*M[k]/mw for k in x},'rho_at_600kPa_573K':600000*mw/1000/(8.314462618*573),'pure_N2_pressure_for_rho3_5_Pa':3.5*8.314462618*573/(M['N2']/1000)}
def prepare(positions,rate,cd,angle):
    p=list(csv.DictReader(Path(positions).open()));r=list(csv.DictReader(Path(rate).open()))
    if len(p)!=8 or len({row['hole'] for row in p})!=8:raise ValueError('Provide eight unique hole centres.')
    t=[float(x['time_s']) for x in r];q=[float(x['mass_flow_kg_s']) for x in r]
    if len(t)<3 or not all(math.isfinite(x) for x in t+q) or any(b<=a for a,b in zip(t,t[1:])) or min(q)<0:raise ValueError('Invalid time or mass flow.')
    if abs(t[0])>1e-12 or abs(t[-1]-.00078)>1e-8:raise ValueError('Align hydraulic SOI=0; this G1 preparation expects duration 0.00078 s.')
    integral=sum((b-a)*(c+d)/2 for a,b,c,d in zip(t,t[1:],q,q[1:]));mass=1e-5
    if integral<=0 or abs(integral/mass-1)>.2:raise ValueError('Measured rate integral differs from 10 mg by more than 20%; check units and shot conditions.')
    if not (0<cd<=1 and 0<angle<45):raise ValueError('Check Cd and local half-angle.')
    lines=['// ECN Spray G G1: generated injection entries; SI units.','injectionModels','{']
    directions=[]
    for i,row in enumerate(p):
        phi=math.radians(float(row['azimuth_deg']))
        if not math.isfinite(phi):raise ValueError('Azimuth must be finite degrees.')
        th=math.radians(37);d=(math.sin(th)*math.cos(phi),math.sin(th)*math.sin(phi),math.cos(th));xyz=[float(row[k]) for k in ['x_m','y_m','z_m']]
        if not all(math.isfinite(v) for v in xyz) or max(abs(v) for v in xyz)>.01:raise ValueError('Hole coordinates must be transformed to metres near the nozzle tip.')
        directions.append(d);vec=lambda a:'('+ ' '.join(f'{v:.9g}' for v in a)+')'
        # coneNozzleInjection normalises this shape using massTotal; retain measured profile shape.
        table='\n'.join(f'            ({ti:.9g} {qi/integral:.9g})' for ti,qi in zip(t,q))
        lines.append(f'''    hole{i+1}
    {{
        type coneNozzleInjection;
        SOI 0;
        massTotal 1.25e-6;
        parcelBasisType mass;
        injectionMethod disc;
        flowType flowRateAndDischarge;
        outerDiameter 0.000165;
        innerDiameter 0;
        duration 0.00078;
        position {vec(xyz)};
        direction {vec(d)};
        parcelsPerSecond 2000000;
        flowRateProfile table
        (
{table}
        );
        Cd constant {cd};
        thetaInner constant 0;
        thetaOuter constant {angle};
        // Set sizeDistribution from selected droplet data before solving.
    }}''')
    lines.append('}');Path('injectionModels.partial').write_text('\n'.join(lines))
    report={'measured_mass_kg':integral,'target_mass_kg':mass,'shape_scale':1/integral,'directions':directions,'required_next_input':'sizeDistribution for each injection; use measured droplet data','mixture':mixture()};Path('injection-report.json').write_text(json.dumps(report,indent=2));return report
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--positions');p.add_argument('--rate');p.add_argument('--cd',type=float);p.add_argument('--half-angle',type=float);a=p.parse_args()
    print(json.dumps(mixture(),indent=2))
    if a.positions and a.rate and a.cd is not None and a.half_angle is not None:print(json.dumps(prepare(a.positions,a.rate,a.cd,a.half_angle),indent=2))
    elif any([a.positions,a.rate,a.cd,a.half_angle]):p.error('Provide --positions, --rate, --cd and --half-angle together.')
