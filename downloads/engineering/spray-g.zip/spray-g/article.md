建立 ECN Spray G 八孔非反应喷雾模型，计算液滴破碎、蒸发、贯穿和喷束相互作用。

## 工程场景与计算目标

缸内直喷将液体燃油在毫秒尺度内送入高温气体。燃油射流破碎为液滴，在气动阻力下减速，并通过换热蒸发。喷射结束后，液态燃油、蒸气与局部降温气体仍同时存在，其空间分布决定后续点火区域的混合状态。

贯穿距离关系到空气利用和壁面液膜形成，液滴尺寸影响蒸发时间，多喷束卷吸则改变扩散与偏转。喷油器计算因此需要同时描述孔位、孔轴方向、流量分配和液滴演化。

本例采用 ECN Spray G 喷油器的 G1 工况，计算喷孔出口至外部气体中的非反应混合。喷孔数、名义孔径、孔轴倾角及燃油与环境条件取自公开资料，孔外等效注入采用下文给定的等角圆周排列。通过液相和气相贯穿检验喷雾发展。

名义设计 STL 用于查看喷嘴结构与尺度，`sprayFoam` 以颗粒追踪描述孔外液滴。喷孔内部流动另需界面解析网格，本例将出口喷射状态作为外部喷雾的输入。

![Spray G 公开喷油器几何与八束喷雾布置](/assets/engineering/spray-g-geometry.webp)

## 几何、尺寸与基准工况

| 项目 | G1 输入 | 对计算的影响 |
| --- | --- | --- |
| 喷孔数 | 8 | 需要 8 个注入位置与方向 |
| 名义喷孔直径 | 0.165 mm | 决定出口尺度和名义流通面积 |
| 喷孔轴与喷油器轴夹角 | 37° | 用于构造各孔中心线方向 |
| 燃油 | 异辛烷 | 液体物性与气相燃油组分需一致 |
| 燃油温度 | 363 K | 影响密度、黏度、表面张力和蒸发 |
| 喷射前燃油压力 | 20 MPa | 试验供油条件；本配置由流量、面积与 Cd 确定注入速度 |
| 环境温度 | 573 K | 提供蒸发所需热量 |
| 环境密度 | 3.5 kg/m³ | 影响阻力、卷吸与贯穿 |
| 标称喷射总质量 | 10 mg | 八个孔的注入质量之和 |
| 液力喷射持续时间 | 0.78 ms | 从实际开始出油到结束出油 |

这些数值见 [ECN G1 目标条件](https://ecn.sandia.gov/gasoline-spray-combustion/target-condition/spray-g-operating-condition/) 与 [喷孔几何说明](https://ecn.sandia.gov/gasoline-spray-combustion/computational-method/mesh-and-geometry/)。0.68 ms 的电子驱动时间与 0.78 ms 的液力持续时间对应不同过程，在注入模型中应使用液力时间及相应的流量曲线。

约 600 kPa 的环境压力与指定组成对应 3.5 kg/m³ 密度。预燃气体的体积分数组成为 89.71% N₂、6.52% CO₂、3.77% H₂O。改变气体组成时，由状态方程重新确定同一密度对应的压力。

### 几何文件怎样使用

本节链接 ECN 第一代名义几何的 `3mm.stl`，其中针阀处于打开状态。原文件包围盒约为 3.699×6.323×3.700 个坐标单位；与毫米级喷嘴外形和 0.165 mm 喷孔共同核对后，导入米制算例时使用 10⁻³ 的长度变换。该旧 CAD 的长轴与当前喷雾测量坐标不同，旋转和平移要在几何预览中确认。

```bash
python3 fetch_geometry.py
surfaceTransformPoints -scale '(0.001 0.001 0.001)' geometry/3mm.stl geometry/3mm-metres.stl
surfaceCheck geometry/3mm-metres.stl
```

下载程序校验几何文件，`surfaceCheck` 核对缩放尺寸。计算坐标以喷油器轴为 z 轴、下游为正方向，从 CAD 提取孔位替换基准注入中心时，对出口中心和孔轴方向采用相同的坐标变换。

结果表记录几何代次和喷油器编号，用于对应名义 CAD、CT 重建及实测孔径。改变孔径后，同步更新流通面积和质量分配。

## `sprayFoam` 中的气相和液滴

气相求解欧拉质量、动量、能量和组分方程，液滴采用拉格朗日追踪。计算颗粒代表一定数量的真实液滴，沿轨迹与周围单元交换质量、动量和能量。

液滴运动的基本关系可写成

\[
m_d\frac{d\mathbf u_d}{dt}
=\frac12 C_D\rho_g A_d|\mathbf U_g-\mathbf u_d|
(\mathbf U_g-\mathbf u_d)+m_d\mathbf g,
\qquad \frac{d\mathbf x_d}{dt}=\mathbf u_d.
\]

下标 d、g 分别表示液滴和气体。液滴相对气体的速度越大，阻力通常越强；直径变化又会改变质量与迎风面积之比，使小液滴更容易跟随气体运动。

液滴从气体吸热，显热提高液滴温度，汽化潜热用于相变。燃油蒸气进入气相组分方程，液滴减少、蒸气增加与气体降温因而构成同一耦合过程。

气相采用 RANS，液滴采用球形阻力、`RanzMarshall` 换热和 `liquidEvaporationBoil` 相变。基准保持非反应，破碎从 `ReitzDiwakar` 开始比较。初始粒径和破碎参数分别结合粒径分布与贯穿数据评价。

## 配置文件与网格建立

下载包提供八孔外部喷雾的完整配置。气相域为 100 mm×100 mm×100 mm 的封闭立方体，网格为 50×50×50，喷雾沿 z 正方向发展。喷嘴内部流动由出口注入条件代替，公开 CAD 随包保留用于尺寸与喷孔构型对照。

八个注入中心在半径 0.5 mm 的圆周上等间隔布置，位于 z=0.2 mm 平面，各孔轴与 z 轴夹角为 37°。这里的出口圆周半径、10° 局部半锥角、流量系数 0.6 和初始粒径分布构成外部喷雾基准参数，汇总于 `injection-design.json`。后续与特定喷油器比较时，用该喷油器的测量或几何数据替换对应条目。

基准流量曲线在前 100 μs 线性上升、中间保持平台、最后 100 μs 下降，总持续时间 780 μs。每孔 `massTotal` 为 1.25 mg，八孔合计 10 mg；注入模型按曲线积分归一分配质量。该梯形曲线用于配置基准，实测喷射率可直接替换 `flowRateProfile` 的时间—权重表。表末将零流量延伸至 0.003 s，使喷射结束附近的时间积分仍落在表格范围内；喷射持续时间仍为 780 μs，总喷油量保持 10 mg。

环境体积分数按分子量换算后，N₂、CO₂、H₂O 的质量分数分别为 0.876266819、0.100051526、0.023681655。温度为 573 K，按理想气体状态方程由 3.5 kg/m³ 密度得到压力 581415.411 Pa。异辛烷气相 NASA 系数取自 [LLNL 热力学数据](https://combustion.llnl.gov/sites/combustion/files/prf_v3_therm_dat.txt)，液相物性使用 OpenFOAM 的 `IC8H18`；化学反应关闭。

## 关键配置与解读

以下配置来自下载包的同名文件。

### `constant/thermophysicalProperties`

```foam
thermoType { type hePsiThermo; mixture reactingMixture; transport sutherland; thermo janaf; energy sensibleEnthalpy; equationOfState perfectGas; specie specie; }
chemistryReader foamChemistryReader;
foamChemistryFile "<case>/constant/reactions";
foamChemistryThermoFile "<case>/constant/thermo";
inertSpecie N2;
liquids { IC8H18; }
solids {}
```

气相采用理想气体混合物和温度相关 JANAF 热力学性质。`foamChemistryReader` 读取随包的 `reactions` 与 `thermo`；反应列表为空，组分输运与液滴蒸发仍然求解。液相与气相均使用 `IC8H18` 名称。

### `constant/sprayCloudProperties`

```foam
hole1
{
 type coneNozzleInjection; SOI 0; massTotal 1.25e-6;
 parcelBasisType mass; injectionMethod disc; flowType flowRateAndDischarge;
 outerDiameter 0.000165; innerDiameter 0;
 duration 0.00078; position (0.0005 0 0.0002); direction (0.601815023152 0 0.798635510047);
 parcelsPerSecond 2000000;
 flowRateProfile table ((0 0) (0.0001 1) (0.00068 1) (0.00078 0) (0.003 0));
 Cd constant 0.6; thetaInner constant 0; thetaOuter constant 10;
 sizeDistribution { type RosinRammler; RosinRammlerDistribution { minValue 1e-6; maxValue 0.000165; lambda 0.00012; n 3; } }
}
```

这是八孔中的第一孔。`position` 的单位为 m，`direction` 为孔轴单位向量；`thetaOuter` 定义围绕该孔轴的局部喷雾半锥角。Rosin–Rammler 分布在 1～165 μm 范围内选取初始液滴直径，lambda 为 120 μm，n 为 3。其余七孔采用旋转后的中心和方向。

### `system/controlDict`

```foam
application sprayFoam;
startFrom startTime; startTime 0; stopAt endTime; endTime 0.003;
deltaT 1e-7; adjustTimeStep yes; maxCo 0.3; maxDeltaT 2e-6;
writeControl adjustableRunTime; writeInterval 2e-5;
purgeWrite 0; writeFormat ascii; writePrecision 10; writeCompression off;
timeFormat general; timePrecision 10; runTimeModifiable true;
```

计算覆盖喷射及喷后发展到 3 ms，最大时间步为 2 μs。初始气相网格为 2 mm；网格和颗粒数比较需要共同进行，以检查液滴源项分布、贯穿和卷吸对空间及统计分辨率的敏感性。

## 运行与计算检查

[下载完整算例与配置代码](/downloads/engineering/spray-g.zip)，解压后进入 `spray-g` 目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
bash Allmesh
bash Allsolve
```

第一行加载 OpenCFD OpenFOAM v2512，安装位置不同则调整路径。`Allmesh` 完成网格建立、区域处理和质量检查，再将 `0.orig/` 复制为运行所用初始场。`Allsolve` 运行 `sprayFoam` 并将最新监测记录整理到 `analysis/last-monitors.json`。在 ParaView 中打开 `case.foam` 查看场文件。

网格修改在新解压目录进行，保留基准算例便于比较。建网格前修改 `0.orig/`，网格完成后修改 `0/`；求解范围与输出频率在 `system/controlDict` 中调整。详细记录保存在 `log.*`，运行脚本遇到错误会停止并显示对应日志。

## 结果提取与工程分析

ECN 分别发布液相、三维液体分布和气相贯穿数据。本节使用 [Sandia 当前 Spray G 数据入口](https://ecn.sandia.gov/data/sandia-spray-g-data/) 中的 G1 异辛烷数据，并记录液相识别阈值。该入口已经指出早期部分气相数据存在问题，选择文件时应沿用当前页面推荐的数据。

先统一时间零点和质量：计算 0 ms 对应液力喷射开始，实验信号按其定义换算。累计喷入量与剩余液滴、燃油蒸气及边界流出燃油共同构成质量收支。

贯穿比较采用与测量一致的投影和识别阈值。将颗粒质量或液相体积投影到相同像素尺度后提取液相贯穿，蒸气贯穿则采用对应浓度判据。

沿轴向设置多个截面，比较喷束中心、液体分布和向中心的偏转。结合气相速度判断卷吸影响，再分析注入方向、粒径及破碎设置的作用。

粒径统计采用带真实液滴数量权重的 Sauter 平均直径：

\[
D_{32}=\frac{\sum n_id_i^3}{\sum n_id_i^2},
\]

其中 \(n_i\) 是第 i 个计算颗粒代表的液滴数。直接对计算颗粒直径求算术平均，会丢失颗粒权重，得到另一个统计量。

> **熊猫说：** 八孔总质量为 10 mg，均匀分配时每孔 1.25 mg。37° 表示孔轴倾角，每束喷雾绕自身孔轴展开的锥角另行设置。

## 几何、数据与配置资料

- [下载八孔喷雾完整算例、几何与数据](/downloads/engineering/spray-g.zip)。随包包含 ECN 原始 STL、八孔配置、气液物性、初始场和运行程序。
- [ECN 喷油器名义 CAD 与 CT 几何](https://ecn.sandia.gov/gasoline-spray-combustion/computational-method/mesh-and-geometry/)。
- [ECN 喷射率数据入口](https://ecn.sandia.gov/gasoline-spray-combustion/target-condition/)：选择与喷油器编号、压力和驱动条件一致的数据。
- [v2512 aachenBomb 喷雾配置原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/sprayFoam/aachenBomb/constant/sprayCloudProperties)：本文文件结构与注入类型的出处。

配套 `VALIDATION.json` 与 `validation/` 保存本配置的网格检查和短程启动记录，`files.sha256` 用于核对文件完整性。

[返回实际工程应用](/topics/engineering/)
