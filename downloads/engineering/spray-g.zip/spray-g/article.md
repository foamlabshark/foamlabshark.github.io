以 ECN Spray G 八孔汽油喷油器为对象，建立非反应喷雾计算，分析液滴破碎、蒸发、贯穿距离与多束喷雾相互作用。

## 工程场景：燃油喷入气缸之后发生了什么

缸内直喷发动机在有限的喷射时间内，将液体燃油送入高温气体。燃油离开喷孔后形成射流，经过破碎产生液滴；液滴在阻力作用下减速，同时与周围气体交换热量并蒸发。喷油结束时，气缸内仍可能同时存在液态燃油、燃油蒸气和较冷的局部气体。这些分布决定了随后点火位置附近的混合气组成。

喷雾贯穿过长，可能使燃油撞击活塞或缸壁并形成液膜；贯穿过短，则可能降低空气利用率。液滴过大时，蒸发需要更长时间；多束喷雾相互靠近时，卷吸气流又会改变各束的方向和扩散速度。因此，喷油器设计既要关注单个喷孔，也要关注孔数、孔轴方向和喷射过程中的总质量分配。

本案例采用 Engine Combustion Network 的 Spray G 喷油器及 G1 工况，研究汽油直喷中的非反应混合过程。计算区域从喷孔出口延伸到外部气体，使用真实喷油器的八孔布置、喷孔尺度、燃油和环境条件。将燃烧关闭后，可以先用液相与气相贯穿距离检验喷雾模型，再研究点火和放热。

这里选用的几何来自 Sandia 公开的名义设计 STL，工况来自 ECN 目标条件。喷孔内部流动与外部喷雾采用不同的空间描述：前者需要解析喷孔和液体界面，后者把液滴表示成计算颗粒。本节主线使用 `sprayFoam` 求解外部喷雾，喷油器 CAD 用来确认孔位、方向和几何尺度。

![Spray G 公开喷油器几何与八束喷雾布置](/assets/engineering/spray-g-geometry.webp)

## 真实模型、尺寸与喷射条件

| 项目 | G1 输入 | 对计算的影响 |
| --- | --- | --- |
| 喷孔数 | 8 | 需要 8 个注入位置与方向 |
| 名义喷孔直径 | 0.165 mm | 决定出口尺度和名义流通面积 |
| 喷孔轴与喷油器轴夹角 | 37° | 用于构造各孔中心线方向 |
| 燃油 | 异辛烷 | 液体物性与气相燃油组分需一致 |
| 燃油温度 | 363 K | 影响密度、黏度、表面张力和蒸发 |
| 喷射前燃油压力 | 20 MPa | 影响喷出速度；不是计算域的环境压力 |
| 环境温度 | 573 K | 提供蒸发所需热量 |
| 环境密度 | 3.5 kg/m³ | 影响阻力、卷吸与贯穿 |
| 标称喷射总质量 | 10 mg | 八个孔的注入质量之和 |
| 液力喷射持续时间 | 0.78 ms | 从实际开始出油到结束出油 |

这些数值见 [ECN G1 目标条件](https://ecn.sandia.gov/gasoline-spray-combustion/target-condition/spray-g-operating-condition/) 与 [喷孔几何说明](https://ecn.sandia.gov/gasoline-spray-combustion/computational-method/mesh-and-geometry/)。0.68 ms 的电子驱动时间与 0.78 ms 的液力持续时间对应不同过程，在注入模型中应使用液力时间及相应的流量曲线。

目标条件中的约 600 kPa 环境压力与指定气体组成共同给出 3.5 kg/m³ 的密度。该预燃环境按体积分数含 89.71% N₂、6.52% CO₂ 和 3.77% H₂O。若改用纯氮气，保持相同密度时压力需要由状态方程重新计算，不能把组分改成纯氮而仍宣称所有目标条件完全相同。

### 几何文件怎样使用

本节链接 ECN 第一代名义几何的 `3mm.stl`，其中针阀处于打开状态。原文件包围盒约为 3.699×6.323×3.700 个坐标单位；与毫米级喷嘴外形和 0.165 mm 喷孔共同核对后，导入米制算例时使用 10⁻³ 的长度变换。该旧 CAD 的长轴与当前喷雾测量坐标不同，旋转和平移要在几何预览中确认。

```bash
python3 fetch_geometry.py
surfaceTransformPoints -scale '(0.001 0.001 0.001)' geometry/3mm.stl geometry/3mm-metres.stl
surfaceCheck geometry/3mm-metres.stl
```

下载程序校验文件哈希，防止把其他代次的喷油器几何混入。缩放后用 `surfaceCheck` 查看尺寸，再在 CAD 或 ParaView 中识别喷孔出口。外部喷雾的计算坐标取喷油器轴为 z 轴、下游为正 z；每个孔的出口中心需经过相同的坐标变换。

第一代名义 CAD、后续 CT 重建几何及各编号喷油器的实测孔径存在差异。结果表应记录所选几何代次和喷油器编号；修改孔径时要同步检查流通面积和各孔质量分配。

## `sprayFoam` 中的气相和液滴

气相采用欧拉场求解质量、动量、能量和组分输运；液滴采用拉格朗日颗粒追踪。一个计算颗粒通常代表多个物理液滴，它的位置和速度随时间更新，并向所在网格单元交换质量、动量和能量。

液滴运动的基本关系可写成

\[
m_d\frac{d\mathbf u_d}{dt}
=\frac12 C_D\rho_g A_d|\mathbf U_g-\mathbf u_d|
(\mathbf U_g-\mathbf u_d)+m_d\mathbf g,
\qquad \frac{d\mathbf x_d}{dt}=\mathbf u_d.
\]

下标 d、g 分别表示液滴和气体。液滴相对气体的速度越大，阻力通常越强；直径变化又会改变质量与迎风面积之比，使小液滴更容易跟随气体运动。

蒸发通过质量和热量交换连接两相。液滴吸收气体热量后升温，同时汽化潜热抑制升温；蒸发出的燃油进入气相组分方程。因而观察结果时，应把液滴消失、燃油蒸气增加和局部气体降温联系起来。

本节采用 RANS 气相、球形阻力、`RanzMarshall` 换热和 `liquidEvaporationBoil` 相变模型，先保持不反应。破碎模型可以从 v2512 教程中的 `ReitzDiwakar` 起步，再比较其他模型对粒径和贯穿的影响。初始粒径分布与破碎模型参数是需要检验的输入，不能用一条贯穿曲线同时确定全部参数。

## 从 v2512 算例搭建八孔喷雾

### 1. 复制完整模板，保留热物性文件结构

```bash
cp -r "$FOAM_TUTORIALS/lagrangian/sprayFoam/aachenBomb" sprayG-G1
cd sprayG-G1
```

模板来自 OpenCFD v2512 的 `aachenBomb`。它提供气相热物性、喷雾云、初始字段和求解控制的完整结构。随后按下表逐项修改；原模板的喷孔、燃油和环境不能直接作为 Spray G 工况。

| 文件或目录 | 需要修改的内容 |
| --- | --- |
| `system/blockMeshDict` | 外部气体域与局部网格尺度 |
| `0/` 或模板的初始字段目录 | U、p、T、k、ε 及各气体组分 |
| `constant/thermophysicalProperties` 及其引用文件 | 气相混合物、液态异辛烷和热力学数据 |
| `constant/combustionProperties` | 关闭燃烧反应 |
| `constant/sprayCloudProperties` | 八孔注入、温度、流量、粒径和破碎模型 |
| `system/controlDict` | 毫秒级计算时间、输出间隔与后处理对象 |

先建立直径约 100 mm、下游长度约 100 mm 的外部气体域作为计算起点，并通过扩大域检查边界影响。出口中心放在域内，不能恰好落在壁面或网格面上。由于主线采用出口注入，喷孔内部 CAD 不作为外部网格中的实心障碍再次覆盖注入位置。

### 2. 配置组分、温度与环境压力

v2512 液体库中异辛烷的名称为 `IC8H18`，应在液体组分、活跃蒸发组分以及气相热物性中保持一致。将教程中正庚烷对应的数据完整替换为异辛烷，不能只把文本 `C7H16` 改名而保留原热物性系数。

气相字典使用质量分数，而目标环境给出的是体积分数。理想气体混合物可按下式换算：

\[
Y_i=\frac{x_iM_i}{\sum_jx_jM_j}.
\]

资料包中的 `prepare_injection.py` 输出质量分数和状态方程检查结果。初始燃油蒸气质量分数为 0，各环境组分质量分数之和为 1。压力使用绝对压力，不能像不可压缩求解器那样把整个密闭环境初始化为 0 Pa。

### 3. 把总喷射质量分给八个孔

若先采用均匀分配，每孔质量为 1.25×10⁻⁶ kg，八孔总和为 10⁻⁵ kg。第 j 个孔的名义方向为

\[
\mathbf d_j=(\sin37^\circ\cos\varphi_j,
\sin37^\circ\sin\varphi_j,\cos37^\circ),
\quad \varphi_j=\varphi_0+45^\circ j.
\]

\(\varphi_0\) 由 CAD 与测量坐标的对齐确定。37° 是孔轴倾角；围绕每个孔轴展开的局部喷雾锥角是另一个参数，两者不能混用。

以下是 `sprayCloudProperties` 的 `subModels/injectionModels` 中单孔的主要条目，完整注入字典按 v2512 `coneNozzleInjection` 的模板组织：

```foam
type                coneNozzleInjection;
SOI                 0;
massTotal           1.25e-6;
parcelBasisType     mass;
injectionMethod     disc;
flowType            flowRateAndDischarge;
outerDiameter       0.000165;
innerDiameter       0;
duration            0.00078;
direction           (0.601815 0 0.798636);
parcelsPerSecond    2000000;
```

这一段规定第一孔的方向、质量和持续时间。完整模型还需填写该孔出口位置、`flowRateProfile`、`Cd`、局部锥角及 `sizeDistribution`。准备程序读取八个实测或 CAD 出口坐标，再生成八份字典；缺少坐标或流量数据时会明确指出缺项。

`flowRateProfile` 使用同一工况测得的随时间变化曲线，先换算到秒并对齐液力喷射起点。资料包提供 CSV 检查和归一化程序，检查时间是否递增、流量是否为非负以及积分质量是否与输入一致。不要把 20 MPa 直接写进质量流量列。

### 4. 选择时间步长并检查颗粒统计

```foam
application         sprayFoam;
startFrom           startTime;
startTime           0;
endTime             0.003;
deltaT              1e-7;
adjustTimeStep      yes;
maxCo               0.3;
maxDeltaT           2e-6;
writeControl        adjustableRunTime;
writeInterval       2e-5;
```

以上 `controlDict` 条目覆盖喷射及喷后发展至 3 ms。`maxCo` 控制气相时间步，喷雾云还需要自己的颗粒运动限制。减小网格后应同步检查时间步和颗粒穿越单元的情况。

```bash
blockMesh
checkMesh
decomposePar
mpirun -np 8 sprayFoam -parallel
reconstructPar
```

开始求解后，先看累计注入质量和颗粒数量，再看残差。颗粒数加倍后，贯穿与粒径统计应逐渐稳定；若图像中的单束喷雾仍呈现明显随机断裂，应检查每束、每个时间区间的颗粒采样量。

## 如何比较计算与测量

ECN 分别发布液相、三维液体分布和气相贯穿数据。本节使用 [Sandia 当前 Spray G 数据入口](https://ecn.sandia.gov/data/sandia-spray-g-data/) 中的 G1 异辛烷数据，并记录液相识别阈值。该入口已经指出早期部分气相数据存在问题，选择文件时应沿用当前页面推荐的数据。

第一步核对时间零点和总质量。计算的 0 ms 定义为液力开始喷射，实验若以电子信号为零点，需要转换。对闭合区域，累计喷入质量应与剩余液滴、燃油蒸气及离开边界的燃油质量相平衡。

第二步比较贯穿距离。液滴最远位置对极少数大液滴很敏感，不能直接等同于光学阈值定义的液相贯穿。应按测量投影方向，将计算颗粒质量或液相体积投影到相同像素尺度，再应用对应阈值。气相贯穿也需要对应的蒸气识别条件。

第三步分析多束喷雾。按轴向距离截取多个平面，比较各束中心位置、液体分布和向中心区域的偏转。再查看气相速度矢量，判断变化来自卷吸流场还是注入方向、粒径与破碎设置。

第四步统计粒径。Sauter 平均直径为

\[
D_{32}=\frac{\sum n_id_i^3}{\sum n_id_i^2},
\]

其中 \(n_i\) 是第 i 个计算颗粒代表的液滴数。直接对计算颗粒直径求算术平均，会丢失颗粒权重，得到另一个统计量。

> **熊猫说：**
>
> 八孔模型最先检查的是质量总和、出口位置和方向。每孔都填入 10 mg 会使总喷油量扩大八倍；把 37° 孔轴倾角写成每束的喷雾锥角，则会改变整个喷雾外形。

## 几何、数据与配置资料

- [下载几何获取、组分换算和八孔注入准备工具](/downloads/engineering/spray-g.zip)。原始 STL 从 ECN 获取；注入程序要求提供八孔出口位置与选定的实测流量曲线。
- [ECN 喷油器名义 CAD 与 CT 几何](https://ecn.sandia.gov/gasoline-spray-combustion/computational-method/mesh-and-geometry/)。
- [ECN 喷射率数据入口](https://ecn.sandia.gov/gasoline-spray-combustion/target-condition/)：选择与喷油器编号、压力和驱动条件一致的数据。
- [v2512 aachenBomb 喷雾配置原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/sprayFoam/aachenBomb/constant/sprayCloudProperties)：本文文件结构与注入类型的出处。

[返回实际工程应用](/topics/engineering/)
