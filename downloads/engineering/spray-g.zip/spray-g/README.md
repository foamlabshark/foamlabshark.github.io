# 汽油直喷 Spray G：八孔喷雾与蒸发

OpenCFD OpenFOAM v2512；本文配套的模型与配置资料。

请先阅读 article.md，其中说明计算对象、几何尺度、文件位置与每个示例的作用。examples/ 保存正文代码片段，须按正文放入对应算例文件；它不是一套已经完成网格的独立算例。

运行 python3 fetch_geometry.py 获取并校验 ECN 原始 CAD。prepare_injection.py 无参数运行显示组分换算；准备八孔米制坐标及实测流量 CSV 后，按脚本说明提供 Cd 与局部半锥角。输出 injectionModels.partial 保留待填的粒径分布，不应直接运行尚缺输入的注入模型。

验证记录：模型生成、文件解析、单位及解析运动校核通过；尚未在 OpenFOAM 中完成网格与流场求解，不包含数值仿真结果。
