"""Extract v2512 force histories and AIJ probe comparisons using standard Python."""
from pathlib import Path
import csv,re,json,math
ROOT=Path(__file__).resolve().parent
NUMBER=r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?'
def data(path):
    return [[float(v) for v in re.findall(NUMBER,line)] for line in path.read_text().splitlines() if line.strip() and not line.lstrip().startswith('#')]
def write_csv(path,head,rows):
    with path.open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(head);w.writerows(rows)
def main():
    out=ROOT/'analysis';out.mkdir(exist_ok=True);tables={};force={};moment={};probes={}
    for p in sorted((ROOT/'postProcessing').rglob('*')):
        if not p.is_file() or (p.suffix!='.dat' and p.name!='U'):continue
        rows=data(p)
        if not rows:continue
        tables[p.relative_to(ROOT).as_posix()]=rows[-1]
        if p.name=='force.dat':force.update({v[0]:v[1:4] for v in rows})
        if p.name=='moment.dat':moment.update({v[0]:v[1:4] for v in rows})
        if p.name=='U' and 'windProbes' in p.parts:probes.update({v[0]:v[1:] for v in rows})
    times=sorted(force.keys()&moment.keys())
    if times:write_csv(out/'loads.csv',['time','Fx','Fy','Fz','Mx','My','Mz'],[[t]+force[t]+moment[t] for t in times])
    if probes and (ROOT/'north-measurements.csv').exists():
        values=probes[max(probes)];measurements=list(csv.DictReader((ROOT/'north-measurements.csv').open()));comparison=[]
        if len(values)!=len(measurements)*3:raise ValueError('Probe count differs from measurement table')
        for i,row in enumerate(measurements):
            U=values[3*i:3*i+3]
            if not all(math.isfinite(v) and abs(v)<1e10 for v in U):raise ValueError('Invalid probe '+row['point']+'; inspect mesh/probe position')
            ratio=math.sqrt(sum(v*v for v in U))/10;measured=float(row['speed_ratio']);comparison.append([row['point'],row['x_m'],row['y_m'],row['z_m'],*U,ratio,measured,ratio-measured])
        write_csv(out/'wind-speed-comparison.csv',['point','x_m','y_m','z_m','Ux','Uy','Uz','speed_ratio','measured_ratio','difference'],comparison)
        tables['probe_comparison']={'iteration':max(probes),'points':len(comparison),'RMSE':math.sqrt(sum(row[-1]**2 for row in comparison)/len(comparison))}
    (out/'last-monitors.json').write_text(json.dumps(tables,indent=2),encoding='utf8')
    print(json.dumps({'monitor_files':len(tables),'load_records':len(times),'probe_records':len(probes),'outputs':[p.name for p in out.iterdir() if p.is_file()]},indent=2))
    if not tables:raise SystemExit('No monitoring outputs; run solver first')
if __name__=='__main__':main()
