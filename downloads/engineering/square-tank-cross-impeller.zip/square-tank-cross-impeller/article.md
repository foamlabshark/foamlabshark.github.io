建立无通气混合槽的稳态循环与功率需求模型，分析转速与桨离底高度对桨轴转矩、槽内循环速度和低速区的影响。

## 工程场景与计算目标

混合槽的桨叶向流体输入转矩，建立周向运动并驱动槽内循环。方形槽壁改变流动方向，在四角和槽底可能形成不同程度的低速区。转速提高会增加循环强度，也会提高轴功率，桨的离底高度同样影响有效混合范围。

本例建立 400 mm 方槽和十字桨，采用局部旋转参考区计算稳态平均流动。顶部使用滑移边界表示平坦液面，槽壁保持静止。比较转速及桨位高度，分析桨轴转矩、底部循环和角部低速区之间的关系。

## 几何、尺寸与基准工况

几何由 `design.json` 中的尺寸和位置生成，采用四臂十字桨、方槽与局部旋转参考区。坐标与尺寸均使用 m，流向由边界速度向量确定。

![方形混合槽的十字桨循环的结构分区与流动方向](/assets/engineering/square-tank-cross-impeller-geometry.webp)

| 参数 | 基准值 | 含义 |
| --- | --- | --- |
| 计算域外包尺寸 | 0.4 × 0.4 × 0.3 m | 实际计算空间由流体块体并集确定 |
| 流体密度 | 998.2 kg/m³ | 惯性、压差换算和质量流量 |
| 运动黏度 | 1.004e-06 m²/s | 分子黏性输运 |
| 基础网格 | 37,600 单元 | 默认 MESH_REFINE=2 的设计网格 |
| 角速度 | 6 rad/s | MRFProperties 中的 omega |

几何各部分的坐标范围如下。流体块体先合并，再从中划分导热固体或扣除障碍物；因此相邻、相交块体不会重复占据体积。

| 部件 | x 范围 / m | y 范围 / m | z 范围 / m |
| --- | --- | --- | --- |
| 流体区域1 | 0～0.4 | 0～0.4 | 0～0.3 |
| 障碍物1 | 0.11～0.29 | 0.19～0.21 | 0.1～0.14 |
| 障碍物2 | 0.19～0.21 | 0.11～0.29 | 0.1～0.14 |
| 障碍物3 | 0.19～0.21 | 0.19～0.21 | 0.14～0.3 |

| 边界名称 | 作用 | 基准条件 |
| --- | --- | --- |
| `atmosphere` | 顶部气相交换 | 大气压力，回流为空气 |

## 物理模型与求解方法

不可压缩流动满足质量守恒与动量守恒：

\[
\nabla\cdot\mathbf U=0,\qquad
\rho\left(\frac{\partial\mathbf U}{\partial t}+\mathbf U\cdot\nabla\mathbf U\right)
=-\nabla p+\nabla\cdot\boldsymbol\tau+\mathbf f.
\]

其中，\(\mathbf U\) 为速度，\(p\) 为物理压力，\(\boldsymbol\tau\) 为黏性应力，\(\mathbf f\) 为单位体积外力。连续性方程约束各截面的流量收支；动量方程描述压力、黏性作用和外力如何改变速度。

旋转区域采用 MRF 方法。相对速度与绝对速度满足

\[
\mathbf U_{\mathrm{rel}}=\mathbf U-\boldsymbol\Omega\times(\mathbf x-\mathbf x_0).
\]

在旋转坐标描述中，科里奥利作用与离心作用分别对应 \(2\boldsymbol\Omega\times\mathbf U_{\mathrm{rel}}\) 和 \(\boldsymbol\Omega\times[\boldsymbol\Omega\times(\mathbf x-\mathbf x_0)]\)。MRF 在固定网格中计算给定相对位置的平均流动，旋转区域与静止壁面由单元区和边界名称区分。

本例使用 `simpleFoam`，通过稳态迭代求解，日志中的 `Time` 表示迭代序号。湍流采用 `kOmegaSST`，同时求解湍动能与比耗散率；近壁分辨率通过 y⁺ 和网格比较评价。

## 配置文件与网格建立

[下载完整算例与配置代码](/downloads/engineering/square-tank-cross-impeller.zip)。解压目录中已提供 `0.orig/`、`constant/`、`system/` 和几何数据，`build_case.py` 根据 `design.json` 重建相同输入；生成程序只使用 Python 标准库。

| 文件或目录 | 操作与用途 |
| --- | --- |
| `design.json` | 修改部件坐标、流体物性、速度或热功率；随后重新生成字典 |
| `geometry/model.obj` | 查看几何分区；曲线叶道以 blockMesh 圆弧为准 |
| `system/blockMeshDict` | 多块六面体网格的顶点、单元数与边界面 |
| `0.orig/` | 初始场和边界条件；建网格时复制到 `0/` |
| `constant/` | 物性、物理模型与区域设置 |
| `system/fvSchemes`、`system/fvSolution` | 离散格式、线性求解和耦合控制 |
| `Allmesh`、`Allsolve` | 分别完成网格准备与求解、结果提取 |

多块网格在肋片边缘、支路开口和分区界面处共享坐标平面，使边界与几何位置一致。默认加密级别为 2，薄通道与窄缝另外保留最低单元层数。

## 关键配置与解读

以下条目取自本页下载包的同名文件，几何和边界名称与上表对应。

### `0.orig/U`

```foam
boundaryField
{
    walls { type noSlip; }
    lid { type slip; }
    rotor { type noSlip; }
}
```

固定速度入口与已知截面积共同确定流量。出口采用 `pressureInletOutletVelocity`，使速度与边界通量协调；实体表面为无滑移壁面。MRF 中的旋转壁面速度由旋转区处理。

### `0.orig/p`

```foam
boundaryField
{
    walls { type zeroGradient; }
    lid { type zeroGradient; }
    rotor { type zeroGradient; }
}
```

`simpleFoam` 中该字段是运动学压力，量纲为 m²/s²。出口参考值为 0，物理压差应乘以流体密度；速度入口使用零法向梯度，让压力由流量约束形成。

### `constant/MRFProperties`

```foam
rotatingFrame
{ active true; cellZone rotating; origin (0.2 0.2 0.12); axis (0 0 1); omega 6; nonRotatingPatches (walls lid inlet outlet); }
```

`cellZone` 指定旋转单元区，`origin` 和 `axis` 共同定义转轴，`omega` 的单位为 rad/s。`nonRotatingPatches` 列出需要保持静止的边界；旋转叶片表面不放入该列表。


## 运行与计算检查

在 Linux 中加载 OpenCFD OpenFOAM v2512，然后进入解压目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
cd square-tank-cross-impeller
bash Allmesh
bash Allsolve
```

安装位置不同，只需调整第一行环境路径。`Allmesh` 生成输入和网格，复制初始场并检查网格质量；`Allsolve` 调用 `simpleFoam`，运行后将监测记录整理到 `analysis/`。各阶段的详细信息分别写入 `log.blockMesh`、`log.checkMesh` 和 `log.simpleFoam`，遇到错误时脚本会停止并显示对应日志末尾。

修改工况时，先在新解压目录中编辑 `design.json`，再执行 `Allmesh`。网格生成以后，边界调整应写入 `0/`；如果重新生成网格，程序会再次使用参数文件和 `0.orig/`。保留各工况独立目录，便于核对尺寸、物性与结果。

先检查残差是否持续下降，再查看流量、压差和温度或转矩是否趋于稳定。不同方程的残差尺度不同，采用工程监测量的稳定性判断迭代是否足够。

## 结果提取与工程分析

以穿过桨轴的竖向切片查看槽底循环，再在桨高处观察四角回流。由 rotor 壁面关于桨轴的力矩计算功率，保留流体力矩与驱动力矩的符号区别。提高桨位时同时移动叶片、轴和旋转区，防止旋转区截断叶片。

在 ParaView 中打开 `case.foam`，选择最后一个已写出时刻。用 **Slice** 建立上述截面，用 **Plot Over Line** 提取沿线变化；流量计算使用速度的截面法向分量，配合 **Integrate Variables** 积分。输出表格时使用 **Save Data**，工况比较保持截面位置、色标和平均方式相同。

`analysis/monitor-history.csv` 保存监测对象的时间或迭代历史，`analysis/metrics.json` 整理边界流量、压力和温度等可用指标。内部通道分流、局部方差或单个壁面载荷按本节给出的选区继续提取。边界流量采用外法向为正，入口一般为负，出口一般为正。

## 参数比较与网格收敛

比较 3、6、9 rad/s，再整体提高桨中心 30 mm，保持轴面与旋转区同步移动，分析底部循环改善。

先完成基准工况，再每次改变一个设计因素。记录几何尺寸、入口总流量、桨轴转矩、槽内循环速度和低速区，将性能变化与流场结构对应。对选定方案再做网格比较：

```bash
MESH_REFINE=4 bash Allmesh
bash Allsolve
```

在新的解压目录执行上述命令，各方向相对默认级别增加一倍单元数。比较时使用相同物性、边界条件及结果提取位置，检查主要工程量随网格变化的幅度。自由液面案例还需减小 `maxDeltaT`，比较水位幅值和相位；示踪混合案例需同时检查浓度界面的数值扩散。

> **熊猫说：** 角速度使用 rad/s，旋转区、转轴原点和旋转壁面要共同对应实际运动。

## 配套代码与资料

- [下载几何、完整配置、运行及分析代码](/downloads/engineering/square-tank-cross-impeller.zip)。`VALIDATION.json` 和 `validation/` 保存 v2512 网格检查与短程启动记录，`files.sha256` 可用于核对文件完整性。
- [OpenFOAM 用户指南](https://www.openfoam.com/documentation/user-guide)：算例结构、网格与求解流程。
- [OpenFOAM v2512 源码文档](https://api.openfoam.com/2512/)：字段、边界和模型实现。

[返回实际工程应用](/topics/engineering/)
