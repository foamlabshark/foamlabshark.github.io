计算高温定容环境中的燃油喷射、液滴破碎和蒸发，分析喷雾贯穿及粒径演化。

## 工程场景与计算目标

直喷发动机中，燃料在有限时间内经历雾化、蒸发和空气混合。喷孔尺寸、喷射持续时间及环境温度共同影响液滴受力、表面积和蒸发速率，进而改变液相贯穿与可燃混合气分布。定容燃烧弹提供固定边界，便于单独考察喷雾过程。

Aachen 算例采用欧拉气相与拉格朗日液滴团的耦合方法。气相求解速度、温度和组分，液滴团交换质量、动量与能量。结果分析分别考察液相贯穿、燃料蒸气分布和粒径变化，并以燃料质量收支检查耦合过程。

## 几何、尺寸与基准工况

![Aachen 定容燃烧弹的燃油喷雾：配套模型与基准输入](/assets/engineering/aachen-spray-geometry.webp)

计算域由 `system/blockMeshDict` 生成。喷口位于 `(0 0.0995 0)` m，喷射方向为负 y，喷孔直径为 0.19 mm。注入模型规定喷口处液滴状态，计算区域覆盖喷孔下游喷雾空间；几何和注入参数取自 `aachenBomb`。

模型与配置来源：[OpenFOAM v2512 · lagrangian/sprayFoam/aachenBomb](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/lagrangian/sprayFoam/aachenBomb)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 喷油总质量 | 6.0 × 10⁻⁶ kg | `massTotal` |
| 喷射持续时间 | 1.25 ms | `duration 1.25e-3` |
| 燃油初温 | 320 K | `constantProperties/T0` |
| 环境初温 | 800 K | `0.orig/T` |
| 破碎与蒸发 | ReitzDiwakar、liquidEvaporationBoil | `constant/sprayCloudProperties` |

## 求解方法与物理模型

液滴运动由 $m_p\,d\mathbf u_p/dt=\mathbf F_D+\cdots$ 描述，气动力改变其速度。蒸发降低液滴质量并吸收潜热，对应质量、动量和能量源项反馈到气相。

粒径采用 Sauter 平均直径 $D_{32}=\sum n_i d_i^3/\sum n_i d_i^2$ 表征，它联系液体总体积与换热、蒸发表面积。喷入总质量为 $m_{\mathrm{inj}}=\int\dot m(t)\,dt$，用于核对注入、液相存量和燃料蒸气之间的收支。

本例使用 `sprayFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/aachen-spray.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip aachen-spray.zip
cd aachen-spray
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 喷油量与注入过程

文件：`constant/sprayCloudProperties`。本段设置喷油量与注入过程。

```foam
model1
{
    type            coneNozzleInjection;
    SOI             0;
    massTotal       6.0e-6;
    parcelBasisType mass;
    injectionMethod disc;
    flowType        flowRateAndDischarge;
    outerDiameter   1.9e-4;
    innerDiameter   0;
    duration        1.25e-3;
    position        (0 0.0995 0);
    direction       (0 -1 0);
    parcelsPerSecond 20000000;
    flowRateProfile table
    (
        (0              0.1272)
        (4.16667e-05    6.1634)
        (8.33333e-05    9.4778)
```

`massTotal` 规定总喷油量，`flowRateProfile` 分配各时刻的流率。`position`、`direction` 和 `outerDiameter` 分别定义注入位置、方向与注入盘直径。调整持续时间时，流率表的时间坐标也需相应改变。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/sprayFoam/aachenBomb/constant/sprayCloudProperties)。

### 2. 液滴子模型

文件：`constant/sprayCloudProperties`。本段设置液滴子模型。

```foam
dispersionModel none;

patchInteractionModel standardWallInteraction;

heatTransferModel RanzMarshall;

compositionModel singlePhaseMixture;

phaseChangeModel liquidEvaporationBoil;

surfaceFilmModel none;

atomizationModel none;

breakupModel    ReitzDiwakar; // ReitzKHRT;

stochasticCollisionModel none;

radiation       off;
```

破碎、相变、换热和壁面碰撞分别由对应子模型处理。气液耦合使液滴蒸发和受力同时影响气相组分、温度与速度，因此喷雾演化与连续相求解共同推进。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/sprayFoam/aachenBomb/constant/sprayCloudProperties)。

### 3. 高温环境与热边界

文件：`0.orig/T`。本段设置高温环境与热边界。

```foam
internalField       uniform 800;

boundaryField
{
    walls
    {
        type                zeroGradient;
    }
}
```

气相初始温度为 800 K，墙面温度零梯度对应无导热通量。调整环境初温可改变液滴蒸发驱动力，比较时保持喷油量和燃油初温一致。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/lagrangian/sprayFoam/aachenBomb/0.orig/T)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.sprayFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `sprayFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `0` |
| `endTime` | `0.01` |
| `deltaT` | `2.5e-06` |
| `writeControl` | `adjustable` |
| `writeInterval` | `5e-05` |
| `adjustTimeStep` | `yes` |
| `maxCo` | `0.1` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选气相内部与喷雾粒子，点击 **Apply**。先选择最后一个已写出的时刻，以 `T` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

在拉格朗日数据中显示液滴位置和直径，在气相数据中显示燃料蒸气质量分数。以喷孔为原点提取轴向液相贯穿，并同步统计累计喷油量、域内液相质量和气相燃料质量。

保持总喷油量不变，比较不同环境温度下的贯穿距离和 $D_{32}$。另设粒子数量比较组，检查增加液滴团采样后统计量的变化；气相剪切层仍需通过空间网格加密独立检查。

> **熊猫说：** `parcelBasisType mass` 采用质量加权液滴团。粒径分布和平均直径统计应计入每个液滴团代表的数量或质量。

## 文件与来源

- [完整算例包](/downloads/engineering/aachen-spray.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/lagrangian/sprayFoam/aachenBomb)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
