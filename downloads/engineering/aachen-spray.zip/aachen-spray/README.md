# Aachen 定容燃烧弹的燃油喷雾

在高温定容环境中计算燃油喷射、液滴破碎与蒸发，建立喷油参数和喷雾贯穿距离之间的联系。

完整指南：https://foamlabshark.github.io/topics/engineering/aachen-spray/

OpenCFD OpenFOAM v2512，Linux。加载安装环境后，按顺序执行：

```bash
bash Allmesh
bash Allsolve
```

Allmesh 包含全部网格与初始化步骤，并在网格检查失败时停止；各命令输出保存在 log.*。Allsolve 使用下载包原有完整时间控制。VALIDATION.json 记录独立进行的网格检查与短步运行；结果分析和工况比较见指南。

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。

模型或网格改变后，在新目录重新解压运行。ParaView 打开 case.foam 查看各区域场量。

上游：https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/lagrangian/sprayFoam/aachenBomb

原始 OpenFOAM 文件遵循随附 COPYING；本站改动见 SOURCE.json。
