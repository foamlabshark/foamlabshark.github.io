联立电势与固体导热方程，计算导电板的焦耳热分布及稳态温升。

## 工程场景与计算目标

电加热板、导电连接件和电极中的电阻损耗构成体积热源。给定端部电势差后，电功率由电导率、导体截面和电流路径共同决定；导热能力与散热边界则决定热量在构件内的分布。

算例采用长导电板，两端维持恒温、侧面绝热。先由电势方程求得电流和焦耳热，再计算稳态温度。通过电功率、端部导热量和最高温度之间的关系，可检查电热耦合设置，并研究端部电压对温升的影响。

## 几何、尺寸与基准工况

![导电元件的焦耳发热与散热：配套模型与基准输入](/assets/engineering/joule-heater-geometry.webp)

导电板长 5 m、高 0.1 m、展向厚 0.1 m，采用 500 × 20 × 1 网格和二维 `empty` 边界。固体区域名为 `solid`，两端温度均为 500 K，上下表面绝热。尺寸与等效材料参数取自 `jouleHeatingSolid`。

模型与配置来源：[OpenFOAM v2512 · heatTransfer/chtMultiRegionSimpleFoam/jouleHeatingSolid](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionSimpleFoam/jouleHeatingSolid)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 固体导热系数 | 200 W/(m·K) | `constant/solid/thermophysicalProperties` 的 `kappa` |
| 两端温度 | 500 K | `0.orig/solid/T` 的 `left` 和 `right` |
| 热源模型 | jouleHeatingSource | `system/solid/fvOptions` |
| 电导率方向性 | 各向同性 | `anisotropicElectricalConductivity no` |

## 求解方法与物理模型

电势满足 $\nabla\cdot(\sigma\nabla V)=0$，其中 $\sigma$ 为电导率。电流密度由 $\mathbf J=-\sigma\nabla V$ 给出，产生的焦耳热为 $q_v=\mathbf J\cdot\mathbf J/\sigma=\sigma|\nabla V|^2$。

将该热源代入 $\nabla\cdot(k\nabla T)+q_v=0$，即可得到稳态温度。绝热侧面限制了横向散热，热量主要沿板长方向传向两端，板中部因导热路径较长而形成温度峰值。

本例使用 `chtMultiRegionSimpleFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/joule-heater.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip joule-heater.zip
cd joule-heater
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `blockMesh -region solid` | 按顶点、块结构和加密比例生成背景网格。 |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 电势与焦耳热耦合

文件：`system/solid/fvOptions`。本段设置电势与焦耳热耦合。

```foam
heating
{
    type            jouleHeatingSource;
    active          true;

    jouleHeatingSourceCoeffs
    {
        anisotropicElectricalConductivity no;

        // Optionally specify sigma as a function of temperature
        //sigma           127599.8469;
        //
        //sigma           table
        //(
        //    (0      127599.8469)
        //    (1000   127599.8469)
        //);
    }
}
```

`jouleHeatingSource` 求解电势，并将电阻耗散作为能量方程的源项。电势和电导率初始场位于 `0.orig/solid`。电压工况通过电势边界调整，焦耳热由耦合模型据此计算。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionSimpleFoam/jouleHeatingSolid/system/solid/fvOptions)。

### 2. 端部恒温与侧面绝热

文件：`0.orig/solid/T`。本段设置端部恒温与侧面绝热。

```foam
left
{
    type            fixedValue;
    value           uniform 500;
}
```

`left`、`right` 的固定温度表示两端接触恒温边界；上下表面的 `zeroGradient` 表示无导热通量。温度场由内部发热与沿长度方向的散热共同确定。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionSimpleFoam/jouleHeatingSolid/0.orig/solid/T)。

### 3. 固体热物性

文件：`constant/solid/thermophysicalProperties`。本段设置固体热物性。

```foam
    mixture         pureMixture;
    transport       constIso;
    thermo          hConst;
    equationOfState rhoConst;
    specie          specie;
    energy          sensibleEnthalpy;
}

mixture
{
    specie
    {
        molWeight   12;
    }
    transport
    {
        kappa   200;
    }
    thermodynamics
    {
        Hf      0;
        Cp      700;
```

`kappa` 控制导热，`Cp`、`rho` 表征热容量。当前求解稳态温度，温升主要由焦耳热、导热系数及端部温度决定；热容量参数在瞬态扩展中控制升温速度。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionSimpleFoam/jouleHeatingSolid/constant/solid/thermophysicalProperties)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.chtMultiRegionSimpleFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `chtMultiRegionSimpleFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。本求解器采用稳态迭代，日志中的 Time 用作迭代序号。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `0` |
| `endTime` | `20000` |
| `deltaT` | `1` |
| `writeControl` | `timeStep` |
| `writeInterval` | `50` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选solid，点击 **Apply**。先选择最后一个已写出的时刻，以 `T` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

沿中心线提取电势和温度。均匀电导率、等截面条件下，电势应近似线性分布。对焦耳热作体积积分得到总功率，与端部电压差和总电流的乘积比较，再核对两端导热量。

固定材料参数和端部温度，将电势差提高 20%，电功率应约增至原来的 1.44 倍。对于均匀热源长板，最高温升可由 $T_{\max}-T_b=q_vL^2/(8k)$ 估算，用于检查长度、导热系数和热源量级。

> **熊猫说：** 电导率 `sigma` 的单位为 S/m，决定电流分布；热导率 `kappa` 的单位为 W/(m·K)，决定热量扩散。两项参数分别进入电势方程和导热方程。

## 文件与来源

- [完整算例包](/downloads/engineering/joule-heater.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionSimpleFoam/jouleHeatingSolid)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
