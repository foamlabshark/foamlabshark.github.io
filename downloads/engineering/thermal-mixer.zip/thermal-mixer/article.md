求解旋转环形混合器中的冷热气流混合，评价转速对温度均匀性和压力损失的影响。

## 工程场景与计算目标

热工调温和工艺供气要求混合后的气体同时满足平均温度与截面均匀性要求。两股气流的焓流决定混合温度，旋转构件则通过卷绕和横向输运消除冷热条带。出口平均值相同的两个工况，局部温差仍可能显著不同。

算例采用内、外环形入口和旋转构件，分别设置两路气流的速度、温度及转子角速度。计算沿下游方向跟踪温度分布，确定混合程度随距离和转速的变化，并将其与压差联系起来评价混合代价。

## 几何、尺寸与基准工况

![环形冷热流混合器的温度均匀性：配套模型与基准输入](/assets/engineering/thermal-mixer-geometry.webp)

模型采用公开的 `annularThermalMixer` 曲面，背景域尺寸为 0.22 m × 0.22 m × 0.22 m。转轴沿 z 方向，运动区域为 `rotatingZone`。内、外入口分别命名为 `innerInlet`、`outerInlet`，公共工况参数保存在 `constant/caseSettings`。

模型与配置来源：[OpenFOAM v2512 · compressible/rhoPimpleFoam/RAS/annularThermalMixer](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/compressible/rhoPimpleFoam/RAS/annularThermalMixer)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 内入口 | 0.2 m/s，233 K | `constant/caseSettings/innerInlet` |
| 外入口 | 0.1 m/s，293 K | `constant/caseSettings/outerInlet` |
| 角速度 | 25 rad/s | `meshMotionProperties/omega` |
| 基准物性 | 理想气体、Sutherland 黏度 | `constant/thermophysicalProperties` |

## 求解方法与物理模型

气体流动与能量输运在运动网格上耦合求解，旋转区与静止区通过 AMI 连接。忽略外部散热时，两路气流满足焓流平衡 $\dot m_i h_i+\dot m_o h_o=(\dot m_i+\dot m_o)h_m$。对于定比热气体，混合温度为 $T_m=(\dot m_iT_i+\dot m_oT_o)/(\dot m_i+\dot m_o)$。

转子改变冷热气流的接触与输运过程，使截面温度逐渐接近混合温度。温度标准差 $\sigma_T=\sqrt{\langle(T-T_m)^2\rangle}$ 描述剩余温度差异，可与平均温度共同用于评价混合效果。

本例使用 `rhoPimpleFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/thermal-mixer.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip thermal-mixer.zip
cd thermal-mixer
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `surfaceFeatureExtract` | 提取曲面棱边，供贴体网格捕捉结构特征。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `snappyHexMesh -overwrite` | 依据随包曲面裁切、贴合背景网格，并执行局部加密。 |
| `createBaffles -overwrite` | 把指定内部面转成成对边界，形成挡板或叶片表面。 |
| `mergeOrSplitBaffles -split -overwrite` | 整理挡板两侧拓扑，使相邻计算区域具有独立的面连接。 |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 两路气流的工况参数

文件：`constant/caseSettings`。本段设置两路气流的工况参数。

```foam
innerInlet
{
    U               (0 0 0.2);
    epsilon         5.70e-5;
    k               2.40e-5;
    T               233;
}
```

两路入口各自给定速度、温度与湍流变量。质量流量由入口面积、速度和对应温度下的密度共同确定，因此计算混合温度时采用质量流量权重。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/compressible/rhoPimpleFoam/RAS/annularThermalMixer/constant/caseSettings)。

### 2. 旋转区域运动

文件：`constant/dynamicMeshDict`。本段设置旋转区域运动。

```foam
dynamicFvMesh   dynamicMotionSolverFvMesh;

motionSolver    solidBody;

cellZone        rotatingZone;

solidBodyMotionFunction  rotatingMotion;

origin      (0 0 0);
axis        (0 0 1);
omega       $/meshMotionProperties/omega;
```

运动参数从公共字典引用，`omega` 同时用于相关运动设置。通过这一入口修改转速，可保持网格运动与速度边界所用参数一致。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/compressible/rhoPimpleFoam/RAS/annularThermalMixer/constant/dynamicMeshDict)。

### 3. 冷热入口边界

文件：`0.orig/T`。本段设置冷热入口边界。

```foam
innerInlet
{
    type            fixedValue;
    value           uniform $/innerInlet/T;
}
```

内、外入口温度分别读取对应的公共参数，出口温度由能量输运求得。保留入口面积、速度方向和密度信息，才能由两股焓流解释出口平均温度。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/compressible/rhoPimpleFoam/RAS/annularThermalMixer/0.orig/T)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.rhoPimpleFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `rhoPimpleFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `latestTime` |
| `startTime` | `0` |
| `endTime` | `2` |
| `deltaT` | `1e-3` |
| `writeControl` | `adjustable` |
| `writeInterval` | `0.02` |
| `adjustTimeStep` | `yes` |
| `maxCo` | `1` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选内外环形流道，点击 **Apply**。先选择最后一个已写出的时刻，以 `T` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

在转子下游沿 z 方向布置多个截面，计算平均温度和温度标准差。前者用于核对焓流平衡，后者用于衡量冷热条带的衰减。叠加温度等值面和速度流线，可以观察旋转构件引起的条带卷绕与横向交换。

将角速度设为 12.5、25、50 rad/s，比较相同位置的温度标准差和进出口压差。各工况在相同转数后开始采样，并覆盖完整的多个周期，得到能够相互比较的周期平均结果。

> **熊猫说：** 气体状态方程和输运性质从 `thermophysicalProperties` 读取。调整物性时修改求解器实际使用的热物性设置。

## 文件与来源

- [完整算例包](/downloads/engineering/thermal-mixer.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/compressible/rhoPimpleFoam/RAS/annularThermalMixer)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
