建立摩托车与骑手的外流模型，计算行驶状态下的阻力、表面压力及尾流。

## 工程场景与计算目标

摩托车绕流由车体、骑手和地面共同决定。风挡改变骑手迎风区域的压力，车尾和人体轮廓影响流动分离，地面运动则影响近地气流。阻力分析需要同时保留这些结构及其相对位置，才能解释姿态或外罩变化产生的效果。

算例采用公开三维曲面，在车体坐标系内设置来流与运动地面。`simpleFoam` 配合 SST 湍流模型求解稳态平均流动，通过车体和骑手表面的压力及黏性应力积分获得气动力。计算重点是阻力收敛、分离位置和尾流恢复。

## 几何、尺寸与基准工况

![摩托车与骑手的外部空气动力学：配套模型与基准输入](/assets/engineering/motorcycle-aero-geometry.webp)

`motorBike.obj.gz` 包含车轮、车架、风挡、骑手和外罩。参考轴距为 1.42 m，参考面积为 0.75 m²。外流域沿 x、y、z 的范围分别为 −5～15 m、−4～4 m、0～8 m，z = 0 对应地面。

模型与配置来源：[OpenFOAM v2512 · incompressible/simpleFoam/motorBike](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/incompressible/simpleFoam/motorBike)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 来流速度 | 20 m/s | `0.orig/include/initialConditions` |
| 空气运动黏度 | 1.5 × 10⁻⁵ m²/s | `constant/transportProperties` |
| 参考长度与面积 | 1.42 m、0.75 m² | `system/forceCoeffs` |
| 参考密度 | 1 kg/m³ | 官方系数文件 `rhoInf`；计算实际阻力时按目标空气状态修改 |

## 求解方法与物理模型

阻力系数定义为 $C_D=F_D/(\tfrac12\rho U_\infty^2A_{\mathrm{ref}})$，表面压力可用 $C_p=(p-p_\infty)/(\tfrac12\rho U_\infty^2)$ 表示。不可压缩求解器保存的压力是运动学压力 $p_k=p/\rho$，因此计算实际气动力时需要补充参考密度。SST 模型用于估计壁面附近及分离区域的湍流黏性。

本例使用 `simpleFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/motorcycle-aero.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip motorcycle-aero.zip
cd motorcycle-aero
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `surfaceFeatureExtract` | 提取曲面棱边，供贴体网格捕捉结构特征。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `snappyHexMesh -overwrite` | 依据随包曲面裁切、贴合背景网格，并执行局部加密。 |
| `topoSet` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `potentialFoam -writephi` | 求解势流初始化问题，使速度与边界通量协调。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 来流与湍流条件

文件：`0.orig/include/initialConditions`。本段设置来流与湍流条件。

```foam
flowVelocity         (20 0 0);
pressure             0;
turbulentKE          0.24;
turbulentOmega       1.78;
```

来流速度、湍动能和比耗散率集中在入口参数文件中。改变速度后，根据湍流强度与长度尺度更新 `k`、`omega`，并将气动力系数的 `magUInf` 改为同一来流速度。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/incompressible/simpleFoam/motorBike/0.orig/include/initialConditions)。

### 2. 运动地面

文件：`0.orig/U`。本段设置运动地面。

```foam
lowerWall
{
    type            fixedValue;
    value           $internalField;
}
```

运动地面在车体坐标系中与来流同向、同速，车体和骑手保持无滑移。该设置表示行驶路面相对车辆运动，决定近地边界层与车底流动。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/incompressible/simpleFoam/motorBike/0.orig/U)。

### 3. 气动力监测

文件：`system/forceCoeffs`。本段设置气动力监测。

```foam
    patches         (motorBikeGroup);
    rho             rhoInf;      // Indicates incompressible
    rhoInf          1;           // Required when rho = rhoInf
    liftDir         (0 0 1);
    dragDir         (1 0 0);
    CofR            (0.72 0 0);  // Axle midpoint on ground
    pitchAxis       (0 1 0);
    magUInf         20;
    lRef            1.42;        // Wheelbase length
    Aref            0.75;        // Estimated
}
```

`motorBikeGroup` 汇集气动力积分所需的车体和骑手表面。`dragDir`、`liftDir`、`pitchAxis` 定义力及力矩方向，`Aref` 定义系数采用的面积。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/incompressible/simpleFoam/motorBike/system/forceCoeffs)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.simpleFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `simpleFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。本求解器采用稳态迭代，日志中的 Time 用作迭代序号。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `0` |
| `endTime` | `500` |
| `deltaT` | `1` |
| `writeControl` | `timeStep` |
| `writeInterval` | `100` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选车辆表面与空气内部，点击 **Apply**。先选择最后一个已写出的时刻，以 `p` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

绘制阻力系数随迭代的变化，结合迎风面压力、风挡后分离和车尾低速区解释阻力来源。在车尾不同位置提取速度截面，以相同色标比较尾流宽度和恢复程度。

网格比较分别覆盖表面曲率、近壁层和尾流剪切层，并检查 y⁺。若力系数在持续迭代后仍表现出有规律的波动，可转入瞬态计算，统计平均阻力和波动幅度；残差与气动力共同用于判断收敛。

> **熊猫说：** 参考面积只用于系数归一化。比较不同构型时，统一 `Aref`、`magUInf` 和密度，同时保留实际阻力值。

## 文件与来源

- [完整算例包](/downloads/engineering/motorcycle-aero.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/incompressible/simpleFoam/motorBike)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
