计算处理器、散热鳍片与机箱空气之间的传热，评价热源功率和风扇转速对芯片温升的影响。

## 工程场景与计算目标

处理器产生的热量经封装传入散热器，再由机箱气流排出。芯片最高温度取决于固体导热能力和空气侧换热条件。鳍片间流量不足、气流绕过散热器以及热空气回流，均会增加局部温升；风扇总流量相同，芯片温度也可能存在明显差异。

算例将处理器、鳍片和空气分别建模，通过区域界面传递热量，并以旋转参考系描述风扇作用。基准热源功率为 100 W。计算需确定处理器热点位置、鳍片散热分布和出口热流，进而评价提高转速能否有效降低热阻。

## 几何、尺寸与基准工况

![CPU 机箱与散热鳍片的共轭传热：配套模型与基准输入](/assets/engineering/cpu-cabinet-geometry.webp)

`cpuCabinet` 几何包含机箱、处理器、散热鳍片、风扇及风罩。背景网格范围为 x = −0.04478～0.27928 m、y = −0.00550502～0.0845552 m、z = −0.29～0.04 m，内部部件轮廓由配套曲面给出。空气区域名为 `domain0`，处理器与鳍片区域分别为 `v_CPU`、`v_fins`。

模型与配置来源：[OpenFOAM v2512 · heatTransfer/chtMultiRegionSimpleFoam/cpuCabinet](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionSimpleFoam/cpuCabinet)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| CPU 功率 | 100 W | `system/v_CPU/fvOptions` 的 `h (100 0)`；`volumeMode absolute` 表示整个选区的总热源 |
| 风扇角速度 | 209.44 rad/s，约 2000 r/min | `constant/domain0/MRFProperties` 的 `omega` |
| 初始与回流温度 | 300 K | 各区域 `T` 与空气出口 `inletValue` |
| 固体导热系数 | 202.4 W/(m·K) | `constant/v_CPU/thermophysicalProperties` 与鳍片物性 |

## 求解方法与物理模型

固体区域求解稳态导热方程 $\nabla\cdot(k_s\nabla T)+q_v=0$，其中 $k_s$ 为导热系数，$q_v$ 为体积热源。空气区域求解流动与能量输运，处理器释放的热量经鳍片进入空气，最终随出口焓流排出。

流固界面满足温度连续条件 $T_s=T_f$ 和热流连续条件 $k_s\partial T_s/\partial n=k_f\partial T_f/\partial n$，式中两侧导数沿同一法向取值。风扇区域采用 MRF 方法：网格保持固定，区域内方程计入旋转参考系效应。

本例使用 `chtMultiRegionSimpleFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/cpu-cabinet.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip cpu-cabinet.zip
cd cpu-cabinet
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `surfaceFeatureExtract` | 提取曲面棱边，供贴体网格捕捉结构特征。 |
| `snappyHexMesh -overwrite` | 依据随包曲面裁切、贴合背景网格，并执行局部加密。 |
| `splitMeshRegions -cellZones -overwrite` | 按区域标记分离流体与固体网格，建立配对界面。 |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `topoSet -region domain0` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

贴合网格时，`system/meshQualityDict` 将内部面和边界面的最大偏斜度均限制为 3.5，常规与 `relaxed` 设置采用相同限值。区域拆分后分别检查空气、处理器和鳍片网格，三者均通过后再启动共轭传热求解。

## 关键配置与解读

### 1. 处理器热源

文件：`system/v_CPU/fvOptions`。本段设置处理器热源。

```foam
v_CPU_AbsoluteEnergySource
{
    type            scalarSemiImplicitSource;
    active          true;

    selectionMode   cellZone;
    cellZone        v_CPU;
    volumeMode      absolute;

    sources
    {
        h           ( 100 0 );
    }
}
```

`selectionMode cellZone` 将热源施加于 `v_CPU` 单元区，`h` 对应焓方程。括号中的两项分别为显式热源和线性系数。采用 `volumeMode absolute` 时，`h (100 0)` 表示该选区总功率为 100 W。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionSimpleFoam/cpuCabinet/system/v_CPU/fvOptions)。

### 2. 风扇旋转区域

文件：`constant/domain0/MRFProperties`。本段设置风扇旋转区域。

```foam
VC_1
{
    cellZone        v_MRF;
    active          true;
    nonRotatingPatches ();
    origin          (-0.01 0.04 -0.06);
    axis            (1 0 0);
    omega           209.44;
}
```

`origin`、`axis` 和 `omega` 分别规定旋转轴位置、方向与角速度，`cellZone` 指定风扇流体区。转速研究保持几何和选区不变；改变风扇位置时，曲面与旋转选区应同步移动。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionSimpleFoam/cpuCabinet/constant/domain0/MRFProperties)。

### 3. 处理器与空气的热耦合

文件：`0.orig/domain0/T`。本段设置处理器与空气的热耦合。

```foam
domain0_to_v_CPU
{
    type            compressible::turbulentTemperatureRadCoupledMixed;
    qrNbr           none;
    qr              none;
    Tnbr            T;
    kappaMethod     fluidThermo;
    useImplicit     true;
    value           $internalField;
}
```

温度边界根据相邻区域的温度和导热能力计算界面热流。空气侧使用 `fluidThermo`，固体侧使用 `solidThermo`；区域分割后，两侧界面通过相应边界名称配对。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionSimpleFoam/cpuCabinet/0.orig/domain0/T)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.chtMultiRegionSimpleFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `chtMultiRegionSimpleFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。本求解器采用稳态迭代，日志中的 Time 用作迭代序号。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `0` |
| `endTime` | `200` |
| `deltaT` | `1` |
| `writeControl` | `timeStep` |
| `writeInterval` | `10` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选v_CPU、v_fins 与 domain0，点击 **Apply**。先选择最后一个已写出的时刻，以 `T` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

同时载入三个区域的温度场，提取处理器最高温度、体积平均温度和鳍片表面温度。隐藏固体后显示空气流线，辨认有效穿过鳍片的气流、旁通流和热空气回流。两个出口的净焓流之和应与 100 W 发热量相对应；温度趋于稳定而热量收支仍不闭合时，应继续检查边界热流与迭代收敛。

系统热阻定义为 $R_\theta=(T_{\max}-T_{\mathrm{in}})/Q$，单位为 K/W。将风扇角速度分别设为基准值的 0.75、1 和 1.25 倍，比较流量与热阻。流量明显增加而热阻变化较小时，可结合鳍片间旁通和固体温度梯度判断主要传热阻力。网格比较重点放在鳍片间隙及热源边缘。

> **熊猫说：** `volumeMode absolute` 对应选区总功率。采用体积发热率时，应同时修改热源数值与 `volumeMode`，并用选区体积核算总输入功率。

## 文件与来源

- [完整算例包](/downloads/engineering/cpu-cabinet.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionSimpleFoam/cpuCabinet)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
