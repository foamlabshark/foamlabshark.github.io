"""AIJ Case F, DOI 10.5281/zenodo.15589622, Tominaga/Kikumoto/Okaze, CC BY 4.0.
Use the original wind-tunnel metre STL at 1:800; output physical-scale metre STL.
Dependency: numpy, trimesh. Input files/attribution supplied in original/.
"""
from pathlib import Path
import csv,hashlib,json
import numpy as np
import trimesh
ROOT=Path(__file__).resolve().parent
SHA='bc3688f5ed22d3cbb7e5db630c30f0ae2a5bce70f10d33ee122ac18df3db772b'
def prepare():
    source=ROOT/'original/BD_caseF.stl'
    if hashlib.sha256(source.read_bytes()).hexdigest()!=SHA:raise ValueError('Expected the reviewed Case F STL. Confirm scale of any replacement file.')
    mesh=trimesh.load(source,force='mesh');mesh.apply_scale(800);out=ROOT/'geometry';out.mkdir(exist_ok=True);mesh.export(out/'shinjuku-metres.stl')
    rows=list(csv.DictReader((ROOT/'original/RS-WT_caseF.csv').open()))
    points=[r for r in rows if r['WD']=='N']
    with (ROOT/'north-measurements.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['point','x_m','y_m','z_m','wind_direction','speed_ratio'])
        for r in points:w.writerow([r['No.'],*[float(r[k])*800 for k in ['x','y','z']],r['WD'],r['U/R']])
    probes='\n'.join('    ('+' '.join(f'{float(r[k])*800:.9g}' for k in ['x','y','z'])+')' for r in points)
    (ROOT/'probeLocations').write_text('probeLocations\n(\n'+probes+'\n);\n')
    profile=list(csv.DictReader((ROOT/'inflow-normalized.csv').open()));outrows=[]
    for r in profile:
        z=float(r['z_m']);u=10*float(r['U_UR']);k=100*float(r['k_UR2']);length=.41*max(z,.5)
        outrows.append([z,u,k,.09**.75*k**1.5/length,length])
    with (ROOT/'inletProfiles.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['z_m','speed_m_s','k_m2_s2','epsilon_m2_s3','assumed_length_m']);w.writerows(outrows)
    report={'source_doi':'10.5281/zenodo.15589622','scale_applied':800,'units':'m','bounds':mesh.bounds.tolist(),'triangles':len(mesh.faces),'watertight':bool(mesh.is_watertight),'north_probe_rows':len(points),'reference_speed_m_s':10,'reference_height_m':500,'height_origin':'Wind tunnel floor; retain the raised terrain and measured probe z coordinates.','geometry_note':'Open terrain and building edges require inspection/repair before volume meshing.','epsilon_model':'L=0.41*max(z,0.5) m relative to inlet floor; sensitivity input, not a measured profile'}
    (out/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':prepare()
