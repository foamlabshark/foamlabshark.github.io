blockMesh
surfaceFeatureExtract
snappyHexMesh -overwrite
checkMesh -allTopology -allGeometry
decomposePar
mpirun -np 8 simpleFoam -parallel
