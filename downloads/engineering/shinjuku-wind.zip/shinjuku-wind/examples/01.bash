python3 prepare_city.py
surfaceCheck geometry/shinjuku-metres.stl
