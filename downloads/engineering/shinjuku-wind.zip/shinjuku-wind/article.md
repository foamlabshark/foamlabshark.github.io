以 AIJ 新宿街区几何与测量为依据，计算建筑下洗、街谷加速和近地风速。

## 工程场景与计算目标

气流遇到高层建筑后向两侧绕行并沿迎风立面下洗。近地气流与道路、裙房和低层建筑相互作用，在转角和窄通道形成加速，背风侧形成回流。建筑间距、高度组合与风向共同决定行人活动区域的风速分布。

街区风场分析服务于建筑入口、广场和通风布局。计算需要定位高风速区域，确定其敏感风向，并评价建筑或挡风设施调整的效果。因此，几何保留建筑遮挡、街道转折和地形高差。

本例采用日本建筑学会 AIJ Case F，其 STL 对应新宿副中心 1978 年 11 月的建筑构型。风洞来流、测点与同期现场观测组成同一基准，计算使用该构型与测量逐项对应。

首先建立北风工况，比较测点无量纲风速，再通过风向变化分析转角、街谷和背风区响应。基准对比完成后，在模型副本中调整局部建筑或挡风设施，评价目标区域的风速变化。

![按 AIJ 原始 STL 绘制的新宿建筑群与尺度](/assets/engineering/shinjuku-geometry.webp)

几何及测量数据由 Tominaga、Kikumoto 和 Okaze 整理发布，采用 CC BY 4.0 许可。[原始数据集与各文件下载](https://zenodo.org/records/15589622)。图中建筑形状来自该数据集，本站仅转换尺度并重新绘图。

## 几何、尺寸与基准工况

`BD_caseF.stl` 采用 1∶800 的风洞尺度，坐标单位为米。本文将几何与风洞测点坐标均乘以 800，转换到实体尺度；入口读取 `LF_CaseF.xls` 的 `Inflow` 无量纲剖面，并取 500 m 高度的参考风速为 10 m/s。

| 文件 | 包含内容 | 本节处理 |
| --- | --- | --- |
| `BD_caseF.stl` | 建筑与地形，风洞尺度 | 坐标乘 800；原文件保留 |
| `AF_caseF.csv` | 来流高度、平均风速、流向速度脉动均方根 | 保留原始测量用于复核 |
| `LF_CaseF.xls` 的 `Inflow` 表 | 完整归一化入口剖面 | 使用实体高度；速度比乘 10，湍动能比乘 100 |
| `RS-WT_caseF.csv` | 风洞测点、风向和无量纲风速 | 三个坐标分量乘 800 |
| `RS-FO_caseF.csv` | 实体尺度现场观测 | 保持原坐标，单独比较 |

原 STL 的平面范围约为 1.8125 m × 1.8125 m，高度为 0.28125 m。实体几何约为 1450 m × 1450 m，最大高度 225 m，外部流体域在此范围外继续扩展。

资料包提供 `prepare_city.py`。它检查原始文件校验值，转换 STL 和测点，并输出北风工况测点表、入口剖面以及几何检查信息：

```bash
python3 prepare_city.py
surfaceCheck geometry/shinjuku-metres.stl
```

随包已提供尺度转换后的表面。`prepare_city.py` 用于重新处理原始资料，另需 NumPy 和 trimesh；直接运行完整算例时无需执行此步骤。原 STL 的开放外缘位于 z=0，与背景网格地面相接，建筑与地形保持原有连接。

模型为表示地下空间整体抬高了实体尺度 10 m。风洞测点 z = 0.02375 m 转换为实体坐标 19 m，对应离当地地面约 9 m。保留原几何时，模型、测点与入口高度均以风洞底板为零点；平移几何时，三者同步平移。

## 流动模型与入口风剖面

采用中性、等温、不可压缩 RANS 模型，先用 `simpleFoam` 和标准 `kEpsilon` 获得平均风场。平均动量方程为

\[
\overline{\mathbf U}\cdot\nabla\overline{\mathbf U}
=-\nabla p_k+\nabla\cdot\left[\nu\nabla\overline{\mathbf U}
-\overline{\mathbf u'\mathbf u'}\right],
\qquad \nabla\cdot\overline{\mathbf U}=0.
\]

\(p_k=p/\rho\) 为运动学压力，\(-\overline{\mathbf u'\mathbf u'}\) 表示速度脉动对平均动量输运的影响。湍流模型将这个未知应力与平均速度梯度联系起来。建筑背风回流、屋顶剪切层和窄通道中的预测偏差，应结合模型对分离和湍流混合的描述来分析。

入口按 `Inflow` 表随高度插值：实体高度 20、80、400 m 处的速度分别为 4.2、6.2、9.4 m/s。该剖面给出近地层与高空不同的来流动量。

`Inflow` 表同时给出归一化湍动能，本节直接读取。若改用只提供流向速度脉动 \(u_{\rm rms}\) 的测量文件，需要先说明湍动能的估算方式。常用的各向同性近似及耗散率关系为：

\[
k(z)=\frac32u_{\rm rms}(z)^2,
\qquad
\varepsilon(z)=\frac{C_\mu^{3/4}k(z)^{3/2}}{L(z)},\quad C_\mu=0.09.
\]

这里的 k 和 ε 分别是湍动能与耗散率。L(z) 是建模输入，决定湍流衰减的尺度；资料包以入口底板为高度零点，取 L=0.41 max(z,0.5) m，并把这一假设与原始测量分开保存。先在去除建筑的空域中计算相同来流，检查剖面沿流向是否保持，再加入建筑。

### 北风工况的方向

坐标系为 x 向东、y 向北、z 向上。北风从北向南，北侧为入口，速度沿负 y。首个工况保留建筑与测点原坐标，据此设置外部边界。

## 配置文件与网格建立

配套模型已将 AIJ Case F 的 1∶800 风洞几何换算为实尺度米制 STL，建筑和地形的相对位置保持一致。背景域取 x=−1500～1500 m、y=−2200～1500 m、z=0～750 m，北风从 y=1500 m 进入并沿负 y 方向流动。

`constant/triSurface/city.stl` 保存米制曲面，`blockMeshDict` 定义背景域，`snappyHexMeshDict` 在城区和建筑表面加密。原模型在 z=0 的外缘与地面边界相接，体积网格保留地面以上的流体区域。网格检查应同时确认 `city` 边界、入口与地面均存在，再核对建筑最高点 225 m 和 22 个北风测点位置。

`0.orig/U`、`k` 和 `epsilon` 的入口使用随包 `inletProfiles.csv` 数据生成的高度插值。插值在相邻高度点间线性进行，超出表格范围时采用端点值；速度方向固定为负 y。入口耗散率按本文给定的长度尺度计算，改变该假设时应同步更新对应剖面。

## 关键配置与解读

以下配置来自下载包的同名文件。

### `constant/turbulenceProperties`

```foam
simulationType RAS; RAS { RASModel kEpsilon; turbulence on; printCoeffs on; }
```

基准采用 k–epsilon 模型求解平均风场。入口 k 来自风洞归一化数据，epsilon 通过规定的长度尺度构造，二者与 U 使用同一高度坐标。

### `0.orig/U`

```foam
inlet { type codedFixedValue; value uniform (0 -10 0); name northProfileU; code
#{
const scalar z[] = {10.0,20.0,35.0,40.0,50.0,60.0,65.0,80.0,100.0,120.0,140.0,160.0,200.0,240.0,280.0,320.0,360.0,400.0,470.0,500.0};
const scalar v[] = {3.2,4.2,4.6000000000000005,5.0,5.5,5.8,6.0,6.2,6.3,6.5,6.800000000000001,7.3,7.7,8.100000000000001,8.4,8.9,9.200000000000001,9.399999999999999,9.6,10.0};
const vectorField& C = patch().Cf();
vectorField result(C.size(), vector::zero);
forAll(C,i)
{
 scalar h=max(C[i].z(),scalar(0)); label j=0;
 while(j<18 && h>z[j+1]) ++j;
 scalar w=min(max((h-z[j])/(z[j+1]-z[j]),scalar(0)),scalar(1));
 scalar value=v[j]+w*(v[j+1]-v[j]);
 result[i]=vector(0,-value,0);
}
operator==(result);
#}; }
```

`northProfileU` 按边界面中心高度读取插值速度；结果的 y 分量为负。建筑与地面采用无滑移，顶部和侧边界采用滑移。改变风向时，需要同时改变入口所在面和速度方向。

### `system/controlDict`

```foam
windProbes { type probes; libs (sampling); fields (U); writeControl timeStep; writeInterval 1;
probeLocations
(
    (268.6 364.1 19)
    (165.4 299.3 19)
    (20.7 343.4 19)
    (40.5 304.1 19)
    (40.5 304.1 30)
    (1.2 220.3 19)
    (1.2 220.3 30)
    (-81.9 164.7 19)
    (-81.9 164.7 30)
    (-128.7 194.6 19)
    (-128.7 194.6 30)
    (-195.4 181 19)
    (-195.4 181 30)
    (-263.7 293.8 19)
    (-93.6 -493.6 19)
    (-93.6 -493.6 30)
    (51.4 143 19)
    (51.4 143 30)
    (81.3 284.7 19)
    (81.3 284.7 30)
    (-50.2 87.5 19)
    (-50.2 87.5 30)
);
 }
```

`windProbes` 在公开北风测点位置记录 U。使用速度模除以 500 m 高度参考风速 10 m/s，得到与测量表一致的无量纲风速。测点若因局部网格分辨率落入实体，应先检查几何和测点位置。

## 运行与计算检查

[下载完整算例与配置代码](/downloads/engineering/shinjuku-wind.zip)，解压后进入 `shinjuku-wind` 目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
bash Allmesh
bash Allsolve
```

第一行加载 OpenCFD OpenFOAM v2512，安装位置不同则调整路径。`Allmesh` 完成网格建立、区域处理和质量检查，再将 `0.orig/` 复制为运行所用初始场。`Allsolve` 运行 `simpleFoam` 并将最新监测记录整理到 `analysis/last-monitors.json`。在 ParaView 中打开 `case.foam` 查看场文件。

网格修改在新解压目录进行，保留基准算例便于比较。建网格前修改 `0.orig/`，网格完成后修改 `0/`；求解范围与输出频率在 `system/controlDict` 中调整。详细记录保存在 `log.*`，运行脚本遇到错误会停止并显示对应日志。

## 结果提取与工程分析

运行结束后，`analysis/wind-speed-comparison.csv` 按 22 个测点编号列出三向速度、计算风速比、测量风速比与差值；`last-monitors.json` 同时记录均方根误差。启动阶段数据用于核对流程，方案评价采用收敛后的测点值。

数据集的风速比定义为

\[
K_i=\frac{|\overline{\mathbf U}_i|}{U_{500}},
\]

风速比以实体高度 500 m 的来流速度归一化，本例取 10 m/s。结果采用 `RS-WT_caseF.csv`；入口采用 `Inflow` 页。旧版结果页中另有屋顶参考速度，比较时按各自定义统一归一化。

按测点编号、坐标和风向逐行对齐数据，计算风速比差值与均方根误差。偏差较大的点结合三维位置检查分离、近壁和窄通道影响。风洞与现场观测分别绘图，以区分来流和统计条件的差异。

空间分析采用近地风速比、主街道竖直截面和高层背风速度矢量三类视图，分别识别绕流加速、下洗与回流。

全年风舒适性评价将各风向速度传递关系与当地风速频率分布结合，按所用标准计算超越概率。

> **熊猫说：** 本数据集同时涉及 1∶800 比例和实体 10 m 的整体抬高。以一处建筑和一个测点核对换算，再导入其余坐标。

## 数据与配置资料

- [下载完整城市风场算例、入口剖面与测点数据](/downloads/engineering/shinjuku-wind.zip)。包含原始 CSV、单位转换程序、文件校验值和配置示例。
- [AIJ Case F 原始 STL、CSV 与说明](https://zenodo.org/records/15589622)，Tominaga、Kikumoto、Okaze，CC BY 4.0。
- [AIJ 城市风环境 CFD 指南](https://doi.org/10.1016/j.jweia.2008.02.058)。
- [codedFixedValue 官方说明](https://doc.openfoam.com/2306/tools/processing/boundary-conditions/rtm/derived/general/codedFixedValue/)：动态编译边界的写法与参数。

配套 `VALIDATION.json` 与 `validation/` 保存本配置的网格检查和短程启动记录，`files.sha256` 用于核对文件完整性。

[返回实际工程应用](/topics/engineering/)
