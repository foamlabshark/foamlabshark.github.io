# 新宿街区风环境：真实建筑群与测点对比

OpenCFD OpenFOAM v2512；本文配套的模型与配置资料。

请先阅读 article.md，其中说明计算对象、几何尺度、文件位置与每个示例的作用。examples/ 保存正文代码片段，须按正文放入对应算例文件；它不是一套已经完成网格的独立算例。

依赖 numpy、trimesh；运行 python3 prepare_city.py。original/ 为 Tominaga、Kikumoto、Okaze 发布的 AIJ Case F 数据，CC BY 4.0，https://zenodo.org/records/15589622 。本站生成文件已转换为实体尺度，见 geometry/report.json。inflow-normalized.csv 逐项转录 LF_CaseF.xls 的 Inflow 表。

验证记录：模型生成、文件解析、单位及解析运动校核通过；尚未在 OpenFOAM 中完成网格与流场求解，不包含数值仿真结果。
