计算汽车风挡和冰层在暖风作用下的升温与融化，评价送风条件对除霜速度的影响。

## 工程场景与计算目标

车辆冷启动时，暖风输入的热量先用于提高风挡与冰层温度，达到融点后继续用于相变。冰层因吸收潜热可在融点附近维持较长时间，因此除霜分析需要同时计算温度和融化程度。送风覆盖不均还会使风挡不同位置具有明显不同的融化时间。

算例将乘员舱、冰层和外部空气划分为三个区域，以界面热耦合传递能量，并用等效热阻表示玻璃导热。送风温度随启动过程上升，冰层通过固化熔化源项更新相变状态。由融化分布、热流和累计送风能量评价除霜效果。

## 几何、尺寸与基准工况

![汽车风挡玻璃的送风除霜：配套模型与基准输入](/assets/engineering/windshield-defrost-geometry.webp)

风挡与送风通道采用 `windshieldDefrost` 曲面，展向宽 0.7 m。冰层由相邻曲面沿 x 方向偏移 0.5 mm 构造，玻璃则以厚度 3 mm 的导热层计入界面。三个区域名为 `cabin`、`ice`、`exterior`。

模型与配置来源：[OpenFOAM v2512 · heatTransfer/chtMultiRegionFoam/windshieldDefrost](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionFoam/windshieldDefrost)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 初始温度 | 260 K | 三个区域初始 `T` |
| 送风速度 | 2 m/s，沿负 x 方向 | `0.orig/cabin/U` |
| 送风升温 | 0～10 s 从 260 K 升到 293 K | `0.orig/cabin/T` |
| 融点与潜热 | 273 K、334000 J/kg | `system/ice/fvOptions` |
| 等效玻璃层 | 3 mm、0.9 W/(m·K) | 温度耦合边界中的 `thicknessLayers`、`kappaLayers` |

## 求解方法与物理模型

融化所需能量包括显热与潜热：$Q=m c_p(T_m-T_0)+mL f_l$，其中 $f_l$ 是液相比例。能量方程将潜热变化表示为 $\rho L\,\partial f_l/\partial t$。玻璃等效热阻为 $R^{\prime\prime}=\delta/k$，它决定热风侧与冰层侧之间的温差。

本例使用 `chtMultiRegionFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/windshield-defrost.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip windshield-defrost.zip
cd windshield-defrost
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `topoSet` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |
| `subsetMesh c0 -patch walls -overwrite` | 从背景网格选出实际计算区域，并生成新的边界面。 |
| `splitMeshRegions -cellZones -overwrite` | 按区域标记分离流体与固体网格，建立配对界面。 |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 暖风启动曲线

文件：`0.orig/cabin/T`。本段设置暖风启动曲线。

```foam
inlet
{
    type            uniformFixedValue;
    uniformValue    table
    (
        (0 260)
        (10 293)
        (1000 293)
    );
}
```

入口温度表规定 0～10 s 的升温过程，以秒为时间单位。该曲线决定初期热量输入，最终 293 K 对应升温结束后的送风状态。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionFoam/windshieldDefrost/0.orig/cabin/T)。

### 2. 冰层潜热

文件：`system/ice/fvOptions`。本段设置冰层潜热。

```foam
iceZone
{
    type            solidificationMeltingSource;
    active          on;

    solidificationMeltingSourceCoeffs
    {
        selectionMode   all;

        Tmelt           273;
        L               334000; // enthalpy of fusion for water [J/kg]
        thermoMode      thermo; // retrieve thermo properties from thermo model
        beta            50e-6;  // thermal expansion coeff [1/K]

        rhoRef          1000;
    }
}
```

`solidificationMeltingSource` 在整个 `ice` 区域计算相变。`Tmelt` 规定融化温度，`L` 规定单位质量相变潜热，二者共同决定升温转入融化的时刻及所需能量。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionFoam/windshieldDefrost/system/ice/fvOptions)。

### 3. 玻璃导热热阻

文件：`0.orig/cabin/T`。本段设置玻璃导热热阻。

```foam
cabin_to_ice
{
    type            compressible::turbulentTemperatureRadCoupledMixed;
    value           uniform 260;
    Tnbr            T;
    kappaMethod     fluidThermo;
    kappa           none;

    // windshield 3 mm
    thicknessLayers (0.003);
    kappaLayers     (0.9);
}
```

耦合温度边界中的附加层表示玻璃导热热阻。`thicknessLayers` 与 `kappaLayers` 分别给出厚度和导热系数，玻璃两侧温降由热流与该热阻共同确定。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionFoam/windshieldDefrost/0.orig/cabin/T)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.chtMultiRegionFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `chtMultiRegionFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `startTime` |
| `startTime` | `0` |
| `endTime` | `400` |
| `deltaT` | `0.0001` |
| `writeControl` | `adjustable` |
| `writeInterval` | `1` |
| `adjustTimeStep` | `yes` |
| `maxCo` | `5` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选cabin、ice 与 exterior，点击 **Apply**。先选择最后一个已写出的时刻，以 `T` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

显示冰层液相比例，统计达到指定融化比例的面积或体积，并与平均温度曲线对照。升温、相变平台和融化后升温对应不同的能量分配阶段，曲线与空间分布共同说明除霜进程。

分别改变送风温度和速度，比较融化时间及累计输入热量。重点比较直接冲击区与风挡远端：若热风集中通过局部区域，流量增加对远端融化的改善可能有限。

> **熊猫说：** 冰厚通过几何设置，玻璃厚度通过界面热阻设置。改变其中一项时，保持另一项不变才能区分两种传热影响。

## 文件与来源

- [完整算例包](/downloads/engineering/windshield-defrost.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/heatTransfer/chtMultiRegionFoam/windshieldDefrost)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
