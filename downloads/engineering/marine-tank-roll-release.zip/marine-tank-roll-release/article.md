建立液舱横倾恢复时的自由振荡抑制模型，分析挡板高度与初始液面倾角对壁面冲击力、液面振幅及衰减时间的影响。

## 工程场景与计算目标

船舶横倾或运动停止后，液舱中的液面会在重力作用下恢复并振荡。液体动量交换产生侧壁载荷，挡板通过改变流路和形成局部涡耗散能量。挡板过低时抑制作用有限，过高则可能使液体在舱间交换受限。

本例在固定液舱中设置倾斜初始液面，释放后求解其自由恢复过程。两块挡板部分浸没，初始液面斜率为 0.12。通过比较无挡板与不同挡板高度，分析液面振幅衰减和壁面载荷，而无需引入持续的船体运动。

## 几何、尺寸与基准工况

几何由 `design.json` 中的尺寸和位置生成，采用两块浸没挡板与初始横倾液面。坐标与尺寸均使用 m，流向由边界速度向量确定。

![船用液舱横倾恢复与纵向挡板的结构分区与流动方向](/assets/engineering/marine-tank-roll-release-geometry.webp)

| 参数 | 基准值 | 含义 |
| --- | --- | --- |
| 计算域外包尺寸 | 1.8 × 0.5 × 0.9 m | 实际计算空间由流体块体并集确定 |
| 流体密度 | 998.2 kg/m³ | 惯性、压差换算和质量流量 |
| 运动黏度 | 1.004e-06 m²/s | 分子黏性输运 |
| 基础网格 | 27,840 单元 | 默认 MESH_REFINE=2 的设计网格 |
| 初始液位 | 0.45 m | 由 setFieldsDict 赋值 |

几何各部分的坐标范围如下。流体块体先合并，再从中划分导热固体或扣除障碍物；因此相邻、相交块体不会重复占据体积。

| 部件 | x 范围 / m | y 范围 / m | z 范围 / m |
| --- | --- | --- | --- |
| 流体区域1 | 0～1.8 | 0～0.5 | 0～0.9 |
| 障碍物1 | 0.59～0.61 | 0～0.5 | 0～0.36 |
| 障碍物2 | 1.19～1.21 | 0～0.5 | 0～0.36 |

| 边界名称 | 作用 | 基准条件 |
| --- | --- | --- |
| `atmosphere` | 顶部气相交换 | 大气压力，回流为空气 |

## 物理模型与求解方法

不可压缩流动满足质量守恒与动量守恒：

\[
\nabla\cdot\mathbf U=0,\qquad
\rho\left(\frac{\partial\mathbf U}{\partial t}+\mathbf U\cdot\nabla\mathbf U\right)
=-\nabla p+\nabla\cdot\boldsymbol\tau+\mathbf f.
\]

其中，\(\mathbf U\) 为速度，\(p\) 为物理压力，\(\boldsymbol\tau\) 为黏性应力，\(\mathbf f\) 为单位体积外力。连续性方程约束各截面的流量收支；动量方程描述压力、黏性作用和外力如何改变速度。

自由液面通过液相体积分数输运方程确定：

\[
\frac{\partial\alpha}{\partial t}+\nabla\cdot(\alpha\mathbf U)
+\nabla\cdot[\alpha(1-\alpha)\mathbf U_c]=0,\qquad
\rho=\alpha\rho_l+(1-\alpha)\rho_g.
\]

\(\alpha=1\) 表示液体充满单元，\(\alpha=0\) 表示气体。界面压缩速度 \(\mathbf U_c\) 用于限制界面数值扩散；物性按相分数混合，动量方程包含重力与表面张力。`p_rgh` 从压力中扣除了静水贡献，评价壁面压力时需要采用相同的重力参考。

本例使用 `interFoam`，通过时间推进计算界面变化。湍流采用 `kOmegaSST`，同时求解湍动能与比耗散率；近壁分辨率通过 y⁺ 和网格比较评价。

## 配置文件与网格建立

[下载完整算例与配置代码](/downloads/engineering/marine-tank-roll-release.zip)。解压目录中已提供 `0.orig/`、`constant/`、`system/` 和几何数据，`build_case.py` 根据 `design.json` 重建相同输入；生成程序只使用 Python 标准库。

| 文件或目录 | 操作与用途 |
| --- | --- |
| `design.json` | 修改部件坐标、流体物性、速度或热功率；随后重新生成字典 |
| `geometry/model.obj` | 查看几何分区；曲线叶道以 blockMesh 圆弧为准 |
| `system/blockMeshDict` | 多块六面体网格的顶点、单元数与边界面 |
| `0.orig/` | 初始场和边界条件；建网格时复制到 `0/` |
| `constant/` | 物性、物理模型与区域设置 |
| `system/fvSchemes`、`system/fvSolution` | 离散格式、线性求解和耦合控制 |
| `Allmesh`、`Allsolve` | 分别完成网格准备与求解、结果提取 |

多块网格在肋片边缘、支路开口和分区界面处共享坐标平面，使边界与几何位置一致。默认加密级别为 2，薄通道与窄缝另外保留最低单元层数。网格完成后，`setFields` 按初始液位设置相分数，液位以上为空气；液舱恢复案例按分段高度形成倾斜初始液面。

## 关键配置与解读

以下条目取自本页下载包的同名文件，几何和边界名称与上表对应。

### `constant/transportProperties`

```foam
phases (water air);
water { transportModel Newtonian; nu 1.004e-06; rho 998.2; }
air { transportModel Newtonian; nu 1.5e-5; rho 1.2; }
sigma 0.072;
```

`phases` 确定两种流体，`nu` 的单位为 m²/s，`rho` 的单位为 kg/m³，`sigma` 的单位为 N/m。相分数字段沿用 `alpha.water`；润滑油案例中该字段代表此处设置物性的油相。

### `0.orig/U`

```foam
boundaryField
{
    walls { type noSlip; }
    atmosphere { type pressureInletOutletVelocity; value uniform (0 0 0); }
}
```

液舱侧壁和底部为无滑移边界，顶部与空气相通。初始液面倾斜提供恢复运动的势能，计算开始时没有持续入口供液。

### `system/controlDict`

```foam
application interFoam;
startFrom startTime;
startTime 0;
stopAt endTime;
endTime 10;
deltaT 0.0005;
writeControl adjustableRunTime;
writeInterval 0.1;
purgeWrite 0;
writeFormat ascii;
writePrecision 10;
writeCompression off;
timeFormat general;
timePrecision 10;
runTimeModifiable true;
adjustTimeStep yes; maxCo 0.3; maxAlphaCo 0.2; maxDeltaT 0.005;
```

`deltaT` 给出初始时间步，`maxCo` 与 `maxAlphaCo` 分别限制流动和界面输运的 Courant 数。`writeInterval` 是场文件输出间隔，监测对象的输出可以更频繁，便于保留水位和载荷曲线。


## 运行与计算检查

在 Linux 中加载 OpenCFD OpenFOAM v2512，然后进入解压目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
cd marine-tank-roll-release
bash Allmesh
bash Allsolve
```

安装位置不同，只需调整第一行环境路径。`Allmesh` 生成输入和网格，复制初始场并检查网格质量；`Allsolve` 调用 `interFoam`，运行后将监测记录整理到 `analysis/`。各阶段的详细信息分别写入 `log.blockMesh`、`log.checkMesh` 和 `log.interFoam`，遇到错误时脚本会停止并显示对应日志末尾。

修改工况时，先在新解压目录中编辑 `design.json`，再执行 `Allmesh`。网格生成以后，边界调整应写入 `0/`；如果重新生成网格，程序会再次使用参数文件和 `0.orig/`。保留各工况独立目录，便于核对尺寸、物性与结果。

观察液相体积分数的范围、Courant 数和液体体积变化，再检查水位或载荷曲线。持续来流问题需要覆盖足够的流经时间，液舱恢复问题需要覆盖若干振荡周期。

## 结果提取与工程分析

在两端壁附近设置固定竖线，记录液面高度随时间的变化，并提取相邻峰值计算衰减。总液体体积应保持稳定；若体积漂移明显，先检查界面输运和时间步。载荷应按左右壁面分别积分，整体 walls 的合力不能替代单侧冲击力。

在 ParaView 中打开 `case.foam`，选择最后一个已写出时刻。用 **Slice** 建立上述截面，用 **Plot Over Line** 提取沿线变化；流量计算使用速度的截面法向分量，配合 **Integrate Variables** 积分。输出表格时使用 **Save Data**，工况比较保持截面位置、色标和平均方式相同。

`analysis/monitor-history.csv` 保存监测对象的时间或迭代历史，`analysis/metrics.json` 整理边界流量、压力和温度等可用指标。内部通道分流、局部方差或单个壁面载荷按本节给出的选区继续提取。边界流量采用外法向为正，入口一般为负，出口一般为正。

## 参数比较与网格收敛

使用相同初始液面斜率，比较无挡板、0.24 m 和 0.36 m 挡板；提取两侧水位与侧壁受力。

先完成基准工况，再每次改变一个设计因素。记录几何尺寸、入口总流量、壁面冲击力、液面振幅及衰减时间，将性能变化与流场结构对应。对选定方案再做网格比较：

```bash
MESH_REFINE=4 bash Allmesh
bash Allsolve
```

在新的解压目录执行上述命令，各方向相对默认级别增加一倍单元数。比较时使用相同物性、边界条件及结果提取位置，检查主要工程量随网格变化的幅度。自由液面案例还需减小 `maxDeltaT`，比较水位幅值和相位；示踪混合案例需同时检查浓度界面的数值扩散。

> **熊猫说：** 体积分数用于区分气液两相；读取压力时还要区分 p 与 p_rgh，并保持相同的重力参考。

## 配套代码与资料

- [下载几何、完整配置、运行及分析代码](/downloads/engineering/marine-tank-roll-release.zip)。`VALIDATION.json` 和 `validation/` 保存 v2512 网格检查与短程启动记录，`files.sha256` 可用于核对文件完整性。
- [OpenFOAM 用户指南](https://www.openfoam.com/documentation/user-guide)：算例结构、网格与求解流程。
- [OpenFOAM v2512 源码文档](https://api.openfoam.com/2512/)：字段、边界和模型实现。

[返回实际工程应用](/topics/engineering/)
