计算 DLR-A 复合燃料射流火焰，分析氢气、甲烷与氮气配比对混合和燃烧的影响。

## 工程场景与计算目标

含氢复合燃料的燃烧特性由组分共同决定。氢气与甲烷的反应和扩散特性不同，氮气稀释改变单位质量混合物的放热量及温升。配比变化还会改变密度与入口动量，因此比较不同燃料时，需要明确保持的是速度、质量流量还是热功率。

DLR-A 采用中央氢气—甲烷—氮气射流和低速空气伴流。本例计算组分、温度和平均速度，重点考察空气卷吸与反应区之间的联系。入口配比经质量分数换算后写入各组分场，化学机理与热物性共同描述其反应和热力学性质。

## 几何、尺寸与基准工况

![DLR-A 复合燃料射流的混合与燃烧：配套模型与基准输入](/assets/engineering/dlr-flame-geometry.webp)

网格采用官方 `DLR_A_LTS` 轴对称喷管构型。`inletfuel` 为燃料入口，`inletair` 为伴流空气入口，喷口壁面为 `burnerwall` 和 `burnertip`。尺寸、楔形角度及喷管长度由 `system/blockMeshDict` 给出，轴向为 z 方向。

模型与配置来源：[OpenFOAM v2512 · combustion/reactingFoam/RAS/DLR_A_LTS](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/combustion/reactingFoam/RAS/DLR_A_LTS)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 燃料射流速度 | 42.2 m/s | `0.orig/U/inletfuel` |
| 空气伴流速度 | 0.3 m/s | `0.orig/U/inletair` |
| 组分输入 | CH4、H2、N2、O2 等质量分数 | `0.orig` 中同名组分场 |
| 化学数据 | GRI CHEMKIN 机理与热物性 | `chemkin` 及转换后的 `constant` 文件 |

## 求解方法与物理模型

摩尔分数 $X_k$ 按 $Y_k=X_kM_k/\sum_jX_jM_j$ 换算为质量分数，其中 $M_k$ 为摩尔质量。组分方程计算燃料与氧化剂的输运和反应，能量方程计算放热引起的温升，状态方程 $\rho=p/(R_{\mathrm{mix}}T)$ 将组成和温度变化反馈到密度。

喷口雷诺数 $Re=\rho U D/\mu$ 表征惯性与黏性作用的相对大小，物性取复合燃料入口状态。改变燃料配方时，即使速度不变，入口动量和雷诺数也会随密度与黏度变化。

本例使用 `reactingFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/dlr-flame.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip dlr-flame.zip
cd dlr-flame
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `chemkinToFoam chemkin/grimech30.dat chemkin/thermo30.dat chemkin/transportProperties constant/reactionsGRI constant/thermo.compressibleGasGRI` | 把随包 CHEMKIN 反应机理、热物性和输运数据转换为求解器字典。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `setFields` | 按几何区域设置初始相分数、组分或温度。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 燃料射流与空气伴流

文件：`0.orig/U`。本段设置燃料射流与空气伴流。

```foam
inletfuel
{
    type            fixedValue;
    value           uniform (0 0 42.2);
}
```

42.2 m/s 的燃料射流进入 0.3 m/s 的空气伴流，速度差驱动剪切层卷吸。出口边界允许按通量确定流出或回流状态；观察反应带与出口的距离，可判断计算域是否覆盖主要燃烧区域。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/combustion/reactingFoam/RAS/DLR_A_LTS/0.orig/U)。

### 2. 混合物热物性

文件：`constant/thermophysicalProperties`。本段设置混合物热物性。

```foam
thermoType
{
    type            hePsiThermo;
    mixture         reactingMixture;
    transport       sutherland;
    thermo          janaf;
    energy          sensibleEnthalpy;
    equationOfState perfectGas;
    specie          specie;
}
```

`thermoType` 指定混合物、状态方程和热力学数据的组织方式。组分名称将初始场与反应机理、物性数据连接起来，混合物热容和密度由各组分状态共同计算。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/combustion/reactingFoam/RAS/DLR_A_LTS/constant/thermophysicalProperties)。

### 3. 化学反应积分

文件：`constant/chemistryProperties`。本段设置化学反应积分。

```foam
chemistryType
{
    solver            ode;
    method            TDAC;
}
```

化学积分器求解每个单元内的反应方程。高温区反应时间尺度较短，化学子步与外层流动迭代共同影响收敛，应结合组分残差和温度变化评价求解进程。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/combustion/reactingFoam/RAS/DLR_A_LTS/constant/chemistryProperties)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.reactingFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `reactingFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。本例采用局部时间步向稳态推进，Time 不作为真实瞬态时间解释。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `latestTime` |
| `startTime` | `0` |
| `endTime` | `5000` |
| `deltaT` | `1` |
| `writeControl` | `runTime` |
| `writeInterval` | `1000` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选复合燃料射流，点击 **Apply**。先选择最后一个已写出的时刻，以 `T` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

沿中心线绘制燃料质量分数、轴向速度和温度，比较燃料消耗与流动衰减的先后关系。结合 OH 或主要产物分布识别反应带，并观察其是否随剪切层向外扩展。各径向剖面使用相同轴向位置，便于比较火焰宽度和峰值。

研究配比影响时，可保持总燃料质量流量，依据混合物密度调整入口速度。对每组工况记录温度峰值及其位置、出口燃料残余量，再通过径向网格加密检查这些量的变化。这样可以分别判断组分变化和空间分辨率对结果的影响。

> **熊猫说：** 摩尔配比通过摩尔质量换算后才能写入组分场。直接填入原始比例会改变燃料质量组成，进而改变热释放和入口动量。

## 文件与来源

- [完整算例包](/downloads/engineering/dlr-flame.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/combustion/reactingFoam/RAS/DLR_A_LTS)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
