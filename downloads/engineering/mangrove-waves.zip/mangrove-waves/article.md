计算波浪穿过等效植被区的传播与衰减，评价植被密度和阻力对透射波的影响。

## 工程场景与计算目标

滨海植被通过枝干和根系阻力改变水流，消耗部分波浪能量。植被密度、淹没深度和入射波条件共同影响消波能力，水槽边界反射与数值耗散也会改变测得波高。比较植被前后的完整水位过程，可以区分这些作用。

算例在三维水槽中设置等效植被区域，以动量和湍流源表示群体作用。上游生成孤立波，下游吸收传播波；沿槽布置水位探针，将有、无植被条件下的波高、到达时间与速度衰减进行对应比较。

## 几何、尺寸与基准工况

![红树林植被与波浪相互作用：配套模型与基准输入](/assets/engineering/mangrove-waves-geometry.webp)

水槽长 7 m、宽 0.55 m、高 0.5 m，初始水深 0.15 m。`seaweed.stl.gz` 用于定义植被分布，将其写入 `MangrovesIndex` 后生成 `c0` 单元区，阻力源在该区域内作用。

模型与配置来源：[OpenFOAM v2512 · multiphase/interFoam/laminar/waves/mangroveInteraction](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/multiphase/interFoam/laminar/waves/mangroveInteraction)。

| 参数 | 基准值 | 设置位置与作用 |
| --- | --- | --- |
| 初始水深 | 0.15 m | `system/setFieldsDict` |
| 入射波高 | 0.05 m | `constant/waveProperties/left` |
| 植被阻力参数 | a = 0.01、N = 560、Cd = 1.52 | `system/fvOptions` |
| 最大时间步 | 0.01 s | `system/controlDict` |
| 下游边界 | shallowWaterAbsorption | `constant/waveProperties/right` |

## 求解方法与物理模型

植被阻力可概括为与 $\tfrac12\rho C_D aN|\mathbf U|\mathbf U$ 成正比，其中 $a$、$N$ 描述等效尺寸与密度。透射系数定义为 $K_t=H_t/H_i$。对相同水深下的线性波，能流与 $H^2$ 成正比，因此波高减小对应更显著的能量降低；孤立波分析应结合完整水位过程积分。

本例使用 `interFoam`。网格与边界定义在 `constant` 和初始场目录，离散格式和方程求解设置分别位于 `system/fvSchemes`、`system/fvSolution`；多区域模型在相应区域子目录中保存这些文件。

## 获取文件与准备网格

[下载完整算例包](/downloads/engineering/mangrove-waves.zip)。包内包含模型资源、初始场、物性、数值设置、运行脚本和来源记录。

先在 Linux 终端加载 OpenCFD OpenFOAM v2512。采用标准软件包安装路径时执行下列命令；安装在其他目录时，将路径改为该安装目录下的 `etc/bashrc`。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
```

输出应为 `v2512`。随后进入下载目录，解压并生成网格：

```bash
unzip mangrove-waves.zip
cd mangrove-waves
bash Allmesh
```

`Allmesh` 按下表顺序生成网格并执行 `checkMesh`，每一步的输出保存在相应 `log.*` 文件中。脚本在命令失败或网格检查不通过时停止。

| 网格步骤 | 作用 |
| --- | --- |
| 复制初始场 | 把 0.orig 中的初始场复制到 0 目录。 |
| `blockMesh` | 按顶点、块结构和加密比例生成背景网格。 |
| `setFields` | 按几何区域设置初始相分数、组分或温度。 |
| `topoSet` | 按位置或曲面生成网格选区，供运动、热源、阻力或初始场使用。 |

首次生成网格前，在 `0.orig/` 修改初始场与边界；`Allmesh` 会把它们复制到 `0/`。网格生成后继续调整边界，应修改 `0/` 中的对应文件。 修改几何或网格字典时，在新目录重新解压并生成网格；保留已有结果目录，便于对比前后工况。

## 关键配置与解读

### 1. 造波与吸收

文件：`constant/waveProperties`。本段设置造波与吸收。

```foam
left
{
    alpha           alpha.water;

    waveModel       Boussinesq;

    nPaddle         1;

    waveHeight      0.05;

    waveAngle       0.0;

    activeAbsorption yes;
}
```

左边界采用 Boussinesq 波模型和主动吸收，右边界采用浅水吸收。波高、初始水深与吸收条件共同组成水槽波浪设置。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/interFoam/laminar/waves/mangroveInteraction/constant/waveProperties)。

### 2. 植被等效作用

文件：`system/fvOptions`。本段设置植被等效作用。

```foam
Mangroves
{
    type            multiphaseMangrovesSource;
    active          yes;

    multiphaseMangrovesSourceCoeffs
    {
        regions
        {
            region1
            {
                cellZone        c0;
                a               0.01;
                N               560;
                Cm              1;
                Cd              1.52;
            }
        }
    }
}
```

`cellZone c0` 指定源项区域，`Cd` 表示阻力作用，`Cm` 表示惯性相关作用，植被尺寸和密度进一步确定源项强度。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/interFoam/laminar/waves/mangroveInteraction/system/fvOptions)。

### 3. 植被范围选取

文件：`system/setFieldsDict`。本段设置植被范围选取。

```foam
surfaceToCell
{
    file            "constant/triSurface/seaweed.stl.gz";
    outsidePoints   ((2 0.25 0.15));
    includeCut      true;
    includeInside   true;
    includeOutside  false;
    nearDistance    -1;

    curvature       -100;

    fieldValues
    (
        volScalarFieldValue MangrovesIndex 1
    );
}
```

曲面选区先设置 `MangrovesIndex`，再生成单元区。修改布局后重新执行这两步，使实际阻力位置随几何更新。

[查看该配置的官方原文件](https://gitlab.com/openfoam/core/openfoam/-/blob/OpenFOAM-v2512/tutorials/multiphase/interFoam/laminar/waves/mangroveInteraction/system/setFieldsDict)。

## 求解运行与检查

```bash
bash Allsolve
tail -n 40 log.interFoam
```

`Allsolve` 读取生成的网格和初始场，调用 `interFoam`；日志用于观察残差、连续性误差及本模型的迭代信息。时间控制给出计算起止位置和输出频率。

| 控制项 | 配置值 |
| --- | --- |
| `startFrom` | `latestTime` |
| `startTime` | `0` |
| `endTime` | `10.0` |
| `deltaT` | `0.1` |
| `writeControl` | `adjustable` |
| `writeInterval` | `0.1` |
| `adjustTimeStep` | `on` |
| `maxCo` | `0.4` |

计算检查包括网格质量、质量守恒与工程量收敛。稳态计算结合残差、流量和载荷判断迭代进程；周期或波动流动采用连续时序统计，比较相同时间窗内的均值与波动。

## 结果提取与工程分析

在 ParaView 中打开 `case.foam`，勾选水槽与植被区域，点击 **Apply**。先选择最后一个已写出的时刻，以 `alpha.water` 着色；用 **Rescale to Data Range** 更新色标。使用 **Slice** 查看内部截面，使用 **Plot Over Line** 沿关注方向提取曲线，最后通过 **Save Data** 导出表格。对比不同工况时固定截面位置和色标范围。

在植被前后固定位置输出水位时序，按波到达顺序比较峰值和持续时间。植被前保留至少两个测点，用于观察入射波与回传波叠加。

以无植被计算作为对照，分别改变植被密度和阻力参数，比较透射波高、传播时延与区域内速度。网格和时间步比较使用同一组探针曲线，使植被作用与数值耗散能够分别判断。

> **熊猫说：** 波高分析需要连续时序。探针按固定时间间隔写出，以覆盖波进入、通过和离开植被区的全过程。

## 文件与来源

- [完整算例包](/downloads/engineering/mangrove-waves.zip)：包含本页使用的全部配置和模型资源。
- [v2512 官方算例目录](https://gitlab.com/openfoam/core/openfoam/-/tree/OpenFOAM-v2512/tutorials/multiphase/interFoam/laminar/waves/mangroveInteraction)：核对原始几何、物性和网格流程。
- `SOURCE.json` 记录来源与本站调整；`files.sha256` 用于核对包内文件；`VALIDATION.json` 记录网格检查和短步运行结果。
