#include "fvCFD.H"
#include <fstream>
#include <iomanip>
int main(int argc, char *argv[])
{
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    IOdictionary cfg(IOobject("heatTheoryDict",runTime.system(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE));
    const word mode=cfg.get<word>("mode"), name=cfg.get<word>("field");
    const scalar av=cfg.get<scalar>("alpha"), pi=constant::mathematical::pi;
    dimensionedScalar alpha("alpha",dimArea/dimTime,av);
    volScalarField T(IOobject(name,runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::AUTO_WRITE),mesh);
    volScalarField source(IOobject("source",runTime.timeName(),mesh),mesh,dimensionedScalar("zero",T.dimensions()/dimTime,0));
    const bool transient=(mode=="decay"||mode=="species");
    auto reference=[&](const vector& x, scalar t)->scalar {
        if(mode=="linear") return 400-100*x.x();
        if(mode=="source") return 300+100*x.x()*(1-x.x());
        if(mode=="poisson") return 300+10*Foam::sin(pi*x.x())*Foam::sin(pi*x.y());
        return (mode=="species"?0:300)+(mode=="species"?1:10)*Foam::sin(pi*x.x())*Foam::exp(-av*pi*pi*t);
    };
    forAll(T,i) {
        if(transient) T[i]=reference(mesh.C()[i],0);
        if(mode=="source") source[i]=200*av;
        if(mode=="poisson") source[i]=20*av*pi*pi*Foam::sin(pi*mesh.C()[i].x())*Foam::sin(pi*mesh.C()[i].y());
    }
    T.correctBoundaryConditions();T.write();
    std::ofstream history((runTime.path()/"history.csv").c_str());
    history<<std::setprecision(15)<<"time,rmsError,maxError,mean,initialResidual,finalResidual,balance\n";
    while(runTime.loop()) {
        const scalar oldIntegral=fvc::domainIntegrate(T).value();
        fvScalarMatrix eqn(-fvm::laplacian(alpha,T)==source);
        if(transient) eqn+=fvm::ddt(T);
        auto perf=eqn.solve();
        scalar e2=0,em=0,vol=0;
        forAll(T,i) {scalar e=T[i]-reference(mesh.C()[i],runTime.value());e2+=e*e*mesh.V()[i];em=max(em,mag(e));vol+=mesh.V()[i];}
        const scalar current=fvc::domainIntegrate(T).value();
        tmp<surfaceScalarField> flux=alpha*fvc::snGrad(T)*mesh.magSf();
        scalar net=0; forAll(mesh.boundary(),p) if(!mesh.boundary()[p].coupled()) net+=gSum(flux().boundaryField()[p]);
        const scalar input=fvc::domainIntegrate(source).value()+net;
        const scalar balance=(transient?(current-oldIntegral)/runTime.deltaTValue():0)-input;
        history<<runTime.value()<<','<<Foam::sqrt(e2/vol)<<','<<em<<','<<current/vol<<','<<perf.initialResidual()<<','<<perf.finalResidual()<<','<<balance<<'\n';
        runTime.write();
    }
    std::ofstream f((runTime.path()/"profile.csv").c_str());f<<std::setprecision(15)<<"x,y,value,reference\n";
    forAll(T,i) f<<mesh.C()[i].x()<<','<<mesh.C()[i].y()<<','<<T[i]<<','<<reference(mesh.C()[i],runTime.value())<<'\n';
    Info<<"End"<<nl;return 0;
}
