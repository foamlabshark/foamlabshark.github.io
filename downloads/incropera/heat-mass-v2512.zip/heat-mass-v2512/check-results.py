from pathlib import Path
import csv,math
root=Path(__file__).resolve().parent
errors={}
for p in sorted((root/'cases').iterdir()):
    assert 'Mesh OK.' in (p/'log.checkMesh').read_text(),p.name
    assert (p/'log.heatTheoryFoam').read_text().strip().endswith('End'),p.name
    history=list(csv.DictReader((p/'history.csv').open()))
    v={k:float(x) for k,x in history[-1].items()}
    assert all(math.isfinite(x) for x in v.values()),p.name
    transient=p.name.startswith(('decay','species'))
    assert v['time']==(1000 if transient else 1),p.name
    assert v['finalResidual']<1e-10 and abs(v['balance'])<1e-10,p.name
    errors[p.name]=v['rmsError']
    print(p.name,'steps',len(history),'rmsError',v['rmsError'],'balance',v['balance'])
for mode in ['source','poisson','decay','species']:
    assert 3.8<errors[mode+'-20']/errors[mode+'-40']<4.2,mode
assert max(errors['linear-20'],errors['linear-40'])<1e-8
print('All ten cases reached their endpoints and passed the checks.')
