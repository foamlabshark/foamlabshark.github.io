from math import exp

volume, flow, inlet = 0.002, 1e-4, 10.0
concentration, dt = 0.0, 1.0
new_value = (volume * concentration + dt * flow * inlet) / (volume + dt * flow)
exact = inlet * (1.0 - exp(-flow * dt / volume))
print(f'隐式一步: {new_value:.6f} kg/m3')
print(f'解析解:   {exact:.6f} kg/m3')
