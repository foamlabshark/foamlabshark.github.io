质量、动量和能量方程分别描述物质如何积累、流体如何加速，以及热量如何传递。有限体积法对每个网格单元积分这些方程，把连续流场转化为各单元之间的通量交换。

## 1. 控制体积中的质量守恒

取一个固定空间区域 $V$，外边界为 $\partial V$，外法向为 $\mathbf n$。区域内总质量是 $\int_V\rho\,dV$，穿过边界的质量流率是 $\rho\mathbf U\cdot\mathbf n$。质量守恒为

\[
\frac{d}{dt}\int_V\rho\,dV
+\oint_{\partial V}\rho\mathbf U\cdot\mathbf n\,dA=0.
\]

第一项表示内部质量变化，第二项表示向外流出的净质量流率。若流入比流出多，第二项为负，第一项为正，区域内质量增加。

利用散度定理，可写成微分形式：

\[
\frac{\partial\rho}{\partial t}+\nabla\cdot(\rho\mathbf U)=0.
\]

密度为常数时，方程简化为 $\nabla\cdot\mathbf U=0$。这里速度的三个分量可以各自随空间变化，只要它们形成的净体积流量满足平衡即可。

例如一个固定体积单元，每秒从左侧流入 0.002 m³，从右侧流出 0.0015 m³，上侧还需流出 0.0005 m³，才能满足不可压缩的体积守恒。

<figure class="wolf-figure"><img src="/assets/wolf/wolf-fvm-convective-face-flux.png" alt="从体积分到离散面通量" loading="lazy"><figcaption><strong>从体积分到离散面通量</strong><small class="figure-source">来源：Joel Guerrero / <a href="https://www.wolfdynamics.com/tutorials.html?id=181&amp;layout=edit">Wolf Dynamics</a> · module6.pdf，p. 11 · <a href="https://creativecommons.org/licenses/by-sa/4.0/">CC BY-SA 4.0</a>（裁剪）</small></figcaption></figure>

## 2. 动量守恒：力引起速度变化

单位体积动量为 $\rho\mathbf U$。对牛顿流体，动量方程可写为

\[
\frac{\partial(\rho\mathbf U)}{\partial t}
+\nabla\cdot(\rho\mathbf U\otimes\mathbf U)
=-\nabla p+\nabla\cdot\boldsymbol\tau+\rho\mathbf g+\mathbf S_U.
\]

$p$ 是物理压力，单位为 Pa；$\boldsymbol\tau$ 是黏性应力；$\mathbf g$ 是重力加速度；$\mathbf S_U$ 是其他单位体积力，例如多孔阻力或电磁力，单位为 N/m³。张量积 $\mathbf U\otimes\mathbf U$ 表示速度携带各方向动量的通量。

左侧的时间项与对流项共同描述流体动量变化。右侧分别是压力作用、黏性作用、重力和附加体积力。静止液柱中，速度为零，压力梯度与重力平衡；管道流动中，压力力还需要克服壁面黏性阻力。

对于密度和运动黏度均为常数的不可压缩流动，除以密度后得到

\[
\frac{\partial\mathbf U}{\partial t}
+\nabla\cdot(\mathbf U\otimes\mathbf U)
=-\nabla p_k+\nu\nabla^2\mathbf U+\mathbf g+\frac{\mathbf S_U}{\rho},
\qquad p_k=\frac p\rho.
\]

`icoFoam` 使用的 `p` 对应这里的 $p_k$，单位为 m²/s²。热力学求解器中的压力通常具有 Pa 的量纲。阅读场文件的 `dimensions`，就能区分两种定义。

## 3. 能量守恒与温度方程

以内能 $e$ 为例，单位质量内能的单位是 J/kg。单组分流体的能量方程可写为

\[
\frac{\partial(\rho e)}{\partial t}
+\nabla\cdot(\rho\mathbf Ue)
=-p\nabla\cdot\mathbf U
+\boldsymbol\tau:\nabla\mathbf U
-\nabla\cdot\mathbf q+Q.
\]

$\mathbf q=-k\nabla T$ 是导热热流密度，单位为 W/m²；$Q$ 是体积热源，单位为 W/m³。压力功表示压缩或膨胀中的能量交换，黏性耗散将机械能转化为内能。

对于常物性、低速不可压缩传热，忽略相应压力功和黏性耗散后，可使用温度方程

\[
\rho c_p\left(\frac{\partial T}{\partial t}+\mathbf U\cdot\nabla T\right)
=\nabla\cdot(k\nabla T)+Q.
\]

再除以 $\rho c_p$，热扩散率为 $\alpha=k/(\rho c_p)$，单位为 m²/s。这个简化形式与 `scalarTransportFoam`、`laplacianFoam` 中的温度扩散有直接联系。可压缩、高速或复杂热物性问题则需要所选求解器的完整能量形式。

## 4. 将三类方程写成通用输运形式

设 $\psi$ 是单位质量对应的物理量，可写成

\[
\frac{\partial(\rho\psi)}{\partial t}
+\nabla\cdot(\rho\mathbf U\psi)
=\nabla\cdot(\Gamma\nabla\psi)+S_\psi.
\]

| 所研究的量 | $\psi$ | 扩散系数示例 | 源项示例 |
| --- | --- | --- | --- |
| 质量 | 1 | 0 | 无质量源时为 0 |
| 组分质量分数 | $Y$ | $\rho D$ | 反应生成率 |
| 某方向动量 | $U_x$ | 常物性简化下的 $\mu$ | 压力梯度、体积力 |
| 温度输运 | $T$ | 方程缩放后为 $\rho\alpha$ | 缩放后的热源 |

符号形式相似，使程序能够复用时间、对流和扩散算子。但每个变量的单位、边界条件和模型含义由具体方程决定。

## 5. 面通量如何进入离散方程

对静止单元 $P$ 积分，并采用单元平均值近似，得到

\[
\frac{(\rho\psi)_P^{n+1}-(\rho\psi)_P^n}{\Delta t}V_P
+\sum_f\dot m_f\psi_f
=\sum_f\Gamma_f(\nabla\psi)_f\cdot\mathbf S_f+S_{\psi,P}V_P.
\]

$\dot m_f=\rho_f\mathbf U_f\cdot\mathbf S_f$ 是面质量流率。内部面只计算一份数值通量，以正负两个符号加入相邻单元。全部单元求和后，内部面项两两抵消，全域只剩外边界与源项。

取一个体积为 $10^{-6}\,\mathrm{m^3}$ 的单元，体积热源为 $2\times10^6\,\mathrm{W/m^3}$，该单元的总加热功率是 2 W。若在源码中直接给总功率，或在字典中给单位体积热源，系数处理应与其定义一致。

稳态扩散中的内部面通量与中心温差成正比，形成相邻单元之间的矩阵系数。时间项则为主对角线增加储存系数 $\rho V/\Delta t$，同时将旧时刻场放入右侧。

## 6. 手算一个完全混合容器

容器体积 $V=0.002\,\mathrm{m^3}$，进出体积流率均为 $Q_v=10^{-4}\,\mathrm{m^3/s}$，入口浓度为 $C_{in}=10\,\mathrm{kg/m^3}$，初始浓度为零。容器内部充分混合，所以出口浓度等于内部浓度 $C$。

\[
V\frac{dC}{dt}=Q_v(C_{in}-C).
\]

响应时间 $\tau=V/Q_v=20\,\mathrm s$，解析解为 $C(t)=C_{in}(1-e^{-t/\tau})$。1 s 时浓度约为 0.487706 kg/m³。

采用一步隐式 Euler，得到

\[
\left(\frac V{\Delta t}+Q_v\right)C^{n+1}
=\frac V{\Delta t}C^n+Q_vC_{in}.
\]

取 $\Delta t=1\,\mathrm s$，求得 $C^1\approx0.476190\,\mathrm{kg/m^3}$。左侧系数同时包含储存和流出，右侧包含旧状态与入口输入。这与有限体积单元方程的结构相同。

```python
from math import exp

volume, flow, inlet = 0.002, 1e-4, 10.0
concentration, dt = 0.0, 1.0
new_value = (volume * concentration + dt * flow * inlet) / (volume + dt * flow)
exact = inlet * (1.0 - exp(-flow * dt / volume))
print(f'隐式一步: {new_value:.6f} kg/m3')
print(f'解析解:   {exact:.6f} kg/m3')
```

分母中的 `volume + dt*flow` 对应隐式主对角系数。将时间步改为 0.5 s 并计算两步，可以比较同一个 1 s 时刻的误差；把体积加倍则使物理响应时间加倍。

## 7. 边界条件提供哪一部分信息

固定值边界给出场值，例如导热杆端部的温度；固定梯度边界给出法向导数，配合材料系数决定扩散通量。Robin 边界将值与梯度联系起来，例如壁面对流换热

\[
-k\frac{\partial T}{\partial n}=h(T_w-T_\infty).
\]

$h$ 为换热系数，单位为 W/(m² K)。若壁温高于外部温度，按指向外部的法向定义，热量从壁面流出。

对流项还依赖面流量方向。流入处需要给定随流体进入的状态；流出处常根据内部场延拓。若出口发生回流，相应边界还需要合理的流入状态。这就是 `inletOutlet` 一类条件根据通量方向切换处理的用途。

边界项最终有两种典型贡献：给定值通过边界通量形成矩阵系数和右侧；给定通量直接进入右侧。求解得到的内部场因此由方程与边界共同确定。

## 8. 对照 v2512 算子

以下是 `scalarTransportFoam` 中已有字段创建后的方程主体：

```cpp
fvScalarMatrix TEqn
(
    fvm::ddt(T)
  + fvm::div(phi, T)
  - fvm::laplacian(DT, T)
 ==
    fvOptions(T)
);
TEqn.relax();
fvOptions.constrain(TEqn);
TEqn.solve();
fvOptions.correct(T);
```

三个 `fvm` 算子组装矩阵。`phi` 是给定速度形成的面体积通量，`DT` 是扩散率；把扩散项移到左侧后出现负号。源项由已选模型加入，约束在求解前作用，场修正在求解后作用。

字典对应关系如下：时间项读取 `ddtSchemes`，对流项读取 `divSchemes/div(phi,T)`，扩散项读取 `laplacianSchemes`，线性算法读取 `fvSolution/solvers/T`。各条设置影响方程的不同阶段。

## 9. 无量纲化怎样得到 Re 与 Pe

取特征长度 $L$、速度 $U_0$、时间 $L/U_0$，定义 $\mathbf x^*=\mathbf x/L$、$\mathbf U^*=\mathbf U/U_0$、$t^*=tU_0/L$。压力用 $\rho U_0^2$ 缩放。忽略体积力时，不可压缩动量方程变为

\[
\frac{\partial\mathbf U^*}{\partial t^*}
+\nabla^*\cdot(\mathbf U^*\otimes\mathbf U^*)
=-\nabla^*p^*+\frac1{Re}\nabla^{*2}\mathbf U^*,
\qquad Re=\frac{U_0L}{\nu}.
\]

黏性项前面的 $1/Re$ 来自同一方程中对流尺度与黏性尺度之比。$Re$ 较小时，黏性作用相对明显；较大时，局部剪切层和其他细尺度需要更细的空间描述。它本身还应与几何和扰动条件一起用于判断流动状态。

若温度差用 $\Delta T$ 缩放，则无源常物性温度方程为

\[
\frac{\partial T^*}{\partial t^*}+\mathbf U^*\cdot\nabla^*T^*
=\frac1{Pe}\nabla^{*2}T^*,
\qquad Pe=\frac{U_0L}{\alpha}=Re\,Pr.
\]

例如 $U_0=0.1\,\mathrm{m/s}$、$L=0.01\,\mathrm m$、$\nu=10^{-6}\,\mathrm{m^2/s}$，得到 $Re=1000$。取 $\alpha=1.4\times10^{-7}\,\mathrm{m^2/s}$，则 $Pr\approx7.14$、$Pe\approx7143$。在这组尺度下，温度对流相对导热很强，薄热边界层的分辨率尤其值得关注。

这也解释了更改物性时为什么要同时记录无量纲数：只把 `nu` 减小十倍，就已改变了模拟的物理工况；保持同一工况做网格细化时，这些物理参数应保持一致。

## 10. 守恒形式与对流形式的关系

展开通用方程左侧可得

\[
\frac{\partial(\rho\psi)}{\partial t}
+\nabla\cdot(\rho\mathbf U\psi)
=\rho\left(\frac{\partial\psi}{\partial t}+\mathbf U\cdot\nabla\psi\right)
+\psi\left[\frac{\partial\rho}{\partial t}+\nabla\cdot(\rho\mathbf U)\right].
\]

连续性方程使最后一组括号为零，两个形式在连续层面相同。离散过程中，质量通量还可能存在迭代残差，因此相应差别会以离散质量不平衡乘场值的形式出现。理解这一点，有助于阅读源项修正、稳态 `bounded` 对流形式和质量一致的标量输运。

在多组分问题中，各组分通量相加还应与总质量通量配合；在多相流中，相分数、密度和动量输运也需使用一致的离散通量。守恒因而不仅体现在单个方程，还体现在多个方程之间的共同收支。

## 11. 练习与答案要点

**练习一：通量收支。** 一个单元流入 3 kg/s，流出 2.7 kg/s。若其余边界不透流，2 s 后质量增加多少？答案为 0.6 kg，来自净流入率乘时间。若模型要求固定密度和固定体积，则速度通量需要进一步校正以满足连续性。

**练习二：热源。** 总体积为 $5\times10^{-5}\,\mathrm{m^3}$，要求总加热功率 50 W，均匀体积热源应为多少？答案为 $10^6\,\mathrm{W/m^3}$。离散后将每个单元的 $QV_i$ 求和，应得到 50 W。

**练习三：稳态极限。** 将完全混合容器方程的时间导数设为零，可得 $C=C_{in}$。改变流量会改变达到该状态的快慢，但在本例固定入口和无反应条件下，稳态浓度保持相同。

**进阶：移动控制体积。** 当网格以速度 $\mathbf U_m$ 运动时，对流通量采用相对速度 $\mathbf U-\mathbf U_m$，体积变化同时进入储存项。动网格求解器需要使网格扫过体积与几何更新一致，这一要求通常称为几何守恒律。

继续阅读：[有限体积法与守恒方程](/read/?slug=finite-volume-conservation)、[扩散、梯度与非正交修正](/read/?slug=diffusion-gradients-laplacian)。
