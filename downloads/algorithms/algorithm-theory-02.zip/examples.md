一个离散格式需要回答三个问题：它是否逼近原方程，误差会不会在计算中被不断放大，网格和时间步变小时数值解是否接近连续解。这三个问题分别对应一致性、稳定性和收敛性。

一维输运和扩散方程足够简单，可以把这些概念直接算出来。得到的结论还能解释迎风扩散、中心振荡，以及 Courant 数和网格 Péclet 数的作用。

## 1. Taylor 展开怎样给出截断误差

设 $T(x)$ 足够光滑，在 $x_i$ 附近展开：

\[
T_{i+1}=T_i+\Delta xT'_i+\frac{\Delta x^2}{2}T''_i
+\frac{\Delta x^3}{6}T_i^{(3)}+\cdots,
\]

\[
T_{i-1}=T_i-\Delta xT'_i+\frac{\Delta x^2}{2}T''_i
-\frac{\Delta x^3}{6}T_i^{(3)}+\cdots.
\]

相减后得到中心差分：

\[
\frac{T_{i+1}-T_{i-1}}{2\Delta x}
=T'_i+\frac{\Delta x^2}{6}T_i^{(3)}+O(\Delta x^4).
\]

首个误差项含 $\Delta x^2$，所以它是一阶导数的二阶精度近似。改用后向差分，则有

\[
\frac{T_i-T_{i-1}}{\Delta x}
=T'_i-\frac{\Delta x}{2}T''_i+O(\Delta x^2).
\]

首项误差与 $\Delta x$ 成正比，对应一阶近似。这里的“阶”描述误差随尺度缩小的规律，当前网格的具体误差还取决于系数和解的光滑程度。

## 2. 手算一次误差阶

取 $T(x)=e^x$，在 $x=0$ 处准确导数为 1。用 $\Delta x=0.2$ 与 0.1 分别计算：

```python
from math import exp

for dx in (0.2, 0.1):
    backward = (1.0 - exp(-dx)) / dx
    central = (exp(dx) - exp(-dx)) / (2.0 * dx)
    print(dx, abs(backward - 1.0), abs(central - 1.0))
```

后向差分的误差约从 0.09365 降到 0.04837，约缩小两倍；中心差分约从 0.006680 降到 0.001668，约缩小四倍。把间距再减半，就能继续观察其阶数规律。

给定两组误差 $E_h$ 与 $E_{h/2}$，可以用 $p=\ln(E_h/E_{h/2})/\ln2$ 估计观察阶。这个办法同样用于有解析参考的 OpenFOAM 教学算例。

## 3. 一致性、稳定性和收敛性

**一致性**关注离散方程本身：将原方程的光滑准确解代入离散式，剩余项随 $\Delta x,\Delta t\to0$ 趋于零，说明离散式逐步逼近原方程。

**稳定性**关注扰动传播：舍入误差、初值误差或每步产生的小误差，经过很多步后是否仍受控制。即使每一步的近似误差很小，若传播过程持续放大，长时间结果仍可能失去意义。

**收敛性**关注最终解：按照合理的网格与时间步序列细化后，离散解是否接近连续问题的解。

对于适定的线性初值问题和一致的线性离散，在相应范数和边界假设下，Lax 等价定理把稳定性与收敛性联系起来。非线性流动中仍可沿这一思路研究误差，并针对耦合、限制器和边界做具体分析。相关推导可参考 [MIT 数值方法讲义](https://ocw.mit.edu/courses/18-086-mathematical-methods-for-engineers-ii-spring-2006/resources/am52/)。

## 4. 显式迎风的 CFL 条件

一维常速对流满足 $T_t+uT_x=0$，取 $u>0$。显式 Euler 加迎风空间离散为

\[
T_i^{n+1}=T_i^n-C(T_i^n-T_{i-1}^n)
=(1-C)T_i^n+CT_{i-1}^n,
\qquad C=\frac{u\Delta t}{\Delta x}.
\]

当 $0\le C\le1$，新值是两个旧值的非负加权平均。例如本地旧值为 0.2、上游旧值为 0.8，$C=0.25$ 时，新值为 0.35，仍位于两者之间。

当 $C=1.2$，本地旧值的权重为 −0.2，来自上游的权重为 1.2，新值可能超出原范围。这说明步长已经改变了更新公式的性质。

CFL 条件也可以从信息传播理解：连续方程的一个时间步中，信息移动 $u\Delta t$；显式迎风只从一个上游相邻单元取得信息。因此稳定推进需要时间和空间尺度相互匹配。

## 5. von Neumann 分析：跟踪一个误差波

将误差分解成 Fourier 模态，取

\[
e_i^n=G^n e^{\mathrm{i}i\theta},
\]

其中 $\theta$ 是相邻单元之间的相位差，$G$ 是每步放大因子。对于上述显式迎风格式，代入得到

\[
G=1-C+Ce^{-\mathrm{i}\theta},
\]

\[
|G|^2=1-2C(1-C)(1-\cos\theta).
\]

所有波数都满足 $|G|\le1$ 的条件正是 $0\le C\le1$。取最短交替波 $\theta=\pi$，$G=1-2C$：$C=0.5$ 时该模态在一步中被完全衰减，$C=1.2$ 时 $G=-1.4$，幅度每步放大 1.4 倍并交替变号。

```python
import cmath
from math import pi

for c in (0.2, 0.5, 1.0, 1.2):
    g = 1.0 - c + c * cmath.exp(-1j * pi)
    print(f'C={c:.1f}, |G|={abs(g):.3f}')
```

输出模长依次为 0.6、0、1、1.4。稳定性检查揭示哪些误差波会增长；模长显著小于 1 还说明格式在衰减空间细节。

## 6. 中心格式为什么会振荡

若保持显式 Euler，将空间导数改为中心差分，则

\[
G=1-\mathrm{i}C\sin\theta,
\qquad |G|^2=1+C^2\sin^2\theta.
\]

对非零 $C$ 和相应非零波数，模长大于 1。这一时间—空间组合对纯对流产生误差增长。

若时间项改成隐式 Euler，中心空间格式的放大因子变为

\[
G=\frac1{1+\mathrm{i}C\sin\theta},
\qquad |G|\le1.
\]

它在这个线性周期模型上满足模态稳定性，但中心插值仍可能在陡变附近产生新极值。稳定性控制误差随时间的放大，有界性控制变量是否超出合理范围，二者研究的性质不同。

<figure class="wolf-figure"><img src="/assets/wolf/wolf-advection-profile-errors.png" alt="一维输运中的格式误差曲线" loading="lazy"><figcaption><strong>一维输运中的格式误差曲线</strong><small class="figure-source">来源：Joel Guerrero / <a href="https://www.wolfdynamics.com/tutorials.html?id=181&amp;layout=edit">Wolf Dynamics</a> · module6.pdf，p. 157 · <a href="https://creativecommons.org/licenses/by-sa/4.0/">CC BY-SA 4.0</a>（裁剪）</small></figcaption></figure>

图中的锋面展宽、过冲和振荡可以分别联系到误差幅值与相位。移动速度不准确会造成相位误差，短波衰减较强会抹平锋面。

## 7. 数值扩散从哪里来

对显式 Euler 加迎风格式进行 Taylor 展开，并用原方程关系 $T_{tt}=u^2T_{xx}$ 消去时间二阶项，可得到主要修正项：

\[
T_t+uT_x
=\frac{u\Delta x}{2}(1-C)T_{xx}+\cdots.
\]

右侧形式与扩散相同，所以其主要数值扩散率为 $D_{num}=u\Delta x(1-C)/2$。它随网格变细而减小，也依赖时间离散和 Courant 数。

当 $C=1$ 时，更新式恰好将旧值向下游平移一个单元，这个特殊的一维常速模型可以准确搬移离散初值。对于实际非均匀网格和变速度流场，局部输运条件会随位置变化，需要按实际设置比较误差。

OpenFOAM 的 `Euler` 为隐式时间离散。上面的显式公式解释了推导方法，而具体 OpenFOAM 计算的修正项需要将其隐式时间形式一起代入展开。

## 8. 网格 Péclet 数与稳态中心离散

考虑一维稳态对流—扩散，定义面流量系数 $F=\rho uA$ 和扩散系数 $D=\Gamma A/\Delta x$。中心插值下，相邻系数可写为

\[
a_W=D+\frac F2,\qquad a_E=D-\frac F2.
\]

在写成 $a_PT_P=a_WT_W+a_ET_E$ 的形式时，邻居权重为非负有助于保持单调性。条件 $|F|/D\le2$ 对应网格 Péclet 数

\[
Pe_\Delta=\frac{\rho|u|\Delta x}{\Gamma}\le2.
\]

若 $F=1$、$D=0.2$，则 $Pe_\Delta=5$，下游系数为 −0.3，中心格式可能出现振荡。缩小 $\Delta x$ 会增大 $D$ 并降低网格 Péclet 数；换用迎风或限制格式则改变面值重建方式。

这里的 $Pe_\Delta$ 使用单元尺度。以整个几何长度定义的物理 Péclet 数描述对流和扩散的整体竞争，两者用途不同。

## 9. 对照 v2512 字典

在标量输运算例的 `system/fvSchemes` 中：

```foam
ddtSchemes
{
    default Euler;
}
divSchemes
{
    default none;
    div(phi,T) Gauss upwind;
}
```

`Euler` 选择隐式时间算子，`upwind` 选择迎风面值。将后者改成 `Gauss linear` 可比较中心插值；改成 `Gauss limitedLinear 1` 可观察限制重建。保持 `deltaT`、网格和初值相同，先比较空间格式；然后固定格式，分别细化网格与时间步。

`bounded Gauss ...` 中的 `bounded` 还涉及离散通量散度的修正，与单独的面值限制器作用不同。源码路径 `src/finiteVolume/finiteVolume/convectionSchemes` 可以帮助定位相应处理。

## 10. 隐式扩散的稳定性与时间精度

对于 $T_t=\alpha T_{xx}$，隐式 Euler 和中心空间差分给出

\[
\frac{T_i^{n+1}-T_i^n}{\Delta t}
=\alpha\frac{T_{i+1}^{n+1}-2T_i^{n+1}+T_{i-1}^{n+1}}{\Delta x^2}.
\]

令 $\mu=\alpha\Delta t/\Delta x^2$，整理为

\[
(1+2\mu)T_i^{n+1}-\mu T_{i-1}^{n+1}-\mu T_{i+1}^{n+1}=T_i^n.
\]

正的 $\mu$ 增大主对角系数。对周期 Fourier 模态，放大因子为

\[
G=\frac1{1+4\mu\sin^2(\theta/2)}.
\]

因此任意 $\mu\ge0$ 都有 $0<G\le1$。这个线性模型允许较大的时间步稳定求解，但热量的衰减速度仍随时间离散改变。实际准确模态在一步内按 $e^{-\alpha k^2\Delta t}$ 衰减，应比较二者的幅度才能评价时间精度。

若某个模态满足 $\alpha k^2\Delta t=1$，准确幅度比例为 $e^{-1}\approx0.3679$；只考虑时间误差的隐式 Euler 比例为 $1/(1+1)=0.5$。一次大步虽然平稳，衰减过程却偏慢。减小时间步或比较更高阶时间格式，能改善这类瞬态误差。

## 11. 怎样定义误差并设计细化序列

数值解与参考解之差可以按不同方式汇总：

\[
E_1=\frac{\sum_iV_i|e_i|}{\sum_iV_i},\qquad
E_2=\sqrt{\frac{\sum_iV_ie_i^2}{\sum_iV_i}},\qquad
E_\infty=\max_i|e_i|.
\]

$E_1$ 反映平均绝对偏差，$E_2$ 对较大误差赋予更高权重，$E_\infty$ 关注最差位置。壁面附近只有少数单元出现明显误差时，平均误差可能很小，最大误差仍较大。把误差位置与场图对应起来，可以判断是否需要局部加密。

研究空间二阶误差时，可让时间误差更小。例如固定足够小的时间步，比较 $h$、$h/2$、$h/4$；随后固定最细网格，比较时间步序列。对于理论推导使用的周期或无限域模型，实际算例的入口、出口和启动处理还可能形成额外误差，可在不同时间和远离边界的位置比较，观察误差来源。

非光滑初值附近，Taylor 展开要求的高阶导数可能不存在，整体误差阶会受到锋面和限制器影响。因此同一格式适合同时测试光滑脉冲与阶跃：前者观察正常精度阶，后者观察有界性和锋面处理。

## 12. 练习与答案要点

**练习一：时间步。** $u=2\,\mathrm{m/s}$，$\Delta x=0.01\,\mathrm m$，显式迎风希望 $C=0.5$，则 $\Delta t=0.0025\,\mathrm s$。单元间距减半后，保持同一 Courant 数也应将时间步减半。

**练习二：扩散稳定性。** 对 $T_t=\alpha T_{xx}$，显式 Euler 与二阶中心空间离散给出 $G=1-4\mu\sin^2(\theta/2)$，其中 $\mu=\alpha\Delta t/\Delta x^2$。由 $|G|\le1$ 得到一维条件 $0\le\mu\le1/2$。网格减半后，显式扩散允许的时间步约减为原来的四分之一。

**练习三：空间与时间误差。** 若误差约为 $a\Delta x^2+b\Delta t$，网格减半但时间步不变，空间部分降为四分之一，时间部分保持。随着空间误差变小，总误差会逐渐受时间部分控制。

**进阶：相位速度。** 写出 $G=|G|e^{-\mathrm{i}\omega_{num}\Delta t}$，由复数相角得到数值频率。将 $\omega_{num}/k$ 与物理速度比较，即可分析不同波长的传播误差。
