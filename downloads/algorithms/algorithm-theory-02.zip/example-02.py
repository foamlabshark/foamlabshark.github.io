import cmath
from math import pi

for c in (0.2, 0.5, 1.0, 1.2):
    g = 1.0 - c + c * cmath.exp(-1j * pi)
    print(f'C={c:.1f}, |G|={abs(g):.3f}')
