一致性、稳定性与收敛性

对应课程：https://foamlabshark.github.io/read/?slug=algorithm-theory-02

examples.md 保存讲解与示例。Python 文件分别对应课中的数值演示，运行方式：python3 文件名。
