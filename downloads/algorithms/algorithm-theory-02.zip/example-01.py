from math import exp

for dx in (0.2, 0.1):
    backward = (1.0 - exp(-dx)) / dx
    central = (exp(dx) - exp(-dx)) / (2.0 * dx)
    print(dx, abs(backward - 1.0), abs(central - 1.0))
