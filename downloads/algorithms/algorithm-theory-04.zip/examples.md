不可压缩流动的压力由速度场的守恒要求确定。离散后，这个关系形成压力泊松型方程：先计算预测通量，再用压力修正各面的流量，使每个单元满足连续性。

OpenFOAM 采用共点存储，压力和速度通常都放在单元中心。压力如何影响面通量，是压力—速度耦合中尤其重要的一步。

## 1. 连续性怎样变成压力方程

对静止网格上的不可压缩流动，单元连续性为

\[
\sum_f\phi_f=0,
\qquad\phi_f=\mathbf U_f\cdot\mathbf S_f.
\]

将已除以密度、并按单元体积归一化的离散动量方程写为

\[
a_P\mathbf U_P=\mathbf H_P-\nabla p_P.
\]

这里 $p$ 是运动压力，单位为 m²/s²；$a_P$ 的量纲为 1/s。定义 $d_P=1/a_P$ 和 $\widehat{\mathbf U}_P=\mathbf H_P/a_P$，于是

\[
\mathbf U_P=\widehat{\mathbf U}_P-d_P\nabla p_P.
\]

将其插入连续性，在连续记号下得到

\[
\nabla\cdot(d\nabla p)=\nabla\cdot\widehat{\mathbf U}.
\]

右侧是预测速度的不平衡，左侧表示压力梯度能够提供的修正。由于 $d$ 可能随单元、时间和外迭代变化，一般得到的是变系数泊松型方程。

## 2. 离散压力通量

在均匀正交网格中，面法向压力梯度可写为

\[
(\nabla p)_f\cdot\mathbf n_f\approx\frac{p_N-p_P}{\Delta n}.
\]

面体积通量于是具有形式

\[
\phi_f=\widehat\phi_f
-d_fA_f\frac{p_N-p_P}{\Delta n}.
\]

$\widehat\phi_f$ 是预测通量，$d_f$ 来自动量方程系数，$A_f$ 为面面积。这个式子直接使用相邻单元的压力差，因此相邻压力可以对公共面流量作出响应。

将每个面表达式代入 $\sum_f\phi_f=0$，就形成压力线性系统。求得压力后，再以相同离散压力通量更新 `phi`，这样压力方程与连续性使用同一套面收支。

## 3. 手算两个单元的压力修正

两个相邻单元的外边界全部不透流，公共面预测通量为 $\widehat\phi=2\times10^{-4}\,\mathrm{m^3/s}$，方向从单元 1 指向单元 2。第一个单元因此出现同等净流出，第二个单元出现同等净流入。

取 $d_f=0.01\,\mathrm s$、$A_f=0.01\,\mathrm{m^2}$、$\Delta n=0.1\,\mathrm m$，压力通量系数为

\[
K=\frac{d_fA_f}{\Delta n}=0.001\,\mathrm{m\,s}.
\]

连续性要求最终内部通量为零，所以

\[
0=\widehat\phi-K(p_2-p_1),
\qquad p_2-p_1=0.2\,\mathrm{m^2/s^2}.
\]

取 $p_1=0$，则 $p_2=0.2$。对应预测面法向速度为 0.02 m/s，压力梯度为 $2\,\mathrm{m/s^2}$，乘以 $d_f$ 后得到 0.02 m/s 的修正，恰好消除不平衡。若密度为 1000 kg/m³，物理压差为 200 Pa。

```python
predicted_flux = 2e-4
rAU, area, distance = 0.01, 0.01, 0.1
coefficient = rAU * area / distance
pressure_difference = predicted_flux / coefficient
corrected_flux = predicted_flux - coefficient * pressure_difference
print('运动压力差 [m2/s2]:', pressure_difference)
print('修正通量 [m3/s]:', corrected_flux)
```

这个小例子保留了压力校正的关键关系：压力差由通量不平衡与动量响应系数共同决定。实际多面体网格中，各单元通过许多公共面同时耦合，需要整体求解压力系统。

## 4. 共点网格为什么会产生棋盘压力

共点网格中，$p_i$ 和 $U_i$ 都在单元中心。如果先用中心差分计算单元压力梯度，再简单插值速度，可能出现奇偶单元之间的压力脱耦。

考虑一维交替压力

\[
p_i=(-1)^i.
\]

中心压力梯度为

\[
\left(\frac{dp}{dx}\right)_i
\approx\frac{p_{i+1}-p_{i-1}}{2\Delta x}=0,
\]

因为左右相邻压力恰好相同。尽管相邻单元之间压力强烈交替，单元中心梯度却“看见”零值，速度更新可能无法消除这种非物理模式。二维情况下对应相邻格子高低交替的棋盘分布。

直接面压力差 $(p_{i+1}-p_i)/\Delta x$ 则能识别这个模式：它在相邻面之间交替变号且幅度很大。因此面通量需要与直接相邻压力差保持联系。

## 5. 动量插值怎样连接面速度与压力

在一维正交、系数变化平缓的情形下，可用下式说明 Rhie–Chow 类动量插值的结构：

\[
u_f=\overline u_f-d_f\left[
\frac{p_N-p_P}{\Delta n}
-\overline{\left(\frac{dp}{dx}\right)}_f\right].
\]

上横线表示从单元中心插值到面的量。方括号比较“直接跨面压力梯度”和“单元梯度插值”。平滑线性压力下二者相同，修正消失；对于棋盘压力，单元中心梯度可能为零，直接跨面梯度仍然保留，面通量便会对交替压力作出反应。

这里的权重 $d_f$ 来自动量方程，因此修正与速度对压力的响应相联系。实际非正交网格、瞬态和松弛处理中还包含对应的一致性项，具体实现应结合求解器。关于共点插值及其对精度、收敛的影响，可参考 [动量插值研究](https://www.sciencedirect.com/science/article/pii/S0377042716301649)。

## 6. 在 icoFoam 中查看对应代码

v2512 的 `icoFoam.C` 先建立动量矩阵，在压力校正内部生成：

```cpp
volScalarField rAU(1.0/UEqn.A());
volVectorField HbyA(constrainHbyA(rAU*UEqn.H(), U, p));
surfaceScalarField phiHbyA
(
    "phiHbyA",
    fvc::flux(HbyA)
  + fvc::interpolate(rAU)*fvc::ddtCorr(U, phi)
);
```

`rAU` 是动量对角系数倒数，对应前面的 $d$；`HbyA` 对应不含当前压力梯度的预测速度部分，并包含边界一致性处理。`fvc::flux(HbyA)` 形成预测面通量，`ddtCorr` 补充时间离散中单元速度与面通量的对应修正。

接着求压力：

```cpp
fvScalarMatrix pEqn
(
    fvm::laplacian(rAU, p) == fvc::div(phiHbyA)
);
pEqn.setReference(pRefCell, pRefValue);
pEqn.solve(p.select(piso.finalInnerIter()));

if (piso.finalNonOrthogonalIter())
{
    phi = phiHbyA - pEqn.flux();
}
U = HbyA - rAU*fvc::grad(p);
U.correctBoundaryConditions();
```

`pEqn.flux()` 返回压力方程中与面相关的离散通量。最终非正交校正结束时，用它更新 `phi`。随后修正单元速度和速度边界。读这一段代码时，把 `phi` 与单元 `U` 分开跟踪，会更容易理解连续性为何在面上满足。

## 7. SIMPLE、PISO、PIMPLE 分别重复哪些步骤

SIMPLE 在稳态外迭代中反复组装动量、求解压力并更新模型，通常配合松弛。PISO 在每个时间步中组装动量，再执行多次压力—速度校正。PIMPLE 在一个时间步内增加外循环，使动量系数和模型也能重复更新。

<figure class="wolf-figure"><img src="/assets/wolf/wolf-pimple-pressure-coupling.png" alt="PIMPLE 外校正与 PISO 内校正" loading="lazy"><figcaption><strong>PIMPLE 外校正与 PISO 内校正</strong><small class="figure-source">来源：Joel Guerrero / <a href="https://www.wolfdynamics.com/tutorials.html?id=181&amp;layout=edit">Wolf Dynamics</a> · module6.pdf，p. 96 · <a href="https://creativecommons.org/licenses/by-sa/4.0/">CC BY-SA 4.0</a>（裁剪）</small></figcaption></figure>

| 循环 | 主要操作 | 对应控制 |
| --- | --- | --- |
| 时间推进 | 更新物理时刻与时间历史 | `controlDict/deltaT` 等 |
| PIMPLE 外校正 | 重新组装动量并更新耦合量 | `nOuterCorrectors` |
| 压力校正 | 调整压力、面通量与速度 | `nCorrectors` |
| 非正交校正 | 更新压力扩散的显式几何修正 | `nNonOrthogonalCorrectors` |

对 `pimpleFoam`，示例设置为：

```foam
PIMPLE
{
    momentumPredictor yes;
    nOuterCorrectors 3;
    nCorrectors 2;
    nNonOrthogonalCorrectors 1;
}
```

在没有提前停止或额外流程时，三轮外校正，每轮两次压力校正，每次压力校正进行一次基础求解和一次非正交修正，共有 12 次压力线性求解。增加这些次数会增加单步成本，应结合目标量变化选择。

## 8. 压力基准与边界条件

若整个区域的压力边界都给定法向梯度，压力加上任意常数仍给出相同梯度，方程因此存在常数零空间。封闭方腔通过 `pRefCell` 和 `pRefValue` 指定一个基准。

压力出口给出固定压力后，通常已确定相应压力基准。速度入口指定流入通量，压力边界则需要与该速度约束配合。`constrainPressure` 等程序步骤用于维持压力边界与面通量处理的一致性。

在多孔、浮力或旋转问题中，附加体积力也会影响压力平衡。若源项与压力梯度的离散方式不协调，静态平衡附近可能产生额外速度；这类问题需要查看源项如何进入动量预测和压力通量。

## 9. 监测局部与全局连续性

全域净通量可以由所有外边界通量相加获得，但内部两个相反误差可能在全域求和中抵消。因此同时观察局部连续性误差和全局收支，可以了解压力校正的不同方面。

在 `icoFoam` 日志中筛选：

```bash
grep -E 'Time =|Solving for p|continuity errors' log.icoFoam
```

按时间步比较压力求解次数和连续性变化。随后把 `nCorrectors` 从 1 改为 2，再比较相同时刻的速度剖面；把时间步减半是另一组比较，用于观察时间分辨率。

面通量满足守恒后，仍可继续检查速度和压力的空间精度。压力校正次数、线性求解容差和网格分辨率分别控制不同误差来源，适合分别调整并记录目标量。

## 10. 从预测压力到压力修正方程

SIMPLE 常通过修正变量解释。设当前预测场为 $\mathbf U^*,p^*$，最终场写成 $\mathbf U=\mathbf U^*+\mathbf U'$、$p=p^*+p'$。将两份动量方程相减，得到

\[
a_P\mathbf U'_P=\mathbf H'_P-\nabla p'_P.
\]

基本 SIMPLE 在构造修正关系时近似处理邻居修正，得到 $\mathbf U'\approx-d\nabla p'$。代入连续性：

\[
\nabla\cdot(d\nabla p')=\nabla\cdot\mathbf U^*.
\]

压力修正消除预测通量的不平衡，再通过外迭代逐步更新此前近似的邻接影响。松弛可减缓更新幅度，使相互耦合的场逐渐协调。consistent SIMPLE 等变体则改进相应系数处理。

这个推导使用 $p'$ 展示修正思想；`icoFoam` 的源码直接构造并求解对应的新压力 $p$，通过 `HbyA` 和 `phiHbyA` 包含已知项。阅读时先确定变量表示“总场”还是“修正场”，两种写法便能相互对应。

## 11. 局部连续性误差为何不会被全局值替代

双单元例子的预测内部通量对单元 1 为正、对单元 2 为负。全域相加恰好为零，但两个单元各自都没有满足守恒。使用绝对值后再汇总，就能保留这两个局部偏差。

对于静止不可压缩网格，可用下面的形式理解常见局部误差统计：

\[
\epsilon_{local}=\Delta t\frac{\sum_iV_i|\operatorname{div}(\phi)|_i}{\sum_iV_i},
\qquad
\epsilon_{global}=\Delta t\frac{\sum_iV_i(\operatorname{div}(\phi))_i}{\sum_iV_i}.
\]

这里的散度由离散面通量求得。局部量取绝对值，全局量保留符号，反映不同的收支信息。时间累计的全局误差还会体现各步带符号偏差的累积。

当压力线性容差收紧后，局部连续性误差通常也会变化；若速度目标量仍对校正次数敏感，则还需要检查耦合更新。将这些指标分开记录，比只保留一条总残差更容易定位误差来源。

## 12. 浮力问题中的压力变量

对使用物理压力的浮力流动，定义 $p_{rgh}=p-\rho\mathbf g\cdot\mathbf r$，可以从压力中分离静水部分。密度恒定时，静止液体满足 $\nabla p=\rho\mathbf g$，因此 $p_{rgh}$ 为常数。

密度随位置变化时，有

\[
-\nabla p+\rho\mathbf g
=-\nabla p_{rgh}-(\mathbf g\cdot\mathbf r)\nabla\rho.
\]

新的压力变量使较大的静水分布被单独处理，剩余密度梯度项仍参与动量平衡。两相密度跃变或温差引起的浮力问题中，密度、重力和压力的面插值因而密切相关。

实际算例还会定义重力势的参考高度。设置 `p_rgh` 边界或解释压力输出时，应结合重力方向、密度和参考位置还原物理压力。这个关系也把不可压缩方腔中的压力校正连接到了多相和传热求解器。

## 13. 练习与答案要点

**练习一：压力差。** 在双单元例子中，把预测通量加倍，其他系数保持，所需运动压差变为 0.4 m²/s²；把 $d_f$ 加倍，则原预测通量只需 0.1 m²/s² 的压差即可修正。

**练习二：线性压力。** 令 $p_i=ax_i+b$。直接面梯度和中心梯度插值都等于 $a$，上面的动量插值修正为零。它保留光滑线性压力梯度，同时对相邻交替压力敏感。

**练习三：循环成本。** 将外校正从 3 改为 2，其他例子参数保持，基础计数从 12 次压力线性求解变为 8 次。比较计算成本时还应看每次矩阵求解的迭代数。

**进阶：静水平衡。** 写出静止流体的 $\nabla p=\rho\mathbf g$。检查重力项与压力项在离散面通量中如何配合，并联系浮力求解器中 `p_rgh` 的定义和边界处理，可以进一步理解压力变量变换的用途。
