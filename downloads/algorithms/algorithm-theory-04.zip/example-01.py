predicted_flux = 2e-4
rAU, area, distance = 0.01, 0.01, 0.1
coefficient = rAU * area / distance
pressure_difference = predicted_flux / coefficient
corrected_flux = predicted_flux - coefficient * pressure_difference
print('运动压力差 [m2/s2]:', pressure_difference)
print('修正通量 [m3/s]:', corrected_flux)
