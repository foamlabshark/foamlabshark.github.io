A = [[3.0, -1.0, 0.0],
     [-1.0, 2.0, -1.0],
     [0.0, -1.0, 3.0]]
b = [2.0, 0.0, 0.0]


def residual(x):
    return max(abs(b[i] - sum(A[i][j] * x[j] for j in range(3)))
               for i in range(3))


def solve(method):
    x = [0.0, 0.0, 0.0]
    for iteration in range(1, 1001):
        previous = x.copy()
        for i in range(3):
            values = previous if method == 'Jacobi' else x
            neighbour = sum(A[i][j] * values[j] for j in range(3) if j != i)
            x[i] = (b[i] - neighbour) / A[i][i]
        if residual(x) < 1e-10:
            return iteration, x, residual(x)
    raise RuntimeError('达到迭代上限')


for method in ('Jacobi', 'Gauss-Seidel'):
    print(method, solve(method))
