有限体积离散后，每个单元提供一个代数方程。一个包含百万单元的温度计算，就会产生约百万个温度未知量。矩阵虽然很大，但每个单元只与附近少数单元相连，因此多数系数为零，这就是稀疏矩阵。

用三个单元的一维导热，可以完整写出矩阵、手算几次迭代，再理解 OpenFOAM 中的线性求解器和预条件器。

## 1. 三个单元的导热问题

长 $L$ 的均匀杆划分为三个等长单元，$\Delta x=L/3$。两端温度分别为 400 K 和 300 K，侧面绝热，没有热源。定义无量纲温度

\[
\theta=\frac{T-300}{100}.
\]

因此左边界 $\theta_L=1$，右边界 $\theta_R=0$。稳态解析解为 $\theta(x)=1-x/L$，三个单元中心位于 $L/6$、$L/2$、$5L/6$。

<figure class="wolf-figure"><img src="/assets/wolf/wolf-diffusion-orthogonal-comparison.png" alt="正交与非正交网格中的扩散通量" loading="lazy"><figcaption><strong>正交与非正交网格中的扩散通量</strong><small class="figure-source">来源：Joel Guerrero / <a href="https://www.wolfdynamics.com/tutorials.html?id=181&amp;layout=edit">Wolf Dynamics</a> · module6.pdf，p. 29 · <a href="https://creativecommons.org/licenses/by-sa/4.0/">CC BY-SA 4.0</a>（裁剪）</small></figcaption></figure>

均匀正交网格上，内部面导热系数为 $D=kA/\Delta x$。边界到最近单元中心只有半个间距，所以边界系数为 $2D$。

第一单元的流出热量与流入热量平衡：

\[
D(\theta_1-\theta_2)+2D(\theta_1-1)=0.
\]

除以 $D$，得到 $3\theta_1-\theta_2=2$。中间单元为 $-\theta_1+2\theta_2-\theta_3=0$；最后一个单元为 $-\theta_2+3\theta_3=0$。

## 2. 写成矩阵并求准确解

\[
\underbrace{\begin{bmatrix}
3&-1&0\\
-1&2&-1\\
0&-1&3
\end{bmatrix}}_A
\underbrace{\begin{bmatrix}\theta_1\\\theta_2\\\theta_3\end{bmatrix}}_{\mathbf x}
=
\underbrace{\begin{bmatrix}2\\0\\0\end{bmatrix}}_{\mathbf b}.
\]

最后一行给出 $\theta_2=3\theta_3$，代入中间行得到 $\theta_1=5\theta_3$，再代入第一行得到 $15\theta_3-3\theta_3=2$，即 $12\theta_3=2$。

因此准确解为

\[
\mathbf x=\begin{bmatrix}5/6\\1/2\\1/6\end{bmatrix},
\qquad
\mathbf T=\begin{bmatrix}383.333\ldots\\350\\316.666\ldots\end{bmatrix}\,\mathrm K.
\]

这与线性解析解在三个中心坐标的值一致。两端中心温度与边界不同，差别由半个单元距离上的热阻造成。

## 3. 稀疏结构对应网格连接

第一单元直接连接第二单元，所以矩阵第一行只在第 1、2 列有非零值；第三单元只直接连接第二单元，所以第三行只在第 2、3 列有非零值。

三维网格中，一个单元有多少邻居，就决定它基本离散方程中有多少非零邻接系数。一般不需要保存整个 $N\times N$ 矩阵，而只保存对角项、上下邻接系数和单元连接信息。OpenFOAM 的 `lduMatrix` 名称正来自 lower、diagonal、upper 三部分。

边界条件改变边界单元的系数和右侧。时间项给对角项增加储存系数，源项可贡献右侧或隐式系数。网格、格式和物理设置因此最终都影响到同一个线性系统。

## 4. Jacobi：每轮都用旧值

将三个方程分别解出对角变量：

\[
\theta_1^{k+1}=\frac{2+\theta_2^k}{3},\quad
\theta_2^{k+1}=\frac{\theta_1^k+\theta_3^k}{2},\quad
\theta_3^{k+1}=\frac{\theta_2^k}{3}.
\]

从 $(0,0,0)$ 开始，第一轮得到 $(2/3,0,0)$；第二轮为 $(2/3,1/3,0)$。每次都使用上一轮的全部值，所以第一轮输入的边界影响需要逐轮传向内部。

写成矩阵分裂 $A=D+L+U$，Jacobi 迭代为

\[
\mathbf x^{k+1}=D^{-1}[\mathbf b-(L+U)\mathbf x^k].
\]

其误差满足 $\mathbf e^{k+1}=B_J\mathbf e^k$，其中 $B_J=-D^{-1}(L+U)$。迭代矩阵谱半径小于 1 时，误差逐步衰减。这是线性迭代收敛分析的基本形式。

## 5. Gauss–Seidel：立即使用新值

Gauss–Seidel 顺次更新。计算第二个变量时，使用刚更新的第一个变量；计算第三个变量时，使用刚更新的第二个变量：

\[
\theta_1^{k+1}=\frac{2+\theta_2^k}{3},\quad
\theta_2^{k+1}=\frac{\theta_1^{k+1}+\theta_3^k}{2},\quad
\theta_3^{k+1}=\frac{\theta_2^{k+1}}{3}.
\]

从零开始，第一轮得到 $(2/3,1/3,1/9)$。边界信息在同一轮中继续向后传播，对本例收敛快于 Jacobi。更新顺序会影响每轮的传播方式，因此网格编号和并行分区也可能影响相应平滑过程。

下面的程序实现两种迭代，只使用 Python 标准功能：

```python
A = [[3.0, -1.0, 0.0],
     [-1.0, 2.0, -1.0],
     [0.0, -1.0, 3.0]]
b = [2.0, 0.0, 0.0]


def residual(x):
    return max(abs(b[i] - sum(A[i][j] * x[j] for j in range(3)))
               for i in range(3))


def solve(method):
    x = [0.0, 0.0, 0.0]
    for iteration in range(1, 1001):
        previous = x.copy()
        for i in range(3):
            values = previous if method == 'Jacobi' else x
            neighbour = sum(A[i][j] * values[j] for j in range(3) if j != i)
            x[i] = (b[i] - neighbour) / A[i][i]
        if residual(x) < 1e-10:
            return iteration, x, residual(x)
    raise RuntimeError('达到迭代上限')


for method in ('Jacobi', 'Gauss-Seidel'):
    print(method, solve(method))
```

`previous` 保存旧值；Jacobi 始终读取它，Gauss–Seidel 则读取正在更新的 `x`。`residual` 返回各行残差绝对值的最大值。两种方法都会接近 $(0.833333,0.5,0.166667)$，但所需迭代次数不同。

## 6. 残差与解误差之间的关系

若准确解为 $\mathbf x^*$，定义 $\mathbf e=\mathbf x^*-\mathbf x$，则

\[
\mathbf r=\mathbf b-A\mathbf x=A\mathbf e,
\qquad\mathbf e=A^{-1}\mathbf r.
\]

对于非零右侧，可用条件数描述相对误差的一个上界：

\[
\frac{\|\mathbf e\|}{\|\mathbf x^*\|}
\le\kappa(A)\frac{\|\mathbf r\|}{\|\mathbf b\|},
\qquad\kappa(A)=\|A\|\|A^{-1}\|.
\]

矩阵条件数较大时，小的右侧或舍入扰动可能造成更明显的解变化。网格尺度差别、材料系数跳变、近乎退化的单元和变量缩放都会影响系统性质。

OpenFOAM 日志采用其定义的归一化残差。解释 `1e-6` 时，应结合方程与目标量：它表示代数求解的某个停止尺度，温度或速度的最终误差还包含离散与建模影响。

## 7. 预条件器怎样帮助迭代

选一个容易求解、又近似 $A$ 的矩阵 $M$，例如采用左预条件形式：

\[
M^{-1}A\mathbf x=M^{-1}\mathbf b.
\]

准确解保持相同，迭代看到的矩阵性质却改变了。最简单的对角预条件将各行除以对角项，调整不同方程的尺度。DIC 和 DILU 使用不完全分解，在较小存储和计算成本下近似处理邻接耦合。

PCG 用于相应的对称正定系统，通常配合 DIC；非对称系统可以用 PBiCGStab 配合 DILU。对流项、边界和源项都可能改变矩阵结构，选择方法时以组装后的系统性质为依据。

GAMG 则利用多层次修正：平滑器先消除局部高频误差，粗层处理更大尺度的误差，再将修正传回细层。大型压力方程常能从中受益。粗化方式、网格长宽比和并行分区会影响效率。

## 8. 在 fvSolution 中设置

对本课正交稳态导热问题，`solvers` 中可写：

```foam
T
{
    solver PCG;
    preconditioner DIC;
    tolerance 1e-12;
    relTol 0;
}
```

`PCG` 求解对称系统，`DIC` 作为预条件器。较紧的绝对容差便于与三单元解析解比较；`relTol 0` 关闭相对初始残差的提前停止条件。

对含对流的标量输运，将算法部分改为：

```foam
solver PBiCGStab;
preconditioner DILU;
```

两段配置放在同一场的求解器子字典内，按方程选择其中一种组合。`tolerance` 与 `relTol` 仍控制线性求解精度。算例规模较大时，可以逐步收紧容差，观察温度、压差或力是否还有明显变化，再决定计算成本是否值得。

## 9. 从代码到矩阵系数

`fvm::laplacian(DT,T)` 根据网格面连接和法向梯度，产生扩散矩阵；`fvm::ddt(T)` 产生时间储存的对角贡献；`fvm::div(phi,T)` 按所选面值重建形成对流系数。

当梯度修正、湍流黏度或物性依赖当前解时，矩阵会随外迭代变化。一次线性求解完成的是当前系数下的系统；随后外迭代更新系数，继续处理非线性耦合。因此线性迭代数和 SIMPLE/PIMPLE 外循环数分别控制不同阶段。

## 10. 对称正定性质从哪里来

对于本课矩阵，任意实向量 $\mathbf y=(y_1,y_2,y_3)^T$ 都满足

\[
\mathbf y^TA\mathbf y
=(y_1-y_2)^2+(y_2-y_3)^2+2y_1^2+2y_3^2.
\]

内部两项来自相邻单元之间的扩散连接，最后两项来自固定温度边界。非零向量必然使右侧为正，所以矩阵对称正定，符合 PCG 的适用条件。

若两端变为绝热边界，相应边界项消失。此时所有分量相同的向量都使右侧为零，矩阵存在常数零空间，正好对应“整个温度场加一个常数仍满足稳态无源方程”的物理性质。

这个例子说明，求解器选择由方程、网格和边界共同决定。压力泊松系统也常具有类似的基准问题；通过正确设置压力参考，可去除相应不确定性。

## 11. 源项线性化怎样影响对角系数

设温度受到线性冷却 $S=\beta(T_\infty-T)$，其中 $\beta>0$，量纲与所采用温度方程一致。将 $-\beta T$ 隐式放在左侧，主对角增加 $\beta V$，右侧增加 $\beta VT_\infty$。

以单个无空间输运的控制体积为例，采用单位体积温度方程：

\[
\left(\frac1{\Delta t}+\beta\right)T^{n+1}
=\frac{T^n}{\Delta t}+\beta T_\infty.
\]

取 $T^n=400\,\mathrm K$、$T_\infty=300\,\mathrm K$、$\beta=2\,\mathrm{s^{-1}}$、$\Delta t=1\,\mathrm s$，隐式更新得到 333.333 K。若完全用旧温度计算源项，显式一步得到 200 K，越过平衡温度，显示出步长与源项尺度的相互作用。

把部分源项隐式化可以改善刚性反应或换热的迭代性质。源项线性化系数的符号直接影响主对角，因此编写 `fvOptions` 或自定义方程时，应从物理公式展开符号，再检查最终矩阵贡献。

## 12. 计算规模增长时看哪些成本

每轮稀疏矩阵乘法的代价主要与非零系数个数成正比。局部有限体积网格中，它通常随单元数近似线性增长；总时间还需要乘以迭代次数，并考虑并行通信和预条件开销。

两种算法即使都需要 20 次迭代，每轮所做工作也可能不同。比较时固定收敛要求，同时记录总时间、内存和目标量。并行情况下增加进程数会减少每进程的单元数，也会增加界面通信，所以存在与问题规模有关的合适并行度。

本例程序的真实输出是 Jacobi 42 轮、Gauss–Seidel 21 轮达到指定最大残差 $10^{-10}$。这一结果说明更新方式的影响；大型非结构网格上的排序、分区和矩阵性质会进一步改变相对性能。

## 13. 练习与答案要点

**练习一：温度恢复。** 将无量纲解还原为 K，并计算左边界到第一中心的热流。答案为 $T_1=383.333\ldots\,\mathrm K$，热流密度 $q''=k(400-T_1)/(L/6)=100k/L$，与全杆线性解一致。

**练习二：热源进入哪里。** 若每个单元增加相同热源，离散右侧增加对应总源项；温度将高于无源直线。若源项与温度成线性关系，隐式处理还会改变主对角系数。

**练习三：两端都绝热。** 对稳态无源导热，所有常温场都满足方程，温度绝对值缺少基准，矩阵存在常数零空间。给定一个温度基准或合适的总能量信息，才能确定唯一状态。

**进阶：细化与迭代成本。** 将三单元扩展为 30 和 300 单元，比较 Jacobi、Gauss–Seidel 和多重网格的迭代增长。局部平滑方法对跨越整个区域的缓慢变化误差通常较慢，这正是粗层修正有用的原因。
