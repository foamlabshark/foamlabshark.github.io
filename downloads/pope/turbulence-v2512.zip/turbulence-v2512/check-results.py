"""Run after Allrun; reject a successful solver exit with unreasonable fields."""
import csv,json,math,sys
from pathlib import Path

case=Path(sys.argv[1]).resolve()
spec=next(x for x in json.loads((Path(__file__).parent/'case-manifest.json').read_text()) if x['name']==case.name)
with (case/'metrics.csv').open() as f:rows=[{k:float(v) for k,v in r.items()} for r in csv.DictReader(f)]
assert rows and rows[-1]['time']==spec['end'],'Configured endpoint was not reached'
assert 'Mesh OK.' in (case/'log.checkMesh').read_text(),'Mesh validation failed'
assert all(math.isfinite(v) for row in rows for v in row.values()),'Nonfinite metric'
r=rows[-1]
if spec['mode']=='vortex':
    assert r['relativeL2']<.006,'Vortex velocity error is too large'
    assert abs(r['kineticEnergy']/r['referenceEnergy']-1)<.006,'Vortex energy error is too large'
elif spec['mode']=='channel':
    assert r['relativeL2']<.0015,'Channel profile error is too large'
    assert abs(r['kineticEnergy']/rows[-2]['kineticEnergy']-1)<1e-8,'Channel iteration is incomplete'
elif spec['mode']=='decay':
    assert abs(r['meanK']/r['referenceK']-1)<.001,'k error is too large'
    assert abs(r['meanEpsilon']/r['referenceEpsilon']-1)<.009,'epsilon error is too large'
else:
    assert r['scalarL2']<.00021,'Scalar error is too large'
    assert abs(r['meanT']-1)<1e-9,'Scalar mean is not conserved'
print(json.dumps({'case':case.name,'endpoint':r['time'],'checks':'passed'}))
