#include "fvCFD.H"
#include "timeSelector.H"
#include <fstream>
#include <iomanip>

int main(int argc, char *argv[])
{
    Foam::argList::addBoolOption("initialise", "Set analytical initial fields");
    Foam::timeSelector::addOptions();
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    Foam::IOdictionary config
    (
        Foam::IOobject("theoryCheckDict", runTime.system(), mesh,
            Foam::IOobject::MUST_READ, Foam::IOobject::NO_WRITE)
    );
    const Foam::word mode(config.get<Foam::word>("mode"));
    const Foam::scalar nu(config.get<Foam::scalar>("nu"));
    if (args.found("initialise"))
    {
        Foam::volVectorField U
        (
            Foam::IOobject("U", runTime.timeName(), mesh,
                Foam::IOobject::MUST_READ, Foam::IOobject::AUTO_WRITE), mesh
        );
        Foam::volScalarField p
        (
            Foam::IOobject("p", runTime.timeName(), mesh,
                Foam::IOobject::MUST_READ, Foam::IOobject::AUTO_WRITE), mesh
        );
        if (mode == "vortex")
        {
            forAll(U, i)
            {
                const auto& x = mesh.C()[i];
                U[i] = Foam::vector(std::sin(x.x())*std::cos(x.y()),-std::cos(x.x())*std::sin(x.y()),0);
                p[i] = 0.25*(std::cos(2*x.x())+std::cos(2*x.y()));
            }
        }
        U.correctBoundaryConditions(); p.correctBoundaryConditions();
        U.write(); p.write();
        if (mode == "scalar")
        {
            Foam::volScalarField T
            (
                Foam::IOobject("T",runTime.timeName(),mesh,
                    Foam::IOobject::MUST_READ,Foam::IOobject::AUTO_WRITE),mesh
            );
            forAll(T,i) T[i] = 1+std::sin(mesh.C()[i].x());
            T.correctBoundaryConditions(); T.write();
        }
        return 0;
    }
    const auto times = Foam::timeSelector::select0(runTime,args);
    std::ofstream summary((runTime.path()/"metrics.csv").c_str());
    summary << std::setprecision(14)
        << "time,relativeL2,kineticEnergy,referenceEnergy,meanK,referenceK,meanEpsilon,referenceEpsilon,meanT,scalarL2\n";
    forAll(times, ti)
    {
        runTime.setTime(times[ti],ti);
        Foam::volVectorField U
        (
            Foam::IOobject("U",runTime.timeName(),mesh,
                Foam::IOobject::MUST_READ,Foam::IOobject::NO_WRITE),mesh
        );
        const double t=runTime.value(), a=std::exp(-2*nu*t);
        double err=0, ref2=0, energy=0, volume=0;
        std::ofstream profile((runTime.path()/("profile-"+runTime.timeName()+".csv")).c_str());
        profile << std::setprecision(14) << "x,y,Ux,Uy,referenceUx,referenceUy\n";
        forAll(U,i)
        {
            const auto& x=mesh.C()[i]; const double v=mesh.V()[i];
            Foam::vector ref(Foam::Zero);
            if(mode=="vortex") ref=Foam::vector(a*std::sin(x.x())*std::cos(x.y()),-a*std::cos(x.x())*std::sin(x.y()),0);
            if(mode=="channel") ref=Foam::vector(1.5*x.y()*(2-x.y()),0,0);
            err+=v*Foam::magSqr(U[i]-ref); ref2+=v*Foam::magSqr(ref);
            energy+=0.5*v*Foam::magSqr(U[i]); volume+=v;
            profile<<x.x()<<','<<x.y()<<','<<U[i].x()<<','<<U[i].y()<<','<<ref.x()<<','<<ref.y()<<'\n';
        }
        double km=0,em=0,tm=0,te=0;
        if(mode=="decay")
        {
            Foam::volScalarField k(Foam::IOobject("k",runTime.timeName(),mesh,Foam::IOobject::MUST_READ,Foam::IOobject::NO_WRITE),mesh);
            Foam::volScalarField e(Foam::IOobject("epsilon",runTime.timeName(),mesh,Foam::IOobject::MUST_READ,Foam::IOobject::NO_WRITE),mesh);
            forAll(k,i){km+=mesh.V()[i]*k[i];em+=mesh.V()[i]*e[i];}
        }
        if(mode=="scalar")
        {
            Foam::volScalarField T(Foam::IOobject("T",runTime.timeName(),mesh,Foam::IOobject::MUST_READ,Foam::IOobject::NO_WRITE),mesh);
            std::ofstream s((runTime.path()/("scalar-"+runTime.timeName()+".csv")).c_str());
            s<<std::setprecision(14)<<"x,T,reference\n";
            forAll(T,i)
            {
                const double ref=1+std::exp(-nu*t)*std::sin(mesh.C()[i].x());
                tm+=mesh.V()[i]*T[i];te+=mesh.V()[i]*Foam::sqr(T[i]-ref);
                s<<mesh.C()[i].x()<<','<<T[i]<<','<<ref<<'\n';
            }
        }
        summary<<t<<','<<(ref2>0?std::sqrt(err/ref2):0)<<','<<energy/volume<<','
            <<(mode=="vortex"?.25*a*a:0)<<','<<km/volume<<','
            <<std::pow(1+.92*t,-1/.92)<<','<<em/volume<<','
            <<std::pow(1+.92*t,-1.92/.92)<<','<<tm/volume<<','<<std::sqrt(te/volume)<<'\n';
    }
    return 0;
}
