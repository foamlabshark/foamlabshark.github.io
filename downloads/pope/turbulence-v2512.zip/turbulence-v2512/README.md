# 湍流理论：OpenCFD OpenFOAM v2512 验证包

本包包含四类验证、八组完整输入，以及 2026-10-14 在 Linux 虚拟机中取得的运行记录和对照数据。`applications/theoryCheck` 是本课程的原生 OpenFOAM C++ 程序，用于设置解析初场并读取数值场计算误差；流动和标量方程分别由 OpenFOAM 自带求解器求解。

## 环境与运行

需要 OpenCFD OpenFOAM v2512、其编译环境和 Python 3。Python 检查只使用标准库。先载入本机安装的 v2512 环境，确认 `foamEtcFile -show-api` 输出 `2512`，然后在解压目录运行：

```bash
sh Allwmake
cd cases/taylor-green-32
sh Allrun
```

`Allwmake` 编译 `theoryCheck`。`Allrun` 依次生成并检查网格、设置初始场、完整求解、与解析关系比较，最后执行误差检查。完成后打开 `case.foam` 查看场。`metrics.csv` 保存每个输出时刻的误差；`profile-*.csv` 保存速度剖面，标量算例另有 `scalar-*.csv`。

每组算例均可从自己的目录运行 `sh Allrun`。重算时使用一份新解压的输入；脚本会拒绝覆盖已有求解日志。网格与时间设置保存在 `system/blockMeshDict` 和 `system/controlDict` 中，初始场位于 `0`，物性和模型位于 `constant`。

## 算例与验证对象

| 目录 | 求解器 | 设置与终点 | 验证对象 |
| --- | --- | --- | --- |
| `taylor-green-32`、`taylor-green-64` | `icoFoam` | 32²、64²；Δt = 0.002 s；t = 1 s | 二维周期涡旋的速度与能量衰减 |
| `channel-32`、`channel-64` | `simpleFoam` | 壁法向 32、64 层；10000 轮 | 层流通道的黏性应力与恒定体力平衡 |
| `ke-decay-0p01`、`ke-decay-0p005` | `pimpleFoam` | 空间均匀；Δt = 0.01、0.005 s；t = 2 s | 标准 k–ε 模型在无生产条件下的常微分方程极限 |
| `scalar-diffusion-32`、`scalar-diffusion-64` | `scalarTransportFoam` | 32、64 个流向单元；Δt = 0.001 s；t = 1 s | 周期正弦标量的扩散与总体积分守恒 |

二维涡旋与层流通道是控制方程验证，不能据此评价湍流闭合模型的预测精度。均匀 k–ε 衰减比较的是同一模型的解析常微分方程解，未把它当作真实格栅湍流试验的替代。

## 结果文件

`verification/report.json` 记录终点、运行时间、误差与加密比；各子目录保存原始求解日志、网格检查、时间序列和剖面。`verification/sha256.json` 记录配套输入、程序和结果文件的校验值。

`metrics.csv` 使用共用列结构。涡旋和通道使用 `relativeL2`、`kineticEnergy`；涡旋另用 `referenceEnergy`；k–ε 衰减使用 `meanK`、`referenceK`、`meanEpsilon`、`referenceEpsilon`；标量扩散使用 `meanT`、`scalarL2`。其余列不属于该算例的物理指标。

`simpleFoam` 的时间目录对应稳态迭代次数。通道的压力修正和横向速度接近零时，归一化初始残差可能仍有波动，应同时查看横向速度绝对值、流向速度误差和最后两次输出间的变化。本包的验收脚本会检查这些算例的主要误差与终点。
