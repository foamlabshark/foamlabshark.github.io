# 03-refinement / OpenFOAM v2512

来源：OpenFOAM v2512 官方教程 `tutorials/multiphase/interFoam/laminar/damBreakWithObstacle`。
本站修改：短程教学运行、ASCII 输出与结果导出；02-overset 将旋转区域移入背景域中央、同步调整挖孔与搜索范围，移除域外速度阻尼；03-refinement 使用 16×16×16 背景网格和一级加密。
原始文件版权声明保留，许可证见 COPYING。

将算例解压到 Linux 工作目录，加载 v2512 环境，在算例目录运行 `bash Allrun`。
脚本依次生成网格、设置场、计算、检查网格并导出 VTK。
日志保存在 log.* 文件；用 ParaView 打开 case.foam 或 VTK 文件夹。
再次计算时使用一份新解压的算例目录。

求解器：interFoam；结束时间/迭代步：0.3。
课程：https://foamlabshark.github.io/read/?slug=advanced-mesh-03
