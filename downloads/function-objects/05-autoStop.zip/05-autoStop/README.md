# 05-autoStop

运行 bash Allrun。runTimeControl 在模拟时间经过 0.2 s 后正常结束计算。对应教程：自动控制。
