# 03-hotRoom / OpenFOAM v2512

来源：v2512 官方教程 `tutorials/heatTransfer/buoyantPimpleFoam/hotRoom`；原始许可证见 COPYING。
本站增加 system/functions 中的后处理配置，使用短程运行和 ASCII 输出。
加载环境后在此目录运行 `bash Allrun`。使用新解压的目录开始一次计算。
运行后用 ParaView 打开 case.foam，探针、积分和导出文件在 postProcessing 中。
求解器：buoyantPimpleFoam；终止时间/迭代步：0.2。
