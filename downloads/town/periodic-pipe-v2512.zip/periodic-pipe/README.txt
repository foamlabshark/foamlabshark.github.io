周期圆管的充分发展湍流
OpenFOAM v2512
来源：incompressible/simpleFoam/pipeCyclic

用一段首尾周期连接的圆管计算充分发展湍流，观察管心与近壁区的速度差。
周期边界连接管段两端；驱动力通过 meanVelocityForce 维持平均速度。topoSet 与 refineHexMesh 对指定单元加密，检查壁面附近的网格分布。
稳态迭代上限 1000；本次保存至迭代 238。写出控制 timeStep，间隔 100。

包内已经包含生成的网格、区域与初始化后的场。加载 v2512 环境，在此目录运行 bash Allrun。
结果图与日志来自同一份输入。这里只是教学运行，不能把有限的运行时长当作网格无关或统计收敛证明。
