溃坝 · 早期坍塌
OpenFOAM v2512
观察前 0.15 s 的水柱倾倒阶段，与 0.5 s 的撞壁结果对比。
endTime = 0.15 s；writeInterval = 0.015 s；初始水柱与基准相同。
加载环境后，在此目录运行 bash Allrun。
