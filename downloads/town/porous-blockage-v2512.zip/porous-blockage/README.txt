通道中的多孔阻力区
OpenFOAM v2512
来源：incompressible/pisoFoam/laminar/porousBlockage

通道中的局部多孔区域阻碍流体通过，流体从阻力区和周围通道分流。
topoSet 选出多孔区域，constant/fvOptions 将阻力加入动量方程。0/U 设置入口流速，pisoFoam 推进瞬态速度和压力。
从 0 s 开始，计算至 20 s；初始时间步 0.05 s。写出控制 runTime，间隔 2。

包内已经包含生成的网格、区域与初始化后的场。加载 v2512 环境，在此目录运行 bash Allrun。
结果图与日志来自同一份输入。这里只是教学运行，不能把有限的运行时长当作网格无关或统计收敛证明。
