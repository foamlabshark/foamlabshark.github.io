润湿壁面附近的毛细上升
OpenFOAM v2512
来源：multiphase/interFoam/laminar/capillaryRise

液体润湿细管壁，表面张力与重力共同决定液面上升和弯月面形状。
setFields 先初始化液体区域；接触角边界控制壁面润湿，transportProperties 给出表面张力。小时间步用于解析毛细运动。
从 0 s 开始，计算至 0.05 s；初始时间步 1e-05 s。开启自适应时间步。写出控制 adjustable，间隔 0.005。

包内已经包含生成的网格、区域与初始化后的场。加载 v2512 环境，在此目录运行 bash Allrun。
结果图与日志来自同一份输入。这里只是教学运行，不能把有限的运行时长当作网格无关或统计收敛证明。
