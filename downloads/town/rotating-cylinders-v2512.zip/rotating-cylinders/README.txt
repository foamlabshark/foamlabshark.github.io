同轴圆筒旋转剪切流
OpenFOAM v2512
来源：incompressible/simpleFoam/rotatingCylinders

同轴圆筒壁面带动中间流体旋转，黏性剪切使周向速度随半径变化。
0/U 中的旋转壁面条件指定角速度；blockMesh 建立环形区域。simpleFoam 采用层流设置求解稳态流场。
稳态迭代上限 1000；本次保存至迭代 1000。写出控制 timeStep，间隔 10。

包内已经包含生成的网格、区域与初始化后的场。加载 v2512 环境，在此目录运行 bash Allrun。
结果图与日志来自同一份输入。这里只是教学运行，不能把有限的运行时长当作网格无关或统计收敛证明。
