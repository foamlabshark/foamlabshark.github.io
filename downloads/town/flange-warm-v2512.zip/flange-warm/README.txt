法兰导热 · 降低热壁温度
OpenFOAM v2512
将热壁由 573 K 降为 423 K，比较温差变化带来的温度场差异。
patch4 = 423 K；patch2 = 273 K；DT = 4e-5 m²/s；计算至 3 s。
加载环境后，在此目录运行 bash Allrun。
