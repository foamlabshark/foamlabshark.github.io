带电细线周围的电势分布
OpenFOAM v2512
来源：electromagnetics/electrostaticFoam/chargedWire

带电细线在周围区域产生电势分布，电荷随电场变化。
electrostaticFoam 读取电荷密度 rho 和电势 phi，求解电势与电荷输运。这里的 phi 是电势场，与流动算例中常见的面通量 phi 含义不同。
从 0 s 开始，计算至 0.02 s；初始时间步 5e-05 s。写出控制 timeStep，间隔 100。

包内已经包含生成的网格、区域与初始化后的场。加载 v2512 环境，在此目录运行 bash Allrun。
结果图与日志来自同一份输入。这里只是教学运行，不能把有限的运行时长当作网格无关或统计收敛证明。
