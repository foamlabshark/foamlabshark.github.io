方形截面弯管的二次流
OpenFOAM v2512
来源：incompressible/simpleFoam/squareBend

湍流经过方形截面弯管时，转弯引起横向压力差和速度重新分布。查看弯前、弯中和弯后的速度变化。
blockMesh 生成弯管，topoSet 按 angledPlane 几何建立采样面集合；simpleFoam 求解稳态速度与压力，k–ε 模型提供湍流黏度。
稳态迭代上限 500；本次保存至迭代 500。写出控制 timeStep，间隔 50。

包内已经包含生成的网格、区域与初始化后的场。加载 v2512 环境，在此目录运行 bash Allrun。
结果图与日志来自同一份输入。这里只是教学运行，不能把有限的运行时长当作网格无关或统计收敛证明。
