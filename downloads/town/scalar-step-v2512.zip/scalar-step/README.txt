标量输运 · 延迟阶跃入口
OpenFOAM v2512
入口信号在 0.1 s 开启，观察阶跃信号进入流场后的传播。
uniformValue 使用官方 table 条目；endTime = 0.2 s。
加载环境后，在此目录运行 bash Allrun。
