后台阶 · realizable k–ε
OpenFOAM v2512
采用 realizableKE 模型，观察模型变化对回流区的影响。
RASModel = realizableKE；沿用官方 k、epsilon 边界；迭代上限 1000。
加载环境后，在此目录运行 bash Allrun。
