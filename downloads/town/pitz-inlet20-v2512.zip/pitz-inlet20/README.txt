后台阶 · 20 m/s 入口
OpenFOAM v2512
把入口平均速度加倍，并保持入口湍流强度与长度尺度一致。
U = 20 m/s；k = 1.5 m²/s²；epsilon = 118.12 m²/s³；kEpsilon。
加载环境后，在此目录运行 bash Allrun。
