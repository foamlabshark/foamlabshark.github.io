后台阶湍流 · pitzDaily
OpenFOAM v2512
入口高速气流经过后台阶后发生分离，用稳态 RANS 模型计算回流区。
采用官方 k–ε 设置；SIMPLE 迭代上限 1000，满足 residualControl 时提前结束。
加载环境后，在此目录运行 bash Allrun。
