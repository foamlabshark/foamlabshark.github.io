法兰导热 · 初期热扩散
OpenFOAM v2512
只观察前 0.3 s，比较早期热边界层与 3 s 温度分布。
endTime = 0.3 s；writeInterval = 0.01 s；DT = 4e-5 m²/s。
加载环境后，在此目录运行 bash Allrun。
