后台阶 · k–ω
OpenFOAM v2512
采用 kOmega 模型，对比相同网格上的平均速度分布。
RASModel = kOmega；其他边界与控制参数保持后台阶基准设置。
加载环境后，在此目录运行 bash Allrun。
