水柱溃坝 · damBreak
OpenFOAM v2512
用 setFields 设置初始水柱，计算重力作用下水体坍塌、铺展和撞击障碍的过程。
setFields 初始化 alpha.water；自适应时间步，maxCo = maxAlphaCo = 1；计算至 0.5 s，每 0.05 s 保存一次。
加载环境后，在此目录运行 bash Allrun。
