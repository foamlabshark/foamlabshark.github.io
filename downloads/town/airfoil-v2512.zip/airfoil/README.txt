翼型外流与压力分布
OpenFOAM v2512
来源：incompressible/simpleFoam/airFoil2D

气流绕过翼型，表面两侧形成不同的压力分布。先查看压力场，再把近壁速度与外部来流联系起来。
采用教程配套翼型网格，renumberMesh 整理面与单元编号。Spalart–Allmaras 模型求解 nuTilda；p 为运动学压力，单位 m²/s²。
稳态迭代上限 500；本次保存至迭代 312。写出控制 timeStep，间隔 50。

包内已经包含生成的网格、区域与初始化后的场。加载 v2512 环境，在此目录运行 bash Allrun。
结果图与日志来自同一份输入。这里只是教学运行，不能把有限的运行时长当作网格无关或统计收敛证明。
