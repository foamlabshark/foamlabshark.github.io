黏弹性流体通过收缩通道
OpenFOAM v2512
来源：incompressible/pimpleFoam/laminar/planarContraction

黏弹性流体从宽通道进入窄通道，在收缩入口发生加速和应力集中。
0/sigma 保存聚合物应力，constant/transportProperties 选择黏弹性模型及材料系数。pimpleFoam 同时推进速度、压力和应力。
从 0 s 开始，计算至 0.25 s；初始时间步 0.0002 s。写出控制 runTime，间隔 0.01。

包内已经包含生成的网格、区域与初始化后的场。加载 v2512 环境，在此目录运行 bash Allrun。
结果图与日志来自同一份输入。这里只是教学运行，不能把有限的运行时长当作网格无关或统计收敛证明。
