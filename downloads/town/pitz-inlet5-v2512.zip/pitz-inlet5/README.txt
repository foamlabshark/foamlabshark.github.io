后台阶 · 5 m/s 入口
OpenFOAM v2512
把入口平均速度减半，并按相同湍流强度与长度尺度调整 k 和 epsilon。
U = 5 m/s；k = 0.09375 m²/s²；epsilon = 1.845625 m²/s³；kEpsilon。
加载环境后，在此目录运行 bash Allrun。
