运动锥体驱动的变形网格流动
OpenFOAM v2512
来源：incompressible/pimpleFoam/laminar/movingCone

锥体沿轴向运动，网格随边界伸缩，周围流体产生瞬态速度与压力变化。
constant/dynamicMeshDict 选择网格运动方法，0/pointMotionUx 给出轴向位移条件。先检查初始网格，再查看运动后的流场与变形网格。
从 0 s 开始，计算至 0.003 s；初始时间步 5e-06 s。写出控制 timeStep，间隔 40。

包内已经包含生成的网格、区域与初始化后的场。加载 v2512 环境，在此目录运行 bash Allrun。
结果图与日志来自同一份输入。这里只是教学运行，不能把有限的运行时长当作网格无关或统计收敛证明。
