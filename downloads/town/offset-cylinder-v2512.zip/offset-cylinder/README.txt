偏心圆柱周围的非牛顿流动
OpenFOAM v2512
来源：incompressible/nonNewtonianIcoFoam/offsetCylinder

偏心圆柱将通道分成宽窄不同的间隙，剪切速率随位置变化，非牛顿黏度也随之改变。
nonNewtonianIcoFoam 根据 transportProperties 中的黏度模型计算局部黏度。比较狭窄间隙中的流速与开阔区域中的流速。
从 0 s 开始，计算至 2 s；初始时间步 0.0025 s。写出控制 runTime，间隔 0.05。

包内已经包含生成的网格、区域与初始化后的场。加载 v2512 环境，在此目录运行 bash Allrun。
结果图与日志来自同一份输入。这里只是教学运行，不能把有限的运行时长当作网格无关或统计收敛证明。
