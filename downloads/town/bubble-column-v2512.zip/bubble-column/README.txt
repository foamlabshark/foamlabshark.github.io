鼓泡塔中的气液两相上升流
OpenFOAM v2512
来源：multiphase/twoPhaseEulerFoam/laminar/bubbleColumn

空气从水柱底部注入，气相向上运动，并通过相间作用力带动液体。
twoPhaseEulerFoam 为气相和液相分别求解速度，alpha.air 表示气相体积分数。constant/phaseProperties 给出相间阻力等模型，入口气量控制鼓泡强度。
从 0 s 开始，计算至 2 s；初始时间步 0.005 s。写出控制 runTime，间隔 0.2。

包内已经包含生成的网格、区域与初始化后的场。加载 v2512 环境，在此目录运行 bash Allrun。
结果图与日志来自同一份输入。这里只是教学运行，不能把有限的运行时长当作网格无关或统计收敛证明。
