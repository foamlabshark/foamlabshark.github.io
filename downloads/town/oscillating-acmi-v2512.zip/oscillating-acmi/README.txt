摆动入口与部分重叠网格接口
OpenFOAM v2512
来源：incompressible/pimpleFoam/RAS/oscillatingInletACMI2D

入口区域周期摆动，与固定区域通过部分重叠接口交换流量。
cyclicACMI 将接口划分为重叠传输区与未重叠区；dynamicMeshDict 给出振荡运动。对照 U 和接口位置，理解运动区域与静止区域之间的连接。
从 0 s 开始，计算至 1 s；初始时间步 0.005 s。开启自适应时间步。写出控制 adjustable，间隔 0.1。

包内已经包含生成的网格、区域与初始化后的场。加载 v2512 环境，在此目录运行 bash Allrun。
结果图与日志来自同一份输入。这里只是教学运行，不能把有限的运行时长当作网格无关或统计收敛证明。
