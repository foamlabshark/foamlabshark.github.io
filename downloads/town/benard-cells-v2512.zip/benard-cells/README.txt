上下温差驱动的 Bénard 对流胞
OpenFOAM v2512
来源：heatTransfer/buoyantBoussinesqPimpleFoam/BenardCells

流体下部受热、上部冷却，温差驱动一组上升和下降交替的对流胞。
冷热壁面提供温度差，重力与热膨胀系数决定浮力强度。buoyantBoussinesqPimpleFoam 推进瞬态流动，对照温度条带与速度方向识别对流结构。
从 0 s 开始，计算至 1000 s；初始时间步 1 s。写出控制 runTime，间隔 50。

包内已经包含生成的网格、区域与初始化后的场。加载 v2512 环境，在此目录运行 bash Allrun。
结果图与日志来自同一份输入。这里只是教学运行，不能把有限的运行时长当作网格无关或统计收敛证明。
