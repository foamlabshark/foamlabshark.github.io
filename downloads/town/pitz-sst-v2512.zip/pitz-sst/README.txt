后台阶 · k–ω SST
OpenFOAM v2512
将湍流模型换为 kOmegaSST，比较近壁区和分离回流区。
RASModel = kOmegaSST，沿用官方 k、omega 和壁面函数；SIMPLE 迭代上限 1000。
加载环境后，在此目录运行 bash Allrun。
