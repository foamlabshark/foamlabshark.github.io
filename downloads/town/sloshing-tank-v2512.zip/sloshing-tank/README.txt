摆动水槽中的自由液面晃荡
OpenFOAM v2512
来源：multiphase/interFoam/laminar/sloshingTank2D

水槽周期摆动，液面随惯性和重力发生晃荡。观察水面倾斜与槽壁附近的爬升。
m4 生成水槽网格字典，setFields 初始化水和空气，dynamicMeshDict 指定槽体运动。alpha.water=1 表示水，0 表示空气，中间值位于界面附近。
从 0 s 开始，计算至 2 s；初始时间步 0.01 s。开启自适应时间步。写出控制 adjustable，间隔 0.2。

包内已经包含生成的网格、区域与初始化后的场。加载 v2512 环境，在此目录运行 bash Allrun。
结果图与日志来自同一份输入。这里只是教学运行，不能把有限的运行时长当作网格无关或统计收敛证明。
