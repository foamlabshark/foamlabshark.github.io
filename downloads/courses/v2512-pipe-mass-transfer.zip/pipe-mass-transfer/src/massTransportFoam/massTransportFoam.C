/* FoamLab 教学求解器；OpenFOAM.com v2512；GPL-3.0-or-later。
 * c = K*a；D 为扩散系数，K 为各相的平衡分配系数。
 * 本算例中的 K 不随时间改变；单相中 K=1。
 */
#include "fvCFD.H"
int main(int argc, char *argv[])
{
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    IOdictionary props(IOobject("massProperties",runTime.constant(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE));
    volScalarField a(IOobject("a",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::AUTO_WRITE),mesh);
    volScalarField D(IOobject("D",runTime.timeName(),mesh,IOobject::READ_IF_PRESENT,IOobject::AUTO_WRITE),mesh,dimensionedScalar("D",dimViscosity,props));
    volScalarField K(IOobject("K",runTime.timeName(),mesh,IOobject::READ_IF_PRESENT,IOobject::AUTO_WRITE),mesh,dimensionedScalar("K",dimless,1));
    volScalarField c(IOobject("c",runTime.timeName(),mesh,IOobject::NO_READ,IOobject::AUTO_WRITE),K*a);
    volVectorField U(IOobject("U",runTime.timeName(),mesh,IOobject::READ_IF_PRESENT,IOobject::AUTO_WRITE),mesh,dimensionedVector("zero",dimVelocity,vector::zero));
    const word profile=props.lookupOrDefault<word>("profile","none");
    const scalar radius=props.lookupOrDefault<scalar>("radius",1),ub=props.lookupOrDefault<scalar>("Umean",0);
    auto velocity=[&](const vector& x){return vector(2*ub*max(1-(sqr(x.y())+sqr(x.z()))/sqr(radius),scalar(0)),0,0);};
    if(profile=="pipe")
    {
        forAll(U,i) U[i]=velocity(mesh.C()[i]);
        forAll(U.boundaryField(),p) if(U.boundaryField()[p].fixesValue())
            forAll(U.boundaryField()[p],i) U.boundaryFieldRef()[p][i]=velocity(mesh.Cf().boundaryField()[p][i]);
    }
    surfaceScalarField phi(IOobject("phi",runTime.timeName(),mesh),fvc::flux(U));
    surfaceScalarField phiK(IOobject("phiK",runTime.timeName(),mesh),fvc::interpolate(K)*phi);
    volScalarField DK(IOobject("DK",runTime.timeName(),mesh),D*K);
    const Switch steady=props.lookupOrDefault<Switch>("steady",true);
    const Switch convection=props.lookupOrDefault<Switch>("convection",false);
    const scalar initial=gSum(mesh.V()*c.primitiveField());
    scalar integratedOut=0;
    OFstream balance(runTime.path()/"balance.csv");balance.precision(16);
    balance<<"time,amount,outflow,integratedOut,balanceError"<<nl;
    while(runTime.loop())
    {
        if(steady)
        {
            if(convection) solve(fvm::div(phiK,a)-fvm::laplacian(DK,a));
            else solve(fvm::laplacian(DK,a));
        }
        else solve(fvm::ddt(K,a)-fvm::laplacian(DK,a));
        c=K*a;
        scalar out=0;
        forAll(a.boundaryField(),p)
        {
            if(mesh.boundary()[p].type()=="empty" || mesh.boundary()[p].type()=="wedge") continue;
            out+=gSum(phi.boundaryField()[p]*c.boundaryField()[p]-DK.boundaryField()[p]*a.boundaryField()[p].snGrad()*mesh.magSf().boundaryField()[p]);
        }
        integratedOut+=runTime.deltaTValue()*out;
        scalar amount=gSum(mesh.V()*c.primitiveField());
        balance<<runTime.value()<<','<<amount<<','<<out<<','<<integratedOut<<','<<amount-initial+integratedOut<<nl;
        runTime.write();
    }
    OFstream os(runTime.path()/"boundary.csv");os.precision(16);
    os<<"patch,x,y,z,area,c,gradA,D,K,volumeFlux"<<nl;
    forAll(a.boundaryField(),p)
    {
        if(mesh.boundary()[p].type()=="empty" || mesh.boundary()[p].type()=="wedge") continue;
        scalarField grad(a.boundaryField()[p].snGrad());
        forAll(a.boundaryField()[p],i)
        {
            const vector& x=mesh.Cf().boundaryField()[p][i];
            os<<mesh.boundary()[p].name()<<','<<x.x()<<','<<x.y()<<','<<x.z()<<','<<mesh.magSf().boundaryField()[p][i]<<','<<c.boundaryField()[p][i]<<','<<grad[i]<<','<<D.boundaryField()[p][i]<<','<<K.boundaryField()[p][i]<<','<<phi.boundaryField()[p][i]<<nl;
        }
    }
    Info<<"End"<<endl;
}
