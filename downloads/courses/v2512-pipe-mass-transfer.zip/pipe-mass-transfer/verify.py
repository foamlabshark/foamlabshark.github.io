from pathlib import Path
import json,csv,math,sys,re
import numpy as np
import vtk
from vtk.util.numpy_support import vtk_to_numpy
p=Path(__file__).resolve().parent
ref=json.loads((p/'reference.json').read_text())
def read(path):
    r=vtk.vtkUnstructuredGridReader();r.SetFileName(str(path));r.ReadAllScalarsOn();r.ReadAllVectorsOn();r.ReadAllFieldsOn();r.Update();d=r.GetOutput()
    t=d.GetFieldData().GetArray('TimeValue');time=t.GetTuple1(0) if t else float(path.stem.rsplit('_',1)[-1])
    cent=vtk.vtkCellCenters();cent.SetInputData(d);cent.Update();xyz=vtk_to_numpy(cent.GetOutput().GetPoints().GetData())
    v=vtk.vtkCellSizeFilter();v.SetInputData(d);v.ComputeVolumeOn();v.Update();vol=vtk_to_numpy(v.GetOutput().GetCellData().GetArray('Volume'))
    f={d.GetCellData().GetArrayName(i):vtk_to_numpy(d.GetCellData().GetArray(i)) for i in range(d.GetCellData().GetNumberOfArrays())}
    return time,xyz,vol,f
data=sorted([read(f) for f in (p/'VTK').glob('*.vtk')],key=lambda q:q[0]);assert data
t,xyz,vol,f=data[-1];assert np.isfinite(f['c']).all() and (vol>0).all()
metrics=[]
def check(name,value,reference,tolerance,relative=True):
    error=abs(value-reference)/(abs(reference) or 1) if relative else abs(value-reference)
    metrics.append(dict(name=name,value=float(value),reference=float(reference),error=float(error),tolerance=tolerance,passed=bool(error<=tolerance)))
rows=list(csv.DictReader((p/'boundary.csv').open()))
balance=list(csv.DictReader((p/'balance.csv').open()))
flux=np.array([float(q['volumeFlux'])*float(q['c'])-float(q['D'])*float(q['K'])*float(q['gradA'])*float(q['area']) for q in rows])
x=xyz[:,0];c=f['c'];exact=None
native=(p/f'{t:g}'/'c').read_text();match=re.search(r'internalField\s+nonuniform\s+List<scalar>\s+\d+\s*\((.*?)\)\s*;',native,re.S)
if match:c=np.fromstring(match[1],sep=' ')
if ref['case']=='concentration-diffusion':
    exact=np.array([ref['concentration']*math.erfc(q/(2*math.sqrt(ref['D']*t))) for q in x])
    check('浓度剖面归一化均方根误差',math.sqrt(np.dot(vol,(c-exact)**2)/vol.sum())/ref['concentration'],0,ref['tolerance'],False)
    amount=ref['concentration']*2*math.sqrt(ref['D']*t/math.pi)*1e-10
    check('扩散进入的总物质的量',float(balance[-1]['amount']),amount,.005)
    scale=max(abs(float(q['amount'])) for q in balance)
    check('逐步物质收支最大相对误差',max(abs(float(q['balanceError'])) for q in balance)/scale,0,1e-7,False)
elif ref['case']=='pipe-mass-transfer':
    last=x>x.max()-1e-7;weight=vol[last]*f['U'][last,0];bulk=float(weight@c[last]/weight.sum())
    station=min((float(q['x']) for q in rows if q['patch']=='wall'),key=lambda xx:abs(xx-x.max()))
    wall=[q for q in rows if q['patch']=='wall' and abs(float(q['x'])-station)<1e-9]
    grad=sum(float(q['area'])*float(q['gradA']) for q in wall)/sum(float(q['area']) for q in wall)
    sh=grad*2*ref['radius']/(1-bulk)
    check('出口舍伍德数',sh,ref['Sherwood'],ref['tolerance'])
    check('进出口与壁面物质收支误差',abs(flux.sum())/sum(abs(flux)),0,1e-6,False)
    cmin=float(c.min());cmax=float(c.max());assert cmin>=-1e-9 and cmax<=1+1e-9
    for name,value in [('出口混合平均浓度',bulk),('最小浓度',cmin),('最大浓度',cmax)]:
        metrics.append(dict(name=name,value=value,reference=None,error=None,tolerance=None,passed=True))
else:
    a1=ref['D1']*ref['K1'];a2=ref['D2']*ref['K2'];L=ref['length'];q=1/(ref['interface']/a1+(L-ref['interface'])/a2)
    a=1-q*(np.minimum(x,ref['interface'])/a1+np.maximum(x-ref['interface'],0)/a2)
    exact=a*np.where(x<ref['interface'],ref['K1'],ref['K2'])
    check('浓度剖面归一化均方根误差',math.sqrt(np.dot(vol,(c-exact)**2)/vol.sum())/max(exact),0,ref['tolerance'],False)
    left=next(z for z in rows if z['patch']=='left');J=-float(left['D'])*float(left['K'])*float(left['gradA'])
    check('界面传质通量',-J,q,ref['tolerance'])
    check('两端物质收支误差',abs(flux.sum())/sum(abs(flux)),0,1e-7,False)
np.savetxt(p/'comparison.csv',np.c_[x,c] if exact is None else np.c_[x,c,exact],delimiter=',',header='x,c'+('' if exact is None else ',reference'),comments='')
result={'case':ref['case'],'time':t,'cells':len(x),'metrics':metrics,'passed':all(m['passed'] for m in metrics)}
(p/'metrics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
sys.exit(0 if result['passed'] else 1)
