from pathlib import Path
import json,csv,math,sys
import vtk,numpy as np
from vtk.util.numpy_support import vtk_to_numpy
p=Path(__file__).resolve().parent;rows=list(csv.DictReader((p/'boundary.csv').open()))
flux={}
for row in rows:flux[row['patch']]=flux.get(row['patch'],0)-float(row['D'])*float(row['K'])*float(row['gradA'])*float(row['area'])
D=4.5e-9;R=.0001;outer=.001;thick=.0001;exact=2*math.pi*thick*D/math.log(outer/R)
data=[]
for f in (p/'VTK').glob('*.vtk'):
 r=vtk.vtkUnstructuredGridReader();r.SetFileName(str(f));r.ReadAllScalarsOn();r.Update();o=r.GetOutput()
 if not o.GetNumberOfCells():continue
 tm=o.GetFieldData().GetArray('TimeValue').GetTuple1(0)
 c=o.GetCellData().GetArray('c')
 if c is None:continue
 cc=vtk.vtkCellCenters();cc.SetInputData(o);cc.Update();xyz=vtk_to_numpy(cc.GetOutput().GetPoints().GetData());rr=np.linalg.norm(xyz[:,:2],axis=1);c=vtk_to_numpy(c)
 err=float(np.sqrt(np.mean((c-(1+np.log(rr/R)/math.log(outer/R)))**2)))
 data.append((tm,err))
data.sort();assert data
metrics=[dict(name='界面摩尔流率',value=flux['bubble'],reference=exact,error=abs(flux['bubble']/exact-1),tolerance=.01),dict(name='边界收支相对误差',value=abs(sum(flux.values()))/exact,reference=0,error=abs(sum(flux.values()))/exact,tolerance=1e-7),dict(name='浓度剖面归一化RMS误差',value=data[-1][1],reference=0,error=data[-1][1],tolerance=.005)]
for m in metrics:m['passed']=m['error']<m['tolerance']
result=dict(case='hydrogen-interface-transfer',scope='固定圆柱界面、稳态浓度扩散；示范边界浓度，不预测气泡形状变化',metrics=metrics,passed=all(m['passed'] for m in metrics))
(p/'metrics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(not result['passed'])
