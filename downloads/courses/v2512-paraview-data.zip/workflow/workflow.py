"""ParaView 6.1.1：从配套数据重复生成图片、曲线与水量核对。"""
from pathlib import Path
import os, json, sys
from paraview.simple import *
from paraview import servermanager

root=Path(__file__).resolve().parent
out=root/'figures';out.mkdir(exist_ok=True)
reader=OpenFOAMReader(FileName=str(root/'data/pitz-kOmegaSST/case.foam'))
reader.MeshRegions=['internalMesh'];reader.CellArrays=['U','p']
reader.Createcelltopointfiltereddata=1
reader.UpdatePipelineInformation()
scene=GetAnimationScene();scene.UpdateAnimationUsingDataTimeSteps()
scene.AnimationTime=max(reader.TimestepValues);reader.UpdatePipeline(scene.AnimationTime)
view=GetActiveViewOrCreate('RenderView');view.ViewSize=[1400,700]
view.UseColorPaletteForBackground=0;view.Background=[1,1,1]
view.OrientationAxesVisibility=0
d=Show(reader,view);d.Representation='Surface With Edges'
ColorBy(d,('POINTS','U','Magnitude'));d.SetScalarBarVisibility(view,True)
lut=GetColorTransferFunction('U');lut.ApplyPreset('Viridis',True);lut.RescaleTransferFunction(0,10)
bar=GetScalarBar(lut,view);bar.Title='U';bar.ComponentTitle='m/s'
bar.TitleColor=[.1,.1,.1];bar.LabelColor=[.1,.1,.1]
b=reader.GetDataInformation().GetBounds();cx=(b[0]+b[1])/2;cy=(b[2]+b[3])/2
view.CameraPosition=[cx,cy,.7];view.CameraFocalPoint=[cx,cy,0]
view.CameraViewUp=[0,1,0];view.CameraParallelProjection=1
ResetCamera(view);view.CameraParallelScale=.095
SaveScreenshot(str(out/'velocity-mesh.png'),view,ImageResolution=[1400,700])

cut=Slice(Input=reader);cut.SliceType='Plane'
cut.SliceType.Origin=[.1,0,0];cut.SliceType.Normal=[0,0,1]
cut.UpdatePipeline(scene.AnimationTime)
Hide(reader,view);d.SetScalarBarVisibility(view,False)
cd=Show(cut,view);ColorBy(cd,('POINTS','p'));cd.SetScalarBarVisibility(view,True)
plut=GetColorTransferFunction('p');plut.ApplyPreset('Viridis',True);cd.RescaleTransferFunctionToDataRange(True,False)
pb=GetScalarBar(plut,view);pb.Title='p';pb.ComponentTitle='m^2/s^2'
pb.TitleColor=[.1,.1,.1];pb.LabelColor=[.1,.1,.1]
SaveScreenshot(str(out/'slice-pressure.png'),view,ImageResolution=[1400,700])

points=CellDatatoPointData(Input=reader)
line=PlotOverLine(Input=points);line.Point1=[.1,-.025,0];line.Point2=[.1,.025,0];line.Resolution=100
line.UpdatePipeline(scene.AnimationTime)
SaveData(str(root/'velocity-line.csv'),proxy=line,Precision=12)
SaveState(str(root/'pipeline.pvsm'))

drop=OpenFOAMReader(FileName=str(root/'data/disc-iso/case.foam'))
drop.SkipZeroTime=0;drop.MeshRegions=['internalMesh'];drop.CellArrays=['alpha.water']
# 修改跳过初始时刻选项后，刷新时间目录。
drop.SMProxy.InvokeCommand('Refresh');drop.UpdatePipelineInformation()
assert 0 in drop.TimestepValues,'初始时刻未读入'
drop.UpdatePipeline(time=0)
integral=IntegrateVariables(Input=drop);integral.UpdatePipeline(time=0)
obj=servermanager.Fetch(integral)
if obj.IsA('vtkMultiBlockDataSet'):obj=obj.GetBlock(0)
value=obj.GetCellData().GetArray('alpha.water').GetTuple1(0)
ref=.019453363437973485;err=abs(value-ref)/ref
SaveData(str(root/'water-volume.csv'),proxy=integral,Precision=12)
result=dict(ParaView='6.1.1',time=0,initial_liquid_volume_m3=value,
            OpenFOAM_cell_sum_m3=ref,relative_error=err,tolerance=1e-5,passed=err<1e-5)
(root/'metrics.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
del obj
ResetSession()
Disconnect()
sys.exit(not result['passed'])
