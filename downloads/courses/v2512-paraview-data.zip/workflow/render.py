"""Reproducible ParaView 6.1 pipeline and quantitative extraction."""
from pathlib import Path
import json,sys,os
if sys.platform.startswith('linux'):os.environ.setdefault('VTK_DEFAULT_OPENGL_WINDOW','vtkOSOpenGLRenderWindow')
from paraview.simple import *
from paraview import servermanager
root=Path(__file__).resolve().parent
out=root/'figures';out.mkdir(exist_ok=True)
reader=OpenFOAMReader(FileName=str(root/'data/pitz-kOmegaSST/case.foam'))
reader.MeshRegions=['internalMesh'];reader.CellArrays=['U','p']
reader.UpdatePipelineInformation();t=max(reader.TimestepValues);reader.UpdatePipeline(time=t)
view=GetActiveViewOrCreate('RenderView');view.ViewSize=[1400,900]
view.UseColorPaletteForBackground=0;view.Background=[1,1,1];view.OrientationAxesVisibility=0
d=Show(reader,view);ColorBy(d,('CELLS','U','Magnitude'));d.Representation='Surface With Edges';d.SetScalarBarVisibility(view,True)
lut=GetColorTransferFunction('U');lut.ApplyPreset('Viridis',True);lut.RescaleTransferFunction(0,12)
bar=GetScalarBar(lut,view);bar.Title='Velocity';bar.ComponentTitle='m/s';bar.TitleColor=[.1,.1,.1];bar.LabelColor=[.1,.1,.1]
ResetCamera(view);b=reader.GetDataInformation().GetBounds();view.CameraPosition=[(b[0]+b[1])/2,(b[2]+b[3])/2,.7];view.CameraFocalPoint=[(b[0]+b[1])/2,(b[2]+b[3])/2,(b[4]+b[5])/2];view.CameraViewUp=[0,1,0];view.CameraParallelProjection=1;view.CameraParallelScale=.12
SaveScreenshot(str(out/'reader-mesh.png'),view,ImageResolution=[1400,900])
Hide(reader,view);cut=Slice(Input=reader);cut.SliceType='Plane';cut.SliceType.Origin=[(b[0]+b[1])/2,(b[2]+b[3])/2,(b[4]+b[5])/2];cut.SliceType.Normal=[0,0,1]
cs=Show(cut,view);ColorBy(cs,('CELLS','p'));cs.SetScalarBarVisibility(view,True);d.SetScalarBarVisibility(view,False)
pl=GetColorTransferFunction('p');pl.ApplyPreset('Cool to Warm (Extended)',True);cs.RescaleTransferFunctionToDataRange(True,False)
pb=GetScalarBar(pl,view);pb.Title='Kinematic pressure';pb.ComponentTitle='m2/s2';pb.TitleColor=[.1,.1,.1];pb.LabelColor=[.1,.1,.1]
SaveScreenshot(str(out/'slice-pressure.png'),view,ImageResolution=[1400,900])
Hide(cut,view);cs.SetScalarBarVisibility(view,False);points=CellDatatoPointData(Input=reader)
st=StreamTracer(Input=points,SeedType='Line');st.Vectors=['POINTS','U'];st.SeedType.Point1=[b[0]+.005,b[2]+.003,(b[4]+b[5])/2];st.SeedType.Point2=[b[0]+.005,b[3]-.003,(b[4]+b[5])/2];st.SeedType.Resolution=30;st.MaximumStreamlineLength=.5
sd=Show(st,view);ColorBy(sd,('POINTS','U','Magnitude'));sd.LineWidth=2;sd.SetScalarBarVisibility(view,True)
SaveScreenshot(str(out/'stream-tracer.png'),view,ImageResolution=[1400,900])
Hide(st,view);sd.SetScalarBarVisibility(view,False);line=PlotOverLine(Input=points);line.Point1=[.1,b[2]+.0001,(b[4]+b[5])/2];line.Point2=[.1,b[3]-.0001,(b[4]+b[5])/2];line.Resolution=200
chart=CreateView('XYChartView');chart.ViewSize=[1400,900];chart.ChartTitle='Velocity profile at x = 0.1 m';ld=Show(line,chart,'XYChartRepresentation');ld.UseIndexForXAxis=0;ld.XArrayName='Points_Y';ld.SeriesVisibility=['U_X'];chart.LeftAxisTitle='Ux / m/s';chart.BottomAxisTitle='y / m'
SaveScreenshot(str(out/'plot-over-line.png'),chart,ImageResolution=[1400,900]);SaveData(str(root/'velocity-line.csv'),proxy=line)
SaveState(str(root/'pipeline.pvsm'))
drop=OpenFOAMReader(FileName=str(root/'data/disc-iso/case.foam'));drop.MeshRegions=['internalMesh'];drop.CellArrays=['alpha.water'];drop.UpdatePipeline(time=0)
integral=IntegrateVariables(Input=drop);integral.UpdatePipeline(time=0);obj=servermanager.Fetch(integral)
if obj.IsA('vtkMultiBlockDataSet'):obj=obj.GetBlock(0)
value=obj.GetCellData().GetArray('alpha.water').GetTuple1(0);ref=.019453363437973496;err=abs(value-ref)/ref
SaveData(str(root/'water-volume.csv'),proxy=integral)
result=dict(ParaView='6.1.1',initial_liquid_volume_m3=value,OpenFOAM_cell_sum_m3=ref,relative_error=err,tolerance=1e-5,passed=err<1e-5)
(root/'metrics.json').write_text(json.dumps(result,indent=2));print(json.dumps(result));sys.exit(not result['passed'])
