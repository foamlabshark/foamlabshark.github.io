# ParaView 练习数据与脚本

使用 ParaView 6.1.1 自带的解释器执行 `pvpython workflow.py`。脚本读取 data 下的台阶流动与圆盘数据，生成图片、采样 CSV、pipeline.pvsm 和水量核对 metrics.json。

在没有桌面的服务器上，先配置安装所支持的离屏渲染环境。本次测试使用软件渲染与 X 虚拟显示；普通桌面环境直接运行上述命令。课程截图由本站实际操作软件取得。
