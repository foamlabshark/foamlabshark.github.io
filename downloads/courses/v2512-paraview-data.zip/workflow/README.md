# ParaView 工作流

ParaView 6.1.1：执行 `pvpython --force-offscreen-rendering render.py`。脚本读取本包真实 pitzDaily 与圆盘平移数据，生成四幅图、中心线 CSV、液体体积 CSV、pipeline.pvsm和metrics.json。数据由OpenFOAM.com v2512计算。讲义界面见对应课程。
