from pathlib import Path
import json,math,sys
import numpy as np
import vtk
from vtk.util.numpy_support import vtk_to_numpy
p=Path(__file__).resolve().parent;ref=json.loads((p/'reference.json').read_text())
def read(path):
    rd=vtk.vtkUnstructuredGridReader();rd.SetFileName(str(path));rd.ReadAllScalarsOn();rd.ReadAllVectorsOn();rd.ReadAllFieldsOn();rd.Update();d=rd.GetOutput();t=d.GetFieldData().GetArray('TimeValue').GetTuple1(0)
    cc=vtk.vtkCellCenters();cc.SetInputData(d);cc.Update();xyz=vtk_to_numpy(cc.GetOutput().GetPoints().GetData())
    ss=vtk.vtkCellSizeFilter();ss.SetInputData(d);ss.ComputeVolumeOn();ss.Update();vol=vtk_to_numpy(ss.GetOutput().GetCellData().GetArray('Volume'))
    f={d.GetCellData().GetArrayName(i):vtk_to_numpy(d.GetCellData().GetArray(i)) for i in range(d.GetCellData().GetNumberOfArrays())}
    if 'rho' not in f:f['rho']=f['p']/(ref['R']*f['T'])
    return t,xyz,vol,f
data=sorted([read(q) for q in (p/'VTK').glob('*.vtk')],key=lambda a:a[0]);assert data
t,xyz,v,f=data[-1];g=ref['gamma'];metrics=[]
assert (v>0).all() and (f['p']>0).all() and (f['rho']>0).all()
def check(name,value,expected,tol,relative=True):
    error=abs(value-expected)/(abs(expected) or 1) if relative else abs(value-expected)
    metrics.append(dict(name=name,value=float(value),reference=float(expected),error=float(error),tolerance=tol,passed=bool(error<=tol)))
if ref['case']=='isentropic-nozzle':
    def AM(M):return (2/(g+1)*(1+(g-1)*M*M/2))**((g+1)/(2*(g-1)))/M
    def Mref(x):
        ratio=1+.5*math.cos(math.pi*x/ref['length'])**2;sup=x>ref['length']/2;lo,hi=(1.,8.) if sup else (1e-6,1.)
        for _ in range(80):
            m=(lo+hi)/2
            if (AM(m)>ratio)==sup:hi=m
            else:lo=m
        return (lo+hi)/2
    xx=np.round(xyz[:,0],8);xs=np.unique(xx);Ma=np.linalg.norm(f['U'],axis=1)/np.sqrt(g*ref['R']*f['T']);rows=[]
    for x in xs:
        sel=xx==x;w=v[sel];m=float(w@Ma[sel]/w.sum());pressure=float(w@f['p'][sel]/w.sum());mass=float(np.sum(v[sel]*f['rho'][sel]*f['U'][sel,0])/(ref['length']/ref['nx']));M=Mref(x);pref=ref['p0']/(1+(g-1)*M*M/2)**(g/(g-1));rows.append((x,m,M,pressure,pref,mass))
    a=np.array(rows);sel=abs(a[:,0]-.5*ref['length'])>.025*ref['length']
    check('马赫数剖面归一化均方根误差',float(np.sqrt(np.mean((a[sel,1]-a[sel,2])**2)))/a[:,2].max(),0,.03,False)
    check('压力剖面归一化均方根误差',float(np.sqrt(np.mean((a[:,3]-a[:,4])**2)))/ref['p0'],0,.03,False)
    check('截面质量流率最大相对偏差',float(np.ptp(a[:,5])/a[:,5].mean()),0,.02,False)
    np.savetxt(p/'comparison.csv',a,delimiter=',',header='x,M,M_reference,p,p_reference,massFlux',comments='')
else:
    sedov=json.loads((p/'sedov-reference.json').read_text());beta=sedov['beta'];history=[]
    energy0=None;mass0=None
    for time,coords,vol,ff in data:
        energy=float(vol@(ff['p']/(g-1)+.5*ff['rho']*np.sum(ff['U']**2,axis=1)));mass=float(vol@ff['rho'])
        if time==0:energy0=energy;mass0=mass;continue
        r=np.linalg.norm(coords[:,:2],axis=1);expected=beta*(ref['energy_per_length']*time*time/ref['density'])**.25
        width=1/ref['n'];bins=np.arange(0,.5,width);idx=np.digitize(r,bins)-1
        # 壳层密度峰在激波后约一个网格内；以外侧半跃迁位置估计波前。
        rb=[];density=[]
        for i in range(len(bins)-1):
            sel=idx==i
            if np.any(sel):rb.append(float(np.average(r[sel],weights=vol[sel])));density.append(float(np.average(ff['rho'][sel],weights=vol[sel])))
        rb=np.array(rb);density=np.array(density);peak=np.argmax(density);threshold=(density[peak]+ref['density'])/2
        ii=np.where((np.arange(len(density)-1)>=peak)&(density[:-1]>=threshold)&(density[1:]<threshold))[0]
        assert len(ii),'未找到波前';i=ii[0];radius=float(np.interp(threshold,density[i:i+2][::-1],rb[i:i+2][::-1]))
        history.append((time,radius,expected,energy,mass))
    h=np.array(history);check('最终冲击波半径',h[-1,1],h[-1,2],.06)
    use=h[:,0]>=.03;exponent=float(np.polyfit(np.log(h[use,0]),np.log(h[use,1]),1)[0]);check('波前半径时间幂指数',exponent,.5,.07,False)
    check('全域总能量相对变化',float(np.max(abs(h[:,3]-energy0))/abs(energy0)),0,1e-5,False)
    check('全域总质量相对变化',float(np.max(abs(h[:,4]-mass0))/abs(mass0)),0,1e-5,False)
    np.savetxt(p/'comparison.csv',h,delimiter=',',header='time,radius,radius_reference,energy,mass',comments='')
result=dict(case=ref['case'],time=float(t),cells=len(v),metrics=metrics,passed=all(q['passed'] for q in metrics))
(p/'metrics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(0 if result['passed'] else 1)
