"""由柱对称 Euler 相似方程生成强冲击波参考，不使用待验证的 OpenFOAM 数据。"""
from pathlib import Path
import json,math
import numpy as np
from scipy.integrate import solve_ivp
root=Path(__file__).resolve().parent.parent
g,d=1.4,2
s=2/(d+2)
def ode(x,q):
    G,U,P=q;w=U-x
    A=np.array([[w,G,0],[0,w,1/G],[-g*w/G,0,w/P]])
    b=np.array([-(d-1)*G*U/x,d*U/2,d])
    return np.linalg.solve(A,b)
xs=np.geomspace(1,.01,3000)
sol=solve_ivp(ode,(1,.01),[(g+1)/(g-1),2/(g+1),2/(g+1)],t_eval=xs,method='DOP853',rtol=1e-10,atol=1e-12)
assert sol.success,sol.message
x=sol.t[::-1];G,U,P=sol.y[:,::-1]
integrand=(P/(g-1)+G*U*U/2)*x**(d-1)
# 中心的压力趋于常数，密度与动能趋于零；补上很小的中心积分。
I=2*math.pi*(np.trapezoid(integrand,x)+P[0]/(g-1)*x[0]**d/d)
beta=(1/(s*s*I))**(1/(d+2))
meta=dict(gamma=g,dimension=d,exponent=s,energy_integral=I,beta=beta,source='柱对称 Euler 相似方程与强激波跃迁条件',reference='https://flash.rochester.edu/site/flashcode/user_support/flash2_users_guide/docs/FLASH2.2/flash2.2_ug.pdf')
for p in [root]:
    np.savetxt(p/'sedov-profile.csv',np.c_[x,G,U,P],delimiter=',',header='xi,density,velocity,pressure',comments='')
    (p/'sedov-reference.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(meta,ensure_ascii=False,indent=2))
