使用安装了 NumPy、SciPy 的 Python 运行 `python reference/sedov-reference.py`，在算例根目录重新生成相似解剖面与能量积分常数。参考解独立于 OpenFOAM 计算结果。
