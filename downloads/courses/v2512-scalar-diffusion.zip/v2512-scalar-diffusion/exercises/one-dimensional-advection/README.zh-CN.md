# one-dimensional-advection

FoamLab 针对 OpenCFD OpenFOAM v2512 编写的教学输入，GPL-3.0-or-later。

一维无物理扩散标量平移：长度 1 m，速度 1 m/s，200 个单元，deltaT=0.001 s，Co=0.2，结束时刻 0.2 s。初值是在 0.15–0.35 m 内的 cos² 脉冲，中心 0.25 m，峰值 1；解析参考在 0.2 s 时平移到中心 0.45 m。初值与入口均为零的域外部分相容，脉冲在测试时间内不经过出口。本例 T 可解释为幅值 1 K 的被动温差，不是绝对热力学温度，也不求完整能量耦合。基线采用 Euler + upwind，预计脉冲展宽，不能期待机器精度匹配。比较时分别修改 div(phi,T) 为 Gauss linear 或 Gauss limitedLinear 1，并保留独立副本。守恒核查要计入边界通量；原脉冲线积分为 0.1 K·m。

在已加载 v2512 的 Linux 终端，从本目录运行 `bash Allrun`。先看 log.blockMesh 与 log.checkMesh，再看求解器日志；compare.py 读取 ASCII 最终 T，写出 comparison.csv 并打印误差。脚本常量对应原始网格、速度与结束时刻，修改这些参数后必须同步修改对照脚本，不能沿用旧坐标或旧参考。

运行状态：教学输入已按 v2512 源码读取项核对；实际核验记录若已附于包内 RUN-VERIFICATION.txt，以该文件记录的输入哈希、版本和范围为准。没有该记录时，仅表示已经生成和检查输入文件，不表示完成求解。
