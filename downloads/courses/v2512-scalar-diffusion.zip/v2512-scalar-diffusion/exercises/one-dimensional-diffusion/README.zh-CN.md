# one-dimensional-diffusion

FoamLab 针对 OpenCFD OpenFOAM v2512 编写的教学输入，GPL-3.0-or-later。

一维稳态温度扩散：长度 0.1 m，40 个单元，左端 400 K，右端 300 K，DT=1e-5 m²/s。fvSchemes 使用 steadyState，所以目录 1 是稳态迭代标识，不是等待了 1 s 的瞬态解。解析解 T=400-100*x/0.1。在这一均匀正交网格与常系数设置下，线性温度解应能很好重现。DT 是热扩散率，不是导热系数；若要按课文算热流密度，另指定 k=10 W/(m K)，得到正 x 方向 10000 W/m²。该输入只含一种均匀材料，没有自动实现两材料交界练习。

在已加载 v2512 的 Linux 终端，从本目录运行 `bash Allrun`。先看 log.blockMesh 与 log.checkMesh，再看求解器日志；compare.py 读取 ASCII 最终 T，写出 comparison.csv 并打印误差。脚本常量对应原始网格、速度与结束时刻，修改这些参数后必须同步修改对照脚本，不能沿用旧坐标或旧参考。

运行状态：教学输入已按 v2512 源码读取项核对；实际核验记录若已附于包内 RUN-VERIFICATION.txt，以该文件记录的输入哈希、版本和范围为准。没有该记录时，仅表示已经生成和检查输入文件，不表示完成求解。
