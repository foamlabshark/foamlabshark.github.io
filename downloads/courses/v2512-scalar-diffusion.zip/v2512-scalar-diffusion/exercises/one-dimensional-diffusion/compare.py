"""Compare the unmodified teaching case against its analytic reference.
Run after Allrun. Changes to mesh, length, velocity or endTime require updating
this explicit comparison as well. Source: FoamLab, GPL-3.0-or-later.
"""
import csv, math, re
from pathlib import Path
n, length, time = 40, 0.1, 1
file=Path(__file__).parent / str(time) / 'T'
text=file.read_text()
match=re.search(r'internalField\s+nonuniform\s+List<scalar>\s+(\d+)\s*\((.*?)\)\s*;',text,re.S)
if match:
 values=[float(x) for x in match.group(2).split()]
 assert int(match.group(1))==len(values)==n
else:
 match=re.search(r'internalField\s+uniform\s+([^;]+);',text)
 if not match: raise ValueError('ASCII internalField not found')
 values=[float(match.group(1))]*n
def expected(x):
 return 400-100*x/length
rows=[((i+.5)*length/n,v,expected((i+.5)*length/n)) for i,v in enumerate(values)]
with (file.parent.parent/'comparison.csv').open('w',newline='') as f:
 writer=csv.writer(f); writer.writerow(['x_m','T_computed','T_reference']); writer.writerows(rows)
print('mean_absolute_error=',sum(abs(v-r) for _,v,r in rows)/n)
print('maximum_absolute_error=',max(abs(v-r) for _,v,r in rows))
print('computed_min_max=',min(values),max(values))
print('line_integral=',sum(values)*length/n)
