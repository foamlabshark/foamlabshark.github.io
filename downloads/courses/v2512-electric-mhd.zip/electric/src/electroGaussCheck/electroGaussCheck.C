/* FoamLab: electric flux and charge check, GPL-3.0-or-later. */
#include "fvCFD.H"
#include "timeSelector.H"
int main(int argc,char *argv[])
{
    timeSelector::addOptions();
    #include "setRootCase.H"
    #include "createTime.H"
    instantList times=timeSelector::select0(runTime,args);
    runTime.setTime(times.last(),times.size()-1);
    #include "createMesh.H"
    IOdictionary props(IOobject("physicalProperties",runTime.constant(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE));
    dimensionedScalar epsilon0("epsilon0",dimensionSet(-1,-3,4,0,0,2,0),props);
    volScalarField potential(IOobject("phi",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE),mesh);
    volScalarField charge(IOobject("rho",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE),mesh);
    surfaceScalarField gradient(fvc::snGrad(potential));
    scalar flux=0,scale=0;
    forAll(mesh.boundary(),p)
    {
        if(mesh.boundary()[p].type()=="empty")continue;
        scalar f=-epsilon0.value()*gSum(gradient.boundaryField()[p]*mesh.magSf().boundaryField()[p]);
        flux+=f;scale+=mag(f);
    }
    scalar q=gSum(charge.primitiveField()*mesh.V());
    scalar error=mag(flux-q)/max(max(scale,mag(q)),scalar(SMALL));
    OFstream out(runTime.path()/"gauss-check.json");out.precision(16);
    out<<"{\n  \"time\": "<<runTime.value()<<",\n  \"charge_C\": "<<q<<",\n  \"outward_electric_flux_C\": "<<flux<<",\n  \"relative_error\": "<<error<<"\n}"<<endl;
    Info<<"charge = "<<q<<" electric flux = "<<flux<<" relative error = "<<error<<endl;
}
