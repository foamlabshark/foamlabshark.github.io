# 化学反应流动 · OpenCFD OpenFOAM v2512

完整输入位于 cases/，本机 v2512 求解器源码位于 source/。

加载环境后，进入一个新解压的算例目录，执行 `sh Allrun`。
执行 `sh Allrun --check` 可复核配置：氢气为 0.001 s，对冲火焰和液滴为 0.002 s，Sandia 为 8 次局部时间迭代。
H2 算例计算到 1 ms。对冲火焰默认计算到 0.5 s；Sandia 算例使用局部时间步，其时间标签表示迭代推进。
短程运行仅验证网格、字段、化学和求解流程，不能作为稳态火焰或网格无关性结论。
droplet-evaporation 用于检查蒸发与载气耦合，气相化学关闭。
各节入口与配图对应关系见 lesson-map.json，实际完成的运行范围见 verification/report.json。

| 课程 | 算例目录 | 求解器 |
| --- | --- | --- |
| 第 02 课 | cases/h2-ignition | chemFoam |
| 第 03 课 | cases/opposed-psi | reactingFoam |
| 第 04 课 | cases/opposed-rho | rhoReactingFoam |
| 第 05 课 | cases/opposed-buoyant | rhoReactingBuoyantFoam |
| 第 06 课 | cases/sandia-edc | reactingFoam，EDC / PaSR |
| 第 07 课 | cases/droplet-evaporation | reactingParcelFoam |

前五组中除 Sandia 外均完成 0.5 s 的空间算例或 1 ms 的均相算例；液滴完成 0.5 s。Sandia 的检查保持化学反应开启，完整稳定火焰需继续迭代。
算例文件、反应机理、热物性和源码保留上游版权说明，按 COPYING 所列 GPL 分发。
