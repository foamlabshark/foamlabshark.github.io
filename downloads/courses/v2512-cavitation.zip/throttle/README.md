# throttle

版本：OpenFOAM.com v2512；后处理：ParaView 6.1.1 的 pvpython。

在已加载 v2512 环境的终端进入本目录，执行 `bash Allrun`。脚本生成网格、运行求解器、导出字段，并执行 `verify.py`。`bash Allclean` 清理计算结果。自定义程序的源码和 Make 文件在 src 中，Allrun 会先编译。

`metrics.json` 保存本次检查，`verified-run/` 保存本站运行的日志和指标。后者为参考记录，重新运行的结果写在算例根目录。

本算例记录 2 项带参考值的检查。`reference_checks` 是脚本判定项；`diagnostics` 记录工程对比或统计差异。阅读对应课程中的实际误差、比较范围与后续细化步骤，结合自己关心的指标继续验证。

原生教程改编自 OpenCFD OpenFOAM-v2512（GPL-3.0-or-later）；新增验证脚本与教学求解器由 FoamLab 编写，同采用 GPL-3.0-or-later。原版权头和 COPYING 保留。
