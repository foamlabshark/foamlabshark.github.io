# Source from Bash after loading the installed OpenCFD v2512 environment.
# This points tutorial resources at this package, not at the software install.
: "${WM_PROJECT_DIR:?Load OpenCFD OpenFOAM v2512 before sourcing this file}"
case "$WM_PROJECT_VERSION" in v2512|2512) ;; *) echo "Expected v2512, found $WM_PROJECT_VERSION" >&2; return 1 ;; esac
export FOAM_TUTORIALS="$(cd "$(dirname "${BASH_SOURCE[0]}")/tutorials" && pwd)"
printf 'Using packaged tutorial resources: %s
' "$FOAM_TUTORIALS"
