# 动网格与 AMI · OpenCFD OpenFOAM v2512

## 先找对运行目录

本包用于配套课程，包含原始输入，不是软件安装包，也不把打包检查称作物理验证。先解压到自己可写的 Linux 工作目录，再进入 `v2512-moving-ami`；保留一个未改动副本用于对照。

官方案例目录：
- `tutorials/incompressible/pimpleFoam/laminar/movingCone`
- `tutorials/incompressible/pimpleFoam/laminar/mixerVesselAMI2D`

建议起点：`tutorials/incompressible/pimpleFoam/laminar/movingCone`。

```bash
# 在新终端中先加载已安装 v2512 的环境；路径以你的安装为准
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
blockMesh -help
# 以下命令从本包根目录执行
source ./environment.sh
cd tutorials/incompressible/pimpleFoam/laminar/movingCone
blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh.initial 2>&1
pimpleFoam > log.pimpleFoam 2>&1
```

每一步都检查退出码和日志；前一步失败时停止，不要继续执行。`checkMesh` 还应检查失败项汇总，不能只看 Shell 退出码。脚本需要 Linux Shell，不能在 Windows PowerShell 中直接执行 OpenFOAM 命令。MPI、m4、Python 3、gnuplot 等额外工具按具体案例说明准备。

## 这个合集怎样用于练习

movingCone 使用 velocityComponentLaplacian 和 pointMotionUx，先阅读真实字段，不要按名称猜成 pointDisplacement。两个 mixerVesselAMI2D 子案例各有 Allrun 和 Allrun.pre，后者使用 m4 生成 blockMeshDict 并运行 topoSet；前者恢复场、分区和并行 pimpleFoam，需 m4 与 MPI。普通子案例采用 reconstructPar，拓扑变化子案例使用 redistributePar -reconstruct；请保留各自脚本。观察全过程网格质量与接口覆盖，不能仅检查 t=0 的网格。本包未运行这些动网格计算。

官方 Allrun 使用 `$WM_PROJECT_DIR/bin/tools/RunFunctions`，`#includeEtc` 使用已安装 v2512 的模板，因此必须安装完整、同分支同版本的 OpenFOAM。environment.sh 只将 FOAM_TUTORIALS 指向本包 tutorials，并不替换 WM_PROJECT_DIR；请在专用终端中使用。它使几何资源从本包读取，不依赖另一套教程的位置。部分字典宏里的 `${../name}` 是字典作用域引用，并不是缺失的父目录文件。

## 对照与运行证据

包内原始教程文件、资源、包含文件及相对链接已经逐项核对；不等于已完成这些案例的 CFD 计算。除方腔课程明确引用的既有基础运行外，本轮官方合集没有新增完整求解证据。FoamLab 新教学案例如有 RUN-VERIFICATION.txt，应按其版本、输入哈希和运行范围阅读，不能外推到整个合集。

计算结果通常写到案例时间目录；监测对象写入 postProcessing/。先核对单位、边界与日志，再看图。比较不同设置时建立独立副本，记录改动；不要将一个案例的结果图作为另一个参数组合的证据。

## 来源、许可与完整性

来源与版本见 SOURCE.txt，完整 GPL 文本见 COPYING；原始版权头和字典代码保留。UPSTREAM.sha256 记录原始文件内容哈希，SYMLINKS.txt 记录为跨平台解压展开的链接，DEPENDENCIES.txt 记录包含关系、系统依赖和生成步骤。MANIFEST.sha256 可用于检查下载后文件完整性。

本包由 `tools/content/refine-core-courses.py` 生成；课程文字在旧 `build-core.py` 生成后由该脚本后处理。无需重新编辑官方源文件即可重新生成同一下载包。
