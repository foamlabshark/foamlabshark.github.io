/* FoamLab teaching solver; GPL-3.0-or-later. OpenFOAM.com v2512. */
#include "fvCFD.H"
int main(int argc,char *argv[])
{
 #include "setRootCase.H"
 #include "createTime.H"
 #include "createMesh.H"
 IOdictionary props(IOobject("labProperties",runTime.constant(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE));
 word name(props.lookupOrDefault<word>("field","T"));
 volScalarField X(IOobject(name,runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::AUTO_WRITE),mesh);
 volScalarField D(IOobject("DT",runTime.timeName(),mesh,IOobject::READ_IF_PRESENT,IOobject::AUTO_WRITE),mesh,dimensionedScalar("DT",dimViscosity,props));
 Switch convection(props.lookupOrDefault<Switch>("convection",false));
 volVectorField U(IOobject("U",runTime.timeName(),mesh,IOobject::READ_IF_PRESENT,IOobject::AUTO_WRITE),mesh,dimensionedVector("zero",dimVelocity,vector::zero));
 word profile(props.lookupOrDefault<word>("profile","none"));
 scalar radius=props.lookupOrDefault<scalar>("radius",1),height=props.lookupOrDefault<scalar>("height",1),ub=props.lookupOrDefault<scalar>("Umean",1);
 auto velocity=[&](const vector& c) {scalar f=1; if(profile=="pipe") f=2*(1-(sqr(c.y())+sqr(c.z()))/sqr(radius)); if(profile=="channel") f=6*c.y()/height*(1-c.y()/height); return vector(ub*max(f,scalar(0)),0,0);};
 if(profile!="none"){
  forAll(U,i)U[i]=velocity(mesh.C()[i]);
  forAll(U.boundaryField(),p)if(U.boundaryField()[p].fixesValue()){
   forAll(U.boundaryField()[p],i)U.boundaryFieldRef()[p][i]=velocity(mesh.Cf().boundaryField()[p][i]);
  }
 }
 surfaceScalarField phi(IOobject("phi",runTime.timeName(),mesh,IOobject::NO_READ,IOobject::AUTO_WRITE),fvc::flux(U));
 Switch steady(props.lookupOrDefault<Switch>("steady",true));
 while(runTime.loop()){
  Info<<"Time = "<<runTime.timeName()<<nl;
  if(steady){
   if(convection)solve(fvm::div(phi,X)-fvm::laplacian(D,X));
   else solve(fvm::laplacian(D,X));
  }else solve(fvm::ddt(X)+fvm::div(phi,X)-fvm::laplacian(D,X));
  if(profile=="darcy"){
   dimensionedScalar K("permeability",dimArea,props),nu("viscosity",dimViscosity,props);
   U=-(K/nu)*fvc::grad(X);
  }
  runTime.write();
 }
 OFstream os(runTime.path()/"boundary.csv");os.precision(14);os<<"patch,x,y,z,area,value,snGrad,volumeFlux"<<nl;
 forAll(X.boundaryField(),p){
  if(mesh.boundary()[p].type()=="empty")continue;
  scalarField grad(X.boundaryField()[p].snGrad());
  forAll(X.boundaryField()[p],i){const vector& c=mesh.Cf().boundaryField()[p][i];os<<mesh.boundary()[p].name()<<','<<c.x()<<','<<c.y()<<','<<c.z()<<','<<mesh.magSf().boundaryField()[p][i]<<','<<X.boundaryField()[p][i]<<','<<grad[i]<<','<<phi.boundaryField()[p][i]<<nl;}
 }
 Info<<"End"<<endl;return 0;
}
