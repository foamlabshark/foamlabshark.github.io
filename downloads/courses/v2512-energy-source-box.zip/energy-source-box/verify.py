import csv,json
from pathlib import Path
p=Path(__file__).resolve().parent
rows=list(csv.DictReader((p/'energy-source.csv').open()))
q=100000.;start=.0027;end=.0137;gamma=1.4001982909941486
energy_error=0;pressure_error=0
for row in rows:
    t=float(row['time_s']);added=q*max(0,min(t,end)-start)
    energy_error=max(energy_error,abs(float(row['change_minus_input_J']))/1100)
    pressure_error=max(pressure_error,abs(float(row['mean_p_Pa'])-(1e5+(gamma-1)*added))/1e5)
tests=[dict(name='energy_balance_relative',value=energy_error,tolerance=1e-9),
       dict(name='pressure_relative_error',value=pressure_error,tolerance=1e-8),
       dict(name='integrated_input_J',value=float(rows[-1]['added_J']),reference=1100,tolerance=1e-8)]
for item in tests:
    item.setdefault('reference',0);item['error']=abs(item['value']-item['reference']);item['passed']=item['error']<item['tolerance']
result=dict(case='energy-source-box',reference_checks=tests,passed=all(x['passed'] for x in tests))
(p/'metrics.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
raise SystemExit(0 if result['passed'] else 1)
