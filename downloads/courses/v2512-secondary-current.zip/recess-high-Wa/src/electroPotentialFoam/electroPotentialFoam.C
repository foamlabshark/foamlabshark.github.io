/* FoamLab educational secondary/tertiary current-distribution solver.
   GPL-3.0-or-later. Supporting electrolyte, isothermal, prescribed flow. */
#include "fvCFD.H"
#include "mixedFvPatchFields.H"
int main(int argc,char *argv[])
{
 #include "setRootCase.H"
 #include "createTime.H"
 #include "createMesh.H"
 IOdictionary d(IOobject("electrochemistryProperties",runTime.constant(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE));
 dimensionedScalar kappa("kappa",d),diff("D",dimViscosity,d);
 scalar j0=d.get<scalar>("j0"),a=d.get<scalar>("alpha"),temp=d.get<scalar>("temperature"),vm=d.get<scalar>("metalPotential"),eq=d.get<scalar>("equilibriumPotential"),cb=d.get<scalar>("bulkConcentration"),n=d.get<scalar>("nElectrons");
 const scalar F=96485.33212,R=8.314462618,beta=n*F/(R*temp);
 Switch tertiary=d.lookupOrDefault<Switch>("tertiary",false);
 label electrode=mesh.boundaryMesh().findPatchID(d.get<word>("electrodePatch"));
 if(electrode<0)FatalErrorInFunction<<"electrodePatch not found"<<exit(FatalError);
 volScalarField V(IOobject("V",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::AUTO_WRITE),mesh);
 volScalarField c(IOobject("c",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::AUTO_WRITE),mesh);
 volVectorField U(IOobject("U",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::AUTO_WRITE),mesh);
 if(d.lookupOrDefault<Switch>("channelFlow",false)){
  scalar H=d.get<scalar>("height"),ub=d.get<scalar>("Umean");
  auto vel=[&](const vector& p){return vector(6*ub*p.y()/H*(1-p.y()/H),0,0);};
  forAll(U,i)U[i]=vel(mesh.C()[i]);
  forAll(U.boundaryField(),p)if(U.boundaryField()[p].fixesValue())forAll(U.boundaryField()[p],i)U.boundaryFieldRef()[p][i]=vel(mesh.Cf().boundaryField()[p][i]);
 }
 surfaceScalarField phi(IOobject("phi",runTime.timeName(),mesh,IOobject::NO_READ,IOobject::AUTO_WRITE),fvc::flux(U));
 auto& vb=refCast<mixedFvPatchScalarField>(V.boundaryFieldRef()[electrode]);
 auto& cc=refCast<mixedFvPatchScalarField>(c.boundaryFieldRef()[electrode]);
 while(runTime.loop()){
  V.storePrevIter();c.storePrevIter();
  scalarField old(V.primitiveField());
  const scalarField delta(vb.patch().deltaCoeffs());
  forAll(vb,i){
   scalar eta=vm-eq-vb[i],ep=std::exp(min(a*beta*eta,scalar(40))),em=std::exp(min(-(1-a)*beta*eta,scalar(40)));
   scalar j=tertiary?j0*max(cc[i],scalar(0))/cb*ep:j0*(ep-em);
   scalar g=tertiary?a*beta*j:j0*beta*(a*ep+(1-a)*em);
   g=max(g,scalar(1e-20));vb.valueFraction()[i]=g/(kappa.value()*delta[i]+g);vb.refValue()[i]=vb[i]+j/g;vb.refGrad()[i]=0;
  }
  vb.setUpdated(false);V.correctBoundaryConditions();solve(fvm::laplacian(kappa,V));V.relax();
  if(tertiary){
   forAll(cc,i){scalar eta=vm-eq-vb[i];scalar rate=j0/(n*F*cb)*std::exp(min(a*beta*eta,scalar(40)));cc.valueFraction()[i]=rate/(diff.value()*delta[i]+rate);cc.refValue()[i]=0;cc.refGrad()[i]=0;}
   cc.setUpdated(false);c.correctBoundaryConditions();solve(fvm::div(phi,c)-fvm::laplacian(diff,c));c.relax();
  }
  scalar change=gMax(mag(V.primitiveField()-old));
  Info<<"Time = "<<runTime.timeName()<<" maxDeltaV = "<<change<<" current_A = "<<gSum(kappa.value()*vb.snGrad()*vb.patch().magSf())<<nl;
  runTime.write();
 }
 OFstream os(runTime.path()/"electrode.csv");os.precision(14);os<<"x,y,z,area,V"; if(tertiary) os<<",c"; os<<",j"<<nl;
 scalarField j(kappa.value()*vb.snGrad());
 forAll(vb,i){const vector& x=mesh.Cf().boundaryField()[electrode][i];os<<x.x()<<','<<x.y()<<','<<x.z()<<','<<vb.patch().magSf()[i]<<','<<vb[i]; if(tertiary) os<<','<<cc[i]; os<<','<<j[i]<<nl;}
 OFstream balance(runTime.path()/"fluxes.csv");balance.precision(14);balance<<"patch,area,outward_current_A,outward_molar_rate_mol_s"<<nl;
 surfaceScalarField cf(fvc::interpolate(c));
 forAll(mesh.boundary(),p){
  if(mesh.boundary()[p].type()=="empty")continue;
  scalarField current(-kappa.value()*V.boundaryField()[p].snGrad()*mesh.magSf().boundaryField()[p]);
  scalarField molar(phi.boundaryField()[p]*cf.boundaryField()[p]-diff.value()*c.boundaryField()[p].snGrad()*mesh.magSf().boundaryField()[p]);
  balance<<mesh.boundary()[p].name()<<','<<gSum(mesh.magSf().boundaryField()[p])<<','<<gSum(current)<<','<<gSum(molar)<<nl;
 }
 Info<<"End"<<endl;return 0;
}
