"""Recompute the lesson's wall statistics from foamToVTK -name VTKwalls output."""
from pathlib import Path
import csv,json,math,re
import vtk,numpy as np
from vtk.util.numpy_support import vtk_to_numpy

def measure(case,result):
    case=Path(case);key=case.name
    patches=['plate'] if key=='transition' else ['bottomWall'] if key.startswith('flat-') else ['lowerWall','upperWall']
    Uref=5.4 if key=='transition' else 69.4 if key.startswith('flat-') else 10.0
    rows=[]
    for patch in patches:
        files=list((case/'VTKwalls'/patch).glob('*.vtk'))
        if not files:raise RuntimeError('Missing wall output: '+patch)
        datasets=[]
        for f in files:
            r=vtk.vtkPolyDataReader();r.SetFileName(str(f));r.ReadAllFieldsOn();r.ReadAllScalarsOn();r.ReadAllVectorsOn();r.Update();o=r.GetOutput()
            t=o.GetFieldData().GetArray('TimeValue');t=float(t.GetTuple1(0)) if t else result['time'];datasets.append((t,o.NewInstance()))
            datasets[-1][1].DeepCopy(o)
        t,o=max(datasets,key=lambda a:a[0]);center=vtk.vtkCellCenters();center.SetInputData(o);center.Update();xyz=vtk_to_numpy(center.GetOutput().GetPoints().GetData())
        sizes=vtk.vtkCellSizeFilter();sizes.SetInputData(o);sizes.ComputeAreaOn();sizes.Update();area=vtk_to_numpy(sizes.GetOutput().GetCellData().GetArray('Area'))
        stress=vtk_to_numpy(o.GetCellData().GetArray('wallShearStress'));yp=vtk_to_numpy(o.GetCellData().GetArray('yPlus'));cf=2*abs(stress[:,0])/Uref**2
        for i in range(len(area)):
            rows.append(dict(patch=patch,time=t,x_m=float(xyz[i,0]),y_m=float(xyz[i,1]),z_m=float(xyz[i,2]),area_m2=float(area[i]),wallShearStress_x_m2_s2=float(stress[i,0]),Cf=float(cf[i]),yPlus=float(yp[i])))
    with (case/'wall-statistics.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    stats={'reference_velocity_m_s':Uref,'coefficient_definition':'Cf=2*abs(kinematic wallShearStress.x)/Uref^2','patches':{}}
    for patch in patches:
        a=[r for r in rows if r['patch']==patch];yp=np.array([r['yPlus'] for r in a]);area=np.array([r['area_m2'] for r in a]);cf=np.array([r['Cf'] for r in a])
        stats['patches'][patch]=dict(face_count=len(a),mean_yPlus=float(yp.mean()),area_mean_yPlus=float(area@yp/area.sum()),min_yPlus=float(yp.min()),max_yPlus=float(yp.max()),mean_Cf=float(cf.mean()),area_mean_Cf=float(area@cf/area.sum()))
    if key.startswith('flat-'):
        a=[r for r in rows if r['x_m']>.2];x=np.array([r['x_m'] for r in a]);cf=np.array([r['Cf'] for r in a]);ref=.0592*(Uref*x/1.388e-5)**(-.2)
        rms=float(np.sqrt(np.mean(((cf-ref)/ref)**2)));stats.update(Cf_correlation_relative_RMS=rms,comparison='unweighted RMS over wall faces with x>0.2 m; Cf_ref=0.0592*(69.4*x/1.388e-5)^(-0.2)',sample_count=len(a))
        with (case/'wall-comparison.csv').open('w',newline='') as f:
            w=csv.writer(f);w.writerow(['x_m','Cf','Cf_reference','relative_error']);w.writerows(zip(x,cf,ref,(cf-ref)/ref))
    elif key=='transition':
        exp=np.loadtxt(case/'validation/exptData/T3A.dat');a=sorted(rows,key=lambda r:r['x_m']);x=np.array([r['x_m'] for r in a]);cf=np.array([r['Cf'] for r in a]);target=exp[:,0]/1000
        assert min(target)>=min(x) and max(target)<=max(x),'Experiment outside sampled plate'
        pred=np.interp(target,x,cf);rms=float(np.sqrt(np.mean(((pred-exp[:,1])/exp[:,1])**2)));stats.update(experiment_relative_RMS=rms,comparison='linear interpolation to all T3A measured x values; x converted from mm to m; unweighted relative RMS',sample_count=len(exp))
        with (case/'wall-comparison.csv').open('w',newline='') as f:
            w=csv.writer(f);w.writerow(['x_m','Cf','Cf_experiment','relative_error']);w.writerows(zip(target,pred,exp[:,1],(pred-exp[:,1])/exp[:,1]))
    result['wall_statistics']=stats
    return result

if __name__=='__main__':
    p=Path(__file__).resolve().parent;result=json.loads((p/'metrics.json').read_text());measure(p,result);(p/'metrics.json').write_text(json.dumps(result,indent=2));print(json.dumps(result['wall_statistics'],indent=2))
