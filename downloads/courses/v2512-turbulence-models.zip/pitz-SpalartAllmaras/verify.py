"""Run with pvpython. Reference checks and physical diagnostics are reported separately."""
from pathlib import Path
import json,math,re,sys,csv
import vtk,numpy as np
from vtk.util.numpy_support import vtk_to_numpy
case=Path(__file__).resolve().parent;key=case.name;data=[];checks=[];diagnostics=[]
for p in (case/'VTK').rglob('*.vtk'):
 rd=vtk.vtkUnstructuredGridReader();rd.SetFileName(str(p));rd.ReadAllFieldsOn();rd.ReadAllScalarsOn();rd.ReadAllVectorsOn();rd.Update();o=rd.GetOutput()
 if not o.GetNumberOfCells():continue
 t=o.GetFieldData().GetArray('TimeValue');t=float(t.GetTuple1(0));cc=vtk.vtkCellCenters();cc.SetInputData(o);cc.Update();xx=vtk_to_numpy(cc.GetOutput().GetPoints().GetData());vv=vtk.vtkCellSizeFilter();vv.SetInputData(o);vv.ComputeVolumeOn();vv.Update();vol=vtk_to_numpy(vv.GetOutput().GetCellData().GetArray('Volume'))
 f={o.GetCellData().GetArrayName(i):vtk_to_numpy(o.GetCellData().GetArray(i)) for i in range(o.GetCellData().GetNumberOfArrays())};data.append(dict(time=t,xyz=xx,volume=vol,region=p.parent.relative_to(case/'VTK').as_posix(),**f))
assert data,'No internal VTK data';data.sort(key=lambda a:a['time']);f=data[-1];v=f['volume'];x=f['xyz'];initial=data[0]
runtime=all(np.isfinite(a['volume']).all() and (a['volume']>0).all() and all(np.isfinite(value).all() for n,value in a.items() if isinstance(value,np.ndarray)) for a in data)
def metric(name,value,ref,tol,relative=True,diagnostic=False):
 err=abs(value-ref)/(abs(ref) or 1) if relative else abs(value-ref);row=dict(name=name,value=float(value),reference=float(ref),error=float(err),tolerance=tol,passed=bool(err<=tol));(diagnostics if diagnostic else checks).append(row)
alpha=[n for n in f if n.startswith('alpha.')]
if alpha:
 metric('phase_lower_bound_violation',max(0,-min(f[n].min() for n in alpha)),0,1e-5,False);metric('phase_upper_bound_violation',max(0,max(f[n].max() for n in alpha)-1),0,1e-5,False)
 if len(alpha)>1:metric('phase_sum_max_error',np.max(abs(sum(f[n] for n in alpha)-1)),0,3e-6,False)
if key.startswith('disc-'):
 mass=float(v@f['alpha.water']);m0=float(initial['volume']@initial['alpha.water']);metric('closed_phase_volume',mass,m0,1e-3)
 center=(v*f['alpha.water'])@x/mass;expected=np.array([.5+f['time'],.5+.5*f['time']]);metric('centroid_distance_m',np.linalg.norm(center[[0,2]]-expected),0,.08,False)
 metric('initial_geometry_volume',m0,math.pi*.25**2*.1,.02)
elif key.startswith('static-drop'):
 p=f['p'];a=f['alpha.water'];dp=float(p[a>.99].mean()-p[a<1e-8].mean());metric('Laplace_pressure_cylinder_Pa',dp,.35,.2)
 metric('parasitic_velocity_m_s',np.linalg.norm(f['U'],axis=1).max(),0,.001,False,True)
elif key=='four-phase':
 for n in alpha:metric('closed_volume_'+n,float(v@f[n]),float(initial['volume']@initial[n]),1e-4)
elif key=='drift':
 a=f['alpha.sludge'];rho=1996*a+996*(1-a);u=996/rho*(-.002198)*10**(-285.84*np.maximum(a,0));metric('drift_velocity_relative_L2',np.linalg.norm(f['Udm'][:,1]-u)/np.linalg.norm(u),0,.005,False)
elif key=='particles':
 log=(case/'log.MPPICFoam').read_text();injected=[float(a) for a in re.findall(r'mass introduced\s*=\s*([\deE.+-]+)',log)];mass=[float(a) for a in re.findall(r'Current mass in system\s*=\s*([\deE.+-]+)',log)];metric('parcel_mass_kg',mass[-1],injected[-1],1e-8)
elif key.startswith('cavity-Ra'):
 Ra=int(key.removeprefix('cavity-Ra'));ref={1000:1.118,10000:2.243,100000:4.519,1000000:8.8}[Ra];sel=x[:,0]<x[:,0].min()+1e-6;hot=float(np.mean((305-f['T'][sel])/x[sel,0])/10);sel=x[:,0]>x[:,0].max()-1e-6;cold=float(np.mean((f['T'][sel]-295)/(1-x[sel,0]))/10);metric('de_Vahl_Davis_Nu',hot,ref,.08);metric('hot_cold_Nu_balance',hot,cold,.005)
elif key.startswith('radiation-'):
 expected=4*5.670374419e-8*300**4;metric('black_cavity_G_relative_max_error',np.max(abs(f['G']-expected))/expected,0,1e-5,False);metric('equilibrium_temperature_K',np.max(abs(f['T']-300)),0,1e-3,False)
elif key=='cht-wall':
 error=[];volume=[]
 for a in data:
  if a['time']!=f['time']:continue
  xx=a['xyz'][:,0];q=100/(.05/1+.05/2);exact=400-q*(np.minimum(xx,.05)+np.maximum(xx-.05,0)/2);error.extend((a['T']-exact)**2);volume.extend(a['volume'])
 metric('two_region_temperature_relative_L2',np.sqrt(np.average(error,weights=volume))/100,0,.002,False)
elif key=='mhd':
 sel=x[:,0]>18;yy=x[sel,1];u=f['U'][sel,0];Ha=20;expected=(1-np.cosh(Ha*yy)/math.cosh(Ha))/(1-math.tanh(Ha)/Ha);metric('Hartmann_profile_relative_L2',np.linalg.norm(u-expected)/np.linalg.norm(expected),0,.15,False)
elif key=='dns':
 order=np.lexsort((x[:,2],x[:,1],x[:,0]));u=f['U'][order].reshape(16,16,16,3);energy=.5*np.mean(np.sum(u*u,axis=3));uh=np.fft.fftn(u,axes=(0,1,2))/16**3;metric('Parseval_energy',.5*np.sum(abs(uh)**2),energy,1e-6)
elif key=='les':
 diagnostics.append(dict(name='statistical_validation',passed=False,comparison='The bundled 0.2 s start-up is not a converged channel statistic; use the full-run configuration and compare measured Re_tau with the DNS reference.'))
elif key in ('throttle','compressible','euler','electric','mixing','porous-vof','porous-block','buoyant','cht') or key.startswith(('flat-','pitz-')):
 diagnostics.append(dict(name='engineering_case_validation',passed=False,comparison='This reduced run checks initial evolution and field invariants. Long-time profiles, experimental comparisons and grid/time refinement are separate checks described in the lesson.'))
result=dict(case=key,time=float(f['time']),cells=len(v),runtime_passed=runtime,reference_checks=checks,diagnostics=diagnostics,passed=bool(runtime and all(a['passed'] for a in checks)))
from wall_metrics import measure
measure(case,result)
(case/'metrics.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));sys.exit(not result['passed'])
