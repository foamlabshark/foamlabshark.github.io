"""比较 v2512 实际结果与理想气体 Riemann 解或斜激波关系。"""
from pathlib import Path
import math,re,json,csv,sys
import numpy as np
import vtk
from vtk.util.numpy_support import vtk_to_numpy
P=Path.cwd()

def number(text,key):return float(re.search(r'\b'+key+r'\s+([\d.eE+-]+)\s*;',text).group(1))
thermo=(P/'constant/thermophysicalProperties').read_text()
R=8314.46261815324/number(thermo,'molWeight');cp=number(thermo,'Cp');gamma=cp/(cp-R)

def read(p):
    r=vtk.vtkUnstructuredGridReader();r.SetFileName(str(p));r.ReadAllFieldsOn();r.ReadAllScalarsOn();r.ReadAllVectorsOn();r.Update();d=r.GetOutput()
    time=d.GetFieldData().GetArray('TimeValue');t=float(time.GetTuple1(0))
    cent=vtk.vtkCellCenters();cent.SetInputData(d);cent.Update();xyz=vtk_to_numpy(cent.GetOutput().GetPoints().GetData())
    size=vtk.vtkCellSizeFilter();size.SetInputData(d);size.ComputeVolumeOn();size.Update();v=vtk_to_numpy(size.GetOutput().GetCellData().GetArray('Volume'))
    f={d.GetCellData().GetArrayName(i):vtk_to_numpy(d.GetCellData().GetArray(i)) for i in range(d.GetCellData().GetNumberOfArrays())}
    assert np.isfinite(v).all() and (v>0).all()
    assert all(np.isfinite(a).all() for a in f.values())
    return t,xyz,v,f

def riemann(x,t,left,right,g):
    rl,ul,pl=left;rr,ur,pr=right;al=math.sqrt(g*pl/rl);ar=math.sqrt(g*pr/rr)
    def f(p,r,p0,a):
        if p>p0:return (p-p0)*math.sqrt(2/((g+1)*r)/(p+(g-1)/(g+1)*p0))
        return 2*a/(g-1)*((p/p0)**((g-1)/(2*g))-1)
    lo=min(pl,pr)*1e-12;hi=max(pl,pr)*10
    while f(hi,rl,pl,al)+f(hi,rr,pr,ar)+ur-ul<0:hi*=10
    for _ in range(100):
        mid=(lo+hi)/2
        if f(mid,rl,pl,al)+f(mid,rr,pr,ar)+ur-ul>0:hi=mid
        else:lo=mid
    ps=(lo+hi)/2;us=.5*(ul+ur+f(ps,rr,pr,ar)-f(ps,rl,pl,al))
    out=[]
    for xi in x/t:
        side=-1 if xi<=us else 1
        r,u,p,a=(rl,ul,pl,al) if side<0 else (rr,ur,pr,ar)
        if ps>p:
            shock=u+side*a*math.sqrt((g+1)/(2*g)*ps/p+(g-1)/(2*g))
            if side*(xi-shock)>0:out.append((r,u,p));continue
            rs=r*(ps/p+(g-1)/(g+1))/((g-1)/(g+1)*ps/p+1);out.append((rs,us,ps))
        else:
            ast=a*(ps/p)**((g-1)/(2*g));head=u+side*a;tail=us+side*ast
            if side*(xi-head)>=0:out.append((r,u,p));continue
            if side*(xi-tail)<=0:out.append((r*(ps/p)**(1/g),us,ps));continue
            uf=2/(g+1)*(-side*a+(g-1)/2*u+xi)
            af=2/(g+1)*(a-side*(g-1)/2*(u-xi))
            out.append((r*(af/a)**(2/(g-1)),uf,p*(af/a)**(2*g/(g-1))))
    return np.array(out),{'star_pressure_Pa':ps,'contact_velocity_m_s':us}

metrics=[]
def metric(name,value,reference,tolerance,relative=True):
    error=abs(value-reference)/(abs(reference) or 1) if relative else abs(value-reference)
    metrics.append(dict(name=name,value=float(value),reference=float(reference),error=float(error),tolerance=tolerance,passed=bool(error<=tolerance)))

data=sorted([read(p) for p in (P/'VTK').glob('*.vtk')],key=lambda x:x[0]);t,xyz,vol,f=data[-1]
rho=f.get('rho',f['p']/(R*f['T']));u=f['U'][:,0]
if 'wedge' in P.name:
    theta=math.radians(15);M=5/math.sqrt(gamma*R);g=gamma
    func=lambda b:2/math.tan(b)*(M*M*math.sin(b)**2-1)/(M*M*(g+math.cos(2*b))+2)-math.tan(theta)
    vals=np.linspace(math.asin(1/M)+1e-6,math.pi/2-1e-6,1000)
    lo,hi=next((a,b) for a,b in zip(vals[:-1],vals[1:]) if func(a)*func(b)<0)
    for _ in range(80):
        mid=(lo+hi)/2
        if func(mid)>0:hi=mid
        else:lo=mid
    beta=(lo+hi)/2;ratio=1+2*g/(g+1)*(M*M*math.sin(beta)**2-1)
    x,y=xyz[:,0],xyz[:,1];sel=(x>.08)&(x<.18)&(y>x*math.tan(theta)+.007)&(y<x*math.tan(beta)-.007)
    assert sel.sum()>10
    actual=np.dot(vol[sel],f['p'][sel])/vol[sel].sum();angle=np.degrees(np.arctan2(f['U'][sel,1],f['U'][sel,0]));angle=float(np.dot(vol[sel],angle)/vol[sel].sum())
    metric('激波后压力比',actual,ratio,.06);metric('激波后转向角_度',angle,15,1,False)
    details=dict(Mach=M,shock_angle_degrees=math.degrees(beta),sample_cells=int(sel.sum()),sample_region='0.08<x<0.18; away from wall and shock by 0.007 m')
    out=np.column_stack([x,y,f['p'],f['U'][:,0],f['U'][:,1]]);header='x,y,p,Ux,Uy'
else:
    left=(100000/(R*348.432),0,100000);right=(10000/(R*278.746),0,10000)
    exact,details=riemann(xyz[:,0],t,left,right,gamma)
    for name,actual,reference,scale in [('密度',rho,exact[:,0],left[0]),('速度',u,exact[:,1],math.sqrt(gamma*left[2]/left[0])),('压力',f['p'],exact[:,2],left[2])]:
        error=float(np.dot(vol,abs(actual-reference))/vol.sum()/scale);metric(name+'剖面归一化平均绝对误差',error,0,.025,False)
    initial=data[0];v0=initial[2];f0=initial[3];rho0=f0.get('rho',f0['p']/(R*f0['T']))
    metric('域内总质量',float(vol@rho),float(v0@rho0),1e-5)
    E=f['p']/(gamma-1)+.5*rho*np.sum(f['U']**2,axis=1)
    E0=f0['p']/(gamma-1)+.5*rho0*np.sum(f0['U']**2,axis=1)
    metric('域内总能量',float(vol@E),float(v0@E0),1e-5)
    out=np.column_stack([xyz[:,0],rho,exact[:,0],u,exact[:,1],f['p'],exact[:,2]]);header='x,rho,rho_reference,Ux,Ux_reference,p,p_reference'
np.savetxt(P/'comparison.csv',out,delimiter=',',header=header,comments='')
report=dict(case=P.name,time=t,cells=len(vol),gas_constant=R,gamma=gamma,reference=details,metrics=metrics,passed=all(m['passed'] for m in metrics))
(P/'metrics.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2));sys.exit(not report['passed'])
