/* First-order conservative teaching solver, GPL-3.0-or-later. */
#include "fvCFD.H"
int main(int argc,char *argv[]){
 #include "setRootCase.H"
 #include "createTime.H"
 #include "createMesh.H"
 IOdictionary p(IOobject("transportProperties",runTime.constant(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE));
 scalar u=p.get<scalar>("DarcyVelocity"),porosity=p.get<scalar>("porosity"),ratio=p.get<scalar>("mobilityRatio");
 volScalarField S(IOobject("S",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::AUTO_WRITE),mesh);
 surfaceScalarField flux(IOobject("wettingFlux",runTime.timeName(),mesh,IOobject::NO_READ,IOobject::NO_WRITE),mesh,dimensionedScalar(dimVolume/dimTime,Zero));
 auto ff=[&](scalar s){return sqr(s)/(sqr(s)+ratio*sqr(1-s));};
 while(runTime.loop()){
  S.correctBoundaryConditions();
  forAll(mesh.neighbour(),f){scalar q=u*mesh.Sf()[f].x();label up=q>=0?mesh.owner()[f]:mesh.neighbour()[f];flux[f]=q*ff(S[up]);}
  forAll(flux.boundaryField(),p){
   const auto& patch=mesh.boundary()[p];
   if(patch.type()=="empty")continue;
   forAll(patch,i){scalar q=u*mesh.Sf().boundaryField()[p][i].x();flux.boundaryFieldRef()[p][i]=q*ff(q>=0?S[patch.faceCells()[i]]:S.boundaryField()[p][i]);}
  }
  S.primitiveFieldRef()-=runTime.deltaTValue()/porosity*fvc::div(flux)().primitiveField();
  Info<<"Time = "<<runTime.timeName()<<" minS = "<<gMin(S)<<" maxS = "<<gMax(S)<<nl;
  runTime.write();
 }
 Info<<"End"<<endl;return 0;
}
