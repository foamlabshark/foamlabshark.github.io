# VOF 多相流与溃坝 · OpenCFD OpenFOAM v2512

## 先找对运行目录

本包用于配套课程，包含原始输入，不是软件安装包，也不把打包检查称作物理验证。先解压到自己可写的 Linux 工作目录，再进入 `v2512-vof-dambreak`；保留一个未改动副本用于对照。

官方案例目录：
- `tutorials/multiphase/interFoam/laminar/damBreak`

建议起点：`tutorials/multiphase/interFoam/laminar/damBreak/damBreak`。

```bash
# 在新终端中先加载已安装 v2512 的环境；路径以你的安装为准
source /usr/lib/openfoam/openfoam2512/etc/bashrc
echo "$WM_PROJECT_VERSION"
blockMesh -help
# 以下命令从本包根目录执行
source ./environment.sh
cd tutorials/multiphase/interFoam/laminar/damBreak/damBreak
bash Allrun
```

每一步都检查退出码和日志；前一步失败时停止，不要继续执行。`checkMesh` 还应检查失败项汇总，不能只看 Shell 退出码。脚本需要 Linux Shell，不能在 Windows PowerShell 中直接执行 OpenFOAM 命令。MPI、m4、Python 3、gnuplot 等额外工具按具体案例说明准备。

## 这个合集怎样用于练习

从内层 damBreak/Allrun 启动基础算例，它依次恢复 0.orig、生成网格、setFields 初始化和运行 interFoam。外层 Allrun 可创建 damBreakFine 并进行并行计算，需要额外资源。0.orig/alpha.water 不是最终初始水柱，setFields 后才建立本课指定水域；在运行前保存 alpha.water 截面。原始字典的 maxCo、maxAlphaCo、nAlphaSubCycles 应分别阅读，不能仅观察速度场 Co。本包只核验源码、路径与依赖，没有本轮溃坝计算结果。

官方 Allrun 使用 `$WM_PROJECT_DIR/bin/tools/RunFunctions`，`#includeEtc` 使用已安装 v2512 的模板，因此必须安装完整、同分支同版本的 OpenFOAM。environment.sh 只将 FOAM_TUTORIALS 指向本包 tutorials，并不替换 WM_PROJECT_DIR；请在专用终端中使用。它使几何资源从本包读取，不依赖另一套教程的位置。部分字典宏里的 `${../name}` 是字典作用域引用，并不是缺失的父目录文件。

## 对照与运行证据

包内原始教程文件、资源、包含文件及相对链接已经逐项核对；不等于已完成这些案例的 CFD 计算。除方腔课程明确引用的既有基础运行外，本轮官方合集没有新增完整求解证据。FoamLab 新教学案例如有 RUN-VERIFICATION.txt，应按其版本、输入哈希和运行范围阅读，不能外推到整个合集。

计算结果通常写到案例时间目录；监测对象写入 postProcessing/。先核对单位、边界与日志，再看图。比较不同设置时建立独立副本，记录改动；不要将一个案例的结果图作为另一个参数组合的证据。

## 来源、许可与完整性

来源与版本见 SOURCE.txt，完整 GPL 文本见 COPYING；原始版权头和字典代码保留。UPSTREAM.sha256 记录原始文件内容哈希，SYMLINKS.txt 记录为跨平台解压展开的链接，DEPENDENCIES.txt 记录包含关系、系统依赖和生成步骤。MANIFEST.sha256 可用于检查下载后文件完整性。

本包由 `tools/content/refine-core-courses.py` 生成；课程文字在旧 `build-core.py` 生成后由该脚本后处理。无需重新编辑官方源文件即可重新生成同一下载包。
