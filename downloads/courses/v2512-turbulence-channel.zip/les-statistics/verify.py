"""检查周期通道流量与统计字段，分别报告 DNS 差异和统计漂移。"""
from pathlib import Path
import json,re,math,sys
import numpy as np
import vtk
from vtk.util.numpy_support import vtk_to_numpy
case=Path(__file__).resolve().parent
def load(p):
 r=vtk.vtkUnstructuredGridReader();r.SetFileName(str(p));r.ReadAllFieldsOn();r.ReadAllScalarsOn();r.ReadAllVectorsOn();r.Update();d=r.GetOutput()
 if not d.GetNumberOfCells():return None
 cc=vtk.vtkCellCenters();cc.SetInputData(d);cc.Update()
 ss=vtk.vtkCellSizeFilter();ss.SetInputData(d);ss.ComputeVolumeOn();ss.Update()
 f={d.GetCellData().GetArrayName(i):vtk_to_numpy(d.GetCellData().GetArray(i)) for i in range(d.GetCellData().GetNumberOfArrays())}
 return dict(time=d.GetFieldData().GetArray('TimeValue').GetTuple1(0),xyz=vtk_to_numpy(cc.GetOutput().GetPoints().GetData()),volume=vtk_to_numpy(ss.GetOutput().GetCellData().GetArray('Volume')),**f)
data=[x for p in (case/'VTK').glob('*.vtk') if (x:=load(p)) is not None]
assert data,'没有导出的内部网格字段'
f=max(data,key=lambda x:x['time']);vol=f['volume']
checks=[]
def check(name,value,reference,tolerance):
 e=abs(value-reference)/(abs(reference) or 1)
 checks.append(dict(name=name,value=float(value),reference=reference,error=float(e),tolerance=tolerance,passed=bool(e<=tolerance)))
check('end_time_s',f['time'],240,1e-6)
check('bulk_velocity_m_s',np.average(f['U'][:,0],weights=vol),.1335,1e-3)
check('mean_bulk_velocity_m_s',np.average(f['UMean'][:,0],weights=vol),.1335,.005)
components=f['UPrime2Mean'].shape[1]
assert components in (6,9),components
# foamToVTK 的 6 分量顺序为 xx yy zz xy yz xz；9 分量则为矩阵行序。
diagonal=[0,4,8] if components==9 else [0,1,2]
check('negative_resolved_variance',max(0,-float(f['UPrime2Mean'][:,diagonal].min())),0,1e-9)
for field in ('U','UMean','UPrime2Mean'):
 checks.append(dict(name='finite_'+field,passed=bool(np.isfinite(f[field]).all())))
blocks=re.split(r'^Time = ',(case/'log.pimpleFoam').read_text(),flags=re.M)[1:]
g=[]
for b in blocks:
 values=re.findall(r'pressure gradient = ([0-9.eE+-]+)',b)
 if values:g.append((float(b.split()[0]),float(values[-1])))
g=np.array(g);use=g[:,0]>=120;ut=math.sqrt(g[use,1].mean());ret=ut/2e-5
y=np.round(f['xyz'][:,1],9);ys=np.unique(y)
u=np.array([np.average(f['UMean'][y==yy,0],weights=vol[y==yy]) for yy in ys]);sel=ys<1
dns=np.loadtxt(case/'reference/chan395.means');yp=ys[sel]*ut/2e-5;up=u[sel]/ut
ref=np.interp(yp,dns[:,1],dns[:,2]);profile=float(np.sqrt(np.mean(((up-ref)/np.maximum(ref,1))**2)))
chunks=[]
for start,end in [(120,160),(160,200),(200,240)]:
 s=(g[:,0]>=start)&(g[:,0]<end);chunks.append(dict(start=start,end=end,Re_tau=float(math.sqrt(g[s,1].mean())/2e-5)))
drift=(max(b['Re_tau'] for b in chunks)-min(b['Re_tau'] for b in chunks))/ret
diagnostics=[dict(name='DNS_Re_tau',value=ret,reference=392.24,relative_error=abs(ret/392.24-1)),
 dict(name='DNS_mean_profile_relative_RMS',value=profile),
 dict(name='window_Re_tau_relative_spread',value=drift,tolerance=.02,passed=drift<.02,blocks=chunks)]
result=dict(case=case.name,time=f['time'],cells=len(vol),reference_checks=checks,diagnostics=diagnostics,
 passed=all(c['passed'] for c in checks),statistically_converged=drift<.02,
 note='passed 表示流量与字段检查通过；统计窗口仍需按分块差异继续检验。')
(case/'metrics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(not result['passed'])
