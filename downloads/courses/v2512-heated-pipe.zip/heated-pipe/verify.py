"""Run with pvpython; compare actual finite-volume results to reference equations."""
from pathlib import Path
import json,math,csv,sys,re
import numpy as np
import vtk
from vtk.util.numpy_support import vtk_to_numpy
case=Path(__file__).resolve().parent
ref=json.loads((case/'reference.json').read_text());files=list((case/'VTK').glob('*.vtk'))
def read(p):
 r=vtk.vtkUnstructuredGridReader();r.SetFileName(str(p));r.ReadAllFieldsOn();r.ReadAllScalarsOn();r.ReadAllVectorsOn();r.Update();d=r.GetOutput()
 tm=d.GetFieldData().GetArray('TimeValue');time=float(tm.GetTuple1(0)) if tm else float(p.stem.rsplit('_',1)[-1])
 cent=vtk.vtkCellCenters();cent.SetInputData(d);cent.Update();xyz=vtk_to_numpy(cent.GetOutput().GetPoints().GetData())
 size=vtk.vtkCellSizeFilter();size.SetInputData(d);size.ComputeVolumeOn();size.Update();vol=vtk_to_numpy(size.GetOutput().GetCellData().GetArray('Volume'))
 fields={d.GetCellData().GetArrayName(i):vtk_to_numpy(d.GetCellData().GetArray(i)) for i in range(d.GetCellData().GetNumberOfArrays())}
 return time,xyz,vol,fields
data=sorted((read(p) for p in files),key=lambda x:x[0]);assert data,'No VTK data';time,xyz,vol,f=data[-1]
assert np.isfinite(vol).all() and (vol>0).all();assert all(np.isfinite(v).all() for v in f.values())
typ=ref['type'];x=xyz[:,0];observed=f.get('T',f.get('V'));exact=None;metrics=[]
if typ in ('linear','composite','secondary','tertiary'):
 name='V' if typ in ('secondary','tertiary') else 'T'
 text=(case/f'{time:g}'/name).read_text();m=re.search(r'internalField\s+nonuniform\s+List<scalar>\s+\d+\s*\((.*?)\)\s*;',text,re.S)
 if m:observed=np.fromstring(m[1],sep=' ')
 # Recover the exact uniform-grid centres; legacy VTK serialises coordinates as float32.
 n=len(x);x=(np.rint(x/ref['length']*n-.5)+.5)*ref['length']/n
def metric(name,value,reference,tolerance,relative=True):
 error=abs(value-reference)/(abs(reference) or 1) if relative else abs(value-reference)
 metrics.append(dict(name=name,value=float(value),reference=float(reference),error=float(error),tolerance=float(tolerance),passed=bool(error<=tolerance)))
def profile(exact,scale):
 error=float(np.sqrt(np.dot(vol,(observed-exact)**2)/vol.sum())/scale)
 metric('relative_profile_L2',error,0,ref['tolerance'],False)
if typ=='erfc':
 exact=np.array([ref['cold']+(ref['hot']-ref['cold'])*math.erfc(v/(2*math.sqrt(ref['diffusivity']*ref['time']))) for v in x]);profile(exact,ref['hot']-ref['cold'])
elif typ=='composite':
 q=(ref['hot']-ref['cold'])/(ref['interface']/ref['D1']+(ref['length']-ref['interface'])/ref['D2'])
 exact=ref['hot']-q*(np.minimum(x,ref['interface'])/ref['D1']+np.maximum(x-ref['interface'],0)/ref['D2']);profile(exact,ref['hot']-ref['cold'])
elif typ in ('linear','upscaled'):
 exact=ref['left']+(ref['right']-ref['left'])*x/ref['length'];profile(exact,abs(ref['left']-ref['right']))
 if typ=='upscaled':metric('macro_Darcy_velocity',float(vol@f['U'][:,0]/vol.sum()),ref['velocity'],ref['tolerance'])
elif typ=='theis':
 def e1(u):
  if u<1:
   value=-.5772156649015329-math.log(u);term=1
   for k in range(1,60):term*=-u/k;value-=term/k
   return value
  a=np.linspace(0,10,2001);return float(np.trapz(np.exp(-u*np.exp(a)),a))
 r=np.linalg.norm(xyz[:,:2],axis=1);u=r*r*ref['storage']/(4*ref['K']*ref['time']);exact=np.array([ref['Q']/(4*math.pi*ref['K']*ref['thickness'])*e1(v) for v in u]);sel=(r>=ref['rmin'])&(r<=ref['rmax']);error=float(np.linalg.norm((observed-exact)[sel])/np.linalg.norm(exact[sel]));metric('Theis_profile_L2',error,0,ref['tolerance'],False)
elif typ=='pipe':
 text=(case/f'{time:g}'/'T').read_text();match=re.search(r'internalField\s+nonuniform\s+List<scalar>\s+\d+\s*\((.*?)\)\s*;',text,re.S)
 if match:observed=np.fromstring(match[1],sep=' ')
 rows=list(csv.DictReader((case/'boundary.csv').open()));station=min((float(a['x']) for a in rows if a['patch']=='wall'),key=lambda xx:abs(xx-x.max()));wall=[a for a in rows if a['patch']=='wall' and abs(float(a['x'])-station)<1e-9]
 last=x>x.max()-1e-7;weights=vol[last]*f['U'][last,0];tb=float(np.dot(weights,observed[last])/weights.sum());grad=sum(float(a['area'])*float(a['snGrad']) for a in wall)/sum(float(a['area']) for a in wall);Nu=grad*2*ref['radius']/(ref['wall']-tb);metric('Nusselt_outlet',Nu,ref['Nusselt'],ref['tolerance'])
elif typ in ('secondary','tertiary'):
 beta=96485.33212/(8.314462618*ref['temperature']);ilim=96485.33212*ref.get('D',1e-9)*ref.get('bulk',1)/ref['length']
 def residual(i):
  eta=ref['Vm']-i*ref['length']/ref['kappa'];kin=ref['j0']*(math.exp(ref['alpha']*beta*eta)-math.exp(-(1-ref['alpha'])*beta*eta)) if typ=='secondary' else ref['j0']*(1-i/ilim)*math.exp(ref['alpha']*beta*eta)
  return i-kin
 lo=0;hi=ref['kappa']*ref['Vm']/ref['length'] if typ=='secondary' else ilim
 for _ in range(100):m=(lo+hi)/2;lo,hi=(m,hi) if residual(m)<0 else (lo,m)
 j=(lo+hi)/2;exact=j*(ref['length']-x)/ref['kappa'];profile(exact,max(exact))
 rows=list(csv.DictReader((case/'electrode.csv').open()));areas=np.array([float(a['area']) for a in rows]);js=np.array([float(a['j']) for a in rows]);mean=float(np.dot(areas,js)/areas.sum());metric('current_density',mean,j,ref['tolerance'])
 if typ=='tertiary':metric('limiting_current_fraction',mean/ilim,j/ilim,ref['tolerance'])
elif typ=='leveque':
 rows=list(csv.DictReader((case/'electrode.csv').open()));a=np.array([float(r['area']) for r in rows]);j=np.array([float(r['j']) for r in rows]);mean=float(a@j/a.sum());expected=96485.33212*ref['bulk']*.8075*(ref['D']**2*6*ref['Umean']/ref['height']/ref['length'])**(1/3);metric('Leveque_mean_current_density',mean,expected,ref['tolerance'])
elif typ=='recess':
 rows=list(csv.DictReader((case/'electrode.csv').open()));a=np.array([float(r['area']) for r in rows]);j=np.array([float(r['j']) for r in rows]);v=np.array([float(r['V']) for r in rows]);beta=96485.33212/(8.314462618*ref['temperature']);eta=ref['Vm']-v;kin=ref['j0']*(np.exp(ref['alpha']*beta*eta)-np.exp(-(1-ref['alpha'])*beta*eta));metric('Butler_Volmer_boundary_residual',float(np.max(abs(j-kin)))/float(np.max(abs(kin))),0,ref['tolerance'],False)
 mean=float(a@j/a.sum());cv=float(np.sqrt(a@((j-mean)**2)/a.sum())/mean);metrics.append(dict(name='current_nonuniformity_CV',value=cv,reference=None,error=None,tolerance=None,passed=True,comparison='Compare the two Wagner-number cases.'))
elif typ=='buckley':
 observed=f['S'];shock=1/math.sqrt(2);ff=lambda s:s*s/(s*s+(1-s)**2);df=lambda s:2*s*(1-s)/(s*s+(1-s)**2)**2
 speed=ff(shock)/shock;xi=x/(ref['DarcyVelocity']/ref['porosity']*ref['time']);exact=np.zeros_like(x)
 for i,q in enumerate(xi):
  if q>speed:continue
  lo=shock;hi=1
  for _ in range(60):m=(lo+hi)/2;lo,hi=(m,hi) if df(m)>q else (lo,m)
  exact[i]=(lo+hi)/2
 error=float(np.dot(vol,abs(observed-exact))/vol.sum());metric('saturation_L1',error,0,ref['tolerance'],False)
 metric('injected_wetting_volume',float(vol@observed)*ref['porosity'],ref['DarcyVelocity']*ref['time']*1e-6,1e-5)
elif typ in ('ergun','permeability'):
 solver='porousSimpleFoam' if typ=='ergun' else 'simpleFoam';log=(case/('log.'+solver)).read_text();vals=re.findall(r'pressure gradient\s*=\s*([\deE.+-]+)',log,re.I);assert vals,'No meanVelocityForce pressure gradient';grad=float(vals[-1]);speed=float(np.dot(vol,f['U'][:,0])/vol.sum());metric('prescribed_mean_velocity',speed,ref['Umean'],1e-5)
 if typ=='ergun':metric('Ergun_pressure_gradient_kinematic',grad,ref['nu']*ref['d']*speed+.5*ref['f']*speed*speed,ref['tolerance'])
 else:
  K=ref['porosity']*ref['nu']*speed/grad;metrics.append(dict(name='bulk_permeability_m2',value=K,reference=None,error=None,tolerance=None,passed=True,comparison='Compare with the refined cylinder-cell mesh; this value is measured, not an analytical reference.'))
else:raise ValueError(typ)
if (case/'fluxes.csv').exists():
 rows=list(csv.DictReader((case/'fluxes.csv').open()));currents=[float(r['outward_current_A']) for r in rows];metric('charge_balance_relative',abs(sum(currents))/(sum(abs(v) for v in currents) or 1),0,1e-5,False)
 if typ in ('tertiary','leveque'):
  rates=[float(r['outward_molar_rate_mol_s']) for r in rows];metric('reactant_balance_relative',abs(sum(rates))/(sum(abs(v) for v in rates) or 1),0,1e-4,False)
if exact is not None:
 with (case/'comparison.csv').open('w',newline='') as o:
  w=csv.writer(o);w.writerow(['x','y','z','numerical','reference','difference']);w.writerows([(*p,float(v),float(a),float(v-a)) for p,v,a in zip(xyz,observed,exact)])
result={'type':typ,'time':time,'cells':len(vol),'metrics':metrics,'passed':all(m['passed'] for m in metrics)}
(case/'metrics.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));sys.exit(not result['passed'])
