from pathlib import Path
import re,json
p=Path(__file__).resolve().parent
text=(p/'constant/gasSupply').read_text()
def value(key):return float(re.search(r'\b'+key+r'\s+([\d.eE+-]+)\s*;',text).group(1))
j=value('currentDensity');eta=value('faradaicEfficiency');T=value('temperature');pressure=value('absolutePressure')
assert j>=0 and 0<=eta<=1 and T>0 and pressure>0
F=96485.33212;R=8.314462618;speed=eta*j*R*T/(2*F*pressure)
template=(p/'0.orig/U.template').read_text()
(p/'0.orig/U').write_text(template.replace('@GAS_SPEED@',format(speed,'.16g')))
(p/'supply.json').write_text(json.dumps(dict(currentDensity=j,efficiency=eta,temperature=T,pressure=pressure,gasSpeed=speed,area=0.0002*0.000025,rate=speed*0.0002*0.000025),indent=2))
print('气体入口速度 / m/s:',speed)
