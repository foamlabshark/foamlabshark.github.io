from pathlib import Path
import json,sys
import vtk,numpy as np
from vtk.util.numpy_support import vtk_to_numpy
p=Path(__file__).resolve().parent;data=[]
for f in (p/'VTK').glob('*.vtk'):
    r=vtk.vtkUnstructuredGridReader();r.SetFileName(str(f));r.ReadAllScalarsOn();r.ReadAllVectorsOn();r.Update();o=r.GetOutput()
    if not o.GetNumberOfCells():continue
    t=o.GetFieldData().GetArray('TimeValue').GetTuple1(0)
    a=vtk_to_numpy(o.GetCellData().GetArray('alpha.water'))
    sizes=vtk.vtkCellSizeFilter();sizes.SetInputData(o);sizes.ComputeVolumeOn();sizes.Update();v=vtk_to_numpy(sizes.GetOutput().GetCellData().GetArray('Volume'))
    cc=vtk.vtkCellCenters();cc.SetInputData(o);cc.Update();xyz=vtk_to_numpy(cc.GetOutput().GetPoints().GetData())
    U=vtk_to_numpy(o.GetCellData().GetArray('U'))
    data.append(dict(time=float(t),gas=float(v@(1-a)),lower=float(a.min()),upper=float(a.max()),topgas=float((1-a)[xyz[:,1]>.0013].max()),finite=bool(np.isfinite(U).all() and np.isfinite(a).all())))
data.sort(key=lambda x:x['time']);assert data and data[0]['time']==0
supply=json.loads((p/'supply.json').read_text());rate=supply['rate'];initial=data[0]['gas'];checks=[]
for d in data[1:]:
    injected=rate*d['time'];error=abs(d['gas']-initial-injected)/injected
    checks.append(dict(time=d['time'],gas=d['gas'],initial=initial,injected=injected,relative_injection_balance_error=error,passed=bool(error<0.02 and d['lower']>=-1e-6 and d['upper']<=1+1e-6 and d['topgas']<1e-6 and d['finite'])))
result=dict(case='hydrogen-gas-feed',scope='二维预置气体帽、规定气体入口；验证供气与体积收支，未模拟成核、电极反应反馈或三维脱离',end_time=data[-1]['time'],supply=supply,checks=checks,passed=bool(checks and abs(data[-1]['time']-.0015)<1e-10 and all(x['passed'] for x in checks)))
(p/'metrics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(not result['passed'])
