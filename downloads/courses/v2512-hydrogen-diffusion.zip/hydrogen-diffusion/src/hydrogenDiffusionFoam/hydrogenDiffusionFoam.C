/* FoamLab: prescribed HER molar flux and transient dissolved H2 diffusion.
   GPL-3.0-or-later. Isothermal, stationary liquid, no gas phase in this solver. */
#include "fvCFD.H"
#include "fixedGradientFvPatchFields.H"

int main(int argc, char *argv[])
{
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"

    IOdictionary properties
    (
        IOobject("hydrogenProperties", runTime.constant(), mesh,
                 IOobject::MUST_READ, IOobject::NO_WRITE)
    );
    dimensionedScalar D("D", dimViscosity, properties);
    const scalar jHER = properties.get<scalar>("currentDensity");
    const scalar efficiency = properties.get<scalar>("faradaicEfficiency");
    const scalar F = 96485.33212;
    const scalar molarFlux = efficiency*jHER/(2*F);
    if (jHER < 0 || efficiency < 0 || efficiency > 1 || D.value() <= 0)
    {
        FatalErrorInFunction << "Check current density, efficiency and D"
                            << exit(FatalError);
    }

    volScalarField cH2
    (
        IOobject("cH2", runTime.timeName(), mesh,
                 IOobject::MUST_READ, IOobject::AUTO_WRITE), mesh
    );
    const label electrode = mesh.boundaryMesh().findPatchID
    (
        properties.get<word>("electrodePatch")
    );
    if (electrode < 0)
        FatalErrorInFunction << "Missing electrode patch" << exit(FatalError);
    auto& electrodeField = refCast<fixedGradientFvPatchScalarField>
    (
        cH2.boundaryFieldRef()[electrode]
    );
    electrodeField.gradient() = molarFlux/D.value();
    cH2.correctBoundaryConditions();

    const scalar area = gSum(mesh.magSf().boundaryField()[electrode]);
    const scalar initialInventory = fvc::domainIntegrate(cH2).value();
    const scalar initialTime = runTime.value();
    OFstream balance(runTime.path()/"hydrogen-balance.csv");
    balance.precision(16);
    balance << "time_s,inventory_mol,generated_mol,residual_mol,wall_c_mol_m3"
            << nl;

    while (runTime.loop())
    {
        solve(fvm::ddt(cH2) - fvm::laplacian(D, cH2));
        const scalar inventory = fvc::domainIntegrate(cH2).value();
        const scalar generated = molarFlux*area*(runTime.value()-initialTime);
        const scalar wallC = gSum
        (
            cH2.boundaryField()[electrode]*mesh.magSf().boundaryField()[electrode]
        )/area;
        balance << runTime.value() << ',' << inventory << ',' << generated << ','
                << inventory-initialInventory-generated << ',' << wallC << nl;
        runTime.write();
    }

    OFstream profile(runTime.path()/"hydrogen-profile.csv");
    profile.precision(16);
    profile << "x_m,c_mol_m3" << nl;
    forAll(cH2, celli)
        profile << mesh.C()[celli].x() << ',' << cH2[celli] << nl;
    Info << "End" << endl;
    return 0;
}
