"""Check independent constant-flux diffusion solution and Faraday inventory."""
import csv, math, json, re
from pathlib import Path
here=Path(__file__).resolve().parent
profile=list(csv.DictReader((here/'hydrogen-profile.csv').open()))
history=list(csv.DictReader((here/'hydrogen-balance.csv').open()))
last=history[-1];t=float(last['time_s'])
props=(here/'constant/hydrogenProperties').read_text()
def parameter(name):
    return float(re.search(r'\b'+name+r'\s+(?:\[[^\]]+\]\s*)?([+\-\d.eE]+)\s*;',props).group(1))
D=parameter('D');J=parameter('currentDensity')*parameter('faradaicEfficiency')/(2*96485.33212)
def exact(x):
    z=x/(2*math.sqrt(D*t))
    return J/D*(2*math.sqrt(D*t/math.pi)*math.exp(-z*z)-x*math.erfc(z))
pairs=[(float(r['c_mol_m3']),exact(float(r['x_m']))) for r in profile]
l2=math.sqrt(sum((v-r)**2 for v,r in pairs)/sum(r*r for v,r in pairs))
inventory_error=max(abs(float(r['residual_mol']))/max(float(r['generated_mol']),1e-30) for r in history)
wall_error=abs(float(last['wall_c_mol_m3'])/exact(0)-1)
tests=[dict(name='profile_relative_L2',value=l2,tolerance=.003),
       dict(name='inventory_relative_error',value=inventory_error,tolerance=1e-8),
       dict(name='wall_concentration_relative_error',value=wall_error,tolerance=.003)]
for item in tests:item.update(reference=0,error=item['value'],passed=item['value']<item['tolerance'])
result=dict(time=t,cells=len(profile),wall_reference=exact(0),reference_checks=tests,
            passed=all(a['passed'] for a in tests))
(here/'metrics.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
raise SystemExit(0 if result['passed'] else 1)
