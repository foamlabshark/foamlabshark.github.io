# 阴极产氢与溶解氢扩散

OpenFOAM.com v2512；Python 3 用于解析解验证。进入本目录执行 `bash Allrun`，脚本编译并运行 `hydrogenDiffusionFoam`。

固定电流密度 10 A/m²、电流效率 1，电子数为 2。水中扩散系数 4.5e-9 m²/s。1 mm 长的液层起初没有溶解氢，电极施加法拉第摩尔通量，其余边界封闭。浓度数值采用 mol/m³、法拉第常数采用 C/mol，整份程序保持相同物质量单位。

本程序求瞬态溶解氢，不含气相。输出 浓度场 `cH2`、`hydrogen-balance.csv` 和 `hydrogen-profile.csv`。`verify.py` 比较半无限域恒通量解析解，并逐步检查法拉第产气量与溶解库存。1 s 内扩散长度远小于液层长度。
