from pathlib import Path
import re
for region in ['leftSolid','rightSolid']:
 p=Path('constant')/region/'polyMesh/boundary';text=p.read_text();patches=re.findall(r'(\w+)\s*\{([^{}]*)\}',text,re.S)
 for field in ['T','p']:
  s='FoamFile {version 2.0; format ascii; class volScalarField; object '+field+';} dimensions ['+('0 0 0 1 0 0 0' if field=='T' else '1 -1 -2 0 0 0 0')+']; internalField uniform '+('350' if field=='T' else '0')+'; boundaryField {'
  for name,body in patches:
   if not re.search(r'\bnFaces\s+\d+',body):continue
   if re.search(r'type\s+empty',body):bc='type empty;'
   elif field=='p':bc='type calculated; value uniform 0;'
   elif name=='hot':bc='type fixedValue; value uniform 400;'
   elif name=='cold':bc='type fixedValue; value uniform 300;'
   elif '_to_' in name:bc='type compressible::turbulentTemperatureCoupledBaffleMixed; Tnbr T; kappaMethod solidThermo; value uniform 350;'
   else:bc='type zeroGradient;'
   s+=name+' {'+bc+'}'
  o=Path('0')/region/field;o.parent.mkdir(parents=True,exist_ok=True);o.write_text(s+'}\n')

