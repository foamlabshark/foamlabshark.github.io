# Tutorial 12: Custom Momentum Source

## Goal

Extend an OpenFOAM momentum source and select source cells programmatically
instead of relying on a pre-existing cell set.

## Source and case

- `customActuationDiskSource.H/.C` define the source class and select cells.
- `customActuationDiskSourceTemplates.C` contains templated source assembly.
- `testCase/constant/fvModels` configures the source.

The example follows the `fvOption` run-time selection pattern and applies an
actuator-disk-like force to the momentum equation.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

The script creates the mesh and runs `simpleFoam`, which reads the custom source
from the case configuration.

## Expected result

The velocity field is modified in the source region. Inspect `Umagnitude.png`
or open the generated case in ParaView with `viewData.pvsm`.
