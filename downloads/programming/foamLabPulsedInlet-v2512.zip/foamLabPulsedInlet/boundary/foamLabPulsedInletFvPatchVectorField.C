// SPDX-License-Identifier: GPL-3.0-or-later
#include "foamLabPulsedInletFvPatchVectorField.H"
#include "fvPatchFieldMapper.H"
#include "addToRunTimeSelectionTable.H"
#include "mathematicalConstants.H"
#include "Time.H"

namespace Foam
{
foamLabPulsedInletFvPatchVectorField::foamLabPulsedInletFvPatchVectorField
(
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF
)
:
    fixedValueFvPatchVectorField(p, iF),
    meanSpeed_(0.1), amplitude_(0.5), frequency_(1), phase_(0),
    yMin_(0), height_(0.01), direction_(1, 0, 0)
{}

foamLabPulsedInletFvPatchVectorField::foamLabPulsedInletFvPatchVectorField
(
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF,
    const dictionary& dict
)
:
    fixedValueFvPatchVectorField(p, iF, dict),
    meanSpeed_(dict.get<scalar>("meanSpeed")),
    amplitude_(dict.get<scalar>("amplitude")),
    frequency_(dict.get<scalar>("frequency")),
    phase_(dict.getOrDefault<scalar>("phase", 0)),
    yMin_(dict.get<scalar>("yMin")),
    height_(dict.get<scalar>("height")),
    direction_(dict.get<vector>("direction"))
{
    if
    (
        height_ <= SMALL || mag(direction_) <= SMALL
     || meanSpeed_ < 0 || frequency_ < 0
     || amplitude_ < 0 || amplitude_ > 1
    )
    {
        FatalIOErrorInFunction(dict)
            << "Require height>0, nonzero direction, meanSpeed>=0, "
            << "frequency>=0 and 0<=amplitude<=1"
            << exit(FatalIOError);
    }
    direction_ /= mag(direction_);
    evaluate();
}

foamLabPulsedInletFvPatchVectorField::foamLabPulsedInletFvPatchVectorField
(
    const foamLabPulsedInletFvPatchVectorField& other,
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF,
    const fvPatchFieldMapper& mapper
)
:
    fixedValueFvPatchVectorField(other, p, iF, mapper),
    meanSpeed_(other.meanSpeed_), amplitude_(other.amplitude_),
    frequency_(other.frequency_), phase_(other.phase_),
    yMin_(other.yMin_), height_(other.height_), direction_(other.direction_)
{}

foamLabPulsedInletFvPatchVectorField::foamLabPulsedInletFvPatchVectorField
(
    const foamLabPulsedInletFvPatchVectorField& other
)
:
    fixedValueFvPatchVectorField(other),
    meanSpeed_(other.meanSpeed_), amplitude_(other.amplitude_),
    frequency_(other.frequency_), phase_(other.phase_),
    yMin_(other.yMin_), height_(other.height_), direction_(other.direction_)
{}

foamLabPulsedInletFvPatchVectorField::foamLabPulsedInletFvPatchVectorField
(
    const foamLabPulsedInletFvPatchVectorField& other,
    const DimensionedField<vector, volMesh>& iF
)
:
    fixedValueFvPatchVectorField(other, iF),
    meanSpeed_(other.meanSpeed_), amplitude_(other.amplitude_),
    frequency_(other.frequency_), phase_(other.phase_),
    yMin_(other.yMin_), height_(other.height_), direction_(other.direction_)
{}

void foamLabPulsedInletFvPatchVectorField::autoMap
(
    const fvPatchFieldMapper& mapper
)
{
    fixedValueFvPatchVectorField::autoMap(mapper);
}

void foamLabPulsedInletFvPatchVectorField::rmap
(
    const fvPatchVectorField& other,
    const labelList& addr
)
{
    fixedValueFvPatchVectorField::rmap(other, addr);
    const auto& inlet =
        refCast<const foamLabPulsedInletFvPatchVectorField>(other);
    meanSpeed_ = inlet.meanSpeed_;
    amplitude_ = inlet.amplitude_;
    frequency_ = inlet.frequency_;
    phase_ = inlet.phase_;
    yMin_ = inlet.yMin_;
    height_ = inlet.height_;
    direction_ = inlet.direction_;
}

void foamLabPulsedInletFvPatchVectorField::updateCoeffs()
{
    if (updated())
    {
        return;
    }

    const vectorField& centres = patch().Cf();
    const scalarField& areas = patch().magSf();
    scalarField shape(patch().size(), Zero);

    forAll(shape, facei)
    {
        const scalar eta =
            (centres[facei].y() - yMin_)/height_;
        if (eta >= 0 && eta <= 1)
        {
            shape[facei] = 6*eta*(1 - eta);
        }
    }

    const scalar area = gSum(areas);
    const scalar weightedShape = gSum(shape*areas);
    if (area <= VSMALL || weightedShape <= VSMALL)
    {
        FatalErrorInFunction
            << "Patch " << patch().name()
            << " must have positive area and faces within yMin..yMin+height"
            << exit(FatalError);
    }

    const scalar t = db().time().value();
    const scalar speed = meanSpeed_*
    (
        1 + amplitude_*sin
        (
            constant::mathematical::twoPi*frequency_*t + phase_
        )
    );

    operator==(direction_*speed*shape*(area/weightedShape));
    fixedValueFvPatchVectorField::updateCoeffs();
}

void foamLabPulsedInletFvPatchVectorField::write(Ostream& os) const
{
    fvPatchVectorField::write(os);
    os.writeEntry("meanSpeed", meanSpeed_);
    os.writeEntry("amplitude", amplitude_);
    os.writeEntry("frequency", frequency_);
    os.writeEntry("phase", phase_);
    os.writeEntry("yMin", yMin_);
    os.writeEntry("height", height_);
    os.writeEntry("direction", direction_);
    writeEntry("value", os);
}

makePatchTypeField
(
    fvPatchVectorField,
    foamLabPulsedInletFvPatchVectorField
);
}
