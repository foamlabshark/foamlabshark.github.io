# 随时间变化的抛物线入口：OpenFOAM v2512

在已加载 v2512 环境的 Linux 终端中，进入本目录：

```bash
bash Allwmake
cd case
bash Allrun
```

共享库写到 `$FOAM_USER_LIBBIN/libfoamLabPulsedInlet.so`。
源码在 boundary，算例在 case，初始入口参数在 case/0/U。
运行结果写到 0.25、0.5、0.75、1；入口平均速度应依次为
0.15、0.10、0.05、0.10 m/s。

首次运行建议直接逐个执行 blockMesh、checkMesh、icoFoam，查看屏幕输出。
重复比较采用独立算例目录，防止已有时间目录与新结果混在一起。
reference-results 提供配套示例计算的平均速度和通量数据。

## 重启

在 case 目录：

```bash
foamDictionary system/controlDict -entry startFrom -set latestTime
foamDictionary system/controlDict -entry endTime -set 1.25
icoFoam > log.restart 2>&1
```

1.25 s 的入口平均速度为 0.15 m/s。

## 两进程计算

复制一份干净的 case 后：

```bash
blockMesh
checkMesh
decomposePar
mpirun -np 2 icoFoam -parallel > log.parallel 2>&1
reconstructPar
```

## 源码

边界继承 fixedValueFvPatchVectorField，按全局面积权重归一化。
适用几何为沿 y 方向跨越高度 H 的平面矩形入口；示例流向为 +x。
源码采用 GPL-3.0-or-later，接口参考 OpenFOAM v2512 的 fvPatchField。
