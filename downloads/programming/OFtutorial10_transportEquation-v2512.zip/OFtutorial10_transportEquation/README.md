# Tutorial 10: Scalar Transport Equation

## Goal

Assemble and solve a steady convection-diffusion equation for a scalar field
using OpenFOAM finite-volume operators.

## Source and case

`OFtutorial10.C`:

1. creates the time and mesh;
2. reads the velocity and scalar fields;
3. reads the diffusion coefficient;
4. assembles the convection and diffusion terms; and
5. solves the scalar equation and writes the result.

The scalar field is `beta`; the transport coefficient is read from
`constant/transportProperties`.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

The case is meshed with `blockMesh` and then `ofTutorial10` is run once.

## Expected result

The transported scalar develops from the left and bottom boundary values. Open
the generated result in ParaView using `viewData.pvsm`.
