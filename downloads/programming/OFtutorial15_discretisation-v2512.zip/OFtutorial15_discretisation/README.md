# Tutorial 15: Discretisation Schemes

## Goal

Implement a custom face-interpolation scheme by combining linear and upwind
weights, then use it in a scalar transport case.

## Source and case

- `OFtutorial15.C` runs the transport calculation.
- `OFtutorial15.H` defines the custom interpolation scheme and its `weights()`
  implementation.
- `testCase/system/fvSchemes` selects the custom scheme.
- `testCase/refData` contains reference centreline data for comparison.

The one-dimensional case transports a scalar discontinuity through a uniform
flow.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

The script meshes the case and runs `scalarTransportFoam`. Afterward, use
`plotData.py` to compare linear, linear-upwind, and upwind results.

## Expected result

The blended scheme reduces upwind diffusion while avoiding the stronger
overshoot tendency of pure linear interpolation. The state file
`viewData.pvsm` shows the solution and `tutorial15.png` shows the expected
comparison.
