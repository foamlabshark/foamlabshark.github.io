# Tutorial 09: Runtime Post-Processing Utility

## Goal

Create a run-time function object that integrates flow through a face zone and
writes the result during a solver run.

## Source and case

- `pipeCalc.H/.C` implement a function object derived from OpenFOAM run-time
  post-processing and logging classes.
- `testCase/system/topoSetDict` creates the face zone.
- `testCase/system/controlDict` loads and configures the function object.

The key implementation stages are construction, file-name creation, header
writing, and the per-time-step `write()` calculation.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

The script creates the mesh and face zone, prepares the initial fields, then
runs `simpleFoam`. The utility is invoked through the solver's run-time
configuration.

## Expected result

The integrated flow rate is printed in the solver log and written below
`postProcessing`. The face zone can be inspected in ParaView with zones enabled.
