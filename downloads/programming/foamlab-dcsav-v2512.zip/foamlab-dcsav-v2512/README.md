# 用 Codex Astra 开发 D-CSAV 两相流求解器

配套课程：https://foamlabshark.github.io/read/?slug=programming-vibe-dcsav

## 内容

- `solver/`：独立编写的 OpenFOAM.com v2512 有限体积教学求解器。
- `cases/`：可编辑的初始场、物性字典、网格字典和求解设置。
- `prompts/`：00–11 共 12 份完整提示词，按顺序使用。
- `paper-notes.md`：方程、量纲和离散约定。
- `equation-map.md`：论文式号、变量与代码实现的对应关系。
- `verified-run/`：本站真实运行的日志、统计文件和末时刻场。

## 开始运行

在 Linux 终端加载 OpenFOAM v2512 环境，进入本目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
sh Allrun
sh Allverify
python3 restart-check.py
```

第一行对应 Ubuntu 软件包的安装位置；其他安装方式使用各自的 `etc/bashrc`。
`Allrun` 编译并运行均匀场、解析涡流、液滴三个算例；`Allverify` 增加三组时间步运行，与小步长结果比较；最后一条命令比较中间时刻续算和连续运行。

查看 `metrics.json`、`convergence.json` 和 `restart.json`。每项都有实际数值和检查状态。`pressure_second_order_observed` 记录压力是否表现出二阶收敛；本次值为 false，实际阶数为约 1.3–1.5。相场和速度约为二阶。

打开 `cases/drop/case.foam` 可在 ParaView 中查看结果。选择 `phase` 着色，添加 `Contour` 并设为 0 以显示界面；选择 `U` 的模查看速度。

## 重新运行与新建算例

```bash
sh Allclean
sh Allrun
python3 prepare.py --name drop-64 --mode drop --n 64 --dt 0.0005 --end 0.08
cd cases/drop-64
blockMesh
checkMesh
foamLabDCSAVFoam
```

`Allclean` 清理本包 `cases` 下生成的网格、计算时间目录、后处理目录和日志，保留原始输入。`prepare.py` 为新算例创建初始场、字典和 `case.foam`，不覆盖已经生成网格的算例。修改 C++ 后用 `sh Allwmake` 重新编译。

## 绘图

安装 NumPy、Matplotlib 和中文字体后：

```bash
python3 render.py --runs cases --output figures
```

如果希望直接使用包内的本站结果：

```bash
python3 render.py --runs verified-run/cases --output figures
```

基础验证、时间步比较和续算脚本只需要 Python 3 标准库。

## 实现范围与下一步

当前代码使用恒定正迁移率、正交网格、固定时间步和串行计算。保留变密度、变动力黏度、扩散质量通量，以及 r、Q、R、K、T 五个标量。首步为论文一阶格式，后续为 BDF2。相场子问题通过体积加权共轭梯度求解，速度采用黏性应力修正，压力使用增量及旋转修正。

当前基础算例和时间步检查可以直接复算。继续研究时，优先检查压力的时间收敛与空间算子一致性，再扩展变迁移率、重力和实体壁面。论文采用有限元法，本工程采用有限体积法；本包的能量曲线给出实际运行结果，尚未建立一般有限体积网格上的无条件能量稳定性证明。

论文：Jinpeng Zhang, Li Luo, Xiaoping Wang, JCP 532 (2025), 113943，https://doi.org/10.1016/j.jcp.2025.113943 。公式核对版本：https://arxiv.org/html/2410.10195v2 。

## 许可证

本包求解器、脚本和原创课程材料由 FoamLab 编写，按 GPL-3.0-or-later 发布；完整许可文本见 `COPYING`。OpenFOAM 为独立项目，遵循其原有许可证。论文引用指向原始出版物，包中不附论文全文。
