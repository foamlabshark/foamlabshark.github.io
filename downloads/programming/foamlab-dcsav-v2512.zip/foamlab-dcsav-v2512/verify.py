#!/usr/bin/env python3
"""Quantitative checks from solver output, without NumPy or cached answers."""
from pathlib import Path
import csv
import json
import math
import re
import sys

ROOT=Path(__file__).resolve().parent

def read_field(path):
    text=path.read_text(encoding='utf-8')
    match=re.search(r'internalField\s+nonuniform\s+List<(scalar|vector)>\s+(\d+)\s*\((.*?)\)\s*;',text,re.S)
    if not match:
        uniform=re.search(r'internalField\s+uniform\s+([^;]+);',text)
        if not uniform: raise ValueError(f'Expected ASCII internalField: {path}')
        count=json.loads((path.parents[1]/'caseInfo.json').read_text())['n']**2
        value=uniform[1].strip()
        if value.startswith('('): return [[float(x) for x in value.strip('()').split()] for _ in range(count)]
        return [float(value)]*count
    values=[float(x) for x in re.findall(r'[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?',match[3])]
    if match[1]=='vector': values=[values[i:i+3] for i in range(0,len(values),3)]
    assert len(values)==int(match[2]),path
    return values

def latest(case):
    return max((p for p in case.iterdir() if p.is_dir() and re.fullmatch(r'[\d.eE+-]+',p.name)),key=lambda p:float(p.name))

def history(case):
    rows={}
    for f in sorted((case/'postProcessing/dcsav').glob('*/history.csv'),key=lambda f:float(f.parent.name)):
        for row in csv.DictReader(f.open(encoding='utf-8')):
            r={k:float(v) for k,v in row.items()};rows[r['time']]=r
    return [rows[t] for t in sorted(rows)]

def rms(values): return math.sqrt(sum(x*x for x in values)/len(values))

def check_case(case):
    info=json.loads((case/'caseInfo.json').read_text())
    rows=history(case); first,last=rows[0],rows[-1]
    tests={}
    def record(key,value,reference,tolerance,error=None):
        error=abs(value-reference) if error is None else error
        tests[key]=dict(value=value,reference=reference,error=error,tolerance=tolerance,passed=math.isfinite(error) and error<=tolerance)
    record('completed_time',last['time'],info['end'],1e-10)
    record('relative_mass_change',max(abs(r['mass']-first['mass'])/abs(first['mass']) for r in rows),0,1e-8)
    record('phase_integral_change',max(abs(r['phaseIntegral']-first['phaseIntegral']) for r in rows),0,1e-8)
    record('maximum_CH_residual',max(r['chResidual'] for r in rows),0,1e-10)
    record('maximum_stress_iteration_change',max(r['stressResidual'] for r in rows),0,1e-10)
    record('maximum_auxiliary_deviation',max(abs(r[k]-1) for r in rows for k in ['r','Q','R','K','T']),0,1e-2)
    if info['mode']=='uniform':
        record('max_velocity',last['maxU'],0,1e-12)
        record('phase_min',last['phaseMin'],0.2,1e-12)
        record('phase_max',last['phaseMax'],0.2,1e-12)
        record('chemical_potential',max(abs(v+0.0768) for v in read_field(latest(case)/'muChem')),0,1e-12)
    if info['mode']=='vortex':
        n,L,t=info['n'],info['L'],last['time'];decay=math.exp(-2*info['eta1']/info['rho1']*t)
        exact=[];exact_p=[]
        for j in range(n):
            for i in range(n):
                x,y=(i+0.5)*L/n,(j+0.5)*L/n
                exact.extend([0.1*math.sin(x)*math.cos(y)*decay,-0.1*math.cos(x)*math.sin(y)*decay,0])
                exact_p.append(info['rho1']*0.1**2/4*(math.cos(2*x)+math.cos(2*y))*decay**2)
        got=[v for row in read_field(latest(case)/'U') for v in row]
        relative=rms([a-b for a,b in zip(got,exact)])/rms(exact)
        record('velocity_relative_L2_error',relative,0,0.01)
        got_p=read_field(latest(case)/'p');mean=sum(got_p)/len(got_p)
        relative_p=rms([a-mean-b for a,b in zip(got_p,exact_p)])/rms(exact_p)
        record('pressure_relative_L2_error',relative_p,0,0.04)
    if info['mode']=='drop':
        record('physical_energy_increase',max(0,last['physicalEnergy']-first['physicalEnergy']),0,1e-8)
        # The BDF1 start and BDF2 use different energies; compare BDF2 rows only.
        increases=[max(0,b['modifiedEnergy']-a['modifiedEnergy']) for a,b in zip(rows[2:],rows[3:])]
        record('maximum_BDF2_energy_increase',max(increases,default=0),0,1e-7)
        record('maximum_divergence_RMS',max(r['divRMS'] for r in rows),0,0.05)
    result=dict(case=case.name,parameters=info,tests=tests,passed=all(t['passed'] for t in tests.values()),initial=first,final=last)
    (case/'metrics.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    return result

if __name__=='__main__':
    names=sys.argv[1:] or ['uniform','vortex','drop']
    results=[check_case(ROOT/'cases'/name) for name in names]
    (ROOT/'metrics.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    for r in results:
        print(r['case'],'PASS' if r['passed'] else 'FAIL')
        for k,v in r['tests'].items():print(f'  {k}: {v["value"]:.8g}, limit={v["tolerance"]:.3g}, {v["passed"]}')
    sys.exit(0 if all(r['passed'] for r in results) else 1)
