/* SPDX-License-Identifier: GPL-3.0-or-later
 * FoamLab D-CSAV teaching implementation, OpenFOAM.com v2512.
 * Time discretization: Zhang, Luo & Wang, JCP 532 (2025) 113943.
 * Equation numbers: author preprint arXiv:2410.10195v2, (54)-(75).
 * Spatial method: orthogonal collocated finite volume, constant mobility.
 * This is an independently written FV implementation, not the authors' FEM code.
 */
#include "fvCFD.H"
#include <fstream>
#include <iomanip>
#include "phaseSolve.H"

int main(int argc, char *argv[])
{
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    if (Pstream::parRun())
    {
        FatalErrorInFunction << "Run this teaching implementation in serial."
            << exit(FatalError);
    }
    IOdictionary props
    (
        IOobject("dcsavProperties", runTime.constant(), mesh,
            IOobject::MUST_READ, IOobject::NO_WRITE)
    );
    dimensionedScalar rho1("rho1", dimDensity, props);
    dimensionedScalar rho2("rho2", dimDensity, props);
    dimensionedScalar eta1("eta1", dimDynamicViscosity, props);
    dimensionedScalar eta2("eta2", dimDynamicViscosity, props);
    dimensionedScalar lambda("lambda", dimForce/dimLength, props);
    dimensionedScalar epsilon("epsilon", dimLength, props);
    dimensionedScalar mobility("mobility", sqr(dimLength)/dimPressure/dimTime, props);
    dimensionedScalar alpha("alpha", dimless/dimEnergy, props);
    dimensionedVector gravity("g", dimAcceleration, props);
    const scalar s = props.get<scalar>("s");
    const scalar phaseTolerance = props.getOrDefault<scalar>("phaseTolerance", 1e-11);
    const scalar stressTolerance = props.getOrDefault<scalar>("stressTolerance", 1e-10);
    const label phaseMaxIter = props.getOrDefault<label>("phaseMaxIter", 3000);
    const label stressMaxIter = props.getOrDefault<label>("stressMaxIter", 40);
    if (min(rho1.value(), rho2.value()) <= 0 || min(eta1.value(), eta2.value()) <= 0
        || lambda.value() <= 0 || epsilon.value() <= 0 || mobility.value() <= 0
        || alpha.value() <= 0 || s < 0)
    {
        FatalErrorInFunction << "Invalid material or algorithm parameters." << exit(FatalError);
    }
    volScalarField phase(IOobject("phase", runTime.timeName(), mesh,
        IOobject::MUST_READ, IOobject::AUTO_WRITE), mesh);
    volScalarField muChem(IOobject("muChem", runTime.timeName(), mesh,
        IOobject::MUST_READ, IOobject::AUTO_WRITE), mesh);
    volVectorField U(IOobject("U", runTime.timeName(), mesh,
        IOobject::MUST_READ, IOobject::AUTO_WRITE), mesh);
    volScalarField p(IOobject("p", runTime.timeName(), mesh,
        IOobject::MUST_READ, IOobject::AUTO_WRITE), mesh);
    if (phase.dimensions() != dimless || muChem.dimensions() != dimPressure
        || U.dimensions() != dimVelocity || p.dimensions() != dimPressure)
    {
        FatalErrorInFunction << "Expected dimensionless phase, Pa muChem/p, m/s U."
            << exit(FatalError);
    }
    // Only homogeneous Neumann, cyclic and empty phase patches are supported.
    forAll(phase.boundaryField(), patchi)
    {
        word type = phase.boundaryField()[patchi].type();
        if (type != "zeroGradient" && type != "cyclic" && type != "empty")
            FatalErrorInFunction << "Unsupported phase patch: " << type << exit(FatalError);
        if (muChem.boundaryField()[patchi].type() != type)
            FatalErrorInFunction << "phase/muChem patch types must match." << exit(FatalError);
    }
    volScalarField omegaP(IOobject("omegaP", runTime.timeName(), mesh,
        IOobject::READ_IF_PRESENT, IOobject::AUTO_WRITE), p*0);
    volScalarField phasePrev(IOobject("phasePrev", runTime.timeName(), mesh,
        IOobject::READ_IF_PRESENT, IOobject::AUTO_WRITE), phase);
    volScalarField muPrev(IOobject("muPrev", runTime.timeName(), mesh,
        IOobject::READ_IF_PRESENT, IOobject::AUTO_WRITE), muChem);
    volVectorField UPrev(IOobject("UPrev", runTime.timeName(), mesh,
        IOobject::READ_IF_PRESENT, IOobject::AUTO_WRITE), U);
    volScalarField omegaPrev(IOobject("omegaPrev", runTime.timeName(), mesh,
        IOobject::READ_IF_PRESENT, IOobject::AUTO_WRITE), omegaP);
    IOdictionary state(IOobject("auxiliaryState", runTime.timeName(), "uniform", mesh,
        IOobject::READ_IF_PRESENT, IOobject::AUTO_WRITE));
    const wordList names({"r", "Q", "R", "K", "T"});
    scalarList aux(5, 1), auxPrev(5, 1);
    forAll(aux, i)
    {
        aux[i] = state.getOrDefault<scalar>(names[i], 1);
        auxPrev[i] = state.getOrDefault<scalar>(word(names[i]+"Prev"), 1);
    }
    label steps = state.getOrDefault<label>("steps", 0);
    const scalar dtValue = runTime.deltaTValue();
    if (steps && mag(state.get<scalar>("deltaT")-dtValue) > SMALL*dtValue)
        FatalErrorInFunction << "BDF2 restart requires the same deltaT." << exit(FatalError);
    if (runTime.value() > SMALL && !steps)
        FatalErrorInFunction << "Restart requires uniform/auxiliaryState and history fields."
            << exit(FatalError);
    if (steps)
    {
        for (const word& name : wordList({"phasePrev", "muPrev", "UPrev", "omegaPrev", "omegaP"}))
            if (!isFile(runTime.path()/runTime.timeName()/name))
                FatalErrorInFunction << "Missing restart field " << name << exit(FatalError);
    }
    const scalarField& V = mesh.V();
    auto integral = [&](const volScalarField& field) { return gSum(V*field.primitiveField()); };
    auto e0 = [&](const volScalarField& field)
    { return lambda.value()/epsilon.value()*integral(0.25*sqr(sqr(field)-scalar(1))-0.5*s*sqr(field)); };
    auto rhoOf = [&](const volScalarField& field)
    { return 0.5*(rho1+rho2)+0.5*(rho1-rho2)*field; };
    auto etaOf = [&](const volScalarField& field)
    { return 0.5*(eta1+eta2)+0.5*(eta1-eta2)*field; };
    volScalarField rho(IOobject("rho", runTime.timeName(), mesh,
        IOobject::NO_READ, IOobject::AUTO_WRITE), rhoOf(phase));
    volScalarField eta(IOobject("eta", runTime.timeName(), mesh,
        IOobject::NO_READ, IOobject::AUTO_WRITE), etaOf(phase));
    dimensionedScalar chi("chi", dimDensity, min(rho1.value(),rho2.value()));
    const fileName outDir(runTime.path()/"postProcessing"/"dcsav"/runTime.timeName());
    mkDir(outDir);
    std::ofstream metrics((outDir/"history.csv").c_str());
    metrics << std::setprecision(16)
        << "time,phaseIntegral,mass,physicalEnergy,modifiedEnergy,r,Q,R,K,T,divRMS,maxU,phaseMin,phaseMax,chResidual,stressResidual\n";
    auto physicalEnergy = [&]()
    {
        return integral(0.5*rho*magSqr(U)
            +0.5*lambda*epsilon*magSqr(fvc::grad(phase))
            +lambda/epsilon*0.25*sqr(sqr(phase)-scalar(1)));
    };
    auto logRow = [&](scalar modified, scalar chResidual, scalar stressResidual)
    {
        volScalarField divU(fvc::div(fvc::flux(U)));
        metrics << runTime.value() << ',' << integral(phase) << ',' << integral(rho)
            << ',' << physicalEnergy() << ',' << modified;
        for (scalar value : aux) metrics << ',' << value;
        metrics << ',' << Foam::sqrt(integral(sqr(divU))/gSum(V))
            << ',' << gMax(mag(U.primitiveField())) << ',' << gMin(phase.primitiveField())
            << ',' << gMax(phase.primitiveField()) << ',' << chResidual << ',' << stressResidual << '\n';
        metrics.flush();
    };
    logRow(physicalEnergy(), 0, 0);
    while (runTime.run())
    {
        ++runTime;
        if (mag(runTime.deltaTValue()-dtValue) > SMALL*dtValue)
            FatalErrorInFunction << "Use a fixed time step." << exit(FatalError);
        const bool first = (steps == 0);
        const scalar a = first ? 1 : 1.5;
        const scalar b = first ? -1 : -2;
        const scalar c = first ? 0 : 0.5;
        const dimensionedScalar dt("dt", dimTime, dtValue);
        volScalarField phN(phase), muN(muChem), pN(p), omN(omegaP), rhoN(rho);
        volVectorField uN(U);
        volScalarField rhoOld(rhoOf(phasePrev));
        volScalarField phStar(phase);
        if (!first) phStar = 2*phase-phasePrev;
        volScalarField muStar(muChem);
        if (!first) muStar = 2*muChem-muPrev;
        volVectorField uStar(U);
        if (!first) uStar = 2*U-UPrev;
        scalarList oldAux(aux), star(aux);
        if (!first) forAll(star,i) star[i] = 2*aux[i]-auxPrev[i];
        volScalarField nonlinear(lambda/epsilon*star[0]*(pow3(phStar)-(1+s)*phStar));
        surfaceScalarField uFlux(fvc::flux(uStar));
        volScalarField advection(fvc::div(uFlux* fvc::interpolate(phStar)));
        volScalarField phaseRhs
        (
            (-b*phN-c*phasePrev)/dt-star[1]*advection+mobility*fvc::laplacian(nonlinear)
        );
        scalar chResidual = solvePhase(phase, phaseRhs.primitiveField(), a/dtValue,
            mobility.value(), lambda.value(), epsilon.value(), s, phaseTolerance, phaseMaxIter);
        muChem = -lambda*epsilon*fvc::laplacian(phase)+lambda*s/epsilon*phase+nonlinear;
        muChem.correctBoundaryConditions();
        rho = rhoOf(phase);
        eta = etaOf(phase);
        if (gMin(rho.primitiveField()) <= 0 || gMin(eta.primitiveField()) <= 0)
            FatalErrorInFunction << "Non-positive material field. Refine space/time resolution."
                << exit(FatalError);
        // Face flux J has units kg/s. Its half-divergence term is essential.
        surfaceScalarField jFlux(0.5*(rho2-rho1)*mobility*fvc::snGrad(muStar)*mesh.magSf());
        surfaceScalarField massFlux(fvc::interpolate(rho)*uFlux+jFlux);
        volVectorField transport
        (
            fvc::div(massFlux,uStar)-0.5*fvc::div(massFlux)*uStar
        );
        volScalarField pressurePredictor(first ? pN+omN : pN+(4.0/3)*omN-(1.0/3)*omegaPrev);
        volVectorField capillary(phStar*fvc::grad(muStar));
        volScalarField rhoRate((a*rho+b*rhoN+c*rhoOld)/dt);
        volScalarField diagonal(star[3]*(a*rho/dt+0.5*rhoRate));
        volVectorField momentumRhs
        (
            -star[3]*rho*(b*uN+c*UPrev)/dt-star[2]*(transport+fvc::grad(pressurePredictor))
            -star[1]*capillary+rho*gravity
        );
        scalar stressResidual = GREAT;
        label correction = 0;
        for (; correction < stressMaxIter; ++correction)
        {
            volVectorField previous(U);
            fvVectorMatrix equation
            (
                fvm::Sp(diagonal,U)-fvm::laplacian(eta,U)
                == momentumRhs+fvc::div(eta*T(fvc::grad(U)))
            );
            equation.solve();
            stressResidual = gMax(mag(U.primitiveField()-previous.primitiveField()));
            if (stressResidual < stressTolerance) break;
        }
        if (stressResidual >= stressTolerance)
            FatalErrorInFunction << "Viscous stress iteration failed: " << stressResidual << exit(FatalError);
        volScalarField divU(fvc::div(fvc::flux(U)));
        dimensionedScalar pressureRate(first ? chi/(2*dt) : 3*chi/(2*dt));
        fvScalarMatrix pressureEquation(fvm::laplacian(omegaP) == star[4]*pressureRate*divU);
        pressureEquation.setReference(0,0);
        pressureEquation.solve();
        p = pN+omegaP;
        if (!first) p -= star[4]*eta*divU;
        p -= dimensionedScalar("meanP",dimPressure,integral(p)/gSum(V));
        p.correctBoundaryConditions();
        // Auxiliary updates: all RHS use the frozen extrapolated scalars.
        scalar e0New=e0(phase), e0N=e0(phN), e0Old=e0(phasePrev);
        scalar rRate = -(a*e0New+b*e0N+c*e0Old)/dtValue
            +star[0]*lambda.value()/epsilon.value()
            *integral((pow3(phStar)-(1+s)*phStar)*(a*phase+b*phN+c*phasePrev))/dtValue;
        scalar qRate = star[1]*integral(advection*muChem+(capillary & U));
        scalar RRate = star[2]*integral((transport+fvc::grad(pressurePredictor)) & U);
        scalar kineticNew=integral(0.5*rho*magSqr(U));
        scalar kineticN=integral(0.5*rhoN*magSqr(uN));
        scalar kineticOld=integral(0.5*rhoOld*magSqr(UPrev));
        scalar kRate = -(a*kineticNew+b*kineticN+c*kineticOld)/dtValue
            +star[3]*integral((rho*(a*U+b*uN+c*UPrev)/dt+0.5*rhoRate*U) & U);
        scalar tRate = integral(p*divU);
        if (!first)
            tRate += (2*dt/(3*chi)).value()*integral(fvc::grad(eta*divU) & fvc::grad(p));
        scalarList rates({rRate,qRate,RRate,kRate,star[4]*tRate});
        forAll(aux,i) aux[i]=(-b*oldAux[i]-c*auxPrev[i]+dtValue*alpha.value()*rates[i])/a;
        scalar modified = physicalEnergy();
        if (!first)
        {
            modified = 1.5*kineticNew-0.5*kineticN
                +lambda.value()*epsilon.value()/4*integral(magSqr(fvc::grad(phase))+magSqr(2*fvc::grad(phase)-fvc::grad(phN)))
                +lambda.value()*s/(4*epsilon.value())*integral(sqr(phase)+sqr(2*phase-phN))
                +dtValue*dtValue/(3*chi.value())*integral(magSqr(fvc::grad(p)))
                +0.5*(3*e0New-e0N);
            forAll(aux,i) modified += (3*aux[i]-oldAux[i]-2)/(2*alpha.value());
        }
        else forAll(aux,i) modified += (aux[i]-1)/alpha.value();
        logRow(modified,chResidual,stressResidual);
        phasePrev=phN; muPrev=muN; UPrev=uN; omegaPrev=omN;
        auxPrev=oldAux; ++steps;
        forAll(aux,i) { state.set(names[i],aux[i]); state.set(word(names[i]+"Prev"),auxPrev[i]); }
        state.set("steps",steps); state.set("deltaT",dtValue);
        runTime.write();
        Info<< "Time = " << runTime.timeName() << "; CH residual = " << chResidual
            << "; stress correction = " << stressResidual << nl;
    }
    Info<< "End" << endl;
    return 0;
}
