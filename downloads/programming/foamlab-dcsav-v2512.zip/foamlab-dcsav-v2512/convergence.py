#!/usr/bin/env python3
"""Same-grid time refinement against an independently run small time step."""
from pathlib import Path
import json
import math
from verify import read_field, latest, rms, check_case
ROOT=Path(__file__).resolve().parent
reference=ROOT/'cases/drop-reference'
ref={k:read_field(latest(reference)/k) for k in ['phase','U','p']}
def flat(values):return [x for v in values for x in v] if isinstance(values[0],list) else values
rows=[]
for name in ['drop-coarse','drop','drop-fine']:
    c=ROOT/'cases'/name;info=json.loads((c/'caseInfo.json').read_text());row={'case':name,'dt':info['dt']}
    for k in ref:
        got=flat(read_field(latest(c)/k));target=flat(ref[k])
        if k=='p':
            mean=sum(got)/len(got);got=[v-mean for v in got]
            mean=sum(target)/len(target);target=[v-mean for v in target]
        row[k+'_L2']=rms([a-b for a,b in zip(got,target)])
    rows.append(row)
for i in range(1,len(rows)):
    for k in ref: rows[i][k+'_order']=math.log2(rows[i-1][k+'_L2']/rows[i][k+'_L2'])
checks=[check_case(ROOT/'cases'/n)['passed'] for n in ['drop-coarse','drop-fine','drop-reference']]
# Refinement must reduce every field's error. Record actual orders, don't round to 2.
decreasing=all(rows[i][k+'_L2']<rows[i-1][k+'_L2'] for i in [1,2] for k in ref)
phase_velocity_second_order=all(1.8<rows[i][k+'_order']<2.3 for i in [1,2] for k in ['phase','U'])
pressure_second_order=all(1.8<rows[i]['p_order']<2.3 for i in [1,2])
result=dict(reference={'case':'drop-reference','deltaT':0.0000625,'kind':'same-grid numerical reference'},rows=rows,decreasing=decreasing,phase_velocity_second_order=phase_velocity_second_order,pressure_second_order_observed=pressure_second_order,passed=all(checks) and decreasing and phase_velocity_second_order)
(ROOT/'convergence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
raise SystemExit(0 if result['passed'] else 1)
