#!/usr/bin/env python3
"""Generate editable OpenFOAM cases. Python standard library only."""
from pathlib import Path
import argparse
import math

ROOT = Path(__file__).resolve().parent

def header(name, cls='dictionary'):
    return f'FoamFile\n{{ version 2.0; format ascii; class {cls}; object {name}; }}\n'

def write(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8')

def prepare(name, n=32, dt=0.001, end=0.08, mode='drop'):
    case = ROOT/'cases'/name
    if (case/'constant/polyMesh').exists():
        raise SystemExit(f'{case}: already meshed; use a new case name or Allclean.')
    L = 2*math.pi if mode == 'vortex' else 1.0
    eps, lam, M = (0.05, 0.02, 0.02)
    rho1, rho2 = 2.0, 1.0
    eta1, eta2 = (0.1, 0.05) if mode == 'vortex' else (0.03, 0.015)
    ph, vel, pressure, centres = [], [], [], []
    for j in range(n):
        for i in range(n):
            x, y = (i+0.5)*L/n, (j+0.5)*L/n
            centres.append((x,y))
            if mode == 'drop':
                radius = math.sqrt(((x-0.5)/1.25)**2+((y-0.5)*1.25)**2)
                ph.append(math.tanh((0.23-radius)/(math.sqrt(2)*eps)))
                vel.append((0,0,0)); pressure.append(0)
            elif mode == 'vortex':
                ph.append(1)
                vel.append((0.1*math.sin(x)*math.cos(y),-0.1*math.cos(x)*math.sin(y),0))
                pressure.append(rho1*0.1**2/4*(math.cos(2*x)+math.cos(2*y)))
            else:
                ph.append(0.2); vel.append((0,0,0)); pressure.append(0)
    mu = []
    for j in range(n):
        for i in range(n):
            v = ph[j*n+i]
            lap = (ph[j*n+(i+1)%n]+ph[j*n+(i-1)%n]
                +ph[((j+1)%n)*n+i]+ph[((j-1)%n)*n+i]-4*v)/(L/n)**2
            mu.append(lam*(-eps*lap+(v**3-v)/eps))
    patches = 'boundaryField\n{\n'+''.join(f'    {x} {{ type cyclic; }}\n' for x in ['left','right','bottom','top'])+'    frontAndBack { type empty; }\n}\n'
    def field(name, values, dims, vector=False):
        typ = 'vector' if vector else 'scalar'
        text = '\n'.join('('+' '.join(f'{v:.16g}' for v in row)+')' if vector else f'{row:.16g}' for row in values)
        write(case/'0'/name, header(name,'volVectorField' if vector else 'volScalarField')
            +f'dimensions {dims};\ninternalField nonuniform List<{typ}>\n{len(values)}\n(\n{text}\n);\n'+patches)
    field('phase', ph, '[0 0 0 0 0 0 0]')
    field('muChem', mu, '[1 -1 -2 0 0 0 0]')
    field('U', vel, '[0 1 -1 0 0 0 0]',True)
    field('p', pressure, '[1 -1 -2 0 0 0 0]')
    write(case/'constant/dcsavProperties', header('dcsavProperties')+f'''
rho1       [1 -3 0 0 0 0 0] {rho1};
rho2       [1 -3 0 0 0 0 0] {rho2};
eta1       [1 -1 -1 0 0 0 0] {eta1};
eta2       [1 -1 -1 0 0 0 0] {eta2};
lambda     [1 0 -2 0 0 0 0] {lam};
epsilon    [0 1 0 0 0 0 0] {eps};
mobility   [-1 3 1 0 0 0 0] {M};
alpha      [-1 -2 2 0 0 0 0] 0.01;
g          [0 1 -2 0 0 0 0] (0 0 0);
s          2;
phaseTolerance 1e-11;
phaseMaxIter 3000;
stressTolerance 1e-10;
stressMaxIter 40;
''')
    write(case/'system/blockMeshDict', header('blockMeshDict')+f'''
scale 1;
vertices ((0 0 0) ({L:.16g} 0 0) ({L:.16g} {L:.16g} 0) (0 {L:.16g} 0)
          (0 0 0.1) ({L:.16g} 0 0.1) ({L:.16g} {L:.16g} 0.1) (0 {L:.16g} 0.1));
blocks (hex (0 1 2 3 4 5 6 7) ({n} {n} 1) simpleGrading (1 1 1));
edges ();
boundary
(
 left {{ type cyclic; neighbourPatch right; faces ((0 4 7 3)); }}
 right {{ type cyclic; neighbourPatch left; faces ((1 2 6 5)); }}
 bottom {{ type cyclic; neighbourPatch top; faces ((0 1 5 4)); }}
 top {{ type cyclic; neighbourPatch bottom; faces ((3 7 6 2)); }}
 frontAndBack {{ type empty; faces ((0 3 2 1) (4 5 6 7)); }}
);
''')
    write(case/'system/controlDict',header('controlDict')+f'''
application foamLabDCSAVFoam;
startFrom startTime;
startTime 0;
stopAt endTime;
endTime {end:.12g};
deltaT {dt:.12g};
writeControl timeStep;
writeInterval {max(1,round(end/dt/4))};
purgeWrite 0;
writeFormat ascii;
writePrecision 16;
timeFormat general;
timePrecision 12;
runTimeModifiable false;
adjustTimeStep false;
''')
    write(case/'system/fvSchemes',header('fvSchemes')+'''
ddtSchemes { default Euler; }
gradSchemes { default Gauss linear; }
divSchemes { default Gauss linear; }
laplacianSchemes { default Gauss linear orthogonal; }
interpolationSchemes { default linear; }
snGradSchemes { default orthogonal; }
fluxRequired { default no; }
''')
    write(case/'system/fvSolution',header('fvSolution')+'''
solvers
{
 U { solver smoothSolver; smoother symGaussSeidel; tolerance 1e-12; relTol 0; }
 omegaP { solver PCG; preconditioner DIC; tolerance 1e-12; relTol 0; }
}
''')
    write(case/'caseInfo.json', __import__('json').dumps(dict(mode=mode,n=n,dt=dt,end=end,L=L,epsilon=eps,lambda_=lam,mobility=M,rho1=rho1,rho2=rho2,eta1=eta1,eta2=eta2),indent=2))
    write(case/'case.foam','')
    print(case)

if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--name');p.add_argument('--mode',choices=['uniform','vortex','drop'],default='drop')
    p.add_argument('--n',type=int,default=32);p.add_argument('--dt',type=float,default=0.001);p.add_argument('--end',type=float,default=0.08)
    args=p.parse_args()
    if args.name: prepare(args.name,args.n,args.dt,args.end,args.mode)
    else:
        prepare('uniform',8,0.001,0.01,'uniform')
        prepare('vortex',32,0.005,0.2,'vortex')
        prepare('drop',32,0.001,0.08,'drop')
