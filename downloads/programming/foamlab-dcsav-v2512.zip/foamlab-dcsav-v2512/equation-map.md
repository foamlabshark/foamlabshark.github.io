# 方程与实现对应表

式号采用作者预印本 arXiv:2410.10195v2。主程序为 `solver/foamLabDCSAVFoam.C`，相场线性求解位于 `solver/phaseSolve.H`。

## 字段与参数

| 论文符号 | 程序名称 | 类型或单位 |
|---|---|---|
| φ | phase | 单元标量场，无量纲 |
| μ | muChem | 单元标量场，Pa |
| u | U | 单元向量场，m/s |
| p | p | 单元标量场，Pa |
| ρ | rho | 单元标量场，kg/m³ |
| ν | eta | 单元标量场，动力黏度 Pa·s |
| λ | lambda | N/m |
| ε | epsilon | m |
| M | mobility | m²/(Pa·s)，本实现取常数 |
| α | alpha | J⁻¹ |
| s | s | 无量纲 |
| r、Q、R、K、T | aux[0] 至 aux[4] | 五个全局无量纲标量 |
| ω | omegaP | 压力增量场，Pa |

`J` 的定义为 `(rho2-rho1)*mobility*grad(muChem)/2`。`jFlux` 对应该通量在面上的法向积分，单位为 kg/s。`D(U)` 定义为速度梯度与其转置之和，不含 1/2。

## 时间推进

| 方程 | 二阶式号 | 对应实现 | 核对内容 |
|---|---|---|---|
| 相场输运 | (66) | `phaseRhs`、`solvePhase` | `phStar`、`uStar`、`star[1]`；迁移率为常数 |
| 化学势 | (67) | `nonlinear`、`muChem` 赋值 | 新相场隐式项与外推非线性项 |
| r 更新 | (68) | `e0`、`rRate` | E0 包含 λ/ε 及稳定化能量项 |
| Q 更新 | (69) | `qRate` | `advection*muChem` 与 `capillary & U` |
| 变密度动量 | (70) | `rhoRate`、`diagonal`、`momentumRhs`、`equation` | 新密度、新黏度、K*、J*、毛细力和完整黏性应力 |
| R 更新 | (71) | `RRate` | 动量输运及预测压力与新速度的内积 |
| K 更新 | (72) | `kineticNew/N/Old`、`kRate` | 三层动能差分及变密度时间项 |
| 压力增量 | (73) | `pressureRate`、`pressureEquation` | T*3χ/(2Δt)，χ 为两种材料密度的较小值 |
| 压力旋转修正 | (74) | `p = pN+omegaP` 及下一行 | −T*η div(U)，随后减去体积均值 |
| T 更新 | (75) | `tRate`、`rates[4]` | 压力做功与 β 梯度项；β=2Δt/(3χ) |
| 修正能量 | (77) | `modified` | 两层相场梯度、动能、自由能、压力梯度与辅助标量；减去常数 5/α |

代码以 `a=1.5`、`b=-2`、`c=0.5` 表示 BDF2 系数，差分为 `(a*xNew+b*xN+c*xOld)/dt`。外推值为 `2*xN-xOld`。`oldAux` 和 `star` 在本步开始时保存，所有辅助变量右端均使用同一组值。

首步采用式 (54)–(63)，系数为 `a=1,b=-1,c=0`，星号量取初值。压力预测采用 `pN+omN`，压力泊松系数为 `chi/(2*dt)`；首步压力更新与 T 方程分别按一阶格式处理。

## 空间离散与核查

相场使用体积加权共轭梯度，线性算子为 `a/dt I−Mλs/ε L+MλεL²`。两次 Laplacian 使用同一离散规则。求解结束后重新计算真实残差。

动量输运由面质量通量构成；黏性应力的转置梯度项在同一时间步内修正至收敛。压力采用增量及旋转修正。

`verify.py` 检查解析场、守恒、能量和迭代指标；`convergence.py` 分别记录相场、速度及压力的时间阶数；`restart-check.py` 比较连续运行与中间时刻续算。当前压力观测阶数约为 1.3–1.5，相关空间算子和初始压力处理为后续研究内容。
