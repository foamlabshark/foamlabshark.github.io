#!/usr/bin/env python3
"""Create a restart case from t=0.04 and compare its t=0.08 state."""
from pathlib import Path
import shutil
import subprocess
import re
import json
import sys
from verify import latest,read_field,rms
ROOT=Path(__file__).resolve().parent
source=ROOT/'cases/drop'; target=ROOT/'cases/drop-restart'
if '--compare' not in sys.argv:
    if target.exists():
        assert target.resolve().parent==(ROOT/'cases').resolve() and target.name=='drop-restart'
        shutil.rmtree(target)
    target.mkdir(exist_ok=False)
    for name in ['constant','system','0.04']:
        shutil.copytree(source/name,target/name)
    shutil.copy2(source/'caseInfo.json',target/'caseInfo.json')
    p=target/'system/controlDict'
    p.write_text(re.sub(r'startTime\s+0;', 'startTime 0.04;', p.read_text()))
    with (target/'log.foamLabDCSAVFoam').open('w') as log:
        subprocess.run(['foamLabDCSAVFoam','-case',str(target)],stdout=log,stderr=subprocess.STDOUT,check=True)
errors={}
for name in ['phase','muChem','U','p','omegaP']:
    a=read_field(latest(source)/name);b=read_field(latest(target)/name)
    if isinstance(a[0],list): a=[v for row in a for v in row];b=[v for row in b for v in row]
    errors[name]=max(abs(x-y) for x,y in zip(a,b))
def state(case):
    text=(latest(case)/'uniform/auxiliaryState').read_text()
    return {k:float(re.search(r'^'+k+r'\s+([^;]+);',text,re.M)[1]) for k in ['r','Q','R','K','T']}
a,b=state(source),state(target)
for k in a:errors[k]=abs(a[k]-b[k])
result=dict(maximum_absolute_errors=errors,tolerance=1e-9,passed=max(errors.values())<1e-9)
(ROOT/'restart.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
raise SystemExit(0 if result['passed'] else 1)
