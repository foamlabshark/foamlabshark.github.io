#!/usr/bin/env python3
"""Render course figures from computed fields. Requires numpy and matplotlib."""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import LinearSegmentedColormap
from verify import read_field,latest,history

p=argparse.ArgumentParser();p.add_argument('--runs',type=Path,default=Path(__file__).resolve().parent/'cases');p.add_argument('--output',type=Path,default=Path('figures'));args=p.parse_args()
out=args.output;out.mkdir(parents=True,exist_ok=True)
fonts={f.name for f in font_manager.fontManager.ttflist}
font=next((n for n in ['Microsoft YaHei','Noto Sans CJK SC','WenQuanYi Zen Hei','SimHei'] if n in fonts),'DejaVu Sans')
plt.rcParams.update({'font.family':font,'axes.unicode_minus':False,'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#7b8d87','text.color':'#29443d','axes.labelcolor':'#29443d','xtick.color':'#52655f','ytick.color':'#52655f','figure.facecolor':'#fffef9','axes.facecolor':'#fffef9','savefig.facecolor':'#fffef9'})
cmap=LinearSegmentedColormap.from_list('phase',['#547b9d','#e3ece3','#dbb167'])
def save(fig,name):fig.savefig(out/name,dpi=180,bbox_inches='tight');plt.close(fig)
x=np.linspace(-0.3,0.3,401);phase=-np.tanh(x/(np.sqrt(2)*0.05))
fig,ax=plt.subplots(1,2,figsize=(7.2,2.7),layout='constrained')
for a in ax:
    a.axvline(0,color='#78867e',ls='--',lw=1);a.set_xlabel('距界面中心的距离 / m');a.grid(alpha=.16)
ax[0].plot(x,phase,color='#267663',lw=2);ax[0].set_ylabel('相场 φ');ax[0].set_title('相场连续通过零点');ax[0].text(-.28,.55,'流体 1');ax[0].text(.11,-.6,'流体 2')
ax[1].plot(x,1.5+.5*phase,color='#b2843e',lw=2);ax[1].set_ylabel('密度 / (kg/m³)');ax[1].set_title('密度随相场变化')
save(fig,'phase-model.png')
case=args.runs/'drop';info=json.loads((case/'caseInfo.json').read_text());n=info['n'];L=info['L'];xy=(np.arange(n)+.5)*L/n;X,Y=np.meshgrid(xy,xy)
initial=np.array(read_field(case/'0/phase')).reshape(n,n);end=latest(case)
ph=np.array(read_field(end/'phase')).reshape(n,n);rho=np.array(read_field(end/'rho')).reshape(n,n);U=np.array(read_field(end/'U')).reshape(n,n,3);speed=np.linalg.norm(U,axis=2)
fig,axes=plt.subplots(2,2,figsize=(7.2,6.4),layout='constrained')
for a,Z,title,cm,units in zip(axes.flat,[initial,ph,rho,speed],['初始相场','0.08 s 的相场','0.08 s 的密度','0.08 s 的速度'],[cmap,cmap,'cividis','YlGnBu'],['φ','φ','kg/m³','m/s']):
    kw=dict(vmin=-1.02,vmax=1.02) if units=='φ' else {}
    im=a.pcolormesh(X,Y,Z,cmap=cm,shading='nearest',rasterized=True,**kw)
    a.contour(X,Y,initial if title=='初始相场' else ph,levels=[0],colors='#233e37',linewidths=.8)
    a.set(aspect='equal',xlabel='x / m',ylabel='y / m',title=title);fig.colorbar(im,ax=a,shrink=.8,label=units)
axes[1,1].quiver(X[::4,::4],Y[::4,::4],U[::4,::4,0],U[::4,::4,1],color='#172f35',alpha=.75)
save(fig,'drop-fields.png')
rows=history(case);t=np.array([r['time'] for r in rows]);energy=np.array([r['physicalEnergy'] for r in rows]);modified=np.array([r['modifiedEnergy'] for r in rows])
fig,ax=plt.subplots(2,1,figsize=(7.2,4.8),layout='constrained')
ax[0].plot(t,energy*1000,label='物理能量',color='#227563',lw=1.7);ax[0].plot(t[2:],modified[2:]*1000,'--',label='二阶修正能量',color='#bd8a37',lw=1.4);ax[0].set(ylabel='能量 / mJ',xlabel='时间 / s');ax[0].legend(frameon=False,ncol=2);ax[0].grid(alpha=.18)
for key in ['r','Q','R','K','T']:ax[1].plot(t,[(r[key]-1)*1e10 for r in rows],label=key,lw=1.4)
ax[1].set(xlabel='时间 / s',ylabel=r'辅助标量偏差 $\times 10^{10}$');ax[1].legend(frameon=False,ncol=5);ax[1].grid(alpha=.18)
save(fig,'validation.png')
conv=json.loads((args.runs.parent/'convergence.json').read_text())
fig,ax=plt.subplots(1,3,figsize=(7.4,2.6),layout='constrained');dt=np.array([r['dt'] for r in conv['rows']])
for a,key,title,unit in zip(ax,['phase','U','p'],['相场','速度','压力'],['无量纲','m/s','Pa']):
    err=np.array([r[key+'_L2'] for r in conv['rows']]);a.loglog(dt,err,'o-',color='#27755f',label='实测误差');a.loglog(dt,err[-1]*(dt/dt[-1])**2,'--',color='#bd8a37',lw=1,label='二阶斜率');a.set(title=title,xlabel='时间步 / s',ylabel='均方根误差 / '+unit);a.grid(alpha=.18,which='both')
ax[0].legend(frameon=False,fontsize=8);save(fig,'convergence.png')
fig=plt.figure(figsize=(8,4.5));gs=fig.add_gridspec(1,2,width_ratios=[1,1.1],left=.07,right=.96,bottom=.1,top=.78,wspace=.18)
a=fig.add_subplot(gs[0]);a.pcolormesh(X,Y,ph,cmap=cmap,shading='nearest');a.contour(X,Y,ph,levels=[0],colors='#25483e',linewidths=1.1);a.quiver(X[::4,::4],Y[::4,::4],U[::4,::4,0],U[::4,::4,1],color='#25483e',alpha=.7);a.set_aspect('equal');a.axis('off')
b=fig.add_subplot(gs[1]);b.axis('off');b.text(.04,.92,'从论文到两相流求解器',fontsize=17,weight='bold',va='top');b.text(.04,.68,'phase   muChem   U   p',fontsize=13,color='#28715f');b.text(.04,.48,'r     Q     R     K     T',fontsize=14,color='#947139');b.text(.04,.21,'提示词 · 算例配置 · 编译验证',fontsize=12);b.text(.04,.04,'OpenFOAM v2512',fontsize=11,color='#697b70');fig.text(.08,.9,'用 Codex Astra 实现 D-CSAV',fontsize=21,weight='bold');save(fig,'cover.png')
print(out)
