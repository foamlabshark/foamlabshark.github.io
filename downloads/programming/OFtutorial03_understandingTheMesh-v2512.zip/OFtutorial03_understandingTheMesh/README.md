# Tutorial 03: Understanding the Mesh

## Goal

Access mesh topology and geometry from C++, including cells, faces, points,
owners, neighbours, and boundary patches.

## Source and case

- `OFtutorial3.C` constructs the case time and `fvMesh`, then reports mesh
  entities and their connectivity.
- `testCase/system/blockMeshDict` defines a small mesh for inspection.

The example is intended to be read alongside the generated `constant/polyMesh`
files after `blockMesh` runs.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

`Allrun` creates the mesh and executes `ofTutorial3`.

## Expected result

The output lists mesh dimensions and representative topology/geometry data.
Use `checkMesh` in the case directory when experimenting with changes to
`blockMeshDict`.
