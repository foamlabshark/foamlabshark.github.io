#!/usr/bin/env python3
"""Compare this tutorial's uniform decay case with two reference solutions."""
import math
from pathlib import Path
import re
import sys

case = Path(sys.argv[1] if len(sys.argv) > 1 else "case")
props = (case / "constant/transportProperties").read_text()
control = (case / "system/controlDict").read_text()
initial = (case / "0/C").read_text()

def value(text, key):
    match = re.search(r"\b" + re.escape(key) + r"\s+(?:\[[^\]]*\]\s*)?([-+0-9.eE]+)\s*;", text)
    if not match:
        raise ValueError("Cannot read numerical entry: " + key)
    return float(match.group(1))

rate = value(props, "kDecay")
delta_t = value(control, "deltaT")
c0 = float(re.search(r"internalField\s+uniform\s+([-+0-9.eE]+)\s*;", initial).group(1))
table = case / "postProcessing/concentrationMean/0/volFieldValue.dat"
rows = [list(map(float, line.split())) for line in table.read_text().splitlines()
        if line.strip() and not line.lstrip().startswith("#")]
t, mean = rows[-1][:2]
steps = round(t / delta_t)
if not math.isclose(steps * delta_t, t, rel_tol=1e-9, abs_tol=1e-12):
    raise ValueError("This comparison expects a fixed time step from t=0.")
exact = c0 * math.exp(-rate * t)
discrete = c0 / (1 + rate * delta_t) ** steps

time_dirs = [p for p in case.iterdir() if p.is_dir()
             and re.fullmatch(r"[0-9.eE+-]+", p.name)
             and math.isclose(float(p.name), t, abs_tol=1e-10)]
field = (time_dirs[0] / "C").read_text()
uniform = re.search(r"internalField\s+uniform\s+([-+0-9.eE]+)\s*;", field)
if uniform:
    cells = [float(uniform.group(1))]
else:
    match = re.search(r"internalField\s+nonuniform\s+List<scalar>\s+(\d+)\s*\((.*?)\)\s*;", field, re.S)
    cells = list(map(float, match.group(2).split()))
    assert len(cells) == int(match.group(1))

print(f"time = {t:g} s; deltaT = {delta_t:g} s; kDecay = {rate:g} 1/s")
print(f"computed mean       = {mean:.12f}")
print(f"analytical solution = {exact:.12f}")
print(f"implicit Euler      = {discrete:.12f}")
print(f"absolute time error = {abs(mean-exact):.12g}")
print(f"relative time error = {abs(mean-exact)/abs(exact):.8%}")
print(f"recurrence error    = {abs(mean-discrete):.3e}")
print(f"cell max - cell min = {max(cells)-min(cells):.3e}")
if abs(mean-discrete) > 1e-9 or max(cells)-min(cells) > 1e-9:
    raise SystemExit("The field differs from the uniform implicit-decay case.")
