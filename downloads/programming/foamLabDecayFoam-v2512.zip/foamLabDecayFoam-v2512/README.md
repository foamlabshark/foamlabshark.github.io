# foamLabDecayFoam — OpenFOAM v2512

从 scalarTransportFoam 派生的标量输运与一阶衰减求解器。

先加载本机 OpenFOAM v2512 环境，随后在本目录执行：

```bash
bash Allwmake > log.build 2>&1
bash Allrun
python3 compare.py case
```

源代码位于 solver/；初始算例位于 case/；修改源码后重新编译，修改字典后重新运行。
compare.py 只依赖 Python 标准库，适用于本包的均匀初始场、固定时间步、t=0 开始的一阶衰减案例。

均匀初始浓度 C=1、U=0、零法向浓度梯度使解析解为 C=exp(-k*t)。
基准参数 k=2 /s，deltaT=0.05 s，t=1 s；隐式 Euler 数值为 1.1^(-20)=0.148643628024。
解析解为 exp(-2)=0.135335283237，二者差值是时间离散误差。
validation/ 保存 v2512 实际运行的均值表、日志和四组比较结果。

衰减方程及案例说明：https://foamlabshark.github.io/read/?slug=development-solver
原源码：OpenFOAM v2512 applications/solvers/basic/scalarTransportFoam。
代码许可：GPL-3.0-or-later，见 COPYING；原作者声明保留于源文件。
FoamLab 修改：增加无量纲标量 C、带量纲 kDecay、隐式衰减项与均值输出。
