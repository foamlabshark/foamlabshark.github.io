#!/bin/sh
set -eu
cd "$(dirname "$0")"

interactive=1
case "${1:-}" in
    --no-gui) interactive=0 ;;
    "") ;;
    *) echo "Usage: $0 [--no-gui]" >&2; exit 2 ;;
esac
if [ -z "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]; then
    interactive=0
fi

if postProcess -func sampleDict -latestTime > log.sampleDict 2>&1; then
    cat log.sampleDict
else
    status=$?
    cat log.sampleDict >&2
    exit "$status"
fi

latest_time=$(foamListTimes -latestTime)
if [ -z "$latest_time" ]; then
    echo "No computed time directory found. Run sh run_solver.sh first." >&2
    exit 1
fi
sample_dir="postProcessing/sampleDict/$latest_time"
for sample in l1_U.xy l2_U.xy; do
    if [ ! -s "$sample_dir/$sample" ]; then
        echo "Missing sampling output: $sample_dir/$sample" >&2
        exit 1
    fi
done

gnuplot -c gnuplot/gnuplot_script "$sample_dir" "$interactive"
