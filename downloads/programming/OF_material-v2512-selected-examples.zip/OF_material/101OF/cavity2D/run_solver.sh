#!/bin/sh
set -eu
cd "$(dirname "$0")"

# Capture stderr as well, and stop before the next stage on failure.
run_logged()
{
    application=$1
    if "$application" > "log.$application" 2>&1; then
        cat "log.$application"
    else
        status=$?
        cat "log.$application" >&2
        return "$status"
    fi
}

# Keep the supplied 0/ fields; -no-auto also avoids the v2512 auto-mode
# exit status 1 when this case has no 0.orig/ directory.
foamCleanTutorials -no-auto
run_logged blockMesh
run_logged checkMesh
run_logged icoFoam
