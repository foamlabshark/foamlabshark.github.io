#!/bin/sh
set -eu
cd "$(dirname "$0")"

sh ./run_solver.sh
sh ./run_sampling.sh "$@"
