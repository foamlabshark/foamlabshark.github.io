#!/usr/bin/env bash

if [[ ${WM_PROJECT_VERSION:-} != v2512 ]]; then
    source /usr/lib/openfoam/openfoam2512/etc/bashrc
fi

set -euo pipefail
cd -- "$(dirname -- "$0")"

foamCleanTutorials || true

blockMesh

checkMesh

rm -rf 0

cp -r 0_org 0

interFoam | tee log.solver

#decomposePar
#mpirun -np 4 interFoam -parallel | tee log.solver
