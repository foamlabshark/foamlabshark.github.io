#!/usr/bin/env bash

if [[ ${WM_PROJECT_VERSION:-} != v2512 ]]; then
    source /usr/lib/openfoam/openfoam2512/etc/bashrc
fi

set -euo pipefail
cd -- "$(dirname -- "$0")"

foamCleanTutorials || true

blockMesh

checkMesh

my_laplace_v1

#postProcess -func PecletNo

postProcess -func sampleDict -latestTime

if command -v gnuplot >/dev/null 2>&1; then
    gnuplot ./gnuplot/gnuplot_script
else
    echo "gnuplot not found; skipping plot generation." >&2
fi
