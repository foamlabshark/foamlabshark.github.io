# Tutorial 07: Custom Libraries

## Goal

Move reusable code into a shared library, compile it separately, and link a
solver against that library.

## Source and build

- `customLibrary/customLibrary.H/.C` defines the library API and implementation.
- `customLibrary/Make/files` and `Make/options` build `libcustomLibrary`.
- `OFtutorial7.C` uses the library.
- The top-level `Make/options` adds the include path and library link flag.

This is the standard pattern for code shared by multiple OpenFOAM applications.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

`Allwmake` builds the library first, then builds `ofTutorial7`. The case creates
the mesh before running the application.

## Expected result

The executable calls functionality supplied by `libcustomLibrary`. The library
is normally installed under `$FOAM_USER_LIBBIN`; `./Allwclean` removes generated
objects and library build products.
