#!/bin/bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
out=/mnt/hgfs/UbuntuShareFolder/.foamlab-build/programming
exec > "$out/core-snippets.log" 2>&1
echo VERSION="$WM_PROJECT_VERSION"
apt-cache policy openfoam2512-default
dpkg-query -W 'openfoam2512*' 2>/dev/null
dir=/home/shark/foamlab-core-snippets-20261002
mkdir -p "$dir"
cp -a "$FOAM_TUTORIALS/incompressible/icoFoam/cavity/cavity" "$dir/"
cd "$dir/cavity"
foamDictionary system/controlDict -entry endTime -set 0.015
cat >> system/controlDict <<'EOF'
functions
{
    solverHistory
    {
        type solverInfo;
        libs (utilityFunctionObjects);
        fields (p U);
        executeControl timeStep;
        executeInterval 1;
        writeResidualFields false;
    }
    cavityProbes
    {
        type probes;
        libs (sampling);
        writeControl timeStep;
        writeInterval 1;
        fields (p U);
        probeLocations ((0.05 0.05 0.005) (0.025 0.05 0.005));
    }
}
EOF
blockMesh > log.blockMesh 2>&1
icoFoam > log.icoFoam 2>&1
echo SOLVER_EXIT=$?
find postProcessing -type f
for file in postProcessing/solverHistory/*/* postProcessing/cavityProbes/*/*; do
  echo "OUTPUT $file"
  head -8 "$file"
done
cp log.icoFoam "$out/core-snippets-icoFoam.log"
