# Tutorial 05: Basic Parallel Computing

## Goal

Convert the field-operation example into a parallel OpenFOAM application and
introduce domain decomposition, processor patches, and MPI execution.

## Source and case

- `OFtutorial5.C` contains the parallel-aware application.
- `createFields.H` creates the fields used by the solver.
- `testCase/system/decomposeParDict` defines four subdomains.

The application uses OpenFOAM's parallel abstractions, so the same source can
run in serial or with the `-parallel` option.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

The script runs `blockMesh`, decomposes the case, launches four MPI processes,
and removes the processor directories afterwards.

## Expected result

The parallel run produces the same physical result as the serial version while
each rank processes only its assigned subdomain. Use `-np 4` only when four MPI
slots are available.
