# Tutorial 08: Custom Boundary Condition

## Goal

Implement a run-time selectable vector boundary condition derived from
`fixedValueFvPatchVectorField`.

## Source and case

- `prescribedPipeInletFvPatchVectorField.H/.C` define the custom condition and
  its dictionary constructor, mapping constructor, `updateCoeffs()`, and write
  method.
- `testCase/0.org/U` contains the custom boundary-condition parameters.
- `testCase/system/controlDict` loads the compiled library.

The case is a turbulent pipe-flow example using `simpleFoam`. `Allrun.mesh`
prepares the mesh and copies the original fields into the active `0` directory.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

The script prepares the mesh, runs `potentialFoam`, decomposes the case, runs
`simpleFoam` on four MPI ranks, reconstructs the latest time, and executes the
`yPlus` and sampling post-processing functions.

## Expected result

The inlet velocity follows the prescribed pipe profile and the solver produces
the usual turbulence and sampled output under `postProcessing`.
