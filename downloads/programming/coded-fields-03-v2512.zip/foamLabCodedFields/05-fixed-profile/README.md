# codeStream 固定入口剖面

OpenFOAM v2512。加载环境后在本目录运行 `bash Allrun`。

程序依次生成网格、检查网格、导出初始场、运行 icoFoam、导出最终场。
`0/U` 是本例的主要代码文件，`system/controlDict` 控制计算时间与保存频率。
ParaView 可以打开 `case.foam`，也可以打开 `VTK` 目录中的初始和最终结果。
改变初值重新计算时，在另一个目录解压原始算例，保留两组输出便于比较。

本例目录：`05-fixed-profile`。完整教程见 https://foamlabshark.github.io/programming/coded-fields/ 。
源码：FoamLab，GPL-3.0-or-later。
