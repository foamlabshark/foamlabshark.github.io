# Tutorial 11: Modifying the Mesh

## Goal

Construct a mesh programmatically from points and demonstrate how OpenFOAM
represents cell shapes, patches, and mesh topology.

## Source and case

- `OFtutorial11.C` creates mesh data and writes an OpenFOAM case.
- `meshPoints.geo` documents the points used by the example.
- `testCase/system/blockMeshDict` provides the input mesh used to launch the
  example.

The generated geometry includes different cell topologies and boundary
patches. Compare the source point lists with `meshPoints.geo` and
`meshPoints.pdf`.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

`Allrun` cleans the previous case, runs `blockMesh`, executes `ofTutorial11`,
and performs a full `checkMesh` topology and geometry check.

## Expected result

The application writes the modified mesh and `checkMesh` reports its cell,
face, point, and boundary statistics. Use `viewGrid.pvsm` to inspect the grid.

## FoamLab verification correction
The current 5-cell demonstration compiles and writes a mesh on v2512, but full checkMesh reports one failed underdeterminedCells quality check. It must not be described as a valid production mesh.
