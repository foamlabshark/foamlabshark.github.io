# Tutorial 01: Input and Output

## Goal

Read values from OpenFOAM dictionaries and write values to the terminal and a
file. This introduces `IOobject`, `IOdictionary`, typed dictionary lookup, and
OpenFOAM file handling.

## Source and case

- `OFtutorial1.C` creates a time and mesh object, reads `constant/customProperties`,
  and writes the selected values.
- `testCase/constant/customProperties` contains the user-defined input.
- `testCase/system/blockMeshDict` supplies the mesh needed by the application.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

`Allrun` first runs `blockMesh`, then executes `ofTutorial1`. Inspect the
generated output files and `log.blockMesh` in `testCase`.

## Expected result

The application reports dictionary values and demonstrates OpenFOAM's standard
case-relative input/output locations. Remove generated files with
`testCase/Allclean` and build products with `./Allwclean`.
