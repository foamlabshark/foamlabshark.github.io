/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | www.openfoam.com
     \\/     M anipulation  |
-------------------------------------------------------------------------------
    Copyright (C) 2021 2021 AUTHOR,AFFILIATION
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    tutSimpleFoam

Description
    This tutorial is about explaining how the SIMPLE algorithm is implemented
    through coding in OpenFOAM solvers like "simpleFoam". This tutorial is
    adapted for OpenFOAM v2512. The teaching implementation uses a
    conservative pressure flux correction and a pressure-free momentum matrix.

    SIMPLE algorithm stands for "Semi-Implicit Method for Pressure Linked
    Equations". it is one of the algorithms used in solving incompressible
    Navier-Stokes equations.

\*---------------------------------------------------------------------------*/

// including basic functions and objects needed for OpenFOAM to run
#include "fvCFD.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

// Incompressible flows are governed by 4 PDEs, 3 momentum equations and 1
// continuity equation. The field variables involved in computation are also
// 4, Ux,Uy,Uz and P. So we have 4 equations and 4 unknowns, but we dont have
// an explicit equation for pressure P, hence the continuity equation is
// modified to involve pressure and thus solved as a pressure correction
// equation.

int main(int argc, char *argv[])
{
    // basic header files that setup the time, mesh and case are included
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"

    // declaring, reading and defining field values
    // the details on how the fields are defined/read/created can be seen
    // on the "createFields.H" file in the same directory
    #include "createFields.H"

    // the following factors are read from the fvSolution dictionary defined
    // in the "createFields.H" file. this file is present in the system/
    // directory of case folder

    // reading relaxation factor
    scalar alpha;
    fvSolution.lookup("alpha") >> alpha;
    // reading index of cell containing reference pressure
    label pRefCell;
    fvSolution.lookup("pRefCell") >> pRefCell;
    // reading reference pressure value
    scalar pRefValue;
    fvSolution.lookup("pRefValue") >> pRefValue;
    const scalar alphaU = fvSolution.lookupOrDefault<scalar>("alphaU", 0.7);
    const label nNonOrthogonalCorrectors =
        fvSolution.lookupOrDefault<label>("nNonOrthogonalCorrectors", 0);
    if (alpha <= 0 || alpha > 1 || alphaU <= 0 || alphaU > 1
        || nNonOrthogonalCorrectors < 0)
    {
        FatalErrorInFunction
            << "Require 0 < alpha, alphaU <= 1 and nNonOrthogonalCorrectors >= 0"
            << exit(FatalError);
    }
    mesh.setFluxRequired(p.name());

    // the read values are printed on to screen for confirmation during run
    Info << nl << "following parameters read:" << endl;
    Info << tab << "relaxation factor \"alpha\" : " << alpha << endl;
    Info << tab << "index of cell containing reference pressure \"pRefCell\" : " << pRefCell << endl;
    Info << tab << "reference pressure value \"pRefValue\" : " << pRefValue << endl;

    // Begin the outer loops.
    // The start and end iterations are read from the controlDict file in the
    // system directory. Since this is a steadyState solver, the timeStep
    // value are just used as iteration count, hence it is usually started on
    // a round number.
    while (runTime.loop())
    {

        Info << nl << "Iteration: " << runTime.timeName() << endl;

        // Assemble convection and diffusion. Pressure is supplied only to
        // the predictor solve, so UEqn.H() excludes an explicit grad(p) source.
        fvVectorMatrix UEqn
        (
            fvm::div(phi, U) - fvm::laplacian(nu, U)
        );
        UEqn.relax(alphaU);
        solve(UEqn == -fvc::grad(p));

        volScalarField rAU(1.0/UEqn.A());
        volVectorField HbyA(constrainHbyA(rAU*UEqn.H(), U, p));
        surfaceScalarField phiHbyA("phiHbyA", fvc::flux(HbyA));
        adjustPhi(phiHbyA, U, p);
        constrainPressure(p, U, phiHbyA, rAU);

        // Correct the face flux with the same operator used for pressure.
        // Zero non-orthogonal correctors means one pressure solve.
        for (label corr = 0; corr <= nNonOrthogonalCorrectors; ++corr)
        {
            fvScalarMatrix pEqn
            (
                fvm::laplacian(rAU, p) == fvc::div(phiHbyA)
            );
            pEqn.setReference(pRefCell, pRefValue);
            pEqn.solve();
            if (corr == nNonOrthogonalCorrectors)
            {
                phi = phiHbyA - pEqn.flux();
            }
        }

        // Relax pressure after flux correction, then correct cell velocity.
        p = alpha*p + (1.0 - alpha)*p_old;
        p.correctBoundaryConditions();
        U = HbyA - rAU*fvc::grad(p);
        U.correctBoundaryConditions();
        p_old = p;

        const volScalarField divPhi(fvc::div(phi));
        Info << "max |div(phi)| = " << gMax(mag(divPhi.primitiveField()))
             << " [1/s]" << nl;

        // Writing computed fields at the intervals insisted by controlDict.
        runTime.write();

    }

    // printing execution time information at the end of simulation
    Info<< nl;
    Info<< "ExecutionTime = " << runTime.elapsedCpuTime() << " s" << endl;
    Info<< "End\n" << endl;

    return 0;
}

// Teaching scope: steady, incompressible, laminar flow on a static mesh.
// Compare the pressure-velocity loop with simpleFoam for further extensions.

// ************************************************************************* //
