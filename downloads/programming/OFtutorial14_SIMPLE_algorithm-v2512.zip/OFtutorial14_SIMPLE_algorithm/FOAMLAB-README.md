# SIMPLE 教学算例 · OpenFOAM v2512

来源：Artur K. Lidtke 及 Basic OpenFOAM Programming Tutorials 贡献者；第 14 课由 Ramkumar 等贡献。保留原作者说明与 GPL-3.0-or-later 许可证。

## 运行

加载 OpenFOAM v2512 环境，在本目录执行 `bash Allwmake`，随后进入 `testCase` 执行 `bash Allrun`。默认通道网格为 100×20×1，计算 500 次稳态迭代。

## 本站修订

- 动量矩阵保存对流和扩散项，压力梯度通过 `solve(UEqn == -fvc::grad(p))` 传入预测求解。
- 用 `constrainHbyA`、`adjustPhi`、`constrainPressure` 处理边界一致性。
- 压力方程完成后，以 `phiHbyA - pEqn.flux()` 更新面通量，再松弛压力和修正单元速度。
- 增加速度方程松弛 alphaU、非正交校正次数与局部连续性输出。
- 默认 alpha=0.3、alphaU=0.7；压力和速度线性容差分别为 1e-10、1e-8。

2026-10-02 在 OpenFOAM v2512 上编译并运行 500 次；最终 max|div(phi)|=3.26667e-9 s^-1。写出结果的入口流量为 -0.001 m3/s，出口流量为 0.00099999998 m3/s。

模型：定常、不可压缩、层流、静止网格。`system/fvSchemes` 使用与配套正交通道网格对应的空间格式。修改几何或边界后，应相应选择离散格式与边界条件。
