# Tutorial 14: SIMPLE algorithm

A steady incompressible laminar teaching solver for OpenFOAM v2512.

Run `bash Allwmake`, then `cd testCase` and `bash Allrun`.

The source keeps the momentum matrix free of an explicit pressure source,
solves the predictor with pressure, and corrects face flux using the pressure
matrix flux. Pressure relaxation follows the conservative flux correction.

Controls in `testCase/system/fvSolution`:
- alpha: pressure field relaxation (0.3)
- alphaU: momentum equation relaxation (0.7)
- nNonOrthogonalCorrectors: additional pressure solves (0)
- pRefCell, pRefValue: reference for cases requiring a pressure datum

The supplied 100 x 20 x 1 channel case runs 500 iterations. See
FOAMLAB-README.md for source attribution and the documented calculation.
