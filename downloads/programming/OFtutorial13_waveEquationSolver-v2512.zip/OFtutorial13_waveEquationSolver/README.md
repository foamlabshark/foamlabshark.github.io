# Tutorial 13: Wave Equation Solver

## Goal

Build a transient custom solver for a basic wave equation and introduce time
loops, field creation, and repeated matrix solves.

## Source and case

- `ofTutorial13.C` contains the transient solver loop.
- `createFields.H` reads or creates the wave fields.
- `testCase/0/h` stores the wave amplitude.
- `testCase/system/setFieldsDict` defines the initial peak.

The mesh is a thin two-dimensional box with `empty` front and back patches.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

`Allrun` runs `blockMesh`, applies the initial condition with `setFields`, and
executes `ofTutorial13`.

## Expected result

The initial pulse propagates and reflects from the boundaries. The generated
time directories can be animated in ParaView; `waveElevation.png` shows the
intended qualitative result.
