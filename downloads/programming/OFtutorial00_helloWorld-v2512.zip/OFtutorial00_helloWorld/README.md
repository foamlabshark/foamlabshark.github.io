# Tutorial 00: Hello World

## Goal

Build the smallest OpenFOAM application and print a message through the OpenFOAM
run-time environment. This is the starting point for all later tutorials.

## Source

- `OFtutorial0.C` contains `main()`.
- `Make/files` defines the executable name.
- `Make/options` links the finite-volume and mesh-tools libraries.

The program uses the standard OpenFOAM application initialisation and writes to
the `Info` stream.

## Run

From this directory, with the OpenFOAM v2512 environment loaded:

```bash
./Allwmake
cd testCase
./Allrun
```

`Allrun` executes `ofTutorial0`. No mesh or input files are required.

## Expected result

The terminal prints the OpenFOAM banner followed by the tutorial's hello-world
message. Clean generated build files with `./Allwclean`.
