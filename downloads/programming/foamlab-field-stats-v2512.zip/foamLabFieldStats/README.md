# foamLabFieldStats — OpenFOAM v2512

加载 OpenFOAM 环境后，执行 `bash Allwmake`，然后进入 `testCase` 执行 `bash Allrun`。
本程序读取已有标量场，输出体积加权统计；输入场保持原样。
测试网格包含体积为 0.25 和 0.75 m³ 的两个单元。
0 时刻 T 为 300、400 K，体积加权平均为 375 K；1 时刻为 310、410 K，平均为 385 K。
串行运行后，可运行 `decomposePar -time '0,1'`，再执行
`mpirun -np 2 foamLabFieldStats T -parallel -time '0,1'`，对比同一输出文件。
程序每次运行重新写出 T.tsv；需要保留比较记录时先复制该文件。

源码由 FoamLab 编写，以 GPL-3.0-or-later 发布。接口参考 OpenFOAM v2512 官方工具。
