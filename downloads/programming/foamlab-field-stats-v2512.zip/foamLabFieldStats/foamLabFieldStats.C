// SPDX-License-Identifier: GPL-3.0-or-later
// FoamLab teaching utility: volume-weighted scalar-field statistics.
#include "fvCFD.H"
#include "timeSelector.H"
#include "OFstream.H"

int main(int argc, char *argv[])
{
    argList::addNote("Write global, volume-weighted scalar-field statistics.");
    argList::addArgument("field");
    timeSelector::addOptions();
    #include "addRegionOption.H"
    #include "setRootCase.H"
    #include "createTime.H"

    const word fieldName(args.get<word>(1));
    const instantList timeDirs(timeSelector::select0(runTime, args));
    if (timeDirs.empty())
    {
        FatalErrorInFunction << "No selected time directories" << exit(FatalError);
    }
    #include "createNamedMesh.H"

    autoPtr<OFstream> report;
    if (Pstream::master())
    {
        const fileName outDir
        (
            runTime.globalPath()/"postProcessing"/"foamLabFieldStats"/mesh.name()
        );
        mkDir(outDir);
        report.reset(new OFstream(outDir/(fieldName + ".tsv")));
        report().precision(12);
        Info<< "Writing " << outDir/(fieldName + ".tsv") << nl;
    }

    forAll(timeDirs, timei)
    {
        runTime.setTime(timeDirs[timei], timei);
        mesh.readUpdate();
        const volScalarField field
        (
            IOobject
            (
                fieldName, runTime.timeName(), mesh,
                IOobject::MUST_READ, IOobject::NO_WRITE
            ),
            mesh
        );
        const scalarField& values = field.primitiveField();
        const scalarField& volumes = mesh.V();
        const scalar totalVolume = gSum(volumes);
        if (totalVolume <= VSMALL)
        {
            FatalErrorInFunction << "The selected mesh has zero total volume"
                << exit(FatalError);
        }
        const scalar integral = gSum(values*volumes);
        const scalar average = integral/totalVolume;
        const scalar minimum = gMin(values);
        const scalar maximum = gMax(values);
        const label cells = returnReduce(mesh.nCells(), sumOp<label>());

        Info<< "time=" << runTime.timeName() << " cells=" << cells
            << " volume=" << totalVolume << " average=" << average
            << " min=" << minimum << " max=" << maximum << nl;
        if (Pstream::master())
        {
            if (timei == 0)
            {
                report()<< "# field " << fieldName << "; dimensions "
                    << field.dimensions() << nl;
                report()<< "time\tcells\tvolume\tminimum\tmaximum\tvolumeAverage\tintegral\n";
            }
            report()<< runTime.timeName() << '\t' << cells << '\t'
                << totalVolume << '\t' << minimum << '\t' << maximum
                << '\t' << average << '\t' << integral << nl;
        }
    }
    Info<< "End" << nl;
    return 0;
}
