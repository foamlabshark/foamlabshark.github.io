# Tutorial 06: Custom Classes

## Goal

Define, implement, and use user classes that follow OpenFOAM conventions,
including inheritance from an OpenFOAM dictionary class.

## Source

- `customClass.H/.C` defines a class for dictionary-related functionality.
- `derivedClass.H/.C` demonstrates inheritance and extension.
- `OFtutorial6.C` constructs and uses the classes.
- `testCase/constant/customProperties` supplies input data.

Pay attention to constructors, member functions, namespaces, and the separation
between declarations and definitions.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

The case is meshed before `ofTutorial6` is executed.

## Expected result

The application prints information from the custom and derived classes,
illustrating that normal OpenFOAM dictionary behaviour remains available after
extension.
