from paraview.simple import *
import os
root='/home/shark/foamlab-programming-packages-20261002/OFtutorial10_transportEquation/testCase'
output='/mnt/hgfs/UbuntuShareFolder/.foamlab-build/programming'
open(root+'/transport.foam','a').close()
reader=XMLUnstructuredGridReader(FileName=[root+'/VTK/testCase_0/internal.vtu'])
reader.CellArrayStatus=['result'];reader.UpdatePipeline(0)
print('arrays',reader.CellData.keys(),reader.PointData.keys())
view=CreateView('RenderView');view.ViewSize=[1600,1100]
view.UseColorPaletteForBackground=0;view.Background=[0.96,0.975,0.99];view.OrientationAxesVisibility=0
display=Show(reader,view);display.Representation='Surface'
ColorBy(display,('CELLS','result'));display.RescaleTransferFunctionToDataRange(False,True)
lut=GetColorTransferFunction('result');lut.ApplyPreset('Cool to Warm',True)
display.SetScalarBarVisibility(view,True)
bar=GetScalarBar(lut,view);bar.Title='Scalar beta';bar.ComponentTitle='dimensionless';bar.TitleColor=[0.1,0.2,0.3];bar.LabelColor=[0.1,0.2,0.3]
bar.WindowLocation='Any Location';bar.Orientation='Horizontal';bar.Position=[0.30,0.035];bar.ScalarBarLength=0.44;bar.TitleFontSize=15;bar.LabelFontSize=14
b=reader.GetDataInformation().GetBounds();x=(b[0]+b[1])/2;y=(b[2]+b[3])/2;z=(b[4]+b[5])/2
view.CameraPosition=[x,y,z+10];view.CameraFocalPoint=[x,y,z];view.CameraViewUp=[0,1,0];view.CameraParallelProjection=1;view.CameraParallelScale=max(b[1]-b[0],b[3]-b[2])*0.64
label=Text();label.Text='OpenCFD OpenFOAM v2512 | Steady scalar transport | Tutorial 10'
ld=Show(label,view);ld.Color=[0.1,0.2,0.3];ld.FontSize=16;ld.WindowLocation='Upper Left Corner'
Render(view);SaveScreenshot(output+'/transport-beta-v2512.png',view,ImageResolution=[1600,1100])
print('bounds',b,'range',reader.CellData['result'].GetRange())
