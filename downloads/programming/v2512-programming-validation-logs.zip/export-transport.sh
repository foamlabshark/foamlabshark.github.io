#!/bin/bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
cd /home/shark/foamlab-programming-packages-20261002/OFtutorial10_transportEquation/testCase
foamToVTK -time 0 -fields '(result)' > /mnt/hgfs/UbuntuShareFolder/.foamlab-build/programming/export-transport.log 2>&1
find VTK -type f >> /mnt/hgfs/UbuntuShareFolder/.foamlab-build/programming/export-transport.log
