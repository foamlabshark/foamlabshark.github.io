# Tutorial 16: Particle Tracking

## Goal

Track a massless particle through a solved flow field and write its path for
visualisation.

## Source and case

`OFtutorial16.C`:

1. reads the selected solution time;
2. loads the mesh and velocity field;
3. locates the cell containing the particle;
4. advances the particle using the local flow velocity; and
5. writes the resulting point path.

The case first solves a simple pipe flow with `simpleFoam`, then uses that
velocity field for tracking.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

`Allrun` creates the mesh, runs `simpleFoam`, executes `ofTutorial16`, and
captures the particle output in `log.particleTracking`.

## Expected result

The particle path is written in a format that can be loaded in ParaView.
Visualise it with `viewData.pvsm` and compare it with `particlePath.png`.
