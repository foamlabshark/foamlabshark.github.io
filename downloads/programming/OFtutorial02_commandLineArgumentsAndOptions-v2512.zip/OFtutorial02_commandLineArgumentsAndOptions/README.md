# Tutorial 02: Command-Line Arguments and Options

## Goal

Learn how an OpenFOAM application accepts positional arguments, switches,
typed options, and dictionary options from the command line.

## Source

`OFtutorial2.C` declares its command-line interface with `argList` and reads:

- a positional word;
- a scalar value;
- a boolean switch;
- an integer option; and
- a dictionary path option.

The example also demonstrates how OpenFOAM validates required arguments and
reports usage errors.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

The run script invokes:

```bash
ofTutorial2 someWordIPassed 5. -someSwitch -someInt 2 \
    -dict path_to_nowhere_in_particular
```

The dictionary path is intentionally only used to illustrate option parsing.

## Expected result

The executable prints each parsed value and switch state. Try changing or
removing an argument to observe OpenFOAM's command-line error handling.
