# Tutorial 04: Basic Field Operations

## Goal

Read OpenFOAM fields, access internal and boundary values, perform arithmetic,
and write a calculated field.

## Source and case

`OFtutorial4.C` reads the case velocity and pressure fields, performs simple
field operations, and writes the result using the OpenFOAM field I/O classes.
The initial fields are in `testCase/0`.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

`Allrun` generates the mesh with `blockMesh` before running `ofTutorial4`.

## Expected result

The terminal shows sampled field values and a new result field is written to
the case time directory. Open the field files to see their dimensions,
internal values, and boundary conditions.
