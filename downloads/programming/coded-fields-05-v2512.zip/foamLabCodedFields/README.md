# 用代码设置初始与边界条件

OpenFOAM v2512 · FoamLab

本包包含：

- 07-ramp
- 08-sine

将本文件夹解压到 Linux 的个人工作目录，加载 OpenFOAM v2512 环境。
进入任一算例，运行 `bash Allrun`。
首次运行会自动编译字典内的 C++ 代码，需要 g++、make 与 OpenFOAM 开发文件。

本包提供生成网格所需的字典，不包含已生成网格、平台库或完整时间目录。
reference-results 目录（如有）是配套 v2512 计算导出的 CSV 与检查结果。

教程：https://foamlabshark.github.io/programming/coded-fields/
教学思路参考：Joel Guerrero / Wolf Dynamics，OpenFOAM Introductory Training，编程部分。
本包的几何、代码、脚本与中文说明由 FoamLab 编写。代码许可证 GPL-3.0-or-later。
