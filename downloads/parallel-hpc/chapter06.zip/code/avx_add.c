#include <immintrin.h>
#include <stddef.h>
void add_avx(double *out, const double *a,
             const double *b, size_t n) {
    size_t main_end = n - n % 4;
    for (size_t i = 0; i < main_end; i += 4) {
        __m256d av = _mm256_loadu_pd(a + i);
        __m256d bv = _mm256_loadu_pd(b + i);
        _mm256_storeu_pd(out + i, _mm256_add_pd(av, bv));
    }
    for (size_t i = main_end; i < n; ++i)
        out[i] = a[i] + b[i];
}
