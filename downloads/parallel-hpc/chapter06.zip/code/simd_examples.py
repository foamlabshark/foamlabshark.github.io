"""Teaching model: index grouping and arithmetic, not actual SIMD execution."""
import math

def layout(n, width_bits=256, element_bits=64):
    if not isinstance(n, int) or n < 0:
        raise ValueError('n must be a nonnegative integer')
    if width_bits not in (128,256,512) or element_bits not in (32,64):
        raise ValueError('unsupported teaching width')
    lanes = width_bits // element_bits
    main_end = n - n % lanes
    groups = [(i,i+lanes) for i in range(0,main_end,lanes)]
    return lanes, groups, (main_end,n)

def grouped_add(a,b,lanes=4):
    if len(a) != len(b) or lanes <= 0:
        raise ValueError('invalid inputs')
    n=len(a)
    out=[0.0]*n
    main_end=n-n%lanes
    for start in range(0,main_end,lanes):
        for lane in range(lanes):
            i=start+lane
            out[i]=a[i]+b[i]
    for i in range(main_end,n):
        out[i]=a[i]+b[i]
    return out

def timestep(heights, active, g=9.8, sigma=.95, dx=.5, dy=.5):
    if len(heights)!=len(active) or g<0 or sigma<=0 or dx<=0 or dy<=0:
        raise ValueError('invalid input')
    values=[]
    for h,use in zip(heights,active):
        if use:
            if h<=0: raise ValueError('this demo requires positive active heights')
            wave=math.sqrt(g*h)
            values.append(sigma/(wave/dx+wave/dy))
    return min(values) if values else None

def run_checks():
    for n in (0,1,3,4,5,7,8,9,17,31,32,33):
        for width in (128,256,512):
            for elem in (32,64):
                lanes,groups,tail=layout(n,width,elem)
                indices=[i for lo,hi in groups for i in range(lo,hi)]+list(range(*tail))
                assert indices==list(range(n))
                assert all(hi-lo==lanes for lo,hi in groups)
                assert 0<=tail[1]-tail[0]<lanes
        a=[float(i) for i in range(n)]
        b=[2.0*i for i in range(n)]
        assert grouped_add(a,b)==[3.0*i for i in range(n)]
    assert layout(17,256,64)==(4,[(0,4),(4,8),(8,12),(12,16)],(16,17))
    assert math.isclose(timestep([10,20],[True,True]),.95/56,rel_tol=1e-14)
    assert timestep([10,20],[False,False]) is None
    for args in ((-1,256,64),(8,123,64),(8,256,16)):
        try: layout(*args)
        except ValueError: pass
        else: raise AssertionError('invalid layout accepted')
    print('SIMD grouping, tails, grouped addition and timestep checks passed')

if __name__=='__main__':
    run_checks()
