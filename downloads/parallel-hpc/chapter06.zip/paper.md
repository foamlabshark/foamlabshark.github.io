# 第 6 章｜向量化

原著：Robert Robey、Yuliana Zamora，Manning，2021。原书 p.175–206 / PDF p.211–242（含第二部分 p.171–173 导读）。

核心段落中英对照、全部编号小节解释、2 幅原图、4 张历史参数表、原书性能输出、公式和代码语法。跨页原表分片展示。6.A 为原书 p.195 输出的讲义标签。不是逐段全文译本。

## 小节索引

- [第 6 章导读｜向量化：充分利用 SIMD](#6-intro)
- [6.1 向量化与 SIMD 概览](#6.1)
- [6.2 向量硬件的发展趋势](#6.2)
- [6.3 实现向量化的五种方式](#6.3)
- [6.3.1 使用优化库](#6.3.1)
- [6.3.2 自动向量化：先看编译报告](#6.3.2)
- [6.3.2（续）别名、restrict 与类型规则](#6.3.2-alias)
- [6.3.3 用指令表达向量化意图：时间步长](#6.3.3)
- [6.3.3（续）条件求和与归约初始化](#6.3.3-reduction)
- [6.3.3（续）RAW、WAR 与 WAW 依赖](#6.3.3-dependence)
- [6.3.3（续）剥离循环、主循环与尾部循环](#6.3.3-reports)
- [6.3.4 向量内在函数：明确加载与运算](#6.3.4)
- [6.3.4（续）向量化 Kahan：保留正确的补偿关系](#6.3.4-kahan)
- [6.3.4（续）GCC 向量类型扩展](#6.3.4-gcc)
- [6.3.4（续）C++ 向量类与部分加载](#6.3.4-vcl)
- [6.3.4（续）怎样读原书精度与时间输出](#6.3.4-results)
- [6.3.5 查看向量汇编](#6.3.5)
- [6.4 有利于向量化的编程风格](#6.4)
- [6.5 编译器参数：把原表当作历史参考](#6.5)
- [6.5（续）在 CMake 中组织选项](#6.5-cmake)
- [6.6 OpenMP SIMD：循环、线程和子句](#6.6)
- [6.6（续）aligned 与内存对齐](#6.6-aligned)
- [6.6（续）collapse、linear、safelen 与 simdlen](#6.6-clauses)
- [6.6（续）declare simd 函数](#6.6-functions)
- [6.7 进一步探索与本章小结](#6.7)
- [6.7.1 延伸阅读](#6.7.1)
- [6.7.2 练习与参考思路](#6.7.2)

## 公式索引

- [E001](#E001) · 原书 p.176 · L = W / b
- [E002](#E002) · 原书 p.184 · Δt_i = σ / ((|U_i|+√(gH_i))/Δx_i + (|V_i|+√(gH_i))/Δy_i)
- [E003](#E003) · 原书 p.189 · N_main = floor(N/L) × L;  N_tail = N mod L

## 术语约定

|原文|译法|说明|
|---|---|---|
|SIMD lane|SIMD 通道|一个数据元素的并行操作通道|
|vector width|向量位宽|以 bit 计的总宽度|
|vector length|向量长度|按元素类型计算的通道数|
|auto-vectorization|自动向量化|编译器转换循环或其他操作|
|intrinsics|内在函数|以语言接口表达指令级操作|
|aliasing|别名|不同访问路径可能涉及同一对象|
|restrict|受限指针限定符|C 的受限访问语义承诺|
|strict aliasing|严格别名规则|基于类型访问规则的推理|
|loop versioning|循环版本化|生成多条路径并选择执行|
|peel loop|剥离循环|处理主向量循环前的部分迭代|
|remainder loop|尾部循环|处理不足一个完整向量的剩余迭代|
|mask|掩码|控制通道或元素参与操作|
|alignment|内存对齐|地址满足指定字节边界|

<a id="6-intro"></a>
## 第 6 章导读｜向量化：充分利用 SIMD
原书 p.171–175。

<a id="S001"></a>
**Source:** 原书 p.175 / PDF p.211 · S001

**Original:** Vectorization is the process of grouping operations together so more than one can be done at a time.

**中文:** 向量化是把操作组织成组，使多个数据元素的操作可以一起完成的过程。

<a id="N001"></a>
### 第二部分的三条路线

**讲解：** 第 6 章关注单个执行线程内部的 SIMD，第 7 章关注多核线程，第 8 章关注消息传递。这些方式可以组合，但不能把 SIMD 通道数、线程数和进程数当成同一概念。MPI 是消息传递接口标准，而不是一种独立编程语言。

<a id="N002"></a>
### “免费的 FLOP”是一种有条件的比喻

**讲解：** 原书标题强调：当硬件存在未利用的并行运算能力时，可以用较少额外时间处理更多运算。但带宽、延迟、指令吞吐、频率与准备开销仍然存在；更宽向量并不保证程序更快或功耗不变。

<a id="N003"></a>
### 本章的阅读方式

**讲解：** 保留原书 6.1–6.7 及编号子小节，长小节按自动向量化、依赖、内在函数和编译选项拆分。原图、历史参数表和代码出处分开标记；教学修正版不会伪装成原书原样代码。


<a id="6.1"></a>
## 6.1 向量化与 SIMD 概览
原书 p.176–177。

<a id="S002"></a>
**Source:** 原书 p.176 / PDF p.212 · S002

**Original:** In the SIMD case, as the name indicates, there is a single instruction that is executed across multiple data streams.

**中文:** 顾名思义，在 SIMD 情形下，同一条指令对多个数据流执行操作。

<a id="F001"></a>
### 图 6.1
**Source:** 原书 p.176 / PDF p.212 · C001
**Placed near:** 6.1 向量化与 SIMD 概览

![图 6.1](assets/fig6_1.png)

**Original caption:** A scalar operation does a single double-precision addition in one cycle. It takes eight cycles to process a 64-byte cache line. In comparison, a vector operation on a 512-bit vector unit can process all eight double-precision values in one cycle.

**中文图注:** 图中以标量逐项加法与 512 位向量同时处理 8 个双精度值作对比，说明一条向量指令可覆盖多个元素。

**Reading note:** “一周期”是原图的理想化说明。实际指令延迟、吞吐和执行端口不同；一条 SIMD 指令并不保证在一个时钟周期内完成，更不能把同周期多条标量指令的能力忽略。

<a id="E001"></a>
**Source:** 原书 p.176 / PDF p.212 · E001

$$
L=W/b
$$

W 是向量宽度（bit），b 是每元素位宽，L 是该操作的元素通道数。512/64=8 个 double 通道，256/32=8 个 float 通道。

<a id="N004"></a>
### 四个术语

**讲解：** lane 是一个数据元素的运算通道；width 是总位宽；length 是按数据类型计算的通道数；instruction set 是可用指令及其语义。缓存行大小与向量宽度可能数值相同，但属于不同概念。

### 向量分组与尾部元素演示

选择数组长度、向量位宽和元素位宽，观察完整分组及剩余元素。仅展示索引划分，不代表时钟周期或实测加速比。

交互版本见网页小节 6.1。展示向量通道数、完整分组与尾部区间，不是性能预测。

<a id="N005"></a>
### 编译与硬件要共同支持

**讲解：** 需要生成目标指令，并确保运行机器和操作系统支持相应执行状态。不能只按 CPU 发布年份断言支持 AVX，也不能把“默认 SSE2”当成所有架构、所有编译器的默认行为。


<a id="6.2"></a>
## 6.2 向量硬件的发展趋势
原书 p.177–178。

<a id="F003"></a>
### 表 6.1（上）
**Source:** 原书 p.177 / PDF p.213 · C003
**Placed near:** 6.2 向量硬件的发展趋势

![图 6.T1a](assets/fig6_T1a.png)

**Original caption:** The vector hardware releases over the last decade have dramatically improved vector functionality.

**中文图注:** 原书表 6.1 上半部分：向量指令逐步增加浮点等功能。

**Reading note:** 这是原书历史表的第一页，不是当前设备支持表。MMX、SSE 等名称只描述指令体系的一部分，不能替代对具体型号和功能位的查询。

<a id="F004"></a>
### 表 6.1（续）
**Source:** 原书 p.178 / PDF p.214 · C004
**Placed near:** 6.2 向量硬件的发展趋势

![图 6.T1b](assets/fig6_T1b.png)

**Original caption:** The vector hardware releases over the last decade have dramatically improved vector functionality. (continued)

**中文图注:** 原书表 6.1 续页：AVX、AVX2 与 AVX-512 的历史概括。

**Reading note:** AVX2 和 FMA 是不同的指令特性，虽常在同代处理器上出现，也应分别检测。AVX-512 又由多个子集组成，不能把名称理解为所有子集都可用。

<a id="F002"></a>
### 图 6.2
**Source:** 原书 p.178 / PDF p.214 · C002
**Placed near:** 6.2 向量硬件的发展趋势

![图 6.2](assets/fig6_2.png)

**Original caption:** The appearance of vector unit hardware for commodity processors began around 1997 and has slowly grown over the last twenty years, both in vector width (size) and in types of operations supported.

**中文图注:** 原书用这张历史图说明通用处理器向量位宽及支持操作逐步扩展。

**Reading note:** 图覆盖约 1997–2017 的示例路线，不是完整硬件史，也不表示所有处理器都按同一时间线升级。较宽向量可能改变频率、功耗和吞吐，仍要测试实际工作负载。


<a id="6.3"></a>
## 6.3 实现向量化的五种方式
原书 p.178–179。

<a id="N006"></a>
### 从较少工作量开始

**讲解：** 原书依次列出优化库、自动向量化、编译器指令、向量内在函数与汇编。通常先确认已有库和编译器能做到什么，再为热点代码增加手动控制。

<a id="N007"></a>
### 证据链要完整

**讲解：** 源码中写了 SIMD 意图，不等于生成了期望指令；生成指令，不等于热点运行路径用到了它；用到指令，也不等于整个程序变快。应结合编译报告、反汇编、运行测量和正确性检查。


<a id="6.3.1"></a>
## 6.3.1 使用优化库
原书 p.179。

<a id="S003"></a>
**Source:** 原书 p.179 / PDF p.215 · S003

**Original:** Many low-level libraries provide highly-optimized routines for programmers seeking performance.

**中文:** 许多底层库为追求性能的程序提供高度优化的例程。

<a id="N008"></a>
### 原书介绍的库类型

**讲解：** 包括 BLAS、LAPACK、ScaLAPACK、FFT 实现和稀疏求解器。BLAS 的通行全称是 Basic Linear Algebra Subprograms，原书写成 System 不够准确。库可以把向量化、分块、线程和不同处理器的调优封装起来。

<a id="N009"></a>
### 调用库之前仍要对齐语义

**讲解：** 确认数据精度、行列布局、步长、尺寸、线程设置与误差要求。数据转置、格式转换及主机/设备传输也应进入端到端计时。库名本身不能证明当前构建已选择适合该机器的实现。


<a id="6.3.2"></a>
## 6.3.2 自动向量化：先看编译报告
原书 p.179–181。

<a id="S004"></a>
**Source:** 原书 p.179 / PDF p.215 · S004

**Original:** Auto-vectorization is the vectorization of the source code by the compiler for standard C, C++, or Fortran languages.

**中文:** 自动向量化是编译器对标准 C、C++ 或 Fortran 源代码进行的向量化转换。

<a id="K001"></a>
**代码出处：** C · 原书 STREAM Triad 内核整理，p.180

```text
for (int i = 0; i < n; ++i) {
    c[i] = a[i] + scalar * b[i];
}
```

<a id="K002"></a>
**代码出处：** Shell · GCC 教学命令，需先提供完整 triad.c 源文件

```text
gcc -O3 -g -march=native -fopt-info-vec-optimized \
    -fopt-info-vec-missed -c triad.c -o triad.o
```

<a id="N010"></a>
### 命令语法逐项理解

**讲解：** -O3 选择优化级别，-g 保留调试信息，-c 只编译成目标文件，-o 指定输出名。vec-optimized 报告成功转换，vec-missed 报告未完成的转换。-march=native 允许生成编译机支持的指令，结果可能不能在另一台机器上运行。[R20]

<a id="N011"></a>
### 有报告还要确认运行路径

**讲解：** 原书的 GCC 8 示例生成 256 位而非预期 512 位代码，随后检查硬件事件。事件名中的 256B 在此语境指相应位宽分类，不应误读为 256 字节数据元素。不同微架构的计数器和事件组定义需分别核对。

<a id="N012"></a>
### 更宽不是强制更快

**讲解：** -mprefer-vector-width=512 表示宽度偏好，不会让不支持相应指令的硬件变得支持，也不是加速承诺。较宽向量可能受数据量、寄存器压力、频率和带宽限制。

<a id="N013"></a>
### 原书基准代码需要补充验证

**讲解：** 8000 万个元素的三数组约占 1.92 GB。c[1]=c[2] 不是可靠的通用防优化手段，应消费可验证的结果；单位也应以计时函数返回约定核对，不能只看 printf 写着 msecs。函数版本还应初始化所有输入并检查真正的输出数组。


<a id="6.3.2-alias"></a>
## 6.3.2（续）别名、restrict 与类型规则
原书 p.181–183。

<a id="S005"></a>
**Source:** 原书 p.182 / PDF p.218 · S005

**Original:** The compiler cannot tell if the arguments to the function point to the same or to overlapping data.

**中文:** 编译器可能无法判断函数参数是否指向相同或相互重叠的数据。

<a id="K003"></a>
**代码出处：** C99 · 教学整理；调用者须满足受限指针访问约定

```text
void triad(int n, double *restrict out,
           const double *restrict a,
           const double *restrict b, double scalar) {
    for (int i = 0; i < n; ++i)
        out[i] = a[i] + scalar * b[i];
}
```

<a id="N014"></a>
### 运行时版本化是什么意思

**讲解：** 当不能静态证明访问安全时，编译器可能生成向量和标量两种路径，并在运行时检查重叠等条件。因此 loop versioned 并不表示没有向量化，只是多了一道选择。

<a id="N015"></a>
### restrict 是语义承诺

**讲解：** 它不是检查器，也不会分配新内存。对于通过受限指针访问并修改的对象，相关访问须满足 C 的受限访问规则。对只读输入的关系也不能简单概括成“所有指针绝对互不重叠”。教学调用可使用三个独立数组，避免违反承诺。

<a id="N016"></a>
### 不要把 strict aliasing 和 restrict 混为一谈

**讲解：** -fstrict-aliasing 主要允许按语言的类型访问规则推理；它不会声明任意两个 double* 都不重叠。原书称其“假设没有别名”过于宽泛。C++ 的 __restrict 等属于编译器扩展，支持形式需按工具链确认。[R21]

<a id="N017"></a>
### 指针的层级也重要

**讲解：** double **restrict 限定的是相应指针访问关系，并不自动证明每一行 double 数据都互不重叠。连续的一维数据块加明确步长，往往比含有多层间接寻址的接口更容易让编译器推理。


<a id="6.3.3"></a>
## 6.3.3 用指令表达向量化意图：时间步长
原书 p.183–186。

<a id="S006"></a>
**Source:** 原书 p.183 / PDF p.219 · S006

**Original:** Here, you will learn how to use pragmas and directives to convey information to the compiler for portable implementation of vectorization.

**中文:** 这里将学习如何用 pragma 和 directive 向编译器传递信息，以实现更可移植的向量化。

<a id="E002"></a>
**Source:** 原书 p.184 / PDF p.220 · E002

$$
\Delta t_i=\frac{\sigma}{(|U_i|+\sqrt{gH_i})/\Delta x_i+(|V_i|+\sqrt{gH_i})/\Delta y_i}
$$

原书时间步长内核的教学公式表达。它针对示例的离散模型，不是所有波动问题通用的稳定性公式；需要有效的水深和正网格尺度。

<a id="K004"></a>
**代码出处：** C / OpenMP SIMD · 原书时间步长示例的教学整理，需 math.h、float.h 及有效输入

```text
double mindt = DBL_MAX;
#pragma omp simd reduction(min:mindt)
for (int i = 0; i < n; ++i) {
    if (celltype[i] == REAL_CELL) {
        double wave = sqrt(g * H[i]);
        double sx = (fabs(U[i]) + wave) / dx[i];
        double sy = (fabs(V[i]) + wave) / dy[i];
        double dt = sigma / (sx + sy);
        if (dt < mindt) mindt = dt;
    }
}
```

<a id="N018"></a>
### 为什么把临时变量放在循环内

**讲解：** wave、sx、sy、dt 在每个迭代内声明，生命周期与当前迭代一致，更容易表达它们不用于后续迭代。reduction(min:mindt) 则说明多个迭代的结果按最小值合并。

<a id="N019"></a>
### 正确性前提不能靠编译选项替代

**讲解：** 必须处理负水深、零 dx/dy、零分母、NaN，以及没有任何有效单元的情况。示例全部速度为零且最大水深为 20、g=9.8、dx=dy=0.5、σ=0.95 时，最小步长约为 0.0169642857。

<a id="N020"></a>
### 浮点选项改变了什么

**讲解：** -fno-math-errno 允许不维护数学函数的 errno；-fno-trapping-math 告诉编译器不依赖用户可见浮点陷阱。它们不是“修复负数开方”或“关闭所有错误”。原书报告这些选项帮助某版 GCC 向量化，实际仍取决于目标和代码。[R21]


<a id="6.3.3-reduction"></a>
## 6.3.3（续）条件求和与归约初始化
原书 p.186–187。

<a id="K005"></a>
**代码出处：** C · 清单 6.1 的核心求和整理

```text
double total = 0.0;
#pragma omp simd reduction(+:total)
for (int i = 0; i < n; ++i) {
    if (celltype[i] == REAL_CELL)
        total += H[i] * dx[i] * dy[i];
}
```

<a id="N021"></a>
### SIMD 不是新建线程团队

**讲解：** 此处允许多个迭代在 SIMD 通道上执行；它本身不会创建 OpenMP 多线程团队。原书图注称其为 thread loop 容易混淆线程与向量通道。条件可由掩码或其他转换实现。

<a id="N022"></a>
### 原变量仍然需要初始化

**讲解：** 归约的私有副本按运算定义初始化，最终还会与原变量合并。不能因为有 reduction(+:total) 就删除 total=0.0。原书“初始化仅在 pragma 被忽略时才需要”的说法不正确。[R23]

<a id="N023"></a>
### 结果比较仍要考虑浮点顺序

**讲解：** 分通道累加后再合并，会改变加法顺序。正确的归约消除共享更新竞争，但不保证与逐项串行加法逐位相同。应按第 5 章的误差与可复现性目标验证。


<a id="6.3.3-dependence"></a>
## 6.3.3（续）RAW、WAR 与 WAW 依赖
原书 p.187–188。

<a id="S007"></a>
**Source:** 原书 p.188 / PDF p.224 · S007

**Original:** The GCC compiler chooses to create two versions and tests which to use at run time.

**中文:** 该 GCC 编译器选择生成两个版本，并在运行时判断使用哪一个。

<a id="N024"></a>
### 三类依赖

**讲解：** RAW 是先写后读的真实数据依赖；WAR 是先读后写的反依赖；WAW 是两次写之间的输出依赖。分析向量化时，关键是这些依赖是否跨越将同时执行的迭代，而不只是同一迭代里存在读写。

<a id="K006"></a>
**代码出处：** C · 教学反例：存在循环携带的 RAW 依赖

```text
for (int i = 1; i < n; ++i)
    x[i] = x[i-1] + 1.0;
```

<a id="N025"></a>
### 不能用 pragma 消除真实依赖

**讲解：** 上例依赖上一轮刚生成的新值，不能把循环迭代随意独立执行。五点模板若读 old、写独立的 next，则情况不同；接口和别名信息应如实表达。错误的独立性承诺可能让优化后的结果错误。


<a id="6.3.3-reports"></a>
## 6.3.3（续）剥离循环、主循环与尾部循环
原书 p.189–190。

<a id="S008"></a>
**Source:** 原书 p.189 / PDF p.225 · S008

**Original:** A loop that executes after the main loop to handle a partial set of data that is too small for a full vector length.

**中文:** 尾部循环在主循环之后执行，处理不足一个完整向量长度的剩余数据。

<a id="N026"></a>
### 三段循环分别做什么

**讲解：** 剥离循环可能先处理起始未对齐部分；主循环处理完整向量组；尾部循环处理剩余元素。编译器也可能采用非对齐加载或掩码尾部，因此不一定真的生成三段独立循环。

<a id="E003"></a>
**Source:** 原书 p.189 / PDF p.225 · E003

$$
N_{main}=\lfloor N/L\rfloor L,\quad N_{tail}=N\bmod L
$$

教学分组公式。以 N=17、L=4 为例，主区间 [0,16)，尾部是元素 16。它只说明一种实现划分，不等于性能模型。

<a id="N027"></a>
### 报告中的 potential 要认真读

**讲解：** 原书报告估计潜在加速约 6.37，但其带宽受限模板实测约 1.39；另一 GCC 测试约 1.22。估计的核心执行成本、数组规模和缓存假设，与整项应用的实际条件不同。


<a id="6.3.4"></a>
## 6.3.4 向量内在函数：明确加载与运算
原书 p.190–191。

<a id="S009"></a>
**Source:** 原书 p.190 / PDF p.226 · S009

**Original:** The downside of vector intrinsics is that these are less portable.

**中文:** 向量内在函数的代价是可移植性较差。

<a id="K007"></a>
**代码出处：** C / x86 AVX · 教学补充，要求目标支持 AVX；数组至少含 n 项且不部分重叠

```text
#include <immintrin.h>
#include <stddef.h>
void add_avx(double *out, const double *a,
             const double *b, size_t n) {
    size_t main_end = n - n % 4;
    for (size_t i = 0; i < main_end; i += 4) {
        __m256d av = _mm256_loadu_pd(a + i);
        __m256d bv = _mm256_loadu_pd(b + i);
        _mm256_storeu_pd(out + i, _mm256_add_pd(av, bv));
    }
    for (size_t i = main_end; i < n; ++i)
        out[i] = a[i] + b[i];
}
```

<a id="N028"></a>
### __m256d 与 loadu/storeu

**讲解：** __m256d 表示 256 位的四个 double；loadu/storeu 用于不要求 32 字节对齐的加载/存储。它们仍要求地址可访问，不能越过数组尾部。原书 _mm256_load_pd 则有相应对齐要求，restrict 并不会保证对齐。

<a id="N029"></a>
### 内在函数也需要编译器

**讲解：** 函数名表达指令级意图，但寄存器分配、调度和具体指令选择仍由工具链参与。应查目标 ISA、操作系统支持和生成代码；不能把含 AVX 内在函数的二进制直接交给不支持 AVX 的机器。


<a id="6.3.4-kahan"></a>
## 6.3.4（续）向量化 Kahan：保留正确的补偿关系
原书 p.190–191。

<a id="N030"></a>
### 原书错误延续到了向量版本

**讲解：** p.191 的 new_sum 使用 local_sum + local_corr，而应加入 corrected_next_term；后面的标量合并也有同类问题。这不是一个性能差异，而是计算逻辑错误。讲义沿用第 5 章已验证的减补偿量写法。

<a id="K008"></a>
**代码出处：** x86 AVX 内在函数 · Kahan 教学修正版，每个通道维护自己的状态

```text
__m256d y = _mm256_sub_pd(values, correction);
__m256d t = _mm256_add_pd(sum, y);
correction = _mm256_sub_pd(_mm256_sub_pd(t, sum), y);
sum = t;
```

<a id="N031"></a>
### 向量化的是多个独立累加链

**讲解：** 通道 0 可处理索引 0、4、8……，通道 1 处理 1、5、9……。每条链仍保留自身的时间依赖，最后再合并通道结果与尾部元素。这改变了分组顺序，并不保证与标量 Kahan 逐位相同。

<a id="N032"></a>
### 原清单还缺少哪些边界

**讲解：** i+=4 且只检查 i<ncells，会在长度不是 4 的倍数时越界加载。全局 static sum[4] 在并发调用时也可能被多个线程同时改写。教学实现应处理尾部，并使用每次调用独立的暂存数组。


<a id="6.3.4-gcc"></a>
## 6.3.4（续）GCC 向量类型扩展
原书 p.191–192。

<a id="K009"></a>
**代码出处：** GCC C 扩展 · 教学示例，对应 p.192 的 vector_size 类型声明

```text
typedef double vec4d __attribute__((vector_size(32)));
vec4d a = {1.0, 2.0, 3.0, 4.0};
vec4d b = {5.0, 6.0, 7.0, 8.0};
vec4d c = a + b;
```

<a id="N033"></a>
### 32 的单位是字节

**讲解：** vector_size(32) 不是 32 个元素，而是总共 32 byte。对于 8 byte 的 double，得到 4 个通道。a+b 表示对应元素相加，这种运算符行为属于编译器扩展，不是把普通 double* 指针相加。[R22]

<a id="N034"></a>
### 类型大小不保证一条机器指令

**讲解：** 如果目标没有对应宽度，编译器可能用更窄操作或其他组合实现。可移植性取决于编译器扩展和目标支持，不能只因为声明了 32 byte 类型就断言硬件执行了一条 256 位指令。

<a id="N035"></a>
### 原书 p.192 的额外问题

**讲解：** 示例先声明 local_corr，后面却出现 local_correction，名称不一致；标量补偿式还缺少减号。直接强转 vec4d* 加载也需满足适当的对齐和实现规则。讲义展示类型语法，不把该印刷清单当作已经编译通过的代码。


<a id="6.3.4-vcl"></a>
## 6.3.4（续）C++ 向量类与部分加载
原书 p.193–194。

<a id="K010"></a>
**代码出处：** C++ / Vector Class Library · 原书思路的教学整理，n≥0，需对应库版本

```text
Vec4d values;
long main_end = (n / 4) * 4;
for (long i = 0; i < main_end; i += 4) {
    values.load(input + i);
    /* Update the four lane states here. */
}
int tail = (int)(n % 4);
if (tail != 0)
    values.load_partial(tail, input + main_end);
```

<a id="N036"></a>
### 类方法与尾部加载

**讲解：** Vec4d 是库定义的类型；load 是成员函数；load_partial 指定有效元素数。必须按该库文档确认其余通道的处理方式，再将结果用于归约。普通 loadu 虽不要求对齐，却不会自动只读剩下的几个元素。

<a id="N037"></a>
### extern "C" 的作用

**讲解：** 原书用 extern "C" 声明接口，使 C++ 编译得到的函数采用 C 语言链接规则，便于由 C 代码调用。它不把函数体变成 C，也不解决不同编译器 ABI、数据类型或链接库的不匹配。

<a id="N038"></a>
### 可移植性的范围

**讲解：** Agner Fog 的 Vector Class Library 主要面向 x86 指令系列，能封装不同宽度或指令级别；不应把它理解成同一源码天然覆盖所有 CPU 架构。原书各向量 Kahan 清单里的错误加数也出现在此版本，仍需修正。[R26]


<a id="6.3.4-results"></a>
## 6.3.4（续）怎样读原书精度与时间输出
原书 p.194–195。

<a id="F009"></a>
### 输出 6.A
**Source:** 原书 p.195 / PDF p.231 · C009
**Placed near:** 6.3.4（续）怎样读原书精度与时间输出

![图 6.A](assets/fig6_A.png)

**Original caption:** relative diff  runtime    Description

**中文图注:** 原书求和实验输出的三列分别是相对差异、运行时间和实现说明。

**Reading note:** 6.A 是讲义为 p.195 未编号输出增加的标签。测试使用 GCC 8.2、Skylake Gold 和特定高低能量数据；不是本机结果，也不能证明印刷清单中的错误代码正确。

<a id="N039"></a>
### “几乎一样快”要分清比较对象

**讲解：** 三套内在函数在相同宽度、相同算法下时间接近。四通道 Kahan 约 1.03，对应普通向量和约 0.683，仍慢约 51%；八通道 Kahan 约 0.689，对应普通向量和约 0.664，才较为接近。不能把后者结论套给全部行。

<a id="N040"></a>
### 精度仍不能只看零

**讲解：** 相对差异显示 0 仅表示针对该参考结果和输出精度得到零，不能推导对任意输入完全准确。跨通道合并、尾部处理和编译器浮点变换均可能改变结果。


<a id="6.3.5"></a>
## 6.3.5 查看向量汇编
原书 p.195–196。

<a id="S010"></a>
**Source:** 原书 p.196 / PDF p.232 · S010

**Original:** Because it seldom makes sense to do more than simply look at the assembler instructions that the compiler generates, we won’t go through a programming example of writing a routine in assembler from scratch.

**中文:** 本书主要查看编译器生成的汇编，而不展开从零手写汇编例程，因为多数情况下没有必要这样做。

<a id="K011"></a>
**代码出处：** Shell · 原书 objdump 用法的教学整理，替换成实际目标文件

```text
objdump -d -M=intel --no-show-raw-insn triad.o
```

<a id="N041"></a>
### 参数和寄存器怎么读

**讲解：** -d 反汇编，-M=intel 请求 Intel 语法，--no-show-raw-insn 隐去原始机器码字节。x86 中 xmm、ymm、zmm 分别对应 128、256、512 位寄存器名称；还要看具体指令是 packed 还是 scalar，不能只看寄存器宽度。

<a id="K012"></a>
**代码出处：** 汇编 · Intel 语法教学示例，第一项为目标

```text
vaddpd ymm0, ymm1, ymm2
vaddsd xmm0, xmm1, xmm2
```

<a id="N042"></a>
### pd 与 sd 的区别

**讲解：** vaddpd 是 packed double 加法，vaddsd 是 scalar double 加法。原书命令写 Intel 语法，但示例包含 %rsi、\$0x4 等 AT&T 风格记法；阅读时不能把两套操作数顺序混用。看不到 zmm 也不足以证明完全没有用到 AVX-512 的其他子特性。


<a id="6.4"></a>
## 6.4 有利于向量化的编程风格
原书 p.196–198。

<a id="S011"></a>
**Source:** 原书 p.197 / PDF p.233 · S011

**Original:** Define local variables within a loop so that it is clear that these are not carried to subsequent iterations (C and C++).

**中文:** 在循环内部定义局部变量，以明确这些变量不会携带到后续迭代中（C/C++）。

<a id="N043"></a>
### 接口与数据布局

**讲解：** 用清晰的输入、输出和尺寸描述访问；在语义成立时使用 restrict；尽量让最内层访问连续；根据第 4 章的实际字段使用模式比较 SoA、AoS、AoSoA，而不是机械地认定 SoA 总是最快。

<a id="N044"></a>
### 循环与变量

**讲解：** 把可独立工作暴露出来，避免在热点中混合无关输出和控制逻辑；保留明确的边界和尾部处理。减少变量复用便于阅读和分析，但多定义变量不等于一定增加内存占用，编译器可能将其保留在寄存器或消除。

<a id="N045"></a>
### 原书建议不是语言禁令

**讲解：** 逐元素原地运算 a[i]*=2 没有跨迭代依赖，也可以向量化；因此“循环中数组只能读或只能写”过于严格。Fortran 数组语法也可能优化良好；小整数类型、手工展开和删去函数调用的收益都应按具体编译结果验证。

<a id="N046"></a>
### 正确性先于优化提示

**讲解：** 不能为强行向量化而移走算法必需的检查、谎报不重叠或放宽仍然需要的浮点语义。对改动分别做结果验证和性能测量。


<a id="6.5"></a>
## 6.5 编译器参数：把原表当作历史参考
原书 p.198–200。

<a id="S012"></a>
**Source:** 原书 p.198 / PDF p.234 · S012

**Original:** Compiler flags for vectorization frequently change, so check the documentation for the compiler version that you are using.

**中文:** 向量化编译选项经常变化，应检查实际使用的编译器版本文档。

<a id="F005"></a>
### 表 6.2（上）
**Source:** 原书 p.198 / PDF p.234 · C005
**Placed near:** 6.5 编译器参数：把原表当作历史参考

![图 6.T2a](assets/fig6_T2a.png)

**Original caption:** Vectorization flags for various compilers

**中文图注:** 原书表 6.2：不同编译器的向量化相关选项，第一页。

**Reading note:** 表中对应 GCC/Clang 9、Intel icc 19 等历史版本。选项不能跨编译器混用，也不能把旧编译器身份直接等同于其后继产品。

<a id="F006"></a>
### 表 6.2（续）
**Source:** 原书 p.199 / PDF p.235 · C006
**Placed near:** 6.5 编译器参数：把原表当作历史参考

![图 6.T2b](assets/fig6_T2b.png)

**Original caption:** Vectorization flags for various compilers

**中文图注:** 原书表 6.2 续页：Cray 选项。

**Reading note:** 这是同一张表的后续行。机器架构选项、别名规则和浮点模式是不同类别，不能因为它们都可能影响向量化就视为同一种开关。

<a id="F007"></a>
### 表 6.3
**Source:** 原书 p.199 / PDF p.235 · C007
**Placed near:** 6.5 编译器参数：把原表当作历史参考

![图 6.T3](assets/fig6_T3.png)

**Original caption:** OpenMP SIMD and vectorization report flags for various compilers

**中文图注:** 原书表 6.3：OpenMP SIMD 与向量化报告选项。

**Reading note:** 区分“启用指令解析”和“输出优化报告”。报告中的行号属于原项目；移植后应看当前构建实际产生的诊断。

<a id="F008"></a>
### 表 6.4
**Source:** 原书 p.200 / PDF p.236 · C008
**Placed near:** 6.5 编译器参数：把原表当作历史参考

![图 6.T4](assets/fig6_T4.png)

**Original caption:** Compiler flags to turn off vectorization

**中文图注:** 原书表 6.4：关闭向量化的编译选项。

**Reading note:** 原书关于默认优化级别和某编译器是否提供开关的描述只适用于其测试版本。现代编译器可能同时有循环向量化与基本块 SLP 向量化，需要分别确认关闭范围。

<a id="N047"></a>
### 构造有意义的对照

**讲解：** 同一输入、精度要求、线程数和计时区域下比较开启/关闭向量化的版本。GCC 的循环与 SLP 选项可分别控制；只关闭一种变换，不能就宣称得到完全标量的基线。[R21]

<a id="K013"></a>
**代码出处：** Shell · GCC 教学对照命令；需核对实际版本支持

```text
gcc -O3 -fno-tree-loop-vectorize -fno-tree-slp-vectorize \
    -c triad.c -o triad_scalar.o
```

<a id="N048"></a>
### 不要为补偿求和随便启用 fast-math

**讲解：** 允许重新结合和代数化简的浮点选项可能破坏补偿表达式。-fno-math-errno 不等于 -ffast-math；也不能把原书 CMake 注释中“防止不安全优化”的描述套到所有列出的标志上。


<a id="6.5-cmake"></a>
## 6.5（续）在 CMake 中组织选项
原书 p.200–203。

<a id="K014"></a>
**代码出处：** CMake · 教学补充；编译选项接受检查不等于运行能力验证

```text
include(CheckCCompilerFlag)
check_c_compiler_flag("-fopenmp-simd" HAVE_OPENMP_SIMD_FLAG)
add_library(triad OBJECT triad.c)
if(HAVE_OPENMP_SIMD_FLAG)
    target_compile_options(triad PRIVATE -fopenmp-simd)
endif()
```

<a id="N049"></a>
### 逐句理解

**讲解：** include 加载 CMake 模块；check_c_compiler_flag 检查编译器能否接受参数；add_library(... OBJECT ...) 构建目标文件集合；PRIVATE 将选项限定给该目标。仍需准备合法源文件，并验证实际生成的代码与目标机器。

<a id="N050"></a>
### 原书 FindVector 是自定义模块

**讲解：** find_package(Vector) 并不意味着任意 CMake 安装都自带这个模块，需要提供原项目的 FindVector.cmake 和搜索路径。原清单还含弯引号、FLAGSS 与 FLAGS 名称不一致，以及不同厂商选项拼法，不能整段复制后假定可用。

<a id="N051"></a>
### 版本判断不等于硬件判断

**讲解：** 编译器版本足够新，不代表运行机器支持 512 位指令。跨机器发布应选择明确的最低 ISA，或使用经过正确运行时检测的多版本分派。


<a id="6.6"></a>
## 6.6 OpenMP SIMD：循环、线程和子句
原书 p.203–204。

<a id="S013"></a>
**Source:** 原书 p.203 / PDF p.239 · S013

**Original:** With the release of the OpenMP 4.0 standard, we have the option of using a more portable set of SIMD directives.

**中文:** 随着 OpenMP 4.0 标准发布，程序可以使用一套更可移植的 SIMD 指令。

<a id="K015"></a>
**代码出处：** C / OpenMP · 两种不同执行方式的教学对照

```text
#pragma omp simd
for (int i = 0; i < n; ++i) out[i] = a[i] + b[i];

/* In a separate version, with OpenMP threading enabled: */
#pragma omp parallel for simd
for (int i = 0; i < n; ++i) out[i] = a[i] + b[i];
```

<a id="N052"></a>
### 三个组合不要混淆

**讲解：** omp simd 表达 SIMD 迭代并行；omp for simd 在现有线程团队内分工并向量化；omp parallel for simd 同时包含创建团队和循环分工。for simd 本身不自动创建新的团队。simd 关联的是符合要求的循环，不是任意代码块。[R24]

<a id="N053"></a>
### private 与 lastprivate

**讲解：** private 生成私有副本，但不自动继承外部初值；lastprivate 把逻辑上最后一次顺序迭代的值带回外部，不是“最后完成线程”的值。临时变量直接放在循环体内声明通常更清楚。

<a id="N054"></a>
### 不要把 firstprivate 直接加到 simd 上

**讲解：** 原书提到 firstprivate 的一般作用，但它不在这里采用的 OpenMP 5.2 simd 构造允许的子句列表中。不同构造和版本支持的子句不同，应按规范核对。[R24]


<a id="6.6-aligned"></a>
## 6.6（续）aligned 与内存对齐
原书 p.204。

<a id="K016"></a>
**代码出处：** OpenMP SIMD · 教学示例，只有地址确实满足 64 字节对齐时才能使用

```text
#pragma omp simd aligned(a, b, out:64)
for (int i = 0; i < n; ++i)
    out[i] = a[i] + b[i];
```

<a id="N055"></a>
### aligned 是断言，不是分配动作

**讲解：** 它告诉编译器相应地址满足指定对齐，不会把指针移动到合适位置。未写对齐数值时由实现决定，不一定是 64 byte。基址对齐也不代表 a+1 仍然满足同样对齐。[R25]

<a id="N056"></a>
### 分配与释放必须配套

**讲解：** C aligned_alloc、POSIX posix_memalign 和 Windows _aligned_malloc 的接口、约束与释放方式不同；不能把原书几行声明当成可互换 API。还需处理分配失败、大小约束和整数溢出。

<a id="N057"></a>
### 用非对齐加载也要守边界

**讲解：** 现代指令常提供非对齐版本，但“允许地址未对齐”不等于“允许访问数组末端之外”。若尾部不满一个向量，选择标量尾循环、合适的掩码操作或文档明确支持的部分加载。


<a id="6.6-clauses"></a>
## 6.6（续）collapse、linear、safelen 与 simdlen
原书 p.204–205。

<a id="K017"></a>
**代码出处：** C / OpenMP · 修正原书独立 #pragma omp collapse(2) 的写法

```text
#pragma omp simd collapse(2)
for (int j = 0; j < ny; ++j) {
    for (int i = 0; i < nx; ++i) {
        out[(size_t)j * nx + i] = 0.0;
    }
}
```

<a id="N058"></a>
### collapse 是子句

**讲解：** 原书单独写 #pragma omp collapse(2) 不构成这里所需的完整指令，应附着在适当构造上。这个简单矩形嵌套可展成一个逻辑迭代空间；实际允许的循环形式与限制应按版本规范确认。

<a id="N059"></a>
### 三个专门子句

**讲解：** linear 描述变量随逻辑迭代按固定步长变化；safelen 给出安全并发的约束；simdlen 指定偏好的 SIMD 迭代数量，并不强制某种物理寄存器宽度。两者同时出现时，simdlen 不得大于 safelen。[R24]

<a id="N060"></a>
### 不能从名字猜依赖安全性

**讲解：** safelen 不会检测或修复依赖。声明必须与程序真实的数据关系相符；不确定时先分析读写集合，必要时使用更明确的算法和测试。


<a id="6.6-functions"></a>
## 6.6（续）declare simd 函数
原书 p.205。

<a id="K018"></a>
**代码出处：** C / OpenMP · 原书 declare simd 示例整理

```text
#include <math.h>
#pragma omp declare simd
double pythagorean(double a, double b) {
    return sqrt(a*a + b*b);
}
```

<a id="N061"></a>
### 它生成什么

**讲解：** declare simd 允许编译器为函数生成可用于 SIMD 调用的版本，不表示单次普通函数调用内部就会自动分成多个线程。调用位置也要有可向量化的工作；生成与选择哪些变体取决于编译器。

<a id="N062"></a>
### uniform 与分支信息

**讲解：** uniform 表示某参数在相关 SIMD 调用的各通道之间保持一致；inbranch/notinbranch 描述相应调用情境。它们是语义信息，不是用于随意强迫编译器优化的开关。

<a id="N063"></a>
### 数学与语言层面的边界

**讲解：** sqrt(a*a+b*b) 在极端幅值下可能溢出或下溢，不能当作任意输入上都稳健的范数实现。Fortran 示例的 real*8 是常见扩展写法，现代可移植声明应明确选择 kind；declare simd 和 linear 的具体语法也要按目标版本核对。


<a id="6.7"></a>
## 6.7 进一步探索与本章小结
原书 p.206。

<a id="S014"></a>
**Source:** 原书 p.206 / PDF p.242 · S014

**Original:** The best approach for further explorations is to try vectorizing a smaller code block and experiment with the compilers that you commonly use.

**中文:** 进一步探索的好方法，是选取较小的代码块，使用常用编译器进行向量化实验。

<a id="N064"></a>
### 一条可以复用的验证路径

**讲解：** 选择可信内核与输入，保存基准结果，读取成功/失败报告，确认指令和执行路径，比较端到端时间，并验证尾部、边界和误差。再逐步改变布局、接口或指令，不要一次混入多项无法归因的改动。

<a id="N065"></a>
### 下一章的连接点

**讲解：** SIMD 提供一个线程内部的并行；OpenMP 线程将不同工作分给多个核心。下一章会把变量作用域、归约、同步和数据竞争放到线程层面继续讨论，二者组合时仍需遵守各自的依赖约定。


<a id="6.7.1"></a>
## 6.7.1 延伸阅读
原书 p.206。

<a id="N066"></a>
### 保留原书阅读线索

**讲解：** John Levesque 与 Aaron Vose 的 Programming for Hybrid Multi/Manycore MPP Systems（2017）；Agner Fog 的 C++ 优化指南与 Vector Class Library 手册。原书列出的版本属于出版时期，学习时核对自己使用的版本。

<a id="N067"></a>
### 本讲义的核对来源

**讲解：** GCC 优化、x86 目标选项和向量扩展文档；OpenMP 5.2 的 simd、aligned、reduction 定义；Vector Class Library 官方项目说明。原表保留，当前规则与历史说法分开说明。


<a id="6.7.2"></a>
## 6.7.2 练习与参考思路
原书 p.206。

<a id="N068"></a>
### 练习 1｜自动向量化多材料循环

**讲解：** 挑选第 4 章一个内核，固定数据和编译器版本，开启报告并记录哪里成功、哪里失败。区分别名、真实依赖、控制流和成本判断；报告只提供线索，仍需实际测量与结果比较。

<a id="N069"></a>
### 练习 2｜添加 OpenMP SIMD

**讲解：** 先证明相关迭代可按所声明方式执行，再选择 simd、private、reduction 等子句。若循环本来就有跨迭代依赖，先改算法，不能靠 pragma 让依赖消失。

<a id="N070"></a>
### 练习 3｜从四通道改为八通道

**讲解：** 不仅修改类型或 i+=4：还要调整加载、存储、通道合并、尾部、对齐、目标编译选项以及运行时支持检查。精度和速度都可能变化，不能只比较循环次数。

<a id="N071"></a>
### 练习 4｜在旧 CPU 上运行

**讲解：** 仅编译成需要新 ISA 的版本，旧机器可能触发非法指令。若要求兼容，应构建匹配的最低 ISA 或正确分派的多版本程序。不要为了“测试”直接在不明支持条件下假定可以运行。

<a id="N072"></a>
### 配套小例子

**讲解：** 资料包提供 Python 分组与时间步长核对脚本，以及 AVX 加法教学源文件。Python 只模拟索引和算式，不执行硬件向量指令；C 示例是否编译、是否真的向量化，需要相应工具链和设备验证。


## 技术核对来源

- [R20 · GCC：x86 目标选项](https://gcc.gnu.org/onlinedocs/gcc/x86-Options.html)
- [R21 · GCC：优化、别名与浮点选项](https://gcc.gnu.org/onlinedocs/gcc/Optimize-Options.html)
- [R22 · GCC：向量扩展](https://gcc.gnu.org/onlinedocs/gcc/Vector-Extensions.html)
- [R23 · OpenMP 5.2：reduction](https://www.openmp.org/spec-html/5.2/openmpsu52.html)
- [R24 · OpenMP 5.2：simd 构造](https://www.openmp.org/spec-html/5.2/openmpse60.html)
- [R25 · OpenMP 5.2：aligned](https://www.openmp.org/spec-html/5.2/openmpse33.html)
- [R26 · Vector Class Library 官方项目](https://github.com/vectorclass/version2)