layout_examples.py 使用 Python 标准功能检查索引和单位；不依赖第三方库，不是硬件基准。commands_and_fragments.txt 是片段资料，不应整份作为脚本执行；C/C++/Fortran 片段未编译。

layout_examples.py 已实际运行，输出 index and network examples passed。
