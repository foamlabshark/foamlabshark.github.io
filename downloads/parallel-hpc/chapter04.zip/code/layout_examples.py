def row_major(row, col, ncols):
    return row * ncols + col

def column_major(row, col, nrows):
    return row + nrows * col

def lower_triangle(row, col):
    if not (0 <= col <= row):
        raise ValueError("outside lower triangle")
    return row * (row + 1) // 2 + col

def network_us(size_bytes, bandwidth_gbs, latency_us):
    if size_bytes < 0 or bandwidth_gbs <= 0 or latency_us < 0:
        raise ValueError("invalid model input")
    return latency_us + size_bytes / (bandwidth_gbs * 1000.0)

assert row_major(2, 3, 5) == 13
assert column_major(2, 3, 4) == 14
assert lower_triangle(3, 2) == 8
assert network_us(8000, 1, 5) == 13
print("index and network examples passed")
