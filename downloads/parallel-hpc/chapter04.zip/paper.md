# 第 4 章｜数据设计与性能模型

原著：Robert Robey、Yuliana Zamora，Manning，2021。原书 p.86–123 / PDF p.122–159。

核心段落中英对照、全部编号小节解释、18 幅核心原图、表 4.1、公式和代码语法。4.A 是 p.121 未编号图的讲义定位标签。不是逐段全文译本。

## 小节索引

- [第 4 章导读｜数据设计与性能模型](#4-intro)
- [4.1 面向性能的数据结构：面向数据设计](#4.1)
- [4.1.1 多维数组：行优先与列优先](#4.1.1)
- [4.1.1（续）Fortran 切片、步长与连续性](#4.1.1-fortran)
- [4.1.1（续）C 二维数组的连续内存分配](#4.1.1-allocate)
- [4.1.1（续）一维访问、二维下标与库接口](#4.1.1-index)
- [4.1.2 AoS 与 SoA：RGB 颜色数据](#4.1.2)
- [4.1.2（续）布局优劣取决于访问模式](#4.1.2-patterns)
- [4.1.3 AoSoA：按小块组织数组](#4.1.3)
- [4.2 缓存未命中的三个 C](#4.2)
- [4.2（续）五点模板：区分引用量与主存流量](#4.2-stencil)
- [4.2（续）局部性与缓存一致性](#4.2-locality)
- [4.3 简单性能模型：多材料案例](#4.3)
- [4.3.1 完整矩阵：按单元或按材料组织](#4.3.1)
- [4.3.2 压缩稀疏存储：以单元为中心](#4.3.2)
- [4.3.2（续）以材料为中心的压缩表示](#4.3.2-material)
- [4.3.2（续）表 4.1：模型与实测比较](#4.3.2-results)
- [4.4 更精细的性能模型](#4.4)
- [4.4（续）ECM 的重叠与非重叠时间](#4.4-ecm)
- [4.5 网络消息：延迟加传输时间](#4.5)
- [4.5（续）幽灵单元交换与归约](#4.5-ghost)
- [4.6 进一步探索与本章小结](#4.6)
- [4.6.1 延伸阅读](#4.6.1)
- [4.6.2 练习与参考思路](#4.6.2)

## 公式索引

- [E001](#E001) · 原书 p.94 · k = j × N_x + i
- [E002](#E002) · 原书 p.103 · I = 5 × 2000² / (2 × 2002² × 8) ≈ 0.312 FLOP/byte
- [E003](#E003) · 原书 p.107 · B_p = N_b × B_f × (B_c + P_c) / ν
- [E004](#E004) · 原书 p.110 · memops = N_c × (N_m + 2F_f N_m + 2)
- [E005](#E005) · 原书 p.113 · bytes = (4 + 16M_f) × N_c + 20M_L
- [E006](#E006) · 原书 p.118 · T_ECM = max(T_nOL + T_data, T_OL)
- [E007](#E007) · 原书 p.119 · T = α + n / B
- [E008](#E008) · 原书 p.123 · k = i(i+1)/2 + j,  0 ≤ j ≤ i < n

## 术语约定

|原文|译法|说明|
|---|---|---|
|AoS|结构体数组|对象字段相邻，再排列对象|
|SoA|数组结构体|同一字段的元素连续|
|AoSoA|数组结构体的数组|按小块混合 AoS 与 SoA|
|row major|行优先|最后一个下标变化最快|
|column major|列优先|第一个下标变化最快|
|stride|步长|相邻逻辑元素的存储间隔|
|array descriptor|数组描述符|描述起点、长度、步长等|
|compulsory miss|首次访问未命中|首次需要数据块|
|capacity miss|容量未命中|工作集超出可用缓存|
|conflict miss|冲突未命中|多个地址竞争有限缓存组路数|
|false sharing|伪共享|不同数据共享同一缓存行导致竞争|
|ECM|执行-缓存-内存模型|Execution Cache Memory model|
|sparse storage|稀疏存储|保留有效条目和导航信息|

<a id="4-intro"></a>
## 第 4 章导读｜数据设计与性能模型
原书 p.86–87。

<a id="S001"></a>
**Source:** 原书 p.86 / PDF p.122 · S001

**Original:** Although it may seem secondary to performance, the data structure and its design are critical. This must be determined in advance because it dictates the entire form of the algorithms, code, and later, the parallel implementation.

**中文:** 数据结构及其设计看起来似乎只是性能的次要因素，实际上却至关重要。它需要尽早确定，因为它会影响算法、代码以及后续并行实现的整体形式。

<a id="N001"></a>
### 本章的主线

**讲解：** 先看数据在内存中怎样排布，再看循环按什么顺序访问，最后估算缓存、主存与网络搬运的成本。即使数学公式相同，数据布局不同也可能带来很大的性能差异。

<a id="N002"></a>
### 和第 3 章如何衔接

**讲解：** 第 3 章用 Roofline 找到性能上界；本章进一步问：为什么程序远低于上界？哪些字节被反复加载，哪些缓存行只用了很少一部分，哪些数据原本就不必保存？

<a id="N003"></a>
### 阅读范围

**讲解：** 保留 4.1–4.6 及全部编号子小节，长小节按概念和代码分为多个阅读单元。核心原图与表保留；4.A 是原书 p.121 未编号的幽灵单元图，表 4.1 保持原表编号。译文、原书示例、教学修正版和数值校核分别标识。


<a id="4.1"></a>
## 4.1 面向性能的数据结构：面向数据设计
原书 p.88–89。

<a id="S002"></a>
**Source:** 原书 p.89 / PDF p.125 · S002

**Original:** This approach is coined data-oriented design, which focuses on the best data layout for the CPU and the cache.

**中文:** 这种方法称为面向数据设计，它关注适合 CPU 和缓存的数据布局。

<a id="N004"></a>
### 从使用方式倒推布局

**讲解：** 要批量处理哪些对象？每一轮只用一个字段，还是所有字段一起用？能否连续访问并复用缓存中的数据？这些问题比“把相关字段放进同一个类就完事”更接近性能瓶颈。

<a id="N005"></a>
### 批量计算与封装并不冲突

**讲解：** 原书批评深调用栈、频繁方法调用和零散分配的开销，但不能由此推出 C++ 类必然慢、C 必然快。编译器可以内联成员函数，也可以在批处理接口内部使用连续数据。应检查实际生成代码和测量结果，而非仅按语言或编程范式判断。

<a id="N006"></a>
### 原书建议的实际含义

**讲解：** 优先考虑数组上的批量操作；控制分配和重分配；让热点路径易于向量化；用连续数组和索引替代到处跳转的链表。它们是针对访问模式的设计手段，不是要求所有数据结构都改成同一种形式。


<a id="4.1.1"></a>
## 4.1.1 多维数组：行优先与列优先
原书 p.90。

<a id="S003"></a>
**Source:** 原书 p.90 / PDF p.126 · S003

**Original:** The C data order is referred to as row major, where data across the row varies faster than data in the column. This means that row data is contiguous in memory.

**中文:** C 的数据排列称为行优先：沿行方向的数据变化快于沿列方向的数据。因此，同一行的数据在内存中连续。

<a id="F001"></a>
### 图 4.2
**Source:** 原书 p.90 / PDF p.126 · C001
**Placed near:** 4.1.1 多维数组：行优先与列优先

![图 4.2](assets/fig4_2.png)

**Original caption:** Conventional C ordering is row major while Fortran ordering is column major. Switching either the Fortran or C index order makes these compatible. Note that convention has Fortran array indices starting at 1 while C starts at 0. Also, C convention numbers the elements from 0 to 15 in contiguous order.

**中文图注:** 通常 C 使用行优先，Fortran 使用列优先。调整索引顺序可以使两种视图的内存顺序对应。C 下标通常从 0 开始，Fortran 默认下界为 1；图中按连续存储顺序用 0–15 标识元素。

**Reading note:** 图中的数字是线性偏移，不是矩阵必须储存的数值。Fortran 下界可以显式指定；索引起点与行/列优先是两个不同问题。

<a id="F002"></a>
### 图 4.3
**Source:** 原书 p.90 / PDF p.126 · C002
**Placed near:** 4.1.1 多维数组：行优先与列优先

![图 4.3](assets/fig4_3.png)

**Original caption:** For C, the important thing to remember is that the last index varies fastest and should be the inner loop of a nested loop. For Fortran, the first index varies fastest and should be the inner loop of a nested loop.

**中文图注:** C 数组的最后一个下标变化最快，适合放在内层循环；Fortran 数组的第一个下标变化最快，适合放在内层循环。

**Reading note:** 这是争取连续访问的通常原则。若存在数据依赖，不能只为连续访问就任意交换循环；还要保证算法含义不变。

<a id="K001"></a>
**代码出处：** C · 原书图 4.3 的循环整理，p.90

```text
for (int j = 0; j < jmax; ++j) {
    for (int i = 0; i < imax; ++i) {
        A[j][i] = 0.0;
    }
}
```

<a id="K002"></a>
**代码出处：** Fortran · 原书图 4.3 的循环整理，p.90

```text
do i = 1, imax
    do j = 1, jmax
        A(j,i) = 0.0
    end do
end do
```

<a id="N007"></a>
### 语法与执行顺序

**讲解：** C 的 ++i 将 i 增加 1，i < imax 排除末端越界；Fortran 的 do j=1,jmax 包含两端。图中同样用 A(j,i) 表示数组，但 Fortran 让第一个下标 j 在内层变化，因此连续访问的是同一列。


<a id="4.1.1-fortran"></a>
## 4.1.1（续）Fortran 切片、步长与连续性
原书 p.91。

<a id="S004"></a>
**Source:** 原书 p.91 / PDF p.127 · S004

**Original:** In Fortran, the dope vector is the metadata for the array containing the start location, length of the array, and the stride between elements for each dimension.

**中文:** 在 Fortran 中，数组描述符包含数组的起始位置、各维长度和各维元素之间的步长等元数据。

<a id="F003"></a>
### 图 4.4
**Source:** 原书 p.91 / PDF p.127 · C003
**Placed near:** 4.1.1（续）Fortran 切片、步长与连续性

![图 4.4](assets/fig4_4.png)

**Original caption:** Different views of a Fortran array created by modifying the dope vector, a set of metadata describing the start, stride, and length in each dimension. The slice operator returns a section of a Fortran array with all of the elements in the dimension with the colon (:). More complicated sections can be created, such as the lower four elements with A(1:2,1:2), where the upper and lower bounds are specified with the colon.

**中文图注:** 通过描述各维起点、步长和长度的数组描述符，可以表示 Fortran 数组的不同视图。冒号表示选取该维的区段；例如 A(1:2,1:2) 选取两个维度各自下标 1–2 的元素。

**Reading note:** 连续列切片 x(:,1) 的元素步长为 1；行切片 x(1,:) 的步长为第一维长度。原图把步长为 4 的一侧也标成 x(:,1)，与数据顺序不符；这里明确更正为 x(1,:) 的情形。

<a id="K003"></a>
**代码出处：** Fortran · 教学修正版，对应 p.91 连续性讨论

```text
real, allocatable :: x(:,:)
allocate(x(4,4))
! x(:,1): contiguous column
! x(1,:): strided row
```

<a id="N008"></a>
### CONTIGUOUS 不能随意附加

**讲解：** 原书写 real, allocatable, contiguous :: x(:,:)，且暗示不用该属性就不保证连续，这不准确。已分配的普通 allocatable 整数组本身是连续的；CONTIGUOUS 主要用于数组指针、假定形状或假定秩形参等适用对象，不应直接套在这个 allocatable 声明上。[R13]

<a id="N009"></a>
### 切片是否复制取决于接口

**讲解：** 带步长的切片可以通过描述符传递，也可能因被调用过程要求连续数据而产生临时副本。不能一概断言切片总会复制，也不能保证从不复制。应结合形参声明、编译器诊断与测量，确认热点调用是否有隐藏搬运。


<a id="4.1.1-allocate"></a>
## 4.1.1（续）C 二维数组的连续内存分配
原书 p.92–93。

<a id="S005"></a>
**Source:** 原书 p.92 / PDF p.128 · S005

**Original:** This listing uses 1+jmax allocations, and each allocation can come from a different place in the heap.

**中文:** 这段清单使用 1+jmax 次分配，每次分配的内存都可能来自堆中的不同位置。

<a id="K004"></a>
**代码出处：** C · 清单 4.1 的教学整理；为突出结构省略失败处理

```text
double **x = malloc(jmax * sizeof *x);
for (int j = 0; j < jmax; ++j)
    x[j] = malloc(imax * sizeof *x[j]);
/* Use x[j][i]. */
for (int j = 0; j < jmax; ++j) free(x[j]);
free(x);
```

<a id="N010"></a>
### double ** 不是普通二维数组

**讲解：** x 指向一组行指针；每个 x[j] 再指向一行 double。行内部可以连续，各行之间却没有连续保证。不能把整张指针表直接当作连续 double 数据传给数值库、GPU 或文件写入接口。

<a id="K005"></a>
**代码出处：** C · 清单 4.2 的教学整理；维度须为正，正式代码须检查溢出与分配失败

```text
double **x = malloc(jmax * sizeof *x);
double *data = malloc((size_t)jmax * imax * sizeof *data);
for (int j = 0; j < jmax; ++j)
    x[j] = data + (size_t)j * imax;
/* Use x[j][i], or data[j * imax + i]. */
free(data);
free(x);
```

<a id="N011"></a>
### 指针加法按元素移动

**讲解：** data + j*imax 跳过 j 行 double，不是跳过 j*imax 个字节。sizeof *data 给出一个 double 的大小。两次分配分别拥有行指针表和数据块，因此分别释放；不能再逐行 free(x[j])，因为那些只是同一分配块内部的地址。

<a id="F004"></a>
### 图 4.5
**Source:** 原书 p.93 / PDF p.129 · C004
**Placed near:** 4.1.1（续）C 二维数组的连续内存分配

![图 4.5](assets/fig4_5.png)

**Original caption:** A contiguous block of memory becomes a 2D array in C.

**中文图注:** 连续内存块可以配合行指针构成 C 中可按二维下标访问的数据结构。

**Reading note:** 行指针是访问视图，真正的标量数据是一块连续区域。图展示将指针表与数据一起分配的思路，但实现时还必须处理大小、偏移和对齐。

<a id="K006"></a>
**代码出处：** C · 原书清单 4.3 摘录，p.93；存在平台假设

```text
double **x = (double **)malloc(jmax*sizeof(double *) +
                              jmax*imax*sizeof(double));
x[0] = (double *)x + jmax;
```

<a id="N012"></a>
### 为什么不直接照抄单块版本

**讲解：** x[0] 的偏移按 double 大小计算，却要跳过 jmax 个 double*。它隐含两种类型大小和对齐兼容的假设，不是通用分配器。正式单块实现需按字节计算指针区大小并向 double 对齐，还需检查整数溢出、零维度和 malloc 失败。初学时优先理解两次分配版本。


<a id="4.1.1-index"></a>
## 4.1.1（续）一维访问、二维下标与库接口
原书 p.93–94。

<a id="S006"></a>
**Source:** 原书 p.93 / PDF p.129 · S006

**Original:** The array can also be indexed as a 1D or a 2D array as shown in listing 4.4.

**中文:** 如清单 4.4 所示，这个数组既可以按一维方式索引，也可以按二维方式索引。

<a id="E001"></a>
**Source:** 原书 p.94 / PDF p.130 · E001

$$
k=j\,N_x+i
$$

教学表达：行优先矩形数组中，0 起点的行 j、列 i 对应线性元素偏移 k。N_x 为列数，0≤i<N_x，0≤j<N_y。

<a id="K007"></a>
**代码出处：** C · 依据清单 4.4 整理，p.94，前提是数据块连续

```text
double *x1d = x[0];
for (int j = 0; j < jmax; ++j) {
    for (int i = 0; i < imax; ++i) {
        x1d[(size_t)j * imax + i] = 0.0;
    }
}
```

<a id="N013"></a>
### 三种写法的关系

**讲解：** 对于上一节的连续分配，x[j][i] 与 data[j*imax+i] 指向同一元素。整块一维遍历常便于批量初始化，但并不意味着编译器处理良好的二维循环必然更慢。性能还取决于地址计算、别名与优化。

<a id="N014"></a>
### C/C++ 本来就有多维数组

**讲解：** 原书说 C/C++ 没有原生多维数组，表述过于绝对。double a[4][5] 就是数组的数组，其元素按连续的子数组布局；它与动态 double** 指针表不是同一种类型。动态尺寸管理、视图和通用数值接口才是这里需要额外设计的部分。[R14]

<a id="N015"></a>
### 传给 Fortran 库要核对什么

**讲解：** 确认行/列优先、元素类型、leading dimension 和函数接口，而不是只交换两个变量名。连续性解决能否整块传递的问题，索引语义和 ABI 仍需要单独匹配。


<a id="4.1.2"></a>
## 4.1.2 AoS 与 SoA：RGB 颜色数据
原书 p.94–96。

<a id="S007"></a>
**Source:** 原书 p.95 / PDF p.131 · S007

**Original:** The SoA is an alternative data layout.

**中文:** SoA 是另一种数据布局。

<a id="K008"></a>
**代码出处：** C · 原书清单 4.5 的紧凑写法，p.95

```text
struct RGB { int R, G, B; };
struct RGB polygon_color[1000];
```

<a id="F005"></a>
### 图 4.6
**Source:** 原书 p.95 / PDF p.131 · C005
**Placed near:** 4.1.2 AoS 与 SoA：RGB 颜色数据

![图 4.6](assets/fig4_6.png)

**Original caption:** Layout in memory of an RGB color model in an Array of Structures (AoS).

**中文图注:** RGB 颜色模型的结构体数组（AoS）内存布局。

**Reading note:** 每个对象的 R、G、B 相邻，对象之间再顺序排列。图示每对象占 16 字节并带填充，但普通三个 4 字节 int 的结构体常为 12 字节；应使用 sizeof 和实际 ABI 核对，不把图中的填充当作必然。

<a id="K009"></a>
**代码出处：** C · 依据清单 4.6 整理，省略分配失败处理

```text
struct RGB_arrays { int *R, *G, *B; };
struct RGB_arrays color;
color.R = malloc(1000 * sizeof *color.R);
color.G = malloc(1000 * sizeof *color.G);
color.B = malloc(1000 * sizeof *color.B);
/* Read color.R[i], color.G[i], color.B[i]. */
free(color.R); free(color.G); free(color.B);
```

<a id="F006"></a>
### 图 4.7
**Source:** 原书 p.96 / PDF p.132 · C006
**Placed near:** 4.1.2 AoS 与 SoA：RGB 颜色数据

![图 4.7](assets/fig4_7.png)

**Original caption:** In the Structure of Arrays (SoA) data layout, the pointers are adjacent in memory, pointing to separate contiguous arrays for each color.

**中文图注:** 在数组结构体（SoA）布局中，指针位于结构体内，各自指向一种颜色的连续数组。

**Reading note:** 连续的是各颜色数组自己的元素，不要求 R、G、B 三块分配彼此紧挨着。只遍历 R 时，SoA 不需要同时搬入每个对象的 G 和 B。

<a id="N016"></a>
### 成员访问的区别

**讲解：** AoS 写 polygon_color[i].R：先选对象，再选字段。SoA 写 color.R[i]：先选数组字段，再选元素。点号访问结构体成员，方括号按数组下标访问。布局差异来自存储组织，而不只是这两个运算符顺序变化。

<a id="N017"></a>
### 填充比例的更正

**讲解：** 原书把 64-bit 边界与 128 bit/16 byte 混在一起；64 bit 实际是 8 byte。若一个 12 字节对象真被填充到 16 字节，填充占总大小的 25%，但相对于原来的 12 字节，大小增加的是 33.3%。


<a id="4.1.2-patterns"></a>
## 4.1.2（续）布局优劣取决于访问模式
原书 p.96–100。

<a id="S008"></a>
**Source:** 原书 p.97 / PDF p.133 · S008

**Original:** Thus, the optimal data layout depends entirely on usage and the particular data access patterns.

**中文:** 因此，最佳数据布局取决于实际用途和具体的数据访问模式。

<a id="K010"></a>
**代码出处：** C · 原书清单 4.7 及半径循环整理，pp.96–97；数组和 math.h 需另行提供

```text
struct point { double x, y, z; };
struct point cell[1000];
/* After initialization: */
for (int i = 0; i < 1000; ++i)
    radius[i] = sqrt(cell[i].x*cell[i].x +
                     cell[i].y*cell[i].y +
                     cell[i].z*cell[i].z);
```

<a id="N018"></a>
### 一起用还是只用一个字段

**讲解：** 求半径时 x、y、z 都会用到，AoS 把三者放在一起较合理；求 x 方向密度梯度时只读 x，AoS 会夹带暂时不用的 y、z。以三个 double、无填充的对象为例，仅从位置数组看有效字段比例约 1/3。

<a id="K011"></a>
**代码出处：** C · 原书清单 4.8 的 SoA 梯度循环，pp.97–98

```text
for (int i = 1; i < 1000; ++i) {
    density_gradient[i] = (density[i] - density[i-1]) /
                         (cell.x[i] - cell.x[i-1]);
}
```

<a id="N019"></a>
### 梯度代码还需要哪些前提

**讲解：** 从 i=1 开始避免 i-1 越界，但输出下标 0 需要另定边界规则；相邻 x 的差必须不为零。代码只是离散差分示例，不意味着任意不规则网格上都可忽略边界和几何细节。

<a id="N020"></a>
### C++ 方法调用不必然有缓存未命中

**讲解：** 清单 4.9 展示每个 Cell 调用 calc_radius 的形式。成员函数可能被内联；调用参数也可能通过寄存器传递，而非全部压栈。因此不能从源码有一次函数调用就推断一定发生指令缓存未命中。清单中的类定义还应以分号结束，数学函数与初始化也需补齐。

<a id="N021"></a>
### 两个额外例子

**讲解：** 哈希查找通常先扫描 key，命中后才读 value，分开数组可能减少无用搬运；物理状态结构有密度、三个动量分量和总能量，如果循环只用密度，其余四项可能浪费流量。原书“CPU 通常偏好 AoS、GPU 偏好 SoA”只是经验概括，不是适用于所有内核的规则。


<a id="4.1.3"></a>
## 4.1.3 AoSoA：按小块组织数组
原书 p.100–101。

<a id="S009"></a>
**Source:** 原书 p.100 / PDF p.136 · S009

**Original:** There are cases where hybrid groupings of structures and arrays are effective.

**中文:** 在某些情况下，结构体与数组的混合分组方式十分有效。

<a id="F007"></a>
### 图 4.8
**Source:** 原书 p.100 / PDF p.136 · C007
**Placed near:** 4.1.3 AoSoA：按小块组织数组

![图 4.8](assets/fig4_8.png)

**Original caption:** An Array of Structures of Arrays (AoSoA) is used with the last array length, matching the vector length of the hardware for a vector length of four.

**中文图注:** AoSoA 的最内层数组长度可按硬件向量长度选择；图中使用长度为 4 的块。

**Reading note:** 一块依次保存 R 的四项、G 的四项、B 的四项，再进入下一块。它在对象聚合和同字段连续访问之间折中。

<a id="K012"></a>
**代码出处：** C++ · 清单 4.13 的教学修正版，含非整除长度处理

```text
#include <vector>
constexpr int V = 4;
struct Block { int R[V], G[V], B[V]; };
int len = 1000;
std::vector<Block> blocks((len + V - 1) / V);
for (int k = 0; k < len; ++k) {
    int block = k / V;
    int lane = k % V;
    blocks[block].R[lane] = 0;
    blocks[block].G[lane] = 0;
    blocks[block].B[lane] = 0;
}
```

<a id="N022"></a>
### 分块下标语法

**讲解：** k/V 是整数除法，定位块；k%V 是余数，定位块内元素；(len+V-1)/V 是正整数向上取整。原书 len 是运行时变量，直接声明 AoSoA[len/V] 属于变长数组写法，不是标准 C++ 数组声明；这里使用 std::vector。尾块未使用的槽位不能当作有效数据参与计算。

<a id="F008"></a>
### 图 4.9
**Source:** 原书 p.101 / PDF p.137 · C008
**Placed near:** 4.1.3 AoSoA：按小块组织数组

![图 4.9](assets/fig4_9.png)

**Original caption:** Performance of the Array of Structures of Arrays (AoSoA) generally matches the best of the AoS and SoA performances. The 1, 8 and NP array length in the x-axis legend is the value for the last array in AoSoA. These values mean that the first set reduces to an AOS, the last set reduces to an SoA, and the middle set has a second array length of 8 to match the vector length of the processor.

**中文图注:** 图中比较 AoSoA 最内层长度取 1、8 和 NP 的性能。长度 1 对应 AoS，长度 NP 对应 SoA，中间的长度 8 用于匹配示例处理器的向量长度；该研究中 AoSoA 综合表现较好。

**Reading note:** 纵轴是时间，越低越好。两类内核偏好的布局不同，总时间需要一起看；本图是特定测试结果，不保证任意 AoSoA 都胜过另外两种布局。

<a id="N023"></a>
### 向量长度不是唯一参数

**讲解：** 块宽还影响索引成本、对齐、缓存工作集与 GPU 访问。V=1 和 V=len 可恢复两种极端布局，但合适的 V 必须结合目标硬件、数据类型和具体内核验证。


<a id="4.2"></a>
## 4.2 缓存未命中的三个 C
原书 p.101–102。

<a id="S010"></a>
**Source:** 原书 p.102 / PDF p.138 · S010

**Original:** When data is loaded, it is loaded in blocks, called cache lines, that are typically 64 bytes long.

**中文:** 数据通常按称为缓存行的块加载；常见缓存行长度为 64 字节。

<a id="N024"></a>
### Compulsory：首次访问未命中

**讲解：** 某个数据块第一次需要进入缓存时产生的未命中。它是分析的基线，但若数据此前已被相关操作预热，测量开始时就未必属于冷缓存。

<a id="N025"></a>
### Capacity：容量未命中

**讲解：** 工作集超过缓存容量，原本还会复用的数据被逐出，后续必须重新加载。减少活跃工作集、分块和提高时间局部性可能缓解这种问题。

<a id="N026"></a>
### Conflict：冲突未命中

**讲解：** 即使总工作集理论上放得下，多个地址映射到同一缓存组，也可能竞争有限的路数并反复互相替换。组相联缓存提供多个候选位置；“同一组”不等于“同一数据缓存行”。

<a id="N027"></a>
### 预取、写分配与实际停顿

**讲解：** 可预测访问有利于预取；写分配策略可能在存储前读取缓存行。并非每次未命中都使整颗核心停顿相同周期：其他独立工作、在途请求、命中层级及写策略会改变开销。


<a id="4.2-stencil"></a>
## 4.2（续）五点模板：区分引用量与主存流量
原书 p.102–104。

<a id="K013"></a>
**代码出处：** C · 原书清单 4.14 的计算内核，p.103

```text
for (int j = 1; j < jmax - 1; ++j) {
    for (int i = 1; i < imax - 1; ++i) {
        xnew[j][i] = (x[j][i] + x[j][i-1] + x[j][i+1]
                     + x[j-1][i] + x[j+1][i]) / 5.0;
    }
}
```

<a id="N028"></a>
### 逐点计数

**讲解：** 每个内部点有 5 次源代码级读取、1 次写入，以及 4 次加法和 1 次除法。在作者的运算计数下为 5 FLOP。相邻点复用输入，因此不能把 5 次读取都直接当成 5 次独立 DRAM 传输。

<a id="N029"></a>
### 192 MB 与 64.1 MB 不是同一个概念

**讲解：** 2000×2000×6×8=192 MB 是按源码引用累计的逻辑字节量，不是数组占用的内存容量。两块 2002×2002 的 double 数据区总占用约 64.128 MB；在作者理想复用和忽略额外写流量的模型中，它也近似代表首次读入与输出所需的数据量。

<a id="E002"></a>
**Source:** 原书 p.103 / PDF p.139 · E002

$$
I=\frac{5\times2000^2}{2\times2002^2\times8}\approx0.312
$$

按原书简化流量模型复算。实际计数器可能包含写分配、额外重载等流量，因此模型与实测须采用一致口径。

<a id="N030"></a>
### 完整清单中的问题应先修复

**讲解：** p.103 声明 double cpu_time 后直接累加，缺少初始化，应先设为 0。初始 x 边界为 5、xnew 边界为 0，交换指针后若不维护边界会交替变化，不能直接当作固定边界的物理模拟。写 flush 数组也不自动证明缓存完全冷；无后续可观察用途的写操作可能被编译器优化。

<a id="K014"></a>
**代码出处：** C · 清单 4.14 指针交换的教学展开

```text
double **tmp = xnew;
xnew = x;
x = tmp;
```

<a id="N031"></a>
### 交换指针而不是复制数组

**讲解：** 三次赋值仅改变哪块数据被视作“旧”和“新”，不会复制整张网格。x1d 等另存的指针也不会随 x 自动更新；如果后面继续使用这些别名，需要核对它们仍指向哪一块。


<a id="4.2-locality"></a>
## 4.2（续）局部性与缓存一致性
原书 p.104–105。

<a id="F009"></a>
### 图 4.10
**Source:** 原书 p.104 / PDF p.140 · C009
**Placed near:** 4.2（续）局部性与缓存一致性

![图 4.10](assets/fig4_10.png)

**Original caption:** The roofline plot of the stencil kernel for the Krakatau example in chapter 1 shows the compulsory upper bound to the right of the measured performance.

**中文图注:** 第 1 章火山示例的模板内核 Roofline 中，首次加载模型的算术强度上界位于实测点右侧。

**Reading note:** 原书给出实测强度 0.247 与简化上界 0.312。固定 FLOP 数时，这对应的流量比约为 0.312/0.247≈1.263，即多约 26.3%，不能直接复算出正文的“约 15%”。图中的全机屋顶也不能与单线程内核不加区分地比较。

<a id="S011"></a>
**Source:** 原书 p.105 / PDF p.141 · S011

**Original:** Spatial locality refers to data with nearby locations in memory that are often referenced close together.

**中文:** 空间局部性指的是：内存位置相近的数据，往往在相近的时间被访问。

<a id="S012"></a>
**Source:** 原书 p.105 / PDF p.141 · S012

**Original:** Temporal locality refers to recently referenced data that is likely to be referenced again in the near future.

**中文:** 时间局部性指的是：刚被访问的数据，很可能在不久后再次被访问。

<a id="N032"></a>
### 第五个值为何不必重新读主存

**讲解：** 计算 x[1][1] 时可能把同一缓存行内的 x[1][2] 一起带入，这是空间局部性。下一个输出还需要 x[1][1]，若它仍在缓存则可复用，这是时间局部性。

<a id="N033"></a>
### 第四个 C：Coherency

**讲解：** 多核对共享数据进行读写时，需要维持缓存一致性。不同线程即使写不同变量，如果它们位于同一缓存行，也可能产生伪共享。改善写入划分、避免多个线程频繁争用同一缓存行，可能比继续增加线程更有用。


<a id="4.3"></a>
## 4.3 简单性能模型：多材料案例
原书 p.105–108。

<a id="S013"></a>
**Source:** 原书 p.106 / PDF p.142 · S013

**Original:** The goal of these models is to get a rough assessment of performance through simple counts of operations in a characteristic kernel to make decisions on programming alternatives.

**中文:** 这些模型的目标，是通过统计代表性内核中的操作次数来粗略评估性能，从而比较不同编程方案。

<a id="F010"></a>
### 图 4.11
**Source:** 原书 p.107 / PDF p.143 · C010
**Placed near:** 4.3 简单性能模型：多材料案例

![图 4.11](assets/fig4_11.png)

**Original caption:** A 3×3 computational mesh shows that cell 7 contains four materials.

**中文图注:** 一个 3×3 计算网格中，单元 7 同时包含四种材料。

**Reading note:** 整个网格有多种材料，但每个单元不必包含全部材料。单元和材料的组合大量为空，这就是压缩稀疏表示可能节省内存的原因。

<a id="N034"></a>
### 原书测试设置

**讲解：** 案例使用约 100 万单元、50 种材料、四个状态数组，比较几何分布和随机分布。几何案例大约 95% 纯单元、5% 混合单元；随机案例大约 80% 纯单元。原书同时考虑平均密度和材料压力计算，二者偏好的布局可能不同。

<a id="N035"></a>
### 先约定符号与物理意义

**讲解：** 密度记为 ρ、压力记为 p，避免 PDF 抽取将两者都变成 p。若 f_m 是体积分数，则平均密度为各 ρ_m f_m 之和；若权重是材料体积，则求和后需除以单元总体积。原书在 V_f 的名称和部分算法的除体积步骤上不够一致，实施时必须先统一这一约定。

<a id="E003"></a>
**Source:** 原书 p.107 / PDF p.143 · E003

$$
B_p=\frac{N_bB_f(B_c+P_c)}{\nu}
$$

原书的分支成本粗估：分支次数 × 未预测成功的比例 × 每次代价，再除以频率。周期换成秒或毫秒时必须统一 ν 的单位；这些经验参数不适用于所有微架构。

<a id="N036"></a>
### 模型需要数什么

**讲解：** 记录读写字节、浮点与整数/地址运算、连续或间接访问、分支和短循环。这里的模型用于筛选方案，不应把一次拟合得到的周期惩罚视为硬件永远不变的常数。


<a id="4.3.1"></a>
## 4.3.1 完整矩阵：按单元或按材料组织
原书 p.109–111。

<a id="S014"></a>
**Source:** 原书 p.109 / PDF p.145 · S014

**Original:** The simplest data structure is a full matrix storage representation. This assumes that every material is in every cell.

**中文:** 最简单的数据结构是完整矩阵存储：为每个单元中的每一种材料都预留一个位置。

<a id="F011"></a>
### 图 4.13
**Source:** 原书 p.109 / PDF p.145 · C011
**Placed near:** 4.3.1 完整矩阵：按单元或按材料组织

![图 4.13](assets/fig4_13.png)

**Original caption:** The cell-centric, full matrix data structure with materials stored contiguously for each cell

**中文图注:** 以单元为中心的完整矩阵，同一单元的材料连续存储。

**Reading note:** C 形式是 state[cell][material]，材料索引连续。不存在的材料仍有零值槽位；单元内材料很稀疏时，这些槽位会占据大量空间。

<a id="N037"></a>
### 单元主导循环

**讲解：** 外层遍历单元，内层遍历材料，将该单元的加权密度累积在一个局部变量中。若加条件跳过零材料，可减少一些读取和计算，但仍需要扫描体积分数，并承担分支成本。

<a id="E004"></a>
**Source:** 原书 p.110 / PDF p.146 · E004

$$
\mathrm{memops}=N_c(N_m+2F_fN_m+2)
$$

原书按源码操作统计。N_c=10^6、N_m=50、F_f=0.021 时为 54.1 Mmemops；若每次为 8 byte，结果为 432.8 MB。后文模型/表格使用约 424 MB，说明计数口径并未完全统一。

<a id="F012"></a>
### 图 4.15
**Source:** 原书 p.111 / PDF p.147 · C012
**Placed near:** 4.3.1 完整矩阵：按单元或按材料组织

![图 4.15](assets/fig4_15.png)

**Original caption:** The material-centric full matrix data structure stores cells contiguously for each material. The array indexing in C would be density[m][C] with the cell index contiguous. The cells with dashes are filled with zeros.

**中文图注:** 以材料为中心的完整矩阵，将同一种材料的单元连续存储。C 下标形式为 density[m][C]，单元索引连续，短横线处实际填零。

**Reading note:** 为连续访问，外层应遍历材料，内层遍历单元。计算单元平均密度时需要先初始化输出，逐材料累加，最后再完成归一化。

<a id="N038"></a>
### 材料主导循环的计数

**讲解：** 原书得到 4N_c(N_m+1)=204 Mmemops，按 8 byte 为 1632 MB；用 13375 MB/s 的带宽估算约 122.02 ms。这是本例的模型值。不能据此认定所有材料主导算法都更慢，换成材料内核可能反而更合适。

<a id="N039"></a>
### 原书模型不一致处

**讲解：** p.107 与 p.110 对预取损失参数的数值不同；分支惩罚符号及是否再次乘次数也不够统一。因此这里保留表中估计结果用于比较趋势，不声称能够用所有印刷公式无歧义地重现 67.2 ms。


<a id="4.3.2"></a>
## 4.3.2 压缩稀疏存储：以单元为中心
原书 p.112–114。

<a id="S015"></a>
**Source:** 原书 p.112 / PDF p.148 · S015

**Original:** The solution is to put the linked list into a contiguous array with the link pointing to the start of the material entries.

**中文:** 一种解决办法是把链表放进连续数组，用链接索引指向材料条目的起始位置。

<a id="F013"></a>
### 图 4.17
**Source:** 原书 p.112 / PDF p.148 · C013
**Placed near:** 4.3.2 压缩稀疏存储：以单元为中心

![图 4.17](assets/fig4_17.png)

**Original caption:** The mixed material arrays for the cell-centric data structure use a linked list implemented in a contiguous array. The different shading at the bottom indicates the materials that belong to a particular cell and match the shading used in figure 4.13.

**中文图注:** 以单元为中心的混合材料数据，在连续数组中实现索引链表。底部不同颜色对应不同单元的材料条目，与图 4.13 的配色相呼应。

**Reading note:** 纯单元可直接保存状态，混合单元进入紧凑条目数组。nextfrac 指向下一条，frac2cell 反查所属单元，material 保存材料编号。索引与数据是两类不同信息。

<a id="N040"></a>
### 负号与结束标记的语法含义

**讲解：** 这是作者自行设计的编码：imaterial 为正时指向纯单元数据，非正时经约定转换到混合条目；nextfrac 的负值表示结束。它不是 C 或 Fortran 的内置链表规则。实现时必须区分合法索引 0、入口编码与终止标记，防止错误取绝对值后无限循环。

<a id="N041"></a>
### 动态增加与局部性

**讲解：** 新材料条目可追加到数组末尾，再通过 nextfrac 链接；这样避免搬动整段数据，但会破坏部分连续性。周期性整理能恢复顺序，却又有重排成本。压缩布局的优势与维护成本应一起衡量。

<a id="E005"></a>
**Source:** 原书 p.113 / PDF p.149 · E005

$$
\mathrm{bytes}=(4+16M_f)N_c+20M_L
$$

按图 4.18 注释补全的教学校正式：4 byte 入口索引；每混合单元两次 double 操作；每混合条目两个 double 与一个 4 byte 索引。原书印刷式最后的条目项缺少 M_L 因子。

<a id="N042"></a>
### 复算 6.74 MB 和 0.87 ms

**讲解：** 取 M_f=0.04895、N_c=10^6、M_L=97970，得到 6.7426 MB；运算数 2M_L+M_fN_c=244890。带宽项约 0.504 ms，再加原书每混合单元 20 周期、2.7 GHz 的循环开销约 0.363 ms，总计约 0.867 ms。


<a id="4.3.2-material"></a>
## 4.3.2（续）以材料为中心的压缩表示
原书 p.114–115。

<a id="F014"></a>
### 图 4.19
**Source:** 原书 p.114 / PDF p.150 · C014
**Placed near:** 4.3.2（续）以材料为中心的压缩表示

![图 4.19](assets/fig4_19.png)

**Original caption:** The material-centric compressed sparse data layout is organized around materials. For each material, there is a variable-length array with a list of the cells that contain the material. The shading corresponds to the shading in figure 4.15. The illustration maps between the full mesh and subsets and the volume fraction and density variables for each subset.

**中文图注:** 以材料为中心的压缩布局，为每种材料保存包含它的单元列表及对应状态。图示给出全网格与各材料子集之间的映射，以及子集中的体积分数和密度，配色与图 4.15 对应。

**Reading note:** subset2mesh 将紧凑下标映射回全网格，mesh2subset 执行反向查询。被映射的索引不是物理坐标，也不是材料编号。

<a id="N043"></a>
### 子集循环怎样省工作

**讲解：** 对某种材料只遍历真正含有它的单元，跳过不存在的零条目。计算全单元平均值时，再通过子集到全网格的映射累加到各单元输出；这会引入索引读取和可能不连续的输出访问。

<a id="N044"></a>
### 原书的成本估计

**讲解：** 原书得到约 74 MB 数据操作量和 3.1 MFLOP；以 13375 MB/s 估计约 5.53 ms。相比材料中心完整矩阵的 122 ms，模型显著降低。但还应计入索引存储、分配与维护，不将非零状态数据的节省比例直接当作整个应用的内存节省比例。


<a id="4.3.2-results"></a>
## 4.3.2（续）表 4.1：模型与实测比较
原书 p.115–116。

<a id="F019"></a>
### 表 4.1
**Source:** 原书 p.115 / PDF p.151 · C019
**Placed near:** 4.3.2（续）表 4.1：模型与实测比较

![图 4.T1](assets/fig4_T1.png)

**Original caption:** The sparse data structures are faster and use less memory than the full 2D matrices.

**中文图注:** 该案例中，稀疏数据结构比完整二维矩阵更快，所需数据量也更少。

**Reading note:** 这是原书表 4.1，图像键 4.T1 仅用于网页定位。流量列为 MB；运算数按前文为百万 FLOP；估计与实测时间按前文语境为毫秒。它不是本机测量结果。

<a id="N045"></a>
### 先比较数量级与排序

**讲解：** 单元中心完整矩阵：估计 67.2 ms，实测 108 ms；材料中心完整矩阵：122 与 164 ms；单元中心压缩：0.87 与 1.4 ms；材料中心压缩：5.5 与 9.6 ms。此平均密度内核的最佳方案是单元中心压缩，但不能外推为所有内核的赢家。

<a id="N046"></a>
### 模型误差应明确分母

**讲解：** 按 |估计−实测|/实测 计算，四项误差约为 37.8%、25.6%、37.9%、42.7%。因此不能逐项宣称都在前文概括的 20–30% 以内。模型仍可有效筛选方案，但精确预测程度应如实表述。

<a id="N047"></a>
### 流量与容量仍要分开

**讲解：** 表头 Memory load 表示内核数据操作量，不等于进程峰值驻留内存。稀疏格式确实可能显著节约容量，但要比较容量，仍应计算所有状态、映射和预留空间的实际大小。


<a id="4.4"></a>
## 4.4 更精细的性能模型
原书 p.116–117。

<a id="S016"></a>
**Source:** 原书 p.116 / PDF p.152 · S016

**Original:** By now, you should realize that the unit of operation for computer hardware is not really bytes or words but cache lines, and we can improve the performance models by counting the cache lines that need to be loaded and stored.

**中文:** 到这里应该认识到，在缓存数据搬运模型中，重要的粒度是缓存行；统计需要加载和存储的缓存行，可以改进性能模型。

<a id="F015"></a>
### 图 4.21
**Source:** 原书 p.117 / PDF p.153 · C015
**Placed near:** 4.4 更精细的性能模型

![图 4.21](assets/fig4_21.png)

**Original caption:** The movement of data between cache levels is a series of discrete operations, more like a bucket brigade than a flow through a pipe. The details of the hardware and how many loads can be issued at each level and in each direction largely impact the efficiency of loading data through the cache hierarchy.

**中文图注:** 缓存层之间的数据移动是一系列离散操作，更像逐级传递水桶，而不是水在管道中平稳流动。各层硬件及双向传输能力会影响数据搬运效率。

**Reading note:** 这个类比帮助理解层间吞吐，但不表示所有传输都必须严格串行。是否重叠需要由具体微架构和模型假设决定。

<a id="N048"></a>
### ECM 想解释什么

**讲解：** Execution Cache Memory 模型按缓存行与周期分析核心执行、L1/L2/L3 和内存之间的代价。它能解释为何同样看似带宽受限的 Copy、Scale、Add、Triad，也会因指令和缓存路径不同而出现性能差异。


<a id="4.4-ecm"></a>
## 4.4（续）ECM 的重叠与非重叠时间
原书 p.117–119。

<a id="F016"></a>
### 图 4.22
**Source:** 原书 p.117 / PDF p.153 · C016
**Placed near:** 4.4（续）ECM 的重叠与非重叠时间

![图 4.22](assets/fig4_22.png)

**Original caption:** The Execution Cache Memory (ECM) model for the Haswell processor provides a detailed timing for the data transfer of the stream triad computation between cache levels. If the data is in main memory, the time it takes to get the data to the CPU is the sum of the transfer times between each cache level or 21.7 + 8 + 5 + 3 = 37.7 cycles. The floating-point operations only take 3 cycles, so the memory loads are the limiting aspect for the stream triad.

**中文图注:** 图中用 Haswell 的 ECM 示例分解 STREAM Triad 的层间传输时间。主存情形将 21.7、8、5 与 3 周期相加得到 37.7 周期，说明供数是主要限制。

**Reading note:** 图注最后把“浮点运算”说成 3 周期，而正文给 T_OL=1、T_nOL=3；3 周期是核心阶段的非重叠限制，不应简单称为纯算术时间。示例还把写分配与输出回写计入搬运。

<a id="E006"></a>
**Source:** 原书 p.118 / PDF p.154 · E006

$$
T_{ECM}=\max(T_{nOL}+T_{data},T_{OL})
$$

T_OL 是可与数据传输重叠的部分，T_nOL 是不可重叠的核心部分，T_data 是所需缓存层间传输。单位为周期，分析对象是指定工作粒度。

<a id="N049"></a>
### 原书记号逐项理解

**讲解：** {1 || 3 | 5 | 8 | 21.7} 中，双竖线分隔可重叠与不可重叠核心工作，后续各项为层间传输。按本例假设，可得到数据驻留 L1、L2、L3、主存时分别约 3、8、16、37.7 周期。不能把这一组数字套到所有处理器上。

<a id="N050"></a>
### 写分配不等于分配虚拟内存

**讲解：** 这里讨论的是写未命中时获取缓存行及相关一致性权限，不是每次数组赋值都调用虚拟内存分配器。缓存策略、非临时存储和写合并会改变流量；原书“streaming store 直接绕过全部缓存”的说法也应作为简化理解。

<a id="N051"></a>
### 向量化还可能改善数据移动

**讲解：** 向量加载/存储可以影响每周期搬运能力和地址生成压力，因此带宽受限内核也可能受益。Gather/scatter 允许访问不连续地址，但不意味着其吞吐与连续访问完全相同。复杂循环仍需要测量，而非只用一张简化传输表下结论。


<a id="4.5"></a>
## 4.5 网络消息：延迟加传输时间
原书 p.119–120。

<a id="S017"></a>
**Source:** 原书 p.119 / PDF p.155 · S017

**Original:** We can extend our data transfer models for use in analyzing the computer network.

**中文:** 可以把数据传输模型扩展到计算机网络的分析中。

<a id="E007"></a>
**Source:** 原书 p.119 / PDF p.155 · E007

$$
T=\alpha+\frac{n}{B}
$$

统一单位后的网络简化模型：α 为秒，n 为字节，B 为字节/秒。网页计算器用 μs、byte、GB/s 输入，并显式换算。该模型不包含争用、协议细节和复杂集体通信。

<a id="N052"></a>
### 先给出正确的数量级

**讲解：** 按原书设定 α=5 μs、B=1 GB/s（十进制），1 MB 的纯传输时间为 1 ms，总计 1.005 ms；1 kB 总计 6 μs；1 byte 的纯传输时间为 1 ns。原书把后者写成 1 μs，并把 1 MB 写成 1 s，差了 1000 倍。

<a id="F017"></a>
### 图 4.23
**Source:** 原书 p.120 / PDF p.156 · C017
**Placed near:** 4.5 网络消息：延迟加传输时间

![图 4.23](assets/fig4_23.png)

**Original caption:** Typical network transfer time as a function of the size of the message gives us a rule of thumb: 1 MB takes 1 s (second), 1 KB takes 1 ms (millisecond), or 1 byte takes 1 microsec.

**中文图注:** 原图注称：典型网络传输时间随消息大小变化，1 MB 用时 1 s、1 KB 用时 1 ms、1 byte 用时 1 μs。

**Reading note:** 注意：上面忠实保留了原图注的错误结论。按图内标注 1 GB/s，传输部分应分别为 1 ms、1 μs、1 ns，再加固定 5 μs 延迟。原图纵轴时间量级不应作为正确算例使用。

### 网络传输时间计算器

教学模型；默认 5 μs 延迟、1 GB/s 带宽、8000 byte 消息。GB/s 是十进制，和 Gbit/s 不同。

交互版本见网页小节 4.5。总时间为固定延迟加传输时间，单位显式换算。

<a id="N053"></a>
### 什么时候合并消息有帮助

**讲解：** 很多小消息会重复支付启动延迟；合并消息可能减少这部分成本。大消息则更受带宽限制。但合并可能增加等待、额外复制或缓冲，是否值得仍要看应用数据依赖和实测。


<a id="4.5-ghost"></a>
## 4.5（续）幽灵单元交换与归约
原书 p.120–122。

<a id="F018"></a>
### 图 4.A
**Source:** 原书 p.121 / PDF p.157 · C018
**Placed near:** 4.5（续）幽灵单元交换与归约

![图 4.A](assets/fig4_A.png)

**Original caption:** Outer cell data is exchanged with adjacent processors so that the stencil calculation is operating on current values. The dashed cells are called ghost cells because these hold duplicated data from another processor. The arrows only show the data exchange for every other cell for clarity.

**中文图注:** 外层单元数据与相邻进程交换，使模板计算使用当前值。虚线单元称为幽灵单元，因为它们保存其他进程数据的副本；为清晰起见，箭头只画出隔一个单元的数据交换。

**Reading note:** 4.A 是讲义为 p.121 未编号原图增加的定位标签。幽灵单元的数量由模板范围、空间维度、边界条件和划分方式共同决定。

<a id="N054"></a>
### 重算一条边的交换

**讲解：** 1000 个 double 共 8000 byte。按 1 GB/s，传输部分为 8 μs；加 5 μs 延迟后为 13 μs。原书的“5 μs + 8 ms”把传输项放大了 1000 倍。这里仅计算一条边的一次消息，不是四条边、双向或多变量交换的完整耗时。

<a id="N055"></a>
### 重算两个 4 字节消息

**讲解：** 每条 4 byte 消息的传输部分为 0.004 μs；两次通信共 2×(5+0.004)=10.008 μs。原书给出的 18 μs 来自相同单位错误。这个例子也表明极小消息中延迟占主导。

<a id="N056"></a>
### 树形归约与同步语义

**讲解：** 配对树的通信层数可随进程数按 log₂N 增长，但实际 MPI 实现可能采用其他算法。归约要求参与进程按规则调用，可能产生等待，却不应把每次归约直接等同于 MPI_Barrier；标准不保证所有集体操作都有完整屏障语义。[R15]


<a id="4.6"></a>
## 4.6 进一步探索与本章小结
原书 p.122–123。

<a id="S018"></a>
**Source:** 原书 p.123 / PDF p.159 · S018

**Original:** Data structures are at the foundation of application design and often dictate performance and the resulting implementation of parallel code.

**中文:** 数据结构是应用设计的基础，常常决定性能表现以及并行代码的实现方式。

<a id="N057"></a>
### 本章的设计顺序

**讲解：** 确定代表性内核，画出字段的访问模式，选择连续维度和对象分组，计算容量与流量，再估算分支、缓存和通信代价。用小型实验验证候选方案，而不是等全程序写完再发现布局难以改变。

<a id="N058"></a>
### 把模型用于选择，而非制造精确幻觉

**讲解：** 简单模型帮助找数量级、瓶颈与方案排序；精细模型帮助解释特定硬件细节。二者都需要明确假设、统一单位并与测量相对照。内存占用、逻辑引用字节、实际 DRAM 流量和网络字节不能混为一谈。


<a id="4.6.1"></a>
## 4.6.1 延伸阅读
原书 p.122–123。

<a id="N059"></a>
### 保留原书文献线索

**讲解：** Noel Llopis 的 Data-oriented design（2009）；Mike Acton 在 CppCon 2014 的 Data-oriented design and C++；Shane Fogerty、Matt Martineau 等的多材料数据结构比较研究（2019）；Holger Stengel、Jan Treibig 等的 ECM 模板性能论文（2015）。它们分别对应面向数据设计、稀疏案例与精细性能模型。

<a id="N060"></a>
### 本讲义核对依据

**讲解：** Fortran 连续性参照 Intel 的 CONTIGUOUS 文档，C++ 数组语义参照工作草案 [dcl.array]，集体通信完成语义参照 MPI 4.1 第 7.1 节。相关链接列在资料来源中。原书图像保留，不通过重新绘图掩盖其单位或标注差异。


<a id="4.6.2"></a>
## 4.6.2 练习与参考思路
原书 p.123。

<a id="N061"></a>
### 练习 1｜下三角矩阵连续存储

**讲解：** 按行保存下三角（包含对角线），第 i 行有 i+1 项，总元素数为 n(n+1)/2；第 i 行的起点为 i(i+1)/2。分配前检查乘法和字节数是否溢出，规定不属于三角区的访问是报错、返回零还是不允许。

<a id="E008"></a>
**Source:** 原书 p.123 / PDF p.159 · E008

$$
k=\frac{i(i+1)}{2}+j,\quad 0\leq j\leq i<n
$$

教学补充：0 起点、按行紧凑保存的下三角下标映射。它只定义有效三角区域，不是普通矩形二维数组的地址公式。

<a id="N062"></a>
### 练习 2｜C 中采用 Fortran 顺序

**讲解：** 对 nrow×ncol 数组，列优先线性偏移为 row+nrow*col。可直接使用一块 double 数据和显式下标函数；若仍要保留指针视图，应明确索引顺序，不能把 double** 强转后当成任意 Fortran 数组接口。

<a id="N063"></a>
### 练习 3｜AoSoA 宏

**讲解：** 使用块号 k/V 和块内号 k%V，把三个颜色分开成块内数组。宏可能重复求值参数；避免传入 k++ 等带副作用的表达式。能使用内联函数或明确的局部变量时，通常更容易检查类型和边界。

<a id="N064"></a>
### 练习 4｜去掉零体积分数条件

**讲解：** 先假设所有槽位的密度、权重都已初始化且乘零有明确语义，再比较无分支版本的读写量和分支节省。不能读取未初始化值后指望乘零“自动修复”；NaN×0 也不一定得到零。性能取决于稀疏程度、分支可预测性和数据流量。

<a id="N065"></a>
### 练习 5｜AVX-512 怎样改变 ECM

**讲解：** 更宽向量可能减少某段工作的指令数，但还要重算执行吞吐、地址生成、加载/存储能力和工作频率；缓存行大小也不因为向量宽度翻倍就自动翻倍。不能简单把 37.7 周期除以 2。

<a id="K015"></a>
**代码出处：** Python · 教学补充 layout_examples.py，用于核对索引与单位算式

```text
def row_major(row, col, ncols):
    return row * ncols + col

def column_major(row, col, nrows):
    return row + nrows * col

def lower_triangle(row, col):
    if not (0 <= col <= row):
        raise ValueError("outside lower triangle")
    return row * (row + 1) // 2 + col

def network_us(size_bytes, bandwidth_gbs, latency_us):
    if size_bytes < 0 or bandwidth_gbs <= 0 or latency_us < 0:
        raise ValueError("invalid model input")
    return latency_us + size_bytes / (bandwidth_gbs * 1000.0)

assert row_major(2, 3, 5) == 13
assert column_major(2, 3, 4) == 14
assert lower_triangle(3, 2) == 8
assert network_us(8000, 1, 5) == 13
print("index and network examples passed")
```

<a id="N066"></a>
### 补充 Python 语法

**讲解：** def 定义函数；return 返回值；// 是整数向下取整除法；raise 报告无效输入；assert 检查预期结果。以上只核对下标和简化通信模型，不是 C/C++ 编译结果或真实硬件基准。


## 技术核对来源

- [R13 · Intel Fortran：CONTIGUOUS 与连续性](https://www.intel.com/content/www/us/en/docs/fortran-compiler/developer-guide-reference/2023-1/contiguous.html)
- [R14 · C++ 工作草案：数组声明与连续布局](https://eel.is/c++draft/dcl.array)
- [R15 · MPI 4.1：集体通信的完成语义](https://www.mpi-forum.org/docs/mpi-4.1/mpi41-report/node114.htm)