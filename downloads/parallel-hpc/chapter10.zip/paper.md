# 第 10 章｜GPU 编程模型

原著：Robert Robey、Yuliana Zamora，Manning，2021。原书 p.346–370 / PDF p.382–406。

核心段落对照、全部编号小节解释、关键原图和代码语法。不是逐段全文译本。

## 小节索引

- [第 10 章导读｜GPU 编程模型](#10-intro)
- [10.1 GPU 并行抽象的共同结构](#10.1)
- [10.1.1 暴露足够的并行工作](#10.1.1)
- [10.1.2 工作组之间的协调限制](#10.1.2)
- [10.1.3 OpenCL 与 CUDA 术语对照](#10.1.3)
- [10.1.4 把计算域分成 grid 或 NDRange](#10.1.4)
- [10.1.5 工作组的大小与共享资源](#10.1.5)
- [10.1.6 子组执行与分支分歧](#10.1.6)
- [10.1.7 工作项：一个局部任务](#10.1.7)
- [10.1.8 每个工作项中的向量操作](#10.1.8)
- [10.2 将循环拆为 kernel 与索引集](#10.2)
- [10.2.1 “以我为中心”的 kernel 与 lambda](#10.2.1)
- [10.2.2 局部与全局索引映射](#10.2.2)
- [10.2.3 向上取整与边缘线程](#10.2.3)
- [10.2.4 数据驻留与协作加载](#10.2.4)
- [10.3 管理 kernel 的有限资源](#10.3)
- [10.3.1 查看寄存器使用与溢出](#10.3.1)
- [10.3.2 Occupancy：驻留占用率](#10.3.2)
- [10.4 跨工作组归约](#10.4)
- [10.5 queues 与 streams：组织异步工作](#10.5)
- [10.6 为应用设计 GPU 并行方案](#10.6)
- [10.6.1 三维大气模拟的分块](#10.6.1)
- [10.6.2 非结构网格的工作与邻居](#10.6.2)
- [10.7 延伸探索与本章小结](#10.7)
- [10.7.1 延伸阅读](#10.7.1)
- [10.7.2 练习：图像流水线与显存容量](#10.7.2)

## 公式索引

- [E001](#E001)
- [E002](#E002)
- [E003](#E003)
- [E004](#E004)
- [E005](#E005)
- [E006](#E006)
- [E007](#E007)

## 术语约定

|原文|译法|说明|
|---|---|---|
|work group|工作组|块内协作和资源共享单位|
|work item|工作项|一个逻辑工作单位|
|subgroup|子组|执行分组|
|kernel|设备核函数|按索引集执行的计算体|
|occupancy|驻留占用率|驻留 warp 数相对上限|
|stream|流|组织操作与依赖的队列|
|lambda|lambda 表达式|形成闭包对象的匿名函数表达式|

<a id="10-intro"></a>
## 第 10 章导读｜GPU 编程模型
原书 p.346–347。

<a id="S001"></a>
**Source:** 原书 p.346 / PDF p.382 · S001

**Original:** The choice of data structures and algorithms has a long-range impact on the performance and ease of programming for the GPU.

**中文:** 数据结构与算法的选择，会长期影响 GPU 程序的性能和编写难度。

<a id="N001"></a>
### 从硬件模型走向代码

**讲解：** 第 9 章回答资源和带宽在哪里；本章回答如何把计算拆给这些资源。核心是工作分解、数据移动和同步，而不是先背下一种 GPU 语言的全部接口。

<a id="N002"></a>
### 本章的交付范围

**讲解：** 保留所有编号小节，用核心段落对照、关键原图与代码语法讲解连接概念。原书硬件限制表属于历史示例；解释中区分通用模型、特定实现与教学假设。


<a id="10.1"></a>
## 10.1 GPU 并行抽象的共同结构
原书 p.348。

<a id="F001"></a>
### 图 10.1
**Source:** 原书 p.348 / PDF p.384 · C001
**Placed near:** 10.1 GPU 并行抽象的共同结构

![图 10.1](assets/fig10_1.png)

**Original caption:** Our mental model for GPU parallelization contains the common programming abstractions across most GPU hardware.

**中文图注:** 从全局计算域分解为工作组，再到子组与工作项；部分实现还提供向量操作。

**Reading note:** 这些是编程抽象，不是固定数量的物理处理器。逻辑上创建许多工作项，不表示它们同时全部驻留或每个占用独立核心。

<a id="N003"></a>
### 四个问题

**讲解：** 全局数据有多大？怎样分成独立的块？块内哪些线程共享数据？最终如何合并或同步？CUDA、OpenCL 和高层框架名称不同，但都需要回答这些问题。


<a id="10.1.1"></a>
## 10.1.1 暴露足够的并行工作
原书 p.348。

<a id="S002"></a>
**Source:** 原书 p.348 / PDF p.384 · S002

**Original:** Because of the large amounts of data, GPUs have massive parallelism.

**中文:** 因为需要处理大量数据，GPU 具备大规模并行能力。

<a id="N004"></a>
### 工作数量与粒度

**讲解：** 大量小任务可供调度器选择，但任务太碎又可能让启动和管理成本占主导。把相同操作作用于许多元素，是最容易理解的起点；复杂控制流仍需分析可并行部分。

<a id="N005"></a>
### 维度并不限制数学问题

**讲解：** 常见 GPU 启动接口提供一到三维索引，但高维问题可以展平或合并循环。选择映射时优先考虑连续存储、独立性和局部复用，不能机械地让每个数学维度对应一个硬件层级。


<a id="10.1.2"></a>
## 10.1.2 工作组之间的协调限制
原书 p.349。

<a id="N006"></a>
### 默认不能假定全网格同时运行

**讲解：** 普通 kernel 中，不同工作组可能以任意顺序分批执行。若已驻留的组忙等尚未调度的组，可能卡住整个执行。不要把 CPU 线程屏障原样搬进 GPU 全局自旋循环。

<a id="N007"></a>
### 限制不等于完全不能通信

**讲解：** 全局内存、原子操作以及受条件限制的协作启动机制可以实现某些跨组协作。本章采用更易理解的方案：完成一个 kernel 后，再用有明确执行依赖的下一 kernel 处理跨组结果。


<a id="10.1.3"></a>
## 10.1.3 OpenCL 与 CUDA 术语对照
原书 p.349。

<a id="F008"></a>
### 表 10.1
**Source:** 原书 p.349 / PDF p.385 · C008
**Placed near:** 10.1.3 OpenCL 与 CUDA 术语对照

![图 10.T1](assets/fig10_T1.png)

**Original caption:** Programming abstractions and associated terminology for GPUs

**中文图注:** NDRange 对应全局索引范围，work group 对应 block，work item 对应 thread。

**Reading note:** 保留原书表格；不同厂商的 subgroup/warp/wavefront 组织并非完全等价。HC 和 C++ AMP 等历史列用于读原书，不作为当前工具链推荐。

<a id="N008"></a>
### 对象与硬件分开记

**讲解：** grid/NDRange 表达本次启动的全局工作；block/work group 是协作与资源共享单位；warp/subgroup 是执行分组；thread/work item 表达一个逻辑工作项。设备是否支持某 API 仍需查询运行环境。


<a id="10.1.4"></a>
## 10.1.4 把计算域分成 grid 或 NDRange
原书 p.350–352。

<a id="S003"></a>
**Source:** 原书 p.350 / PDF p.386 · S003

**Original:** The technique of data decomposition is at the heart of how GPUs obtain performance.

**中文:** 数据分解是 GPU 获得性能的核心方法。

<a id="F002"></a>
### 图 10.2
**Source:** 原书 p.350 / PDF p.386 · C002
**Placed near:** 10.1.4 把计算域分成 grid 或 NDRange

![图 10.2](assets/fig10_2.png)

**Original caption:** The GPU subgroup (warp) scheduler switches to other subgroups to cover memory reads and instruction stalls. Multiple work groups allow work to be done even when a work group is being synchronized.

**中文图注:** 调度就绪子组，让其他线程等待访存或同步时，执行资源仍有工作可做。

**Reading note:** 这是延迟隐藏示意，不是每个周期必然按照图中的顺序轮换。驻留组数受寄存器、共享存储及硬件限制；增加工作数量不保证线性提速。

<a id="E001"></a>
**Source:** 原书 p.351 / PDF p.387 · E001

$$
N_x=\lceil G_x/T_x\rceil,\quad N_y=\lceil G_y/T_y\rceil,\quad N=N_xN_y
$$

对非负全局长度、正块尺寸向上取整。原书 1024×1024 配 16×8 块，得到 64×128=8192 个工作组。不能整除时需要处理边缘工作项。

<a id="N009"></a>
### 形状与 halo

**讲解：** 相同线程数可以排成不同形状。x 方向连续访问有利于内存合并；更接近方形的 tile 又可能减少二维 stencil 的重复边界加载。最佳形状取决于布局、halo、共享存储和寄存器，不由单一规则决定。


<a id="10.1.5"></a>
## 10.1.5 工作组的大小与共享资源
原书 p.353。

<a id="S004"></a>
**Source:** 原书 p.353 / PDF p.389 · S004

**Original:** The work group spreads out the work across the threads on a compute unit.

**中文:** 工作组把工作分配给计算单元上的线程。

<a id="N010"></a>
### 最大值不是推荐值

**讲解：** 设备和 kernel 都可能限制最大组大小。使用最大块可能让每个块占用太多资源，减少同时驻留的块；较小块也可能降低资源利用或增加管理成本，应测代表性输入。

<a id="N011"></a>
### 子组倍数是常用调优选择

**讲解：** 原书说工作组“必须”是子组大小的倍数，表述过强。CUDA 允许不足整 warp 的合法块，尾 warp 的部分通道不活跃；选择倍数通常是效率建议，具体合法性仍取决于 API 与设备。


<a id="10.1.6"></a>
## 10.1.6 子组执行与分支分歧
原书 p.353–354。

<a id="N012"></a>
### 共享指令流，不共享所有状态

**讲解：** 同一执行组的线程仍有各自索引、寄存器状态和条件结果。走不同分支时可能需要分阶段执行并屏蔽部分通道，降低有效吞吐；不表示所有线程都执行每条分支的可见写操作。

<a id="N013"></a>
### 不要依赖隐式同步

**讲解：** 原书以锁步解释 SIMT，适合入门但不能据此省略必要同步。具有独立线程调度的架构可能使旧的 warp 同步假设失效；共享数据的生产与消费应使用适当屏障或同步原语。[R48]


<a id="10.1.7"></a>
## 10.1.7 工作项：一个局部任务
原书 p.354。

<a id="S005"></a>
**Source:** 原书 p.354 / PDF p.390 · S005

**Original:** The basic unit of operation is called a work item in OpenCL.

**中文:** OpenCL 把基本操作单位称为工作项。

<a id="N014"></a>
### 不是一个永久专属核心

**讲解：** 一个工作项通常根据自己的索引计算输出。硬件执行资源可分时处理许多工作项；线程数、驻留数、发射数与物理运算单元数不能混为一谈。


<a id="10.1.8"></a>
## 10.1.8 每个工作项中的向量操作
原书 p.354–355。

<a id="N015"></a>
### 向量类型与物理实现

**讲解：** OpenCL 的向量类型可以表达多个元素，实际映射到向量指令、多个标量操作或其他执行方式由编译器和硬件决定。CUDA 的 float4 等类型也不能仅凭类型名就当作四倍算术吞吐。

<a id="N016"></a>
### 可移植性与资源压力

**讲解：** 每个工作项处理更多元素可能增加复用，也可能增加寄存器和指令需求。应区分数据打包、内存加载宽度与真正的计算向量化，不对不同厂商直接套用同一倍率。


<a id="10.2"></a>
## 10.2 将循环拆为 kernel 与索引集
原书 p.355–356。

<a id="F003"></a>
### 图 10.8
**Source:** 原书 p.355 / PDF p.391 · C003
**Placed near:** 10.2 将循环拆为 kernel 与索引集

![图 10.8](assets/fig10_8.png)

**Original caption:** Correspondence between standard loop and the GPU kernel code structure

**中文图注:** CPU 循环的循环体变成 kernel 的工作；迭代范围由主机启动配置与索引计算表达。

**Reading note:** 复制循环体前应先确认迭代独立。边界检查必须覆盖填充线程；后续若引入块内屏障，还需重新设计边缘线程的参与方式。

<a id="K001"></a>
**代码出处：** CUDA C++ · 原书图 10.8 的教学展开；设备指针有效且输出不产生跨迭代冲突

```text
__global__ void triad(const double *a, const double *b,
                      double *c, double scalar, size_t n) {
    size_t i = (size_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    c[i] = a[i] + scalar * b[i];
}
```

<a id="N017"></a>
### 语法对应

**讲解：** __global__ 标识可由主机启动的设备 kernel；blockIdx 是块编号，blockDim 是每块线程尺寸，threadIdx 是块内编号。const 限制通过该指针修改输入，不自动证明数组之间不存在别名。


<a id="10.2.1"></a>
## 10.2.1 “以我为中心”的 kernel 与 lambda
原书 p.356–357。

<a id="S006"></a>
**Source:** 原书 p.356 / PDF p.392 · S006

**Original:** The separation of the loop body and the index set can be done in C++ with either functors or lambda expressions.

**中文:** 在 C++ 中，可以通过函数对象或 lambda 表达式分离循环体与索引集。

<a id="K002"></a>
**代码出处：** C++11 · 清单 10.1 的完整 CPU 教学修正版；不是 GPU 程序

```text
#include <array>
#include <cassert>
int main() {
    constexpr int n = 100;
    std::array<double,n> a{}, b{}, c{};
    a.fill(1.0); b.fill(2.0);
    double scalar = 0.5;
    auto body = [&](int i) { c[i] = a[i] + scalar * b[i]; };
    for (int i = 0; i < n; ++i) body(i);
    for (double value : c) assert(value == 2.0);
}
```

<a id="N018"></a>
### 四部分语法

**讲解：** [&] 表示按引用捕获被使用的外部局部变量；(int i) 是参数；花括号内是函数体；body(i) 调用闭包对象。auto 让编译器推导闭包类型，结尾分号结束变量定义。原书数组未初始化，本例补上初值与结果检查。

<a id="N019"></a>
### 捕获不会自动搬数据

**讲解：** [=] 复制被捕获对象或指针值，不等于深拷贝指针所指数组到显存。[&] 也不保证主机地址在设备可用。实际 GPU lambda 需要框架或编译器的设备支持及有效数据生命周期。


<a id="10.2.2"></a>
## 10.2.2 局部与全局索引映射
原书 p.357–358。

<a id="F004"></a>
### 图 10.9
**Source:** 原书 p.358 / PDF p.394 · C004
**Placed near:** 10.2.2 局部与全局索引映射

![图 10.9](assets/fig10_9.png)

**Original caption:** Mapping of the index of individual work item to global index space. The OpenCL call is given first, followed by the variable defined in CUDA.

**中文图注:** 用组编号、局部尺寸与局部编号定位全局元素。

**Reading note:** 图按零全局偏移、规则块尺寸展示。OpenCL 若使用非零 global offset，应按相应 API 语义处理；CUDA 的 gridDim 是块数，不是全局元素总数。

<a id="E002"></a>
**Source:** 原书 p.357 / PDF p.393 · E002

$$
g_x=b_xT_x+t_x,\qquad k=g_yN_x+g_x
$$

第一式映射一维线程；第二式将二维行主序坐标展平。Nₓ 为数组实际行跨度对应的元素数，存在 pitch 或 halo 时不能盲用内部网格宽度。

<a id="K003"></a>
**代码出处：** CUDA C++ · 二维连续行主序数组索引片段；乘积需在 size_t 范围内

```text
size_t x = (size_t)blockIdx.x * blockDim.x + threadIdx.x;
size_t y = (size_t)blockIdx.y * blockDim.y + threadIdx.y;
if (x >= nx || y >= ny) return;
size_t k = y * nx + x;
```

<a id="N020"></a>
### 区分两种展平

**讲解：** 把线程块内坐标展平用于判断 warp 分组，通常 x 变化最快；把全局坐标展平则用于访问数据数组。两者使用的行宽不同，不能用 blockDim.x 替代数组全局行跨度。


<a id="10.2.3"></a>
## 10.2.3 向上取整与边缘线程
原书 p.358–359。

<a id="E003"></a>
**Source:** 原书 p.358 / PDF p.394 · E003

$$
B=\lfloor N/T\rfloor+[N\bmod T\ne0],\qquad G=BT
$$

要求 N≥0、T>0。避免 (N+T−1) 在极大整数下的加法溢出；最终 B×T 和启动维度仍需范围检查。

<a id="K004"></a>
**代码出处：** CUDA C++ · 教学启动片段；threads 合法且数组已准备在设备上

```text
size_t blocks = n / threads + (n % threads != 0);
if (n != 0) {
    triad<<<blocks, threads>>>(a, b, c, scalar, n);
    /* 检查启动错误，并在需要结果前确认完成 */
}
```

<a id="N021"></a>
### 原书示例的两处修正

**讲解：** 1000 个元素、每组 128 个，需要 8 组、1024 个逻辑线程。有效索引是 0–999，因此 gidx>=1000 必须排除；原书写 > 会让索引 1000 越界。ceil(1000/128) 若先执行整数除法，只得到 ceil(7)=7。

<a id="N022"></a>
### 零规模与同步例外

**讲解：** N=0 时可直接跳过启动。简单无屏障逐元素 kernel 可让多余线程返回；存在块内集体同步时，不能沿用这段提前返回模板而不检查参与规则。更通用的教学方式是让无效线程加载中性值、参加同步，仅屏蔽最终写入。


<a id="10.2.4"></a>
## 10.2.4 数据驻留与协作加载
原书 p.359–360。

<a id="F005"></a>
### 图 10.10
**Source:** 原书 p.360 / PDF p.396 · C005
**Placed near:** 10.2.4 数据驻留与协作加载

![图 10.10](assets/fig10_10.png)

**Original caption:** For stencils on regular grids, load all the data into local memory and then use local memory for the computation. The inner solid rectangle is the computational tile. The outer dashed rectangle encloses the neighboring data needed for the calculation. You can use cooperative loads to load the data in the outer rectangle into the local memory for each work group. Because irregular grids have an unpredictable size, load only the computed region into local memory and use registers for each thread for the rest.

**中文图注:** 规则网格可协作加载含 halo 的 tile；不规则网格需按邻接关系规划共享与私有数据。

**Reading note:** 共享内存只是可选优化。额外加载、屏障、bank conflict 和资源占用可能抵消收益；应与直接访问全局内存的正确基线比较。

<a id="K005"></a>
**代码出处：** CUDA C++ · 共享存储与屏障教学片段；i 已计算，启动时分配足够动态共享内存

```text
extern __shared__ double tile[];
unsigned int t = threadIdx.x;
/* 示意：每个线程负责一个槽位，无效输入使用中性值 */
tile[t] = (i < n) ? input[i] : 0.0;
__syncthreads();
/* 现在可以消费本块所有线程已写好的 tile */
if (i < n) output[i] = tile[t];
```

<a id="N023"></a>
### 同步范围与边界

**讲解：** __syncthreads() 协调当前线程块，不同步整个 grid。把它放进条件分支时必须满足块内一致参与等规则。示例用中性值保证边缘工作项仍参与；真正 stencil 还需指定 halo 加载与物理边界。[R48]

<a id="N024"></a>
### 容量不是简单相加

**讲解：** 多个 GPU 的显存总和不自动成为一个设备可直接使用的大数组；需要分区和通信。设备端动态分配并非一概禁止，但开销、容量和可移植性要考虑；原书“只能在 CPU 分配”属于过度简化。

<a id="N025"></a>
### 合并访问依赖实际地址

**讲解：** 相邻线程访问接近且对齐的地址，通常可减少内存事务。硬件能合并部分访问不代表任意随机访问都变便宜；要看每个执行组的地址分布及有效字节占比。


<a id="10.3"></a>
## 10.3 管理 kernel 的有限资源
原书 p.361。

<a id="F009"></a>
### 表 10.4
**Source:** 原书 p.361 / PDF p.397 · C009
**Placed near:** 10.3 管理 kernel 的有限资源

![图 10.T4](assets/fig10_T4.png)

**Original caption:** Some resource limitations on current GPUs

**中文图注:** 原书列出的 V100 与 MI50 资源限制示例。

**Reading note:** 这是出版时的特定架构表，不能当作所有 GPU 的上限。寄存器“64K”与字节数不是同一单位；块上限、线程上限与共享内存配置都需核对实际设备。

<a id="S007"></a>
**Source:** 原书 p.361 / PDF p.397 · S007

**Original:** The key to good GPU programming is to manage the limited resources available for executing kernels.

**中文:** 写好 GPU 程序的关键，是管理执行 kernel 时可用的有限资源。

<a id="N026"></a>
### 最先耗尽的资源形成约束

**讲解：** 块线程数、寄存器、共享内存和块数上限共同限制驻留。增大 tile 虽减少 halo 比例，却可能使一个 SM 只能容纳更少的块；优化需在复用与并发之间取舍。


<a id="10.3.1"></a>
## 10.3.1 查看寄存器使用与溢出
原书 p.361–362。

<a id="K006"></a>
**代码出处：** Shell · 原书寄存器报告方法；需要实际 CUDA 编译器与源文件

```text
nvcc -Xptxas=-v -c triad.cu -o triad.o
```

<a id="N027"></a>
### 报告中的字段

**讲解：** Used registers 反映编译器分配的每线程寄存器数量；smem 是共享内存，spill loads/stores 表示寄存器压力可能引起的溢出访问。关注报告对应的具体 kernel 和目标架构。

<a id="N028"></a>
### 每线程上限不是独占预算

**讲解：** 原书例子使用 14 个寄存器，不代表每个线程还可无代价增加到 255。所有驻留线程共同消耗 SM 的寄存器文件，还存在分配粒度与每块限制。强行限制寄存器数可能增加 spill 并变慢。


<a id="10.3.2"></a>
## 10.3.2 Occupancy：驻留占用率
原书 p.362–363。

<a id="E004"></a>
**Source:** 原书 p.362 / PDF p.398 · E004

$$
O=W_{\mathrm{resident}}/W_{\max}
$$

是资源与驻留程度指标，不是“算术单元每周期都忙”的直接度量。理论占用率与实际执行期间测得的占用率也应区分。

<a id="N029"></a>
### 不是越高越快

**讲解：** 足够的就绪工作有助隐藏延迟，但受带宽、计算吞吐或依赖限制时，更高 occupancy 未必更快。牺牲复用或增加溢出换来更高百分比，可能反而降低性能。[R49]

<a id="N030"></a>
### 模型的用途与边界

**讲解：** 可先按线程、块数、寄存器、共享内存四类上限取最小可驻留块数，理解瓶颈。实际架构有分配粒度和其他规则，精确值应使用对应工具链工具，不能用教学除法代替硬件 occupancy 计算器。


<a id="10.4"></a>
## 10.4 跨工作组归约
原书 p.364–365。

<a id="F006"></a>
### 图 10.11
**Source:** 原书 p.364 / PDF p.400 · C006
**Placed near:** 10.4 跨工作组归约

![图 10.11](assets/fig10_11.png)

**Original caption:** The reduction pattern on the GPU requires two kernels to synchronize multiple work groups. We exit the first kernel, represented by the rectangle, and then start another one the size of a single work group to allow thread cooperation for the final pass.

**中文图注:** 第一阶段各块生成局部结果，第二阶段在有明确依赖的新 kernel 中合并。

**Reading note:** 这是通用易理解的两阶段方案，不是所有归约必须恰好两个 kernel。更大问题可递归多阶段，也可采用适用的库或其他算法；原书“唯一办法”表述不宜绝对化。

<a id="K007"></a>
**代码出处：** Python · 原书图 10.11 的分层归约教学模型；block>0

```text
# Python 串行模型：表示阶段边界，不是 GPU 实现
partials = [sum(data[i:i+block])
            for i in range(0, len(data), block)]
result = sum(partials)
```

<a id="N031"></a>
### 同步必须落实到执行依赖

**讲解：** 同一有序 stream 内先启动阶段一再启动阶段二，可建立所需顺序；跨 stream 则需显式事件等依赖。阶段一的临时数组不能在阶段二结束前释放，且每个局部和必须有唯一写入者。

<a id="N032"></a>
### 算术与边界

**讲解：** 尾块要只读有效元素并对其他槽填归约单位元。浮点求和改变分组后可能改变末位；不能把它误判成竞争，也不能忽略数值要求。原书 xmax=sum(x(:)) 实际是求和，不是求最大值。


<a id="10.5"></a>
## 10.5 queues 与 streams：组织异步工作
原书 p.365–366。

<a id="F007"></a>
### 图 10.14
**Source:** 原书 p.366 / PDF p.402 · C007
**Placed near:** 10.5 queues 与 streams：组织异步工作

![图 10.14](assets/fig10_14.png)

**Original caption:** Overlapping computation and data transfers reduce the time for three images from 75 ms to 45 ms. This is possible because the GPU can do a computation, a data transfer from the host to the device, and another one from the device to the host simultaneously.

**中文图注:** 在原图的三阶段并行资源假设下，三张图像可由串行 75 ms 缩短到 45 ms。

**Reading note:** 假设 H2D 与 D2H 可同时进行、计算可与传输重叠，且各图片无依赖、缓冲区独立。实际并发还受复制引擎、页锁定内存、stream 语义与资源竞争限制。

<a id="K008"></a>
**代码出处：** CUDA C++ · 独立图像处理的教学流程，transform 为示意 kernel；省略创建/分配和错误检查

```text
cudaMemcpyAsync(d_in, h_in, bytes, cudaMemcpyHostToDevice, stream);
transform<<<blocks, threads, 0, stream>>>(d_in, d_out, n);
cudaMemcpyAsync(h_out, d_out, bytes, cudaMemcpyDeviceToHost, stream);
cudaStreamSynchronize(stream);
/* 同步成功后主机才能消费 h_out 或复用相关缓冲 */
```

<a id="N033"></a>
### 异步不是直到 wait 才启动

**讲解：** 异步表示主机提交与设备完成不必同时发生，设备可以在主机调用等待之前运行。原书关于“通常请求结果才执行”的说法不应推广为调度规则。OpenCL 的提交、flush 与完成查询也有各自语义。

<a id="E005"></a>
**Source:** 原书 p.366 / PDF p.402 · E005

$$
T_n\approx H+K+D+(n-1)\max(H,K,D)
$$

教学理想流水线：每阶段各有独立资源且任务相同，无额外开销。H=10、K=5、D=10 ms、n=3 得 45 ms；串行是 n(H+K+D)=75 ms。

<a id="N034"></a>
### 一个 stream 不等于一套硬件

**讲解：** 多个 stream 暴露并发机会，不保证同时运行。默认 stream 行为随设置变化；使用事件表达跨流依赖，避免在每个操作后全设备同步把流水线重新串行化。[R49]


<a id="10.6"></a>
## 10.6 为应用设计 GPU 并行方案
原书 p.366–368。

<a id="N035"></a>
### 从数据和依赖出发

**讲解：** 列出每阶段读写的数据、总容量、复用机会及同步需求，再选择工作组尺寸。先构建可验证的直接实现，再依据剖析决定共享存储、分块与异步流水线。

<a id="N036"></a>
### CPU 与 GPU 的约束不同

**讲解：** CPU 可用较少的大任务，GPU 通常需要更多可调度工作和较小的协作块。但“需要几万个组”不是所有硬件与算法统一的下限，应结合资源驻留和实际工作量判断。


<a id="10.6.1"></a>
## 10.6.1 三维大气模拟的分块
原书 p.367。

<a id="N037"></a>
### 原书三种候选

**讲解：** 按整平面分块：共享存储需求可过大；按长列分块：组数增加但每组邻域仍可能很大；按小立方块分块：更容易控制共享工作集，并得到大量独立块。

<a id="E006"></a>
**Source:** 原书 p.367 / PDF p.403 · E006

$$
M=(T_x+2h)(T_y+2h)(T_z+2h)vs
$$

完整 halo 包围盒模型；v 是同时缓存的变量数，s 是每变量字节数。4×4×8 的 tile、h=1、v=1、s=8，得到 2880 B=2.8125 KiB，不是整个应用内存。

<a id="N038"></a>
### 全局容量重算

**讲解：** 1024³ 个单元、一个 double 字段为 8 GiB；8192³ 个单元则为 4 TiB。按每卡 32 GiB、只存一个字段的极简容量下限是 128 卡，不能直接套用原书“最多 512 GPU”。多变量、双缓冲、halo 和临时数组会继续提高需求。


<a id="10.6.2"></a>
## 10.6.2 非结构网格的工作与邻居
原书 p.368。

<a id="S008"></a>
**Source:** 原书 p.368 / PDF p.404 · S008

**Original:** We will also need space for some integer mapping and neighbor arrays to provide the connectivity between the cells.

**中文:** 还需要为整数映射和邻居数组留出空间，用来描述单元之间的连接关系。

<a id="N039"></a>
### 一维列表只是存储表示

**讲解：** 原书按 128 个单元分块，是合理的入门方案；不代表非结构网格只有一种划分方式。也可以依据邻接图、空间分区和工作量重新排序，降低随机访存或长短任务混杂。

<a id="N040"></a>
### 不能只数一个字段

**讲解：** 千万个 double 是 80 MB 十进制，但坐标、状态量、面、邻居与临时数组可能远大于此。每线程持有很多邻居值还可能增加寄存器压力，并溢出到设备内存。

<a id="N041"></a>
### 重排需保持映射一致

**讲解：** 空间填充曲线或分区库可以帮助提升局部性；必须同时更新邻接索引及原编号映射，并验证重排前后物理结果相同。优化不应破坏边界条件和数据对应关系。


<a id="10.7"></a>
## 10.7 延伸探索与本章小结
原书 p.368–370。

<a id="N042"></a>
### 统一的思考框架

**讲解：** 把循环体与索引集分开，把全局存储与组内协作分开，把提交与完成分开。工作组大小、寄存器、共享内存和调度能力之间的取舍，是性能分析的主线。

<a id="N043"></a>
### 历史叙述的处理

**讲解：** 原书有关 Aurora、Intel 市场份额、未来交付时间和移动端软件入口的段落属于出版时代背景，本讲义不将其作为当前系统排名或可用软件承诺。具体设备支持应查当前厂商资料。


<a id="10.7.1"></a>
## 10.7.1 延伸阅读
原书 p.369–370。

<a id="N044"></a>
### 原书推荐的方向

**讲解：** CUDA 编程与最佳实践指南、GPU Gems、AMD GPUOpen/ROCm 以及 Intel oneAPI 资料。老材料可帮助理解思想，线程同步、资源上限和 API 支持需对照实际工具链版本。

<a id="N045"></a>
### 本讲义的核对资料

**讲解：** 针对独立线程调度与屏障，引用 NVIDIA CUDA 12.4.1 编程指南；占用率与流水线原则沿用官方最佳实践。规范允许的机制与某台 GPU 实测效果分开表述。


<a id="10.7.2"></a>
## 10.7.2 练习：图像流水线与显存容量
原书 p.370。

<a id="N046"></a>
### 练习一：百万张图像

**讲解：** CPU 每图 100 ms、16 核完全独立处理时，总时间约 6250 s。GPU 每阶段 5 ms：不重叠时需 15000 s；满足独立三阶段流水线假设时，需 15+(1000000−1)×5=5000010 ms，即 5000.01 s。是否更快取决于能否实现重叠。

<a id="N047"></a>
### 练习二：链路升级与减少输出

**讲解：** 若只有传输从 5 ms 降到 2.5 ms，而 kernel 仍为 5 ms，长期吞吐仍受计算限制。实际 PCIe 升级不保证复制时间严格减半；分类结果通常远小于原图，减少 D2H 数据量也能缩短延迟。

<a id="E007"></a>
**Source:** 原书 p.370 / PDF p.406 · E007

$$
L=\left\lfloor\sqrt[3]{fM/(vs)}\right\rfloor
$$

立方网格边长容量估计：M 是显存字节数，f 是可用比例。忽略 halo、对齐和额外元数据，实际分配应留余量。

<a id="N048"></a>
### 练习三：双精度与单精度

**讲解：** 例如明确假设 8 GiB 显存、只用一半、每单元 4 个变量：double 得到 512³；float 可容纳更多单元，但边长只增至 645，不能把边长直接翻倍。精度改变后还须重新验证数值误差。


## 技术核对来源

- [R48 · CUDA 12.4.1 编程指南：线程与同步](https://docs.nvidia.com/cuda/archive/12.4.1/cuda-c-programming-guide/index.html)
- [R49 · CUDA 最佳实践：占用率与流](https://docs.nvidia.com/cuda/archive/13.2.1/cuda-c-best-practices-guide/index.html)