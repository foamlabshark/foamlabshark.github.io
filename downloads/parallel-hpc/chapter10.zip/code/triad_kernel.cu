#include <cuda_runtime.h>
#include <stddef.h>
__global__ void triad(const double *a, const double *b,
                      double *c, double scalar, size_t n) {
    size_t i = (size_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    c[i] = a[i] + scalar * b[i];
}
