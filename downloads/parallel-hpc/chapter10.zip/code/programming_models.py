"""Serial teaching models, not GPU execution."""
def groups(n,t):
    if type(n) is not int or type(t) is not int or n<0 or t<=0:raise ValueError('invalid dimensions')
    return n//t+(n%t!=0)

def pipeline(n,h,k,d):
    if n<0 or min(h,k,d)<0:raise ValueError('negative input')
    if n==0:return 0
    return h+k+d+(n-1)*max(h,k,d)

def schedule(n,h,k,d):
    a=b=c=0
    for _ in range(n):
        a+=h;b=max(a,b)+k;c=max(b,c)+d
    return c

def cube_fit(bytes_available,fields,bytes_each):
    if bytes_available<0 or fields<=0 or bytes_each<=0:raise ValueError('invalid capacity')
    cells=bytes_available//(fields*bytes_each)
    lo,hi=0,cells+1
    while lo+1<hi:
        mid=(lo+hi)//2
        if mid**3<=cells:lo=mid
        else:hi=mid
    return lo

def check():
    for n in range(1025):
        for t in [1,2,7,32,128,256]:
            g=groups(n,t)
            ids=[b*t+x for b in range(g) for x in range(t) if b*t+x<n]
            assert ids==list(range(n))
    assert groups(1000,128)==8
    assert not (1000>1000) and (1000>=1000)
    for nx,ny in [(1,1),(13,7),(32,16),(0,7)]:
        seen=[]
        for by in range(groups(ny,4)):
            for bx in range(groups(nx,8)):
                for ty in range(4):
                    for tx in range(8):
                        x,y=bx*8+tx,by*4+ty
                        if x<nx and y<ny:seen.append(y*nx+x)
        assert sorted(seen)==list(range(nx*ny))
    for n in range(8):
        for h,k,d in [(10,5,10),(5,5,5),(2,7,3),(0,5,0)]:assert pipeline(n,h,k,d)==schedule(n,h,k,d)
    assert pipeline(3,10,5,10)==45
    assert pipeline(1_000_000,5,5,5)==5_000_010
    assert cube_fit(4*2**30,4,8)==512
    assert cube_fit(4*2**30,4,4)==645
    assert (4+2)*(4+2)*(8+2)*8==2880
    for n in range(65):
        data=list(range(n))
        for block in [1,3,8,32]:assert sum(sum(data[i:i+block]) for i in range(0,n,block))==sum(data)
    for n,t in [(-1,4),(2,0),(1.5,2)]:
        try:groups(n,t)
        except ValueError:pass
        else:raise AssertionError('invalid dimensions accepted')
    print('6150 one-dimensional launch cases, 2D mapping, reduction, pipeline and capacity checks passed.')
    print('No C++/CUDA compilation or GPU execution performed.')
if __name__=='__main__':check()
