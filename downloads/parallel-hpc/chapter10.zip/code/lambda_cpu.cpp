#include <array>
#include <cassert>
int main() {
    constexpr int n = 100;
    std::array<double,n> a{}, b{}, c{};
    a.fill(1.0); b.fill(2.0);
    double scalar = 0.5;
    auto body = [&](int i) { c[i] = a[i] + scalar * b[i]; };
    for (int i = 0; i < n; ++i) body(i);
    for (double value : c) assert(value == 2.0);
}
