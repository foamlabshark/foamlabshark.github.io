programming_models.py 使用 Python 标准库，已运行 6150 个一维启动覆盖用例，二维索引、归约、理想流水线、容量与非法输入检查。
lambda_cpu.cpp 是完整 CPU C++11 教学示例，未编译；triad_kernel.cu 仅为 CUDA kernel 源码，未编译运行，需自行提供合法设备缓冲和主机启动流程。commands_and_fragments.txt 是片段合集，不是完整脚本。
没有 GPU 实机性能或并发验证。