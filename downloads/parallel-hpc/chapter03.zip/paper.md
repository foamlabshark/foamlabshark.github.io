# 第 3 章｜性能极限与性能分析

原著：Robert Robey、Yuliana Zamora，Manning，2021。原书 p.58–85 / PDF p.94–121。

核心段落中英对照、全部编号小节解释、9 幅原图、公式和代码语法。3.A–3.C 是为原书未编号图增加的讲义定位标签。不是逐段全文译本。

## 小节索引

- [第 3 章导读｜性能极限与性能分析](#3-intro)
- [3.1 了解应用潜在的性能限制](#3.1)
- [3.2 通过基准测试确定硬件能力](#3.2)
- [3.2.1 收集系统特征的工具](#3.2.1)
- [3.2.2 计算理论峰值浮点性能](#3.2.2)
- [3.2.3 存储层次与理论内存带宽](#3.2.3)
- [3.2.4 实测带宽与浮点性能：STREAM](#3.2.4)
- [3.2.4（续）把计算与带宽画进 Roofline](#3.2.4-roofline)
- [3.2.5 计算机器平衡点](#3.2.5)
- [3.3 描述应用的性能特征](#3.3)
- [3.3.1 性能工具：热点与调用图](#3.3.1)
- [3.3.1（续）用应用 Roofline 定位内核](#3.3.1-advisor)
- [3.3.1（续）LIKWID 硬件计数器](#3.3.1-likwid)
- [3.3.1（续）清单 3.1：测量指定代码区间](#3.3.1-markers)
- [3.3.1（续）绘制自己的 Roofline](#3.3.1-plot)
- [3.3.2 实测处理器频率与能耗](#3.3.2)
- [3.3.3 跟踪运行时内存](#3.3.3)
- [3.4 进一步探索与本章小结](#3.4)
- [3.4.1 延伸阅读](#3.4.1)
- [3.4.2 练习与参考思路](#3.4.2)

## 公式索引

- [E001](#E001) · 原书 p.61 · B_nc = U_cache × B_E
- [E002](#E002) · 原书 p.65 · F_T = C_v × f_c × I_c
- [E003](#E003) · 原书 p.65 · I_c = (VW / W_bits) × F_ops
- [E004](#E004) · 原书 p.66 · B_T = MTR × M_c × T_w × N_s
- [E005](#E005) · 原书 p.69 · P ≤ min(F_peak, B × I)
- [E006](#E006) · 原书 p.71 · MB = F / B

## 术语约定

|原文|译法|说明|
|---|---|---|
|bandwidth|带宽|数据传输速率；明确内存层级与单位|
|latency|延迟|一次数据访问的等待时间|
|arithmetic intensity|算术强度|FLOP/byte；指定数据移动边界|
|machine balance|机器平衡点|峰值运算速率 / 带宽|
|Roofline|Roofline 性能模型|结合计算与带宽的性能上界|
|cache line|缓存行|缓存系统的数据传输与管理粒度|
|FMA|融合乘加|性能计数常计为每元素 2 FLOP|
|inclusive cost|包含式成本|包括被调用函数的成本|
|exclusive / self cost|自身成本|不含被调用函数的成本|
|RSS|驻留集大小|驻留物理内存，不能等同虚拟地址空间|
|MT/s|每秒百万次传输|M 为十进制 10^6|
|GB / GiB|十进制/二进制容量单位|1 GB=10^9 byte；1 GiB=2^30 byte|

<a id="3-intro"></a>
## 第 3 章导读｜性能极限与性能分析
原书 p.58。

<a id="S001"></a>
**Source:** 原书 p.58 / PDF p.94 · S001

**Original:** By measuring the performance of your hardware and your application, you can determine where it’s most effective to spend your development time.

**中文:** 通过测量硬件与应用的性能，可以判断把开发时间投入哪里最有效。

<a id="N001"></a>
### 本章的三步逻辑

**讲解：** 先判断应用可能受什么限制，再测量目标硬件在相同指标上的能力，最后分析应用的实际表现。三者结合，才能把“程序很慢”转化成一个可验证的优化任务。

<a id="N002"></a>
### 接上第 2 章的开发循环

**讲解：** 本章详细展开 Profile 阶段：找瓶颈、做基准测试、读调用图和硬件计数器。测量不是为了堆出大量报表，而是为了决定下一次迭代该改哪些数据结构、内核或通信。

<a id="N003"></a>
### 范围与标记

**讲解：** 保留 3.1–3.4 及所有编号子小节；较长的 3.2.4 与 3.3.1 拆分阅读。图 3.1–3.6 沿用原编号；3.A、3.B、3.C 是本讲义为原书未编号插图增加的定位标签，分别来自原书第 71、74、76 页。历史硬件数字均按原书语境解释。


<a id="3.1"></a>
## 3.1 了解应用潜在的性能限制
原书 p.59–61。

<a id="S002"></a>
**Source:** 原书 p.59 / PDF p.95 · S002

**Original:** Bandwidth is the best rate at which data can be moved through a given path in the system.

**中文:** 带宽是在系统中沿某条给定路径移动数据时所能达到的最高速率。

<a id="S003"></a>
**Source:** 原书 p.59 / PDF p.95 · S003

**Original:** Latency is the time required for the first byte or word of data to be transferred.

**中文:** 延迟是传输第一个字节或数据字所需的时间。

<a id="N004"></a>
### 带宽和延迟不是同一个指标

**讲解：** 连续搬运大量数据时，关注每秒能搬多少字节；读取零散、存在依赖的数据时，关注下一项数据多久能到。带宽的单位是 byte/s，延迟的单位是时间，不能把两者的数值直接相除后称为“快多少”。

<a id="N005"></a>
### Speeds 与 feeds

**讲解：** Speeds 表示执行计算的能力；feeds 表示把数据送到计算单元的能力。可能的约束包括浮点、整数或地址运算，内存带宽/延迟，指令获取，网络和磁盘。原书强调许多科学应用受数据移动限制，但具体程序仍需要测量。

<a id="F001"></a>
### 图 3.1
**Source:** 原书 p.60 / PDF p.96 · C001
**Placed near:** 3.1 了解应用潜在的性能限制

![图 3.1](assets/fig3_1.png)

**Original caption:** Feeds and speeds shown on a roofline plot. The conventional scalar CPU is close to the 1 word loaded per cycle and 1 flop per cycle indicated by the shaded circle. The multipliers for the increase in flops are due to the fused multiply-add instruction, vectorization, multiple cores, and hyperthreads. The relative speeds of memory movement are also shown. We’ll discuss the roofline plot more in section 3.2.4.

**中文图注:** Roofline 图同时展示供数与计算能力。阴影圆点对应每周期加载一个数据字、完成一次浮点运算的传统标量参考情形。图中用 FMA、向量化、多核和超线程说明计算能力的增长，并展示不同存储层级的数据移动速率。3.2.4 将进一步讲解 Roofline。

**Reading note:** 横轴是 FLOP/byte，纵轴是 GFLOP/s，均为对数尺度。水平线限制运算，斜线限制供数。原图将超线程作为理想倍数，是简化表达；不能用逻辑处理器数直接推算独立运算单元。

<a id="N006"></a>
### 算术强度：一份数据做多少工作

**讲解：** 算术强度是完成的浮点运算数除以跨指定存储边界移动的字节数。必须说清是 DRAM、缓存还是别的边界。若以 double 数据字计量，每 word 为 8 byte，FLOP/word 数值是 FLOP/byte 的 8 倍。

<a id="E001"></a>
**Source:** 原书 p.61 / PDF p.97 · E001

$$
B_{nc}=U_{cache}\,B_E
$$

原书的非连续访问有效带宽粗估。U_cache 是取值 0–1 的有效使用比例，B_E 是经验带宽；它不是包含所有延迟、预取和缓存冲突效应的精确模型。

<a id="N007"></a>
### 64 字节缓存行的例子

**讲解：** 若一次取回 64 byte，即 8 个 double，却只使用其中一个，那么有效数据利用率只有 1/8。按此粗估，有效带宽约为连续访问的 1/8。循环按列遍历行优先数组时可能出现这种浪费；实际结果还取决于行长、缓存与后续复用。


<a id="3.2"></a>
## 3.2 通过基准测试确定硬件能力
原书 p.62。

<a id="S004"></a>
**Source:** 原书 p.62 / PDF p.98 · S004

**Original:** To complement this conceptual model, you can also make empirical measurements on your target hardware. The empirical measurements are made with micro-benchmark applications.

**中文:** 为了补充这种概念模型，还可以在目标硬件上进行经验测量；这些测量通过微基准程序完成。

<a id="N008"></a>
### 理论上限和实测上限的分工

**讲解：** 理论上限依据硬件资源和假设计算，帮助判断数量级；微基准测量特定条件下能够达到的水平。应用能达到的性能通常还受分支、依赖、工作量分配和算法本身约束。理论值、基准值和应用值应分别记录。

<a id="N009"></a>
### 先统一指标与范围

**讲解：** FLOP/s 是计算速率，GB/s 是数据传输速率，W 是功率，J 是能量。测全节点时就用全节点峰值，测一个核心时就用单核峰值；不能把单核程序与整节点带宽简单混成同一个模型。


<a id="3.2.1"></a>
## 3.2.1 收集系统特征的工具
原书 p.62–65。

<a id="S005"></a>
**Source:** 原书 p.62 / PDF p.98 · S005

**Original:** Although complementary, the theoretical value provides an upper bound to performance, and the empirical measurement confirms what can be achieved in a simplified kernel in close to actual operating conditions.

**中文:** 理论值和经验测量相互补充：前者提供性能上界，后者确认简化内核在接近实际运行条件下可以达到的水平。

<a id="F002"></a>
### 图 3.2
**Source:** 原书 p.63 / PDF p.99 · C002
**Placed near:** 3.2.1 收集系统特征的工具

![图 3.2](assets/fig3_2.png)

**Original caption:** Hardware topology for a Mac laptop using the lstopo command

**中文图注:** 使用 lstopo 命令得到的一台 Mac 笔记本硬件拓扑。

**Reading note:** 从 Machine、Package、NUMA、缓存往下读到 Core 和 PU。一个 Core 下两个 PU 表示两个逻辑执行上下文，不是两个独立物理核心。图中各级缓存的共享关系比单看“总核心数”更有用。

<a id="K001"></a>
**代码出处：** Linux / Unix 命令 · 原书工具整理，pp.62–65

```text
lstopo
lscpu
cat /proc/cpuinfo
lspci
```

<a id="N010"></a>
### 命令逐项理解

**讲解：** lstopo 来自 hwloc，显示拓扑；lscpu 汇总 Linux CPU 信息；/proc/cpuinfo 提供处理器相关信息；lspci 枚举 PCI 设备。支持的输出格式、字段和运行平台依版本而异。命令展示不是要求你安装原书指定的旧版本。

<a id="F003"></a>
### 图 3.3
**Source:** 原书 p.64 / PDF p.100 · C003
**Placed near:** 3.2.1 收集系统特征的工具

![图 3.3](assets/fig3_3.png)

**Original caption:** Output from lscpu for a Linux desktop that shows a 4-core i5-6500 CPU @ 3.2 GHz with AVX2 instructions

**中文图注:** 一台 Linux 台式机的 lscpu 输出，显示支持 AVX2 的四核 i5-6500，标称频率为 3.2 GHz。

**Reading note:** 关注 socket、core、thread 的关系，以及指令集 flags。瞬时 CPU MHz 与型号标称频率不同，不代表硬件报告互相矛盾。

<a id="F004"></a>
### 图 3.4
**Source:** 原书 p.65 / PDF p.101 · C004
**Placed near:** 3.2.1 收集系统特征的工具

![图 3.4](assets/fig3_4.png)

**Original caption:** Output from the lspci command from a Linux desktop that shows an NVIDIA GeForce GTX 960 GPU.

**中文图注:** 一台 Linux 台式机的 lspci 输出，显示 NVIDIA GeForce GTX 960 GPU。

**Reading note:** 这里只能识别设备；看到 GPU 不等于目标程序已经在 GPU 上运行，也不说明当前驱动和编译工具已配置好。

<a id="N011"></a>
### 原书安装步骤的适用范围

**讲解：** 书中包含 cairo、hwloc 的旧版本源码构建，以及 Windows wmic、macOS sysctl 等线索。本讲义保留工具用途，不把 2021 年的平台说明当作当前安装指南；本次也没有修改你的硬件或系统配置。


<a id="3.2.2"></a>
## 3.2.2 计算理论峰值浮点性能
原书 p.65。

<a id="S006"></a>
**Source:** 原书 p.65 / PDF p.101 · S006

**Original:** To determine the number of operations that can be performed, we take the vector width (VW) and divide by the word size in bits (Wbits).

**中文:** 为了确定能够执行多少数据元素的运算，将向量宽度 VW 除以数据字的位宽 Wbits。

<a id="E002"></a>
**Source:** 原书 p.65 / PDF p.101 · E002

$$
F_T=C_v\,f_c\,I_c
$$

原书公式：逻辑核心数 × 时钟频率 × 每周期浮点运算数。保留符号用于对照，但 C_v 与 I_c 的定义必须避免重复计算共享资源；下面给出更明确的物理资源解释。

<a id="E003"></a>
**Source:** 原书 p.65 / PDF p.101 · E003

$$
I_c=\frac{VW}{W_{bits}}\,F_{ops}
$$

原书示例：256/64 = 4 个 double 通道；FMA 每个通道计算乘法加法，计作 2 FLOP，因此一条四通道 FMA 对应 8 FLOP。每周期可发射几条这样的指令，需要另查执行单元吞吐。

<a id="N012"></a>
### 原书的 236.8 GFLOP/s 如何看

**讲解：** 作者以 4 核、2 超线程、3.7 GHz、每周期 8 FLOP 得到 8×3.7×8=236.8 GFLOP/s。超线程共享执行资源，不能据此认定它直接让峰值翻倍。应改为明确数物理核心、每核心每周期向量指令吞吐、每指令通道数和每通道 FLOP 数。

<a id="N013"></a>
### 更严谨的计数示例

**讲解：** 教学假设：4 个物理核心，每核心每周期能执行 2 条四通道双精度 FMA，频率 3.7 GHz。那么峰值为 4×3.7×2×4×2=236.8 GFLOP/s。相同数值来自明确的执行单元假设，而不是超线程本身。本例不替代对某型号实际指令吞吐的核验。

<a id="N014"></a>
### FMA 与频率的两个边界

**讲解：** FMA 是一条指令，但在此性能口径下计为乘加共 2 FLOP。标称频率、短时睿频、全核频率和长时间向量负载下的频率可能不同。计算上限时记录采用哪个频率，不要把广告中的最高瞬时频率视为长期保证。


<a id="3.2.3"></a>
## 3.2.3 存储层次与理论内存带宽
原书 p.66–67。

<a id="S007"></a>
**Source:** 原书 p.66 / PDF p.102 · S007

**Original:** The memory hierarchy has grown deeper over the years with the addition of more levels of cache to compensate for the increase in processing speed relative to the main memory access times.

**中文:** 随着处理速度相对于主存访问速度不断提高，存储层次逐渐加深，通过增加缓存层级来缓解两者之间的差距。

<a id="F005"></a>
### 图 3.5
**Source:** 原书 p.66 / PDF p.102 · C005
**Placed near:** 3.2.3 存储层次与理论内存带宽

![图 3.5](assets/fig3_5.png)

**Original caption:** Memory hierarchy and access times. Memory is loaded into cache lines and stored at each level of the cache system for reuse.

**中文图注:** 存储层次与访问时间。数据按缓存行加载，并保留在缓存层次中，以供再次使用。

**Reading note:** 图中的 4、10、75、400 周期是教学示意，不是所有 CPU 的固定延迟。图内将一次主存访问摊到 8 个 double 上的计算，也不能替代真实流式吞吐测量；延迟隐藏和多个在途请求会影响带宽。

<a id="E004"></a>
**Source:** 原书 p.66 / PDF p.102 · E004

$$
B_T=MTR\,M_c\,T_w\,N_s
$$

数据传输率 × 每插槽内存通道数 × 每通道每次传输字节数 × 插槽数。相乘前确认各因素描述同一配置，各通道已安装并实际可用。

<a id="N015"></a>
### 按单位重算原书例题

**讲解：** 2133 MT/s × 2 通道 × 8 byte × 1 插槽 = 34128 MB/s = 34.128 GB/s，约 31.78 GiB/s。MT/s 的 M 是十进制百万，GB 是 10^9 byte，GiB 是 2^30 byte。原书写 34128 MiB/s 和 34.1 GiB/s，存在十进制与二进制单位混用；讲义不沿用这一单位错误。

<a id="N016"></a>
### DDR 不要多乘一次 2

**讲解：** 如果规格已经给出 MT/s，它通常已经包含双沿传输效果，不应再为了“DDR”额外乘 2。若给出的是实际总线时钟频率，才需要依据接口的每周期传输次数换算。

<a id="N017"></a>
### 通道、插槽和可达带宽

**讲解：** 双插槽总峰值只有在两侧内存通道都被合理使用时才可能体现；跨 NUMA 区域访问可能带来额外成本。内存扩容方式取决于实际主板、插槽和焊接设计，不能把原书“必须更换全部模块”的说法当作通用规则。


<a id="3.2.4"></a>
## 3.2.4 实测带宽与浮点性能：STREAM
原书 p.67–68。

<a id="S008"></a>
**Source:** 原书 p.68 / PDF p.104 · S008

**Original:** The STREAM Benchmark measures the time to read and write a large array.

**中文:** STREAM 基准测试测量读写大型数组所需的时间。

<a id="N018"></a>
### 四种运算的计数口径

**讲解：** 按 double 为 8 byte，并按 STREAM 的有用数据流量计数：Copy 读一个数、写一个数，共 16 byte、0 FLOP；Scale 为 16 byte、1 FLOP；Add 为 24 byte、1 FLOP；Triad 为 24 byte、2 FLOP。物理总线实际流量可能因写分配等机制不同；不要把有用字节数与总线计数器流量混在一起。[R9]

<a id="K002"></a>
**代码出处：** C 表达式 · 原书 STREAM 操作的下标形式整理，p.68

```text
a[i] = b[i];             /* Copy  */
a[i] = q * b[i];         /* Scale */
a[i] = b[i] + c[i];      /* Add   */
a[i] = b[i] + q * c[i];  /* Triad */
```

<a id="N019"></a>
### 数组语法与算术强度

**讲解：** 方括号选择第 i 个元素；q 是标量，b、c 是输入数组，a 是输出数组。Triad 包含一次乘法与一次加法；按上面的有用流量口径，算术强度为 2/24≈0.0833 FLOP/byte。FMA 融合不会把计数从 2 FLOP 改成 1 FLOP。

<a id="K003"></a>
**代码出处：** Shell · 教学整理，需先取得 STREAM 的 stream.c 源码

```text
gcc -O3 -march=native -fopenmp \
    -DSTREAM_ARRAY_SIZE=80000000 -DNTIMES=20 \
    stream.c -o stream_c.exe
./stream_c.exe
```

<a id="N020"></a>
### 编译选项逐项理解

**讲解：** -O3 启用优化；-march=native 为当前编译机器选择指令集，生成程序未必能在更老的 CPU 上运行；-fopenmp 启用 OpenMP；-D 定义预处理宏；-o 指定输出文件。反斜杠在 POSIX shell 中续行，不能直接当作 PowerShell 的续行方式。

<a id="N021"></a>
### 避免把缓存测试当作主存测试

**讲解：** 数组要足够大，以超过相关缓存容量，才能反映大型流式工作负载。书中 8000 万元素的三个 double 数组约占 1.92 GB（约 1.79 GiB），还需留出系统与运行时空间。本次不在你的机器上执行这一大数组基准。

<a id="N022"></a>
### 原书测量值应怎样解释

**讲解：** 表中 Copy 的 Best Rate 是 22086.5 MB/s，即约 22.09 GB/s；Triad 是 16605.8 MB/s，即约 16.61 GB/s。选择最快一项可描述该基准的最大有用带宽，但给 Triad 类应用建模时，也应保留操作匹配的带宽值，而非总挑最高值。


<a id="3.2.4-roofline"></a>
## 3.2.4（续）把计算与带宽画进 Roofline
原书 p.69–71。

<a id="S009"></a>
**Source:** 原书 p.69 / PDF p.105 · S009

**Original:** The roofline model has a vertical axis of flops per second and a horizontal axis of arithmetic intensity.

**中文:** Roofline 模型的纵轴为每秒浮点运算数，横轴为算术强度。

<a id="N023"></a>
### 从一个运算估算上限

**讲解：** 如果算术强度为 I FLOP/byte，数据带宽为 B byte/s，那么供数最多能支持 B×I FLOP/s；硬件本身又不能超过峰值 F_peak。因此可达速率的简化上界取两者较小值。

<a id="E005"></a>
**Source:** 原书 p.69 / PDF p.105 · E005

$$
P\leq\min(F_{peak},B\,I)
$$

教学补充：将原书对 Roofline 的文字说明写成公式。它是简化性能上界，不是实测预测保证；分支、依赖、延迟和并行开销都可能使应用低于屋顶。

<a id="F007"></a>
### 图 3.A
**Source:** 原书 p.71 / PDF p.107 · C007
**Placed near:** 3.2.4（续）把计算与带宽画进 Roofline

![图 3.A](assets/fig3_A.png)

**Original caption:** Roofline for 2017 Mac Laptop shows the maximum FLOPs as a horizontal line, and the maximum bandwidth from various cache and memory levels as sloped lines.

**中文图注:** 2017 年 Mac 笔记本的 Roofline：水平线表示浮点性能上限，斜线表示不同缓存和内存层次的带宽上限。

**Reading note:** 3.A 是本讲义标签，原图位于 p.71、未编号。图中峰值为 264.4 GFLOP/s，DRAM 线为 22.5 GB/s。使用这些数据时应保持图中的单位，不把 GB/s 改成 GiB/s。原书指出经验拟合的缓存层标签未必完全可靠。

<a id="N024"></a>
### 怎样读图的左右区域

**讲解：** 左侧算术强度低，数据搬运限制较强；向右移动表示每个搬运字节承担更多计算。超过带宽线与水平线的交点后，再增加复用不再提高这个简化模型的上界，需要改善计算执行效率或使用更多计算资源。

<a id="N025"></a>
### Empirical Roofline Toolkit 的作用

**讲解：** ERT 改变工作集、算术强度和并行配置，采样不同存储层次的可达性能。原书给出旧版配置文件、MPI/OpenMP 参数及输出路径；应把它看作测量流程示例，不能假设旧安装命令、目录名和全部依赖在当前环境仍适用。

<a id="N026"></a>
### 原书单位校核

**讲解：** p.70 正文出现“约 22 MB/s”，但相邻 STREAM 表、Roofline 图和比值都指向约 22 GB/s 的数量级。同时正文把 GB/s 与 GiB/s 混用。按 22.0865/34.128 计算约为 64.7%，比例接近作者的 65%，但单位应一致。


<a id="3.2.5"></a>
## 3.2.5 计算机器平衡点
原书 p.71。

<a id="S010"></a>
**Source:** 原书 p.71 / PDF p.107 · S010

**Original:** The machine balance is the flops divided by the memory bandwidth.

**中文:** 机器平衡点由浮点运算速率除以内存带宽得到。

<a id="E006"></a>
**Source:** 原书 p.71 / PDF p.107 · E006

$$
MB=F/B
$$

机器平衡点单位为 FLOP/byte。此处 MB 是 machine balance 的符号，不是兆字节。比较应用算术强度时必须采用相同内存边界、设备范围和精度。

<a id="N027"></a>
### 用原图数据复算

**讲解：** 以图 3.A 的 264.4 GFLOP/s 与 22.5 GB/s 为一组一致口径，交点为约 11.75 FLOP/byte；对于 8 byte 的 double word，相当于约 94.01 FLOP/word。原书使用取整带宽 22，并混入 GiB 标记，得到约 96；这里明确数据来源与单位差别。

<a id="N028"></a>
### 比较应用与机器

**讲解：** 若某内核只有 0.1 FLOP/byte，明显低于 11.75 的交点，那么这个模型认为它受带宽限制。增加计算峰值而保持带宽不变，通常不会提高它的理论屋顶。实际点如果还远低于带宽屋顶，需要继续检查缓存行利用率、延迟、并行度与同步。

### Roofline 上限计算器

教学计算，不读取本机硬件；默认值来自原书图 3.A。单位统一为 GFLOP/s、GB/s、FLOP/byte。

交互版本见网页小节 3.2.5。上限取 min(F_peak, B×I)，交点为 F_peak/B。

<a id="N029"></a>
### 试着改变一个因素

**讲解：** 先将 I 设为 0.1，计算上限是 2.25 GFLOP/s；把带宽翻倍，上限升至 4.5。再将 I 设为 20，上限变成 264.4，此时仅提高带宽不再提高屋顶。这是区分“加核心”和“减少数据移动”的一个练习。


<a id="3.3"></a>
## 3.3 描述应用的性能特征
原书 p.71–72。

<a id="S011"></a>
**Source:** 原书 p.71 / PDF p.107 · S011

**Original:** Additionally, you should develop an understanding of how different subroutines and functions depend on each other.

**中文:** 此外，还应理解不同子程序与函数之间的依赖关系。

<a id="N030"></a>
### 同一应用需要多种视角

**讲解：** 墙钟计时回答任务实际花了多久；调用图回答哪些函数调用了谁；硬件计数器回答执行了哪些事件、移动了多少数据。单一指标不足以同时说明运行时间、能耗和瓶颈原因。

<a id="N031"></a>
### 测量记录最小集合

**讲解：** 记录输入规模、精度、版本、编译器及选项、线程/进程数、亲和性、计时区域和重复次数。固定条件才能比较改动前后；应把初始化、计算与输出分别计时，同时保留端到端时间。


<a id="3.3.1"></a>
## 3.3.1 性能工具：热点与调用图
原书 p.72–74。

<a id="S012"></a>
**Source:** 原书 p.72 / PDF p.108 · S012

**Original:** The goal is not to understand every last detail of your current performance.

**中文:** 目标并不是弄清当前性能的每一个细节。

<a id="S013"></a>
**Source:** 原书 p.72 / PDF p.108 · S013

**Original:** Hot spots are kernels that occupy the largest amount of time during execution. Additionally, a call graph is a diagram that shows which routines call other routines.

**中文:** 热点是执行过程中占用最多时间的计算内核。调用图则展示各例程之间的调用关系。

<a id="K004"></a>
**代码出处：** Shell · 原书流程整理，p.73；12345 为需替换的输出编号

```text
valgrind --tool=callgrind -v ./clover_leaf
qcachegrind callgrind.out.12345
```

<a id="N032"></a>
### 命令语法与指标口径

**讲解：** --tool=callgrind 选择调用关系分析工具；-v 增加详细输出；./clover_leaf 是待测程序。第二行打开对应输出文件。Callgrind 默认主要统计指令执行与调用事件，不直接等同于真实墙钟时间；查看百分比时先确认所选事件。[R10]

<a id="F008"></a>
### 图 3.B
**Source:** 原书 p.74 / PDF p.110 · C008
**Placed near:** 3.3.1 性能工具：热点与调用图

![图 3.B](assets/fig3_B.png)

**Original caption:** Call graph for CloverLeaf from KCacheGrind shows the largest contributors to run time.

**中文图注:** KCacheGrind 展示的 CloverLeaf 调用图，用于定位主要开销来源。

**Reading note:** 3.B 是讲义标签，原图 p.74。框表示函数，箭头表示调用关系，次数与百分比帮助定位重点。虽然原图注称其为运行时间贡献，实际解读必须以工具选择的事件为准；默认指令计数不能直接当作秒数。

<a id="N033"></a>
### Inclusive 和 exclusive

**讲解：** 包含式成本（inclusive）包含被调用函数的成本；自身成本（exclusive/self）只算该函数自身。因此主函数的 100% 与子函数的 50% 存在包含关系，不能把各层百分比相加。先沿热点分支向下追，再决定修改哪一层。

<a id="N034"></a>
### 原书术语混用的澄清

**讲解：** 本节标题和部分文字写 Cachegrind，实际命令为 --tool=callgrind。两者相关但用途不同：Callgrind 重点保留函数调用关系，Cachegrind 侧重缓存/分支模拟。这里按实际命令讲解，不把两个名称当作完全同义词。


<a id="3.3.1-advisor"></a>
## 3.3.1（续）用应用 Roofline 定位内核
原书 p.74–76。

<a id="N035"></a>
### 原书中的 Advisor 流程

**讲解：** 构建带调试信息的 CloverLeaf OpenMP 版本，设置可执行文件和工作目录，再收集 Roofline。下面保留原书的历史命令用于解释语法；具体工具名称和界面应按安装版本核对。

<a id="K005"></a>
**代码出处：** Shell · 原书 Advisor 命令，p.75，历史版本示例

```text
advixe-cl --collect roofline --project-dir ./advixe_proj -- ./clover_leaf
```

<a id="N036"></a>
### 双横线为何出现两种用法

**讲解：** --collect 和 --project-dir 是分析器选项；单独的 -- 将分析器参数与目标程序分开，后面的 ./clover_leaf 是要运行的应用。--project-dir 指定结果目录，不能把它理解为应用源码目录。

<a id="F009"></a>
### 图 3.C
**Source:** 原书 p.76 / PDF p.112 · C009
**Placed near:** 3.3.1（续）用应用 Roofline 定位内核

![图 3.C](assets/fig3_C.png)

**Original caption:** Roofline from Intel® Advisor for Cloverleaf (clover_bm256_short.in) on a Skylake Gold_6152 processor

**中文图注:** CloverLeaf 在 Skylake Gold 6152 处理器上运行 clover_bm256_short.in 时的 Intel Advisor Roofline。

**Reading note:** 3.C 是讲义标签，原图 p.76。每个点表示一个内核，点的大小与颜色帮助表示相对重要性。先选择耗时高的点，再比较它与同一内存边界屋顶之间的距离；不是图中最低的点就一定最值得优化。

<a id="N037"></a>
### 两种算术强度数字不要强行合并

**讲解：** p.75 摘要文字给出约 0.11 FLOP/byte，p.76 说明又写 0.01。它们可能涉及不同区域，但原文没有充分统一说明；本讲义保留差异，不把两数当成同一个全程序指标。判断具体内核时，以该点的测量范围、计数口径和图中坐标为依据。


<a id="3.3.1-likwid"></a>
## 3.3.1（续）LIKWID 硬件计数器
原书 p.76–78。

<a id="N038"></a>
### 计数器与性能指标

**讲解：** 硬件计数器记录特定事件，工具再将它们转换成 FLOP/s、内存流量、频率或能耗等指标。事件定义依微架构和工具版本而异；不能只看“DP MFLOP/s”这一行名就自行决定如何叠加。

<a id="K006"></a>
**代码出处：** Shell · 原书示例，p.77；CPU 编号和事件组必须按实际系统调整

```text
likwid-perfctr -C 0-87 -g MEM_DP ./clover_leaf
```

<a id="N039"></a>
### -C、-g 与事件组

**讲解：** -C 选择要绑定并测量的逻辑 CPU 列表，0-87 是该示例的编号范围；-g 选择性能事件组。大小写不同的 -c 主要选择测量 CPU，而 -C 还涉及绑定。先确认系统拓扑和事件组支持，不能在小型机器上照抄 88 个编号。[R11]

<a id="N040"></a>
### 权限说明与本次范围

**讲解：** 访问计数器可能需要管理员预先配置相应驱动或服务。原书出现 sudo modprobe msr 等步骤，本次只讲解概念，不执行提权、加载模块或更改系统权限；在受管集群上应采用管理员提供的测量方式。

<a id="N041"></a>
### 原书计算率的数值与限制

**讲解：** 书中以 22163.8134 + 4×4777.5260 得到约 41273.9174 MFLOP/s，即 41.27 GFLOP/s；再除以 123319.9692 MB/s，得到约 0.3347 FLOP/byte。这个加权是否适用取决于当时事件组定义；如果某一行已包含向量 FLOP，再乘通道数可能重复计数。不要把这一公式用于所有 LIKWID 报表。

<a id="N042"></a>
### 为什么不同工具给出不同强度

**讲解：** 差异可能来自时间区域不同、统计缓存行还是有用字节、统计标量还是完整向量、是否包含整数操作，以及线程或插槽的汇总方式。只有分子、分母覆盖同一段工作，才能解释比值。

<a id="N043"></a>
### 能耗算例复核

**讲解：** 按原书两组数据，处理器能耗减少 (212747.7787−151590.4909)/212747.7787≈28.75%；DRAM 能耗减少约 23.29%。这些是原书运行的比较，不能当作本机结果，也不应把重复计数的包级能量跨逻辑线程直接相加。


<a id="3.3.1-markers"></a>
## 3.3.1（续）清单 3.1：测量指定代码区间
原书 p.78。

<a id="S014"></a>
**Source:** 原书 p.78 / PDF p.114 · S014

**Original:** Markers can be used in likwid to get performance for one or multiple sections of code.

**中文:** 可以使用 LIKWID 的标记功能获取一个或多个代码区间的性能数据。

<a id="K007"></a>
**代码出处：** C 片段 · 依据原书清单 3.1 整理，补上头文件与 REGISTER 行分号

```text
#include <likwid-marker.h>

LIKWID_MARKER_INIT;
LIKWID_MARKER_THREADINIT;
LIKWID_MARKER_REGISTER("Compute");
LIKWID_MARKER_START("Compute");
/* Put the serial region to measure here. */
LIKWID_MARKER_STOP("Compute");
LIKWID_MARKER_CLOSE;
```

<a id="N044"></a>
### 这段代码不是独立程序

**讲解：** 这是应放进应用合适位置的调用片段，不包含 main。INIT 建立测量环境，REGISTER 预注册名为 Compute 的区域，START/STOP 夹住测量区间，CLOSE 汇总并结束。字符串名称必须一致，分号结束语句。

<a id="N045"></a>
### 多线程放在哪里

**讲解：** 串行区域与多线程区域的放置不同：进程级初始化和结束通常在外层；线程相关注册和 START/STOP 应按 Marker API 要求由参与线程执行。不能只让主线程打点，就假定记录了所有工作线程的计数。[R12]

<a id="K008"></a>
**代码出处：** Shell · 串行教学示例；路径、事件组和代码依赖需按环境替换

```text
gcc -O3 -DLIKWID_PERFMON -I/path/to/likwid/include \
    app.c -L/path/to/likwid/lib -llikwid -o app
likwid-perfctr -C 0 -g MEM -m ./app
```

<a id="N046"></a>
### 编译和运行参数

**讲解：** -D 定义预处理宏；-I 添加头文件搜索路径；-L 添加库搜索路径；-llikwid 链接 LIKWID 库；-m 启用 Marker 模式。若应用含 OpenMP，还要按其构建方式启用线程编译和链接选项。该示例未在本环境编译执行。[R11]


<a id="3.3.1-plot"></a>
## 3.3.1（续）绘制自己的 Roofline
原书 p.78–82。

<a id="N047"></a>
### 从数据表到图形

**讲解：** 原书演示将硬件参数和应用测量输入 Jupyter，再使用 Python、NumPy、Matplotlib 绘图。绘图只展示输入数据，不会自动证明它们正确。先统一 FLOP、byte、时间和测量范围，再选择对数轴、单位和图例。

<a id="K009"></a>
**代码出处：** Python · 教学补充 roofline_demo.py，绘制模型曲线，不含本机实测点

```text
import numpy as np
import matplotlib.pyplot as plt

peak = 264.4       # GFLOP/s: historical example
bandwidth = 22.5   # GB/s: same decimal-unit convention
intensity = np.logspace(-3, 2, 400)
roof = np.minimum(peak, bandwidth * intensity)

fig, ax = plt.subplots()
ax.loglog(intensity, roof, label="Model ceiling")
ax.set_xlabel("Arithmetic intensity [FLOP/byte]")
ax.set_ylabel("Performance [GFLOP/s]")
ax.grid(True, which="both", alpha=0.25)
ax.legend()
fig.tight_layout()
fig.savefig("roofline_demo.png", dpi=180)
plt.close(fig)
```

<a id="N048"></a>
### Python 语法逐行看

**讲解：** import ... as ... 为模块设置简写；logspace(-3,2,400) 在 10^-3 到 10^2 之间按对数间隔取 400 点；数组乘法逐元素计算 B×I；minimum 逐元素取小值；fig, ax 是两个返回对象的解包；loglog 设置双对数坐标；savefig 保存图片。

<a id="F006"></a>
### 图 3.6
**Source:** 原书 p.82 / PDF p.118 · C006
**Placed near:** 3.3.1（续）绘制自己的 Roofline

![图 3.6](assets/fig3_6.png)

**Original caption:** Overall performance of Clover Leaf on a Skylake Gold processor

**中文图注:** CloverLeaf 在 Skylake Gold 处理器上的整体性能。

**Reading note:** 圆点是 OpenMP 加向量化版本，方点是串行版本。3.3.1 给出的 41.27/2.97≈13.90 倍，与正文“约 15 倍”属于不同精度的概括，不把它写成精确 15.00 倍。图中 GiB/s 标注也应与实际字节口径核对。

<a id="N049"></a>
### 怎样判断改动的效果

**讲解：** 点向上表示计算速率提高，点向右表示单位搬运字节承担更多运算。性能提高并不一定伴随算术强度改变；例如仅增加线程、改善向量执行，也可能主要让点向上移动。判断应配合总运行时间与结果正确性。


<a id="3.3.2"></a>
## 3.3.2 实测处理器频率与能耗
原书 p.82–83。

<a id="S015"></a>
**Source:** 原书 p.82 / PDF p.118 · S015

**Original:** With the aggressive management of processor frequency, processors seldom are at their nominal frequency setting.

**中文:** 由于处理器会积极管理频率，它们往往并不始终工作在标称频率上。

<a id="K010"></a>
**代码出处：** Linux Shell · 原书频率观察命令，p.82

```text
watch -n 1 "lscpu | grep MHz"
watch -n 1 "grep MHz /proc/cpuinfo"
```

<a id="N050"></a>
### watch、管道和引号

**讲解：** watch -n 1 每秒重复执行一次命令；管道 | 把前一条命令的输出交给后一条；grep MHz 筛选包含 MHz 的行。引号使里面的整条命令由 watch 重复执行。瞬时频率快照不能替代完整负载区间的平均值。

<a id="K011"></a>
**代码出处：** C 调用片段 · 原书清单 3.2，p.83

```text
powerstats_init();
powerstats_sample();
powerstats_finalize();
```

<a id="N051"></a>
### 初始化、采样、结束

**讲解：** init 在开始时调用，sample 在计算中按阶段或周期调用，finalize 在结束时汇总。它们是特定库接口，不是标准 C 函数；要核对该库版本的头文件、链接方式和支持平台。原书所述 PowerStats、Power Gadget 支持状态属于历史背景。

<a id="N052"></a>
### 功率与能量必须满足量纲

**讲解：** 能量是功率对时间的积分；若用平均功率，则 E=P_avg×T。1 Wh=3600 J，1 mWh=3.6 J。比较串行与并行版本时应固定任务、包含同样的设备范围，不能只比较瞬时 W。

<a id="N053"></a>
### 原书输出表的内部一致性

**讲解：** p.83 示例给出 Processor Energy=94.47181 mWh、Power=71.07833 W、Time=12.13246 s。前两者与该时间并不能直接满足同一窗口的能量关系：94.47 mWh≈340.10 J，除以 12.13 s 约 28.03 W。原文未解释窗口或口径差异，因此不能把三项同时当作相互验证的结果。


<a id="3.3.3"></a>
## 3.3.3 跟踪运行时内存
原书 p.83–84。

<a id="S016"></a>
**Source:** 原书 p.83 / PDF p.119 · S016

**Original:** Memory usage is also another aspect of performance that isn’t easily visible to the programmer.

**中文:** 内存使用量也是程序员不容易直接观察到的性能方面。

<a id="K012"></a>
**代码出处：** Linux Shell · 教学整理，12345 替换为实际 PID

```text
watch -n 1 "grep VmRSS /proc/12345/status"
ps -p 12345 -o pid,rss,vsz,comm
top -d 1 -p 12345
```

<a id="N054"></a>
### PID、RSS 与虚拟地址空间

**讲解：** PID 是进程编号；VmRSS/RSS 反映驻留在物理内存的规模；VSZ 是虚拟地址空间规模，两者不可混同。多进程共享页会使简单相加产生重复计算；GPU 设备内存也不能只靠进程 RSS 得知。字段单位以系统工具说明为准。

<a id="N055"></a>
### 为什么改写原书 top 示例

**讲解：** 原书写 top -s 1 -p <pid>；不同系统 top 参数语义不一致，在常见 Linux procps top 中 -d 指刷新间隔，-s 指安全模式。因此这里明确标为 Linux 教学写法，避免把原书命令原样当作跨平台语法。

<a id="K013"></a>
**代码出处：** C 声明式示意 · 原书 MemSTATS 接口列表整理，p.84

```text
long long memstats_memused();
long long memstats_mempeak();
long long memstats_memfree();
long long memstats_memtotal();
```

<a id="N056"></a>
### long long 与测量位置

**讲解：** long long 是整数类型，适合容纳较大的计数值，但具体返回单位仍须查库约定。函数名称分别提示当前用量、峰值、空闲和总量；名称本身不能证明作用范围是进程还是系统。将测量放在分配前、分配后、计算后和释放后，有助于定位阶段性增长。


<a id="3.4"></a>
## 3.4 进一步探索与本章小结
原书 p.84–85。

<a id="S017"></a>
**Source:** 原书 p.85 / PDF p.121 · S017

**Original:** However, the most valuable tools are those that provide actionable information rather than quantity.

**中文:** 最有价值的工具，是能够提供可用于行动的信息，而不是仅仅产生大量信息的工具。

<a id="N057"></a>
### 把一份性能报告变成下一步工作

**讲解：** 例如：已测得主存带宽；热点为某模板循环；应用点远低于带宽屋顶；数据布局使缓存行利用不足。下一步可以针对该循环改变访问顺序，并用相同输入重新验证结果与端到端时间。比“再跑十种工具”更有针对性。

<a id="N058"></a>
### 测量时始终问三个问题

**讲解：** 测的是什么事件或时间，覆盖哪个范围，单位是什么？这些问题能防止把指令百分比当时间，把逻辑线程当物理执行单元，把 GB 当 GiB，以及把图上的理论上界当作实际保证。


<a id="3.4.1"></a>
## 3.4.1 延伸阅读
原书 p.84。

<a id="N059"></a>
### 保留原书阅读线索

**讲解：** John McCalpin，STREAM: Sustainable Memory Bandwidth in High Performance Computers（1995），以及 Lawrence Berkeley National Laboratory 的 Roofline Performance Model 资料。前者帮助理解流式带宽的计数规则，后者帮助理解用算术强度统一计算与访存约束。

<a id="N060"></a>
### 本讲义核对来源

**讲解：** R9 为 STREAM 官方说明，R10 为 Callgrind 手册，R11–R12 为 LIKWID 官方项目文档。原书工具链的旧版本安装过程没有在本机重现；工具命令在网页中只作为学习内容展示。


<a id="3.4.2"></a>
## 3.4.2 练习与参考思路
原书 p.84–85。

<a id="N061"></a>
### 练习 1｜计算一台系统的理论性能

**讲解：** 先写出物理核心数、可持续或假设频率、每核心每周期指令吞吐、向量通道、每通道运算数，再算峰值；用通道、传输率、传输宽度计算内存带宽；最后按统一字节口径求 F/B。不要把超线程数和执行单元数量重复相乘。

<a id="N062"></a>
### 练习 2–3｜用 ERT 逐步增加并行

**讲解：** 先跑一个处理器/线程的基准，再逐步启用优化、向量化和更多线程，记录每一步的配置与结果。保持工作集、计数范围和正确性标准一致；观察提升来自哪个屋顶变化，而非只保留最高值。本次没有执行这些硬件基准。

<a id="N063"></a>
### 练习 4｜测 STREAM 带宽

**讲解：** 使用超过缓存容量但内存可承受的数组，保留四种操作的结果、重复次数与编译选项。根据工作负载选择对应的带宽，并核对 MB/s、GB/s 与 GiB/s。不能把放得进缓存的小数组结果称为 DRAM 带宽。

<a id="N064"></a>
### 练习 5｜生成调用图

**讲解：** 选择小型代表应用，确认调用路径和热点事件；比较 inclusive 与 self 成本，选出一个足够重要且可独立改动的内核。原书指向 17.1 的位置与全书目录不一致；基准与 mini-app 集中在 17.4。

<a id="N065"></a>
### 练习 6｜测算术强度

**讲解：** 用 Advisor 或 LIKWID 记录同一个代码区间的运算量与数据移动量。写清使用有用字节还是总线流量、统计 DRAM 还是缓存，以及是否将 FMA 计为两次运算。不同工具不一致时先核对这些定义。

<a id="N066"></a>
### 练习 7｜测频率和能耗

**讲解：** 记录整个任务的运行区间，区分瞬时频率和平均频率、功率和能量；验证 J、Wh、mWh 的换算。比较相同任务与设备范围，报告总能量而不仅是峰值功率。

<a id="N067"></a>
### 练习 8｜测内存用量

**讲解：** 在初始化前后、主要数据结构建立后、计算峰值和释放后采样，区分进程驻留内存、共享内存和设备内存。一次退出前的快照无法反映运行峰值。


## 技术核对来源

- [R9 · STREAM 官方参考与计数规则](https://www.cs.virginia.edu/stream/ref.html)
- [R10 · Valgrind Callgrind 手册](https://valgrind.org/docs/manual/cl-manual.html)
- [R11 · LIKWID perfctr 官方文档](https://github.com/RRZE-HPC/likwid/wiki/likwid-perfctr)
- [R12 · LIKWID Marker API 教程](https://github.com/RRZE-HPC/likwid/wiki/TutorialMarkerC)