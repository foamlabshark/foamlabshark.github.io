import numpy as np
import matplotlib.pyplot as plt

peak = 264.4       # GFLOP/s: historical example
bandwidth = 22.5   # GB/s: same decimal-unit convention
intensity = np.logspace(-3, 2, 400)
roof = np.minimum(peak, bandwidth * intensity)

fig, ax = plt.subplots()
ax.loglog(intensity, roof, label="Model ceiling")
ax.set_xlabel("Arithmetic intensity [FLOP/byte]")
ax.set_ylabel("Performance [GFLOP/s]")
ax.grid(True, which="both", alpha=0.25)
ax.legend()
fig.tight_layout()
fig.savefig("roofline_demo.png", dpi=180)
plt.close(fig)
