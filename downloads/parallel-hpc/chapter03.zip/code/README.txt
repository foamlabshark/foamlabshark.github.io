roofline_demo.py 使用 Python、NumPy、Matplotlib 绘制模型上限，输入为原书历史示例，不是本机实测。commands_and_fragments.txt 是命令/片段资料，不应整份作为脚本执行。性能工具可能有版本和平台差异，C/LIKWID 片段未编译。

验证：Python 绘图脚本已通过语法检查，环境缺少 Matplotlib，未执行绘图。模型算式已独立复核，网页计算器已验证带宽翻倍、算力上限、零带宽拒绝和恢复默认值。
