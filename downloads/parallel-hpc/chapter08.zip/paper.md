# 第 8 章｜MPI：并行计算的骨干

原著：Robert Robey、Yuliana Zamora，Manning，2021。原书 p.254–304 / PDF p.290–340。

核心段落翻译与全部编号小节讲解，保留图 8.1–8.6。不是逐段全文译本。长程序以有出处的核心片段及教学说明呈现。

## 小节索引

- [第 8 章导读｜MPI：并行计算的骨干](#8-intro)
- [8.1 MPI 程序的基本结构](#8.1)
- [8.1.1 初始化、rank 与通信器](#8.1.1)
- [8.1.2 MPI 编译器包装器](#8.1.2)
- [8.1.3 启动多个进程](#8.1.3)
- [8.1.4 最小工作示例](#8.1.4)
- [8.2 点对点消息的组成与匹配](#8.2)
- [8.2（续）阻塞、非阻塞与死锁](#8.2-completion)
- [8.3 集体通信的整体图景](#8.3)
- [8.3.1 屏障与并行计时](#8.3.1)
- [8.3.2 广播小型输入文件](#8.3.2)
- [8.3.3 归约与全局统计](#8.3.3)
- [8.3.4 用 Gather 排序调试输出](#8.3.4)
- [8.3.5 Scatterv 与 Gatherv 的不均匀分块](#8.3.5)
- [8.4 数据并行：划分数据与连接子域](#8.4)
- [8.4.1 MPI STREAM Triad 与内存带宽](#8.4.1)
- [8.4.2 二维网格的幽灵单元交换](#8.4.2)
- [8.4.2（续）缓冲区、Pack 与通信生命周期](#8.4.2-pack)
- [8.4.3 三维网格：面、棱与角](#8.4.3)
- [8.5 用类型与拓扑表达通信结构](#8.5)
- [8.5.1 派生数据类型](#8.5.1)
- [8.5.2 笛卡尔拓扑与邻域通信](#8.5.2)
- [8.5.3 幽灵交换方案的性能比较](#8.5.3)
- [8.6 MPI 与 OpenMP 混合并行](#8.6)
- [8.6.1 混合并行的收益与代价](#8.6.1)
- [8.6.2 线程支持等级与混合代码](#8.6.2)
- [8.7 进一步探索与本章小结](#8.7)
- [8.7.1 延伸阅读](#8.7.1)
- [8.7.2 练习与参考思路](#8.7.2)

## 术语约定

|原文|译法|说明|
|---|---|---|
|communicator|通信器|进程组及通信上下文|
|rank|进程编号|通信器内部编号|
|tag|标签|区分消息协议|
|request|请求|跟踪非阻塞操作|
|ghost cell|幽灵单元|邻接子域数据的本地副本|
|extent|类型跨度|重复类型实例之间的间距|

<a id="8-intro"></a>
## 第 8 章导读｜MPI：并行计算的骨干
原书 p.254–255。

<a id="S001"></a>
**Source:** 原书 p.254 / PDF p.290 · S001

**Original:** The name message passing refers to the ability to easily send messages from one process to another.

**中文:** 消息传递这个名称，指的是从一个进程向另一个进程发送消息的能力。

<a id="N001"></a>
### 从线程转向进程

**讲解：** OpenMP 线程通常共享进程地址空间；MPI 让进程通过明确的通信接口协作，从一台机器扩展到多个计算节点。MPI 是接口标准，MPICH、Open MPI 是实现，不是一门需要特殊语言编译器的独立语言。

<a id="N002"></a>
### 本章路线

**讲解：** 先掌握初始化、rank 与通信器，再理解消息匹配和完成条件；随后学习集体通信、网格幽灵单元、派生类型、拓扑及 MPI+OpenMP。所有编号小节保留，长例子使用有出处的核心代码与教学说明，不逐行重印数百行程序。


<a id="8.1"></a>
## 8.1 MPI 程序的基本结构
原书 p.255–256。

<a id="F001"></a>
### 图 8.1
**Source:** 原书 p.255 / PDF p.291 · C001
**Placed near:** 8.1 MPI 程序的基本结构

![图 8.1](assets/fig8_1.png)

**Original caption:** The MPI approach is library-based. Just compile, linking in the MPI library, and launch with a special parallel startup program.

**中文图注:** MPI 程序通过库接口编写、编译链接，再用进程启动程序运行。

**Reading note:** 图展示传统 World 模型；MPI_Init 或 MPI_Init_thread 后使用 MPI_COMM_WORLD，结束前完成通信并调用 MPI_Finalize。不要把 Finalize 当作代替请求完成检查的捷径。

<a id="N003"></a>
### 三个环节不能混淆

**讲解：** mpicc 负责调用底层编译器并补充 MPI 配置；mpiexec 等负责启动进程；MPI_Comm_rank 等是运行中的库调用。单纯把程序运行多份，不会自动把循环数据划分成互不重叠的区间。


<a id="8.1.1"></a>
## 8.1.1 初始化、rank 与通信器
原书 p.256。

<a id="S002"></a>
**Source:** 原书 p.256 / PDF p.292 · S002

**Original:** Most programs will need the number of processes and the process rank within the group that can communicate, called a communicator.

**中文:** 多数程序需要知道可通信进程组中的进程数量和自身编号；这一通信上下文由通信器表示。

<a id="K001"></a>
**代码出处：** C · 原书 p.256 基本调用整理

```text
MPI_Init(&argc, &argv);
int rank, size;
MPI_Comm_rank(MPI_COMM_WORLD, &rank);
MPI_Comm_size(MPI_COMM_WORLD, &size);
/* 计算与通信 */
MPI_Finalize();
```

<a id="N004"></a>
### 地址符号与返回值

**讲解：** &rank 传入变量地址，使函数能够写回编号；函数自身的 int 返回值用于错误状态。rank 是指定通信器内部的编号，从 0 到 size-1；同一进程在不同通信器中的编号可能不同。通信器还提供消息隔离上下文。


<a id="8.1.2"></a>
## 8.1.2 MPI 编译器包装器
原书 p.256–257。

<a id="K002"></a>
**代码出处：** Shell · 原书包装器用法整理；选项随 MPI 实现不同

```text
mpicc -O2 hello_mpi.c -o hello_mpi
# Open MPI 包装器信息
mpicc --showme:compile
mpicc --showme:link
```

<a id="N005"></a>
### 包装器做了什么

**讲解：** mpicc、mpicxx、mpifort 分别服务于 C、C++、Fortran。它们补充头文件路径、库和链接参数；不自动将串行代码变成并行程序。MPICH 的查询选项与 Open MPI 不同，不能混用。

<a id="N006"></a>
### 工具链保持一致

**讲解：** 编译时的头文件、链接时的库以及运行时的启动器应来自兼容的 MPI 安装。原书 CMake 例子较早，迁移时应查询实际 CMake FindMPI 支持，不机械复制清理目录的 shell 命令。


<a id="8.1.3"></a>
## 8.1.3 启动多个进程
原书 p.257。

<a id="K003"></a>
**代码出处：** Shell · 在已配置的 MPI 运行环境中启动四个进程

```text
mpiexec -n 4 ./hello_mpi
```

<a id="N007"></a>
### 四个进程不一定四台机器

**讲解：** -n 指进程数量，放置在哪些节点和核心由启动器、资源分配与绑定决定。集群的 srun、厂商启动器和 mpiexec 并非参数完全相同的别名，应按本地环境使用。

<a id="N008"></a>
### 先做小规模验证

**讲解：** 先运行 1、2、4 个进程检查结果与输出，再考虑跨节点和绑定。多个 rank 的 printf 到达控制台的顺序不保证，不能由打印先后推导通信完成顺序。


<a id="8.1.4"></a>
## 8.1.4 最小工作示例
原书 p.257–259。

<a id="K004"></a>
**代码出处：** C · 清单 8.1 整理，完整程序 hello_mpi.c；未编译运行

```text
#include <mpi.h>
#include <stdio.h>
int main(int argc, char **argv) {
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    printf("Rank %d of %d\n", rank, size);
    MPI_Finalize();
    return 0;
}
```

<a id="N009"></a>
### 语法逐项看

**讲解：** char **argv 是字符串指针数组的常见参数形式；&argv 将它的地址交给初始化接口。每个进程都有自己的 rank、size 变量。所有进程执行同一程序，依据编号选择负责的数据或通信对象。

<a id="N010"></a>
### 退出路径也要协作

**讲解：** 初始化之后某个进程单独 exit，可能使其他进程永远等待。可恢复错误要设计一致的处理流程；不可恢复错误可使用 MPI_Abort 结束相关并行作业。正式程序还需补充错误检查。


<a id="8.2"></a>
## 8.2 点对点消息的组成与匹配
原书 p.259–261。

<a id="S003"></a>
**Source:** 原书 p.260 / PDF p.296 · S003

**Original:** The message itself is always composed of a triplet at both ends: a pointer to a memory buffer, a count, and a type.

**中文:** 消息在发送和接收两端都由三个要素描述：内存缓冲区指针、元素数量和数据类型。

<a id="F002"></a>
### 图 8.2
**Source:** 原书 p.260 / PDF p.296 · C002
**Placed near:** 8.2 点对点消息的组成与匹配

![图 8.2](assets/fig8_2.png)

**Original caption:** A message in MPI is always composed of a pointer to memory, a count, and a type. The envelope has an address composed of a rank, a tag, and a communication group along with an internal MPI context.

**中文图注:** 缓冲区、数量和类型描述数据；rank、tag 与通信器上下文描述消息匹配。

**Reading note:** 传的是指针所指的数据，不是把本进程地址作为远端可直接使用的指针。发送端指定目的 rank，接收端指定来源。MPI_ANY_TAG 和 MPI_ANY_SOURCE 是接收侧通配选择，不能拿去充当发送标签或目的进程。

<a id="N011"></a>
### 类型匹配不是任意数值转换

**讲解：** 发送和接收可有不同布局，但相应基本类型序列必须匹配；不能随意将 MPI_INT 发给 MPI_DOUBLE 来获得数值转换。接收容量可大于实际消息，但过小属于截断错误。MPI_INT 对应 C int，不应跨所有平台写死为 4 字节。


<a id="8.2-completion"></a>
## 8.2（续）阻塞、非阻塞与死锁
原书 p.261–266。

<a id="F003"></a>
### 图 8.3
**Source:** 原书 p.261 / PDF p.297 · C003
**Placed near:** 8.2（续）阻塞、非阻塞与死锁

![图 8.3](assets/fig8_3.png)

**Original caption:** The ordering of blocking send and receives is tricky to do correctly. It is much safer and faster to use the non-blocking or immediate forms of the send and receive operations and then wait for completion.

**中文图注:** 图比较双方先接收、先发送、交替调用及非阻塞通信的时序。

**Reading note:** 原图“更快”不是普遍保证。双方先阻塞接收会相互等待；双方先 MPI_Send 可能因小消息缓冲而暂时成功，却不能依赖这种行为保证正确性。

<a id="K005"></a>
**代码出处：** C · 清单 8.6 核心整理；收发缓冲区应互不重叠，peer 必须有效

```text
MPI_Sendrecv(sendbuf, n, MPI_DOUBLE, peer, 10,
             recvbuf, n, MPI_DOUBLE, peer, 10,
             MPI_COMM_WORLD, MPI_STATUS_IGNORE);
```

<a id="K006"></a>
**代码出处：** C · 清单 8.7 教学整理；comm 为有效通信器

```text
MPI_Request req[2];
MPI_Irecv(recvbuf, n, MPI_DOUBLE, peer, 10, comm, &req[0]);
MPI_Isend(sendbuf, n, MPI_DOUBLE, peer, 10, comm, &req[1]);
/* 可做不访问上述活动缓冲区的独立计算 */
MPI_Waitall(2, req, MPI_STATUSES_IGNORE);
```

<a id="N012"></a>
### 完成条件

**讲解：** Send 返回表示发送缓冲可安全复用，不一定表示远端已经处理完数据；Recv 返回表示接收数据可用。Isend/Irecv 返回时操作可能尚未完成：完成前不能修改发送数据或访问接收数据。原书注释“Irecv completes”应理解为调用已返回，而非接收完成。

<a id="N013"></a>
### Request_free 不是 Wait

**讲解：** 释放活动请求句柄不会等待通信完成，随后也不能再用该句柄检测完成。原书清单 8.8 在接收后释放发送请求，不足以一般性证明发送缓冲可复用；教学流程保留发送请求并显式等待。[R41]

<a id="N014"></a>
### 接口校核

**讲解：** MPI_Sendrecv 是点对点操作，不是集体通信。原书伪原型中的 MPI_COMM 应为 MPI_Comm，MPI_Receive 应为 MPI_Recv。非阻塞方式允许组织重叠，但实际进展与加速依赖实现和工作负载。[R42]


<a id="8.3"></a>
## 8.3 集体通信的整体图景
原书 p.266–267。

<a id="F004"></a>
### 图 8.4
**Source:** 原书 p.266 / PDF p.302 · C004
**Placed near:** 8.3 集体通信的整体图景

![图 8.4](assets/fig8_4.png)

**Original caption:** The data movement of the most common MPI collective routines provide important functions for parallel programs. Additional variants MPI_Scatterv, MPI_Gatherv, and MPI_Allgatherv allow a variable amount of data to be sent or received from the processes. Not shown are some additional routines such as the MPI_Alltoall and similar functions.

**中文图注:** 广播、归约、分发与汇集描述不同的数据流；带 v 的变体允许不同进程贡献不同数量。

**Reading note:** root 表示根进程；All 前缀通常表示结果分发到所有参与者。各进程须在同一通信器上按兼容顺序调用集体操作；集体调用并不自动修复不一致顺序，也不能一概当作屏障。

<a id="N015"></a>
### 按需求选择接口

**讲解：** 同一配置发给所有进程用 Bcast；合并统计量用 Reduce/Allreduce；将全局数组分块用 Scatter(v)；收回各块用 Gather(v)。不要把所有通信都手写成大量 Send/Recv。


<a id="8.3.1"></a>
## 8.3.1 屏障与并行计时
原书 p.267–268。

<a id="K007"></a>
**代码出处：** C · 清单 8.9、8.11 的教学组合；统计本地用时的最大值

```text
MPI_Barrier(comm);
double t0 = MPI_Wtime();
/* 本进程的计算 */
double local = MPI_Wtime() - t0;
double maximum;
MPI_Reduce(&local, &maximum, 1, MPI_DOUBLE, MPI_MAX, 0, comm);
```

<a id="N016"></a>
### 时钟与同步

**讲解：** MPI_Wtime 给出本地墙钟秒数，不保证不同进程时钟起点相同。比较同一进程的前后差，再归约最大值。结束前加 Barrier 会把等待及屏障开销算入，根进程所见时间不等于精确的各地用时最大值。

<a id="N017"></a>
### 屏障的用途要明确

**讲解：** 调试或建立计时边界时可以需要屏障；不能将原书“生产中不用屏障”理解成绝对禁令。保留算法真正需要的同步，避免为了让输出好看而在热点路径随意增加全局等待。


<a id="8.3.2"></a>
## 8.3.2 广播小型输入文件
原书 p.268–269。

<a id="S004"></a>
**Source:** 原书 p.269 / PDF p.305 · S004

**Original:** To do this, we need to first broadcast the size so that every process can allocate an input buffer and then broadcast the data.

**中文:** 为此，先广播大小，让每个进程能够分配输入缓冲区，再广播数据。

<a id="K008"></a>
**代码出处：** C · 清单 8.10 的字符串结束修正；此前还须广播长度和读取状态

```text
/* root 已成功读取 n 字节；所有进程均已分配 n+1 字节 */
MPI_Bcast(buf, n, MPI_CHAR, 0, comm);
buf[n] = '\0';
```

<a id="N018"></a>
### 原清单遗漏了什么

**讲解：** 原书只在 rank 0 设置字符串结束符，却只广播 input_size 个字符；其他进程的最后一字节未初始化就交给 strtok。应在各进程补写结束符，或广播包含结束符的数据。还需检查 fopen、ftell、fread、分配和长度转换失败。

<a id="N019"></a>
### 大文件需要另一种思路

**讲解：** 单进程读入再广播适合小配置。大文件集中读会遇到内存和 I/O 瓶颈，应考虑第 16 章的并行 I/O；并行文件系统并不是“本质上只能串行工作”。


<a id="8.3.3"></a>
## 8.3.3 归约与全局统计
原书 p.269–273。

<a id="K009"></a>
**代码出处：** C · 一个局部标量合成全局标量

```text
MPI_Allreduce(&local_sum, &global_sum, 1, MPI_DOUBLE, MPI_SUM, comm);
```

<a id="N020"></a>
### 先局部，再跨进程

**讲解：** MPI_Reduce 按对应元素在进程间合并数据，不自动把每个进程的一整个数组变成一个标量。先求本地数组和，再用 count=1 归约；count>1 时通常得到多个按位置合并的结果。Reduce 只在 root 得到结果，Allreduce 让所有参与者获得结果。

<a id="N021"></a>
### Kahan 示例需要复核

**讲解：** 清单 8.14 的 new_sum 再次把 local.correction 当作加数，正确递推应加入 corrected_next_term。清单 8.13 的用户算子还应处理回调传入的 len 项，不能只处理第一项。结构体布局和类型 extent 也需核对。

<a id="N022"></a>
### 自定义算子不是可复现保证

**讲解：** MPI 用户归约要求满足所声明的运算性质。补偿状态合并的浮点行为不能凭名称断言严格结合或交换，commutative=1 更不应随意设置。若强调可复现，可用固定顺序合并作对照；仍须分别测试误差和规模变化。


<a id="8.3.4"></a>
## 8.3.4 用 Gather 排序调试输出
原书 p.273–274。

<a id="S005"></a>
**Source:** 原书 p.273 / PDF p.309 · S005

**Original:** A gather operation can be described as a collate operation, where data from all processors is brought together and stacked into a single array as shown in figure 8.4 in the lower center.

**中文:** Gather 可以理解为一种汇集操作：把各进程的数据集中起来，按顺序放入一个数组，如图 8.4 下方中间所示。

<a id="K010"></a>
**代码出处：** C · 清单 8.15 核心整理；root 的 times 至少容纳 size 个 double

```text
MPI_Gather(&local_time, 1, MPI_DOUBLE,
           times, 1, MPI_DOUBLE, 0, comm);
if (rank == 0)
    for (int r = 0; r < size; ++r)
        printf("%d: %g seconds\n", r, times[r]);
```

<a id="N023"></a>
### 接收数量按每个进程计算

**讲解：** 这里 recvcount=1，不是 size。Gather 按 rank 顺序放入根的数组，再由根顺序打印。非根上的接收参数按接口规则不参与结果存储，但本地 C 变量仍应初始化为有效值或 NULL，避免读取未初始化指针。

<a id="N024"></a>
### 计时变量先赋值

**讲解：** 原书 total_time 未初始化就 +=；应先置零或直接赋为本次时间差。输出顺序整齐不证明计算正确，也不应把大量调试输出的时间混入内核性能。


<a id="8.3.5"></a>
## 8.3.5 Scatterv 与 Gatherv 的不均匀分块
原书 p.274–276。

<a id="K011"></a>
**代码出处：** C · 清单 8.16 教学整理；n 非负，乘积与 int count/displacement 均须在可表示范围内

```text
for (int r = 0; r < size; ++r) {
    long b = (long)n * r / size;
    long e = (long)n * (r + 1) / size;
    counts[r] = (int)(e - b);
    displs[r] = (int)b;
}
MPI_Scatterv(global, counts, displs, MPI_DOUBLE,
             local, counts[rank], MPI_DOUBLE, 0, comm);
```

<a id="N025"></a>
### 位移的单位

**讲解：** Scatterv/Gatherv 的位移以对应数据类型 extent 为单位，不是默认字节。MPI_DOUBLE 连续数组里可理解成 double 元素偏移。不要与 Neighbor_alltoallw 的字节位移混淆。

<a id="N026"></a>
### 空块和大规模

**讲解：** N 不能整除 P 时块长最多差 1，N<P 会出现零元素进程，它们仍参加集体调用。原书使用 int 数量有范围限制，不能把 long 转成 int 当作解决溢出；更大数据需采用适用接口或分批通信。


<a id="8.4"></a>
## 8.4 数据并行：划分数据与连接子域
原书 p.276。

<a id="N027"></a>
### 先分工，再通信

**讲解：** 数据并行让每个 rank 负责一部分数据。纯局部运算可能不需要中途通信；差分、stencil 等算子需要邻域输入，通过少量成批交换连接各子域。

<a id="N028"></a>
### 局部与全局索引

**讲解：** 全局编号用于表达原问题，局部编号用于访问当前进程数组。必须记录本地范围、邻居、halo 深度和物理边界，不能把 rank 当成数组索引直接混用。


<a id="8.4.1"></a>
## 8.4.1 MPI STREAM Triad 与内存带宽
原书 p.276–277。

<a id="S006"></a>
**Source:** 原书 p.276 / PDF p.312 · S006

**Original:** This gives a target bandwidth to aim for with more complicated applications.

**中文:** 这为更复杂的应用提供了一个可作为优化目标的带宽参考。

<a id="K012"></a>
**代码出处：** C · 清单 8.17 的本地内核

```text
for (long i = 0; i < local_n; ++i)
    c[i] = a[i] + scalar * b[i];
```

<a id="N029"></a>
### 进程数与带宽

**讲解：** 同一节点多个进程共享内存系统，总带宽可能很快饱和。多个节点的带宽可以汇总，但要明确每进程工作量与总工作量；固定局部规模属于弱扩展方向，不能与固定全局规模混为一谈。

<a id="N030"></a>
### 统计口径

**讲解：** 原书只报主进程时间，可能掩盖较慢 rank。应收集最大用时，并按相同计时范围统计总有效字节。数据大小、缓存状态、写分配与结果校验都会影响带宽解释。


<a id="8.4.2"></a>
## 8.4.2 二维网格的幽灵单元交换
原书 p.277–285。

<a id="S007"></a>
**Source:** 原书 p.277 / PDF p.313 · S007

**Original:** Ghost cells are the mechanism that we use to link the meshes on adjacent processors.

**中文:** 幽灵单元是连接相邻处理器上各块网格的一种机制。

<a id="F005"></a>
### 图 8.5
**Source:** 原书 p.281 / PDF p.317 · C005
**Placed near:** 8.4.2 二维网格的幽灵单元交换

![图 8.5](assets/fig8_5.png)

**Original caption:** The corner cell version of the ghost cell update first exchanges data to the left and right (on the top half of the figure), followed by a top and bottom exchange (on the bottom half of the figure). With care, the left and right exchange can be smaller with just the real cells plus the outer boundary cells, although there is no harm in making it the full vertical size of the mesh. The updating of the boundary cells surrounding the mesh is done separately.

**中文图注:** 需要角点时，先交换左右，再把包含已更新侧边的数据用于上下交换。物理边界更新另行处理。

**Reading note:** 第二阶段依赖第一阶段接收到的数据，应等待相应请求完成；不一定需要全局 MPI_Barrier。五点 stencil 通常只需四个面邻居，是否需要角点由实际算子决定。

<a id="N031"></a>
### halo 与物理边界

**讲解：** halo 是网格外层存储的统称；幽灵单元保存邻接子域真实单元的副本，物理边界单元则施加边界条件。MPI_PROC_NULL 不会自动替你生成反射、流入或固定值边界。

<a id="N032"></a>
### 行连续，列有步长

**讲解：** 对连续行主序二维数组，整行容易一次发送，列元素之间相隔行跨度。可用循环打包、MPI_Pack 或派生类型描述。double** 并不自动保证所有行连续，必须了解实际分配方式。


<a id="8.4.2-pack"></a>
## 8.4.2（续）缓冲区、Pack 与通信生命周期
原书 p.280–285。

<a id="K013"></a>
**代码出处：** C · 基于清单 8.20 的教学流程；省略分配与错误处理

```text
int capacity, pos = 0;
MPI_Pack_size(n, MPI_DOUBLE, comm, &capacity);
/* packed 至少分配 capacity 字节 */
MPI_Pack(values, n, MPI_DOUBLE, packed, capacity, &pos, comm);
MPI_Isend(packed, pos, MPI_PACKED, peer, tag, comm, &request);
MPI_Wait(&request, MPI_STATUS_IGNORE);
/* 到这里才可覆盖或释放 packed */
```

<a id="N033"></a>
### Pack 参数语法

**讲解：** capacity 是打包缓冲区容量上界，pos 是当前位置，由 MPI_Pack 更新；实际发送打包后的 pos 字节。接收与 Unpack 必须使用匹配的打包布局和初始位置。不能用 n*sizeof(double) 普遍代替 Pack_size 查询。

<a id="N034"></a>
### 为什么不能只等接收

**讲解：** 即使本次接收已完成，己方非阻塞发送仍可能读取缓冲区。下一轮重新装填或释放缓冲区前必须证明发送完成。改成派生类型也不取消这个要求，因为发送直接引用原数组。


<a id="8.4.3"></a>
## 8.4.3 三维网格：面、棱与角
原书 p.285–286。

<a id="N035"></a>
### 六个直接邻居

**讲解：** 三维子域有六个面方向；若算子需要棱或角的数据，可以分阶段沿各轴传播，或者直接联系更多邻居。需要哪些单元应从离散算子的访问模式推导。

<a id="E001"></a>
**Source:** 原书 p.286 / PDF p.322 · E001

$$
H=(n_x+2h)(n_y+2h)(n_z+2h)-n_xn_yn_z
$$

教学补充：完整外壳的存储单元数，不等于每次实际发送量。只交换面而不含棱角时，通信量更少。

<a id="N036"></a>
### 强扩展的限制

**讲解：** 全局问题固定时，进程越多，本地体积缩小，而表面积占比增大，通信相对计算的成本上升。halo 深度不能超过简单单跳交换方案可提供的邻接数据范围；极小子域需额外设计。


<a id="8.5"></a>
## 8.5 用类型与拓扑表达通信结构
原书 p.286–287。

<a id="N037"></a>
### 把不变量提前建立

**讲解：** 派生类型描述数据在内存中的布局；拓扑描述通信器内进程的逻辑邻接。固定网格可以在启动时建立这些对象并重复使用，使每轮更新更容易审查。

<a id="N038"></a>
### 简化代码不等于免除检查

**讲解：** 仍需检查数组真实布局、类型跨度、邻居顺序、标签和请求完成。MPI 可能在内部打包，不能仅因使用派生类型就宣称零拷贝或一定更快。


<a id="8.5.1"></a>
## 8.5.1 派生数据类型
原书 p.287–292。

<a id="S008"></a>
**Source:** 原书 p.287 / PDF p.323 · S008

**Original:** This allows the encapsulation of complex data into a single custom data type that you can use in communication calls.

**中文:** 这样可以将复杂的数据布局封装成一个自定义类型，在通信调用中使用。

<a id="F006"></a>
### 图 8.6
**Source:** 原书 p.287 / PDF p.323 · C006
**Placed near:** 8.5.1 派生数据类型

![图 8.6](assets/fig8_6.png)

**Original caption:** Three MPI custom data types with illustrations of the arguments used in their creation

**中文图注:** 连续块、等步长向量和矩形子数组三种派生类型。

**Reading note:** count、blocklength 与 stride 含义不同；vector 的 stride 以旧类型 extent 为单位。类型描述布局，不分配或移动应用的数据。

<a id="K014"></a>
**代码出处：** C · 清单 8.23–8.24 的列交换教学片段；收发列必须不重叠且索引有效

```text
MPI_Datatype column;
MPI_Type_vector(rows, 1, pitch, MPI_DOUBLE, &column);
MPI_Type_commit(&column);
/* flat 为连续行主序缓冲，pitch 为含 halo 的每行元素数 */
MPI_Sendrecv(flat + send_col, 1, column, right, 20,
             flat + recv_col, 1, column, left, 20,
             comm, MPI_STATUS_IGNORE);
MPI_Type_free(&column);
```

<a id="N039"></a>
### 一次发送多少

**讲解：** count=1 表示一个 column 类型实例，其中已包含 rows 个 double。若把 count 又写成 rows，就重复发送多个完整派生类型，容易越界。type size 是有效数据字节数，extent 是重复实例的跨度，含洞布局中二者可不同。[R43]

<a id="K015"></a>
**代码出处：** C · 清单 8.25 的三维面类型教学示例；使用整个分配区起始地址

```text
int sizes[3] = {nz+2*h, ny+2*h, nx+2*h};
int subs[3] = {nz, ny, h};
int starts[3] = {h, h, h};
MPI_Datatype face;
MPI_Type_create_subarray(3, sizes, subs, starts,
                        MPI_ORDER_C, MPI_DOUBLE, &face);
MPI_Type_commit(&face);
```

<a id="N040"></a>
### 不要重复施加偏移

**讲解：** subarray 的 starts 已经编码起点；再给缓冲指针额外加同样的偏移，会移动两次。各维顺序按实际内存布局书写，这里 z、y、x 且 x 最快变化。原书函数名应为 MPI_Type_commit、MPI_Type_free，C 大小写不能混用。


<a id="8.5.2"></a>
## 8.5.2 笛卡尔拓扑与邻域通信
原书 p.292–297。

<a id="S009"></a>
**Source:** 原书 p.292 / PDF p.328 · S009

**Original:** Not covered are general graph functions for unstructured applications.

**中文:** 本节不讨论用于非结构化应用的一般图拓扑函数。

<a id="K016"></a>
**代码出处：** C · 清单 8.27–8.28 的二维拓扑教学整理

```text
int dims[2] = {0, 0}, periods[2] = {0, 0};
MPI_Dims_create(size, 2, dims);
MPI_Comm cart;
MPI_Cart_create(MPI_COMM_WORLD, 2, dims, periods, 1, &cart);
if (cart != MPI_COMM_NULL) {
    int cr, coords[2], left, right;
    MPI_Comm_rank(cart, &cr);
    MPI_Cart_coords(cart, cr, 2, coords);
    MPI_Cart_shift(cart, 1, 1, &left, &right);
    /* 用 cart 内的邻居编号通信 */
    MPI_Comm_free(&cart);
}
```

<a id="N041"></a>
### reorder 与通信器编号

**讲解：** reorder=1 允许重排，之后应在 cart 中重新查询 rank，不能拿 WORLD 的编号直接当笛卡尔编号。网格容纳的进程少于输入通信器时，有些进程得到 MPI_COMM_NULL；更大则错误。[R44]

<a id="N042"></a>
### Dims_create 不知道网格形状

**讲解：** 它分解进程数量，但不针对长条形物理网格自动最小化通信面。8×8×1000 网格若在各方向平均切分，局部形状可能很差，应结合计算域长宽和负载设计分区。

<a id="N043"></a>
### Neighbor_alltoallw 的三个检查

**讲解：** 邻居顺序按拓扑维度、负向后正向组织，不能脱离维度约定固定叫上下左右；位移单位是字节，使用 MPI_Aint 和实际 sizeof/地址计算；同一底层分配区的互不重叠发送/接收区域，不应与 MPI_IN_PLACE 常量混为一谈。角点传播仍需分阶段依赖。


<a id="8.5.3"></a>
## 8.5.3 幽灵交换方案的性能比较
原书 p.297–298。

<a id="N044"></a>
### 原书实验条件

**讲解：** 原书比较显式数组缓冲、Pack、MPI 派生类型和笛卡尔邻域通信，使用两节点、144 个进程等配置，并以多次运行的中位数绘图。具体硬件、版本、halo 深度、角点需求和网格规模都会改变排序。

<a id="N045"></a>
### 怎样公平比较

**讲解：** 确认每种方案交换同样的单元，比较同样的边界条件和结果。把一次性类型构造与每轮通信分开计时；记录慢进程时间及波动。原书未编号性能图仅作为历史结果讨论，不新增虚构图号。

<a id="N046"></a>
### 可维护性也是收益

**讲解：** 即使时间相近，明确的类型和拓扑可能减少手写索引错误。只有实际剖析和测试才能判断内部打包是否减少、通信是否重叠，不能凭源码行数推断速度。


<a id="8.6"></a>
## 8.6 MPI 与 OpenMP 混合并行
原书 p.299–302。

<a id="S010"></a>
**Source:** 原书 p.299 / PDF p.335 · S010

**Original:** The combination of two or more parallelization techniques is called a hybrid parallelization, in contrast to all MPI implementations that are also called pure MPI or MPI-everywhere.

**中文:** 将两种或更多并行技术结合，称为混合并行；只用 MPI 的方式则常称为纯 MPI 或 MPI-everywhere。

<a id="N047"></a>
### 分层分工

**讲解：** MPI 进程负责子域之间的通信，OpenMP 线程负责进程内部工作，SIMD 可进一步处理单线程的数据通道。减少 MPI rank 数可能降低元数据与通信缓冲占用，但增加线程同步与 NUMA 管理复杂度。


<a id="8.6.1"></a>
## 8.6.1 混合并行的收益与代价
原书 p.299–300。

<a id="N048"></a>
### 可能的收益

**讲解：** 更少的 MPI 子域可能减少幽灵存储、网卡争用和集体通信参与者；共享内存可帮助平衡进程内部的工作。收益取决于问题分布，不保证所有程序都胜过纯 MPI。

<a id="N049"></a>
### 明确资源账目

**讲解：** 4 个 MPI 进程各运行 22 个 OpenMP 线程，是 4 个进程、最多 88 个团队线程的配置，不是原书所写的 88 个进程。还要防止线程绑定到过小的 CPU 集合，造成超额订阅。


<a id="8.6.2"></a>
## 8.6.2 线程支持等级与混合代码
原书 p.300–302。

<a id="S011"></a>
**Source:** 原书 p.301 / PDF p.337 · S011

**Original:** The additional code checks that the requested thread safety level is available and exits if it is not.

**中文:** 额外的代码检查请求的线程支持等级是否可用；若不可用，则退出。

<a id="K017"></a>
**代码出处：** C · 清单 8.33–8.34 的教学核心；n 与数组已初始化

```text
int provided;
MPI_Init_thread(&argc, &argv, MPI_THREAD_FUNNELED, &provided);
if (provided < MPI_THREAD_FUNNELED)
    MPI_Abort(MPI_COMM_WORLD, 1);
/* 初始化线程负责 MPI 通信 */
#pragma omp parallel for
for (int i = 0; i < n; ++i)
    out[i] = a[i] + b[i];
/* 并行区已结束，可继续在初始化线程调用 MPI */
```

<a id="N050"></a>
### 四级支持

**讲解：** SINGLE：程序只执行一个线程；FUNNELED：仅调用初始化的线程调用 MPI；SERIALIZED：可由不同线程调用但不同时进入；MULTIPLE：允许多线程并发调用。provided 是实际支持，不能假设等于请求。[R45]

<a id="N051"></a>
### single 不是 FUNNELED 保证

**讲解：** OpenMP single 可以由任意团队线程执行，所以不能仅靠 single 就保证 MPI 由初始化线程调用。最容易审查的入门结构是把 MPI 放在并行区域之外。需要更复杂结构时，应明确线程身份和同步。

<a id="N052"></a>
### 绑定配置校核

**讲解：** 原书 OMP_CPU_BIND 应改为 OMP_PROC_BIND。请求更高线程支持可能有成本，但不能断言每升一级都必然更慢。启动器绑定选项随 MPI 实现变化，应按实际版本与分配资源测试。


<a id="8.7"></a>
## 8.7 进一步探索与本章小结
原书 p.302–304。

<a id="N053"></a>
### 通信器、图拓扑与单边通信

**讲解：** 子通信器用于局部团队，图拓扑用于不规则邻接。共享内存窗口与 RMA 提供不同访问方式；单边操作仍需遵守窗口与同步阶段约定。原书 MPI_Puts、MPI_Gets 应为 MPI_Put、MPI_Get。

<a id="N054"></a>
### 本章的检查顺序

**讲解：** 先明确各进程拥有的数据，再检查通信器与消息匹配，随后确认缓冲区生命周期和所有参与者的调用顺序，最后测量性能。类型与拓扑帮助表达结构，但正确性仍来自这些约束。


<a id="8.7.1"></a>
## 8.7.1 延伸阅读
原书 p.303。

<a id="N055"></a>
### 原书推荐

**讲解：** Pacheco 的并行编程入门、Gropp 等的 Using MPI，以及 MPI+OpenMP 课程材料适合继续学习。历史书中的 MPI 3.1 描述是出版语境，不作为当前最新版本声明。

<a id="N056"></a>
### 查阅方法

**讲解：** 优先查所用 MPI 实现对应版本的函数手册，核对参数、类型匹配、完成语义和集体调用规则。本讲义补充链接采用明确的 Open MPI 5.0.6 文档版本。


<a id="8.7.2"></a>
## 8.7.2 练习与参考思路
原书 p.303。

<a id="N057"></a>
### 练习 1–3：只等待接收安全吗

**讲解：** 分别列出发送和接收引用的缓冲区，以及下一次覆盖时刻。接收完成不普遍证明发送完成；使用 vector 类型直接发送原数组，也要在覆盖该区域前确认对应发送请求完成。比较性能之前先证明生命周期正确。

<a id="N058"></a>
### 练习 4：通配标签

**讲解：** MPI_ANY_TAG 只能放在接收侧；发送仍须合法明确标签。通配接收可能让不同阶段或方向的消息被错误匹配，不能以一次运行成功证明普遍安全。明确标签有助于表达协议。

<a id="N059"></a>
### 练习 5–7：计时与混合调优

**讲解：** 比较有无屏障时，说明等待是否计入；给 STREAM 添加 min/max/avg 统计；再试不同 MPI rank 数、OpenMP 线程数与 SIMD。保持总资源和问题规模可比较，先验证答案再讨论速度。


## 技术核对来源

- [R41 · MPI_Request_free](https://docs.open-mpi.org/en/v5.0.6/man-openmpi/man3/MPI_Request_free.3.html)
- [R42 · MPI_Sendrecv](https://docs.open-mpi.org/en/v5.0.0/man-openmpi/man3/MPI_Sendrecv.3.html)
- [R43 · MPI_Type_vector](https://docs.open-mpi.org/en/v5.0.6/man-openmpi/man3/MPI_Type_vector.3.html)
- [R44 · MPI_Cart_create](https://docs.open-mpi.org/en/v5.0.6/man-openmpi/man3/MPI_Cart_create.3.html)
- [R45 · MPI_Init_thread](https://docs.open-mpi.org/en/v5.0.6/man-openmpi/man3/MPI_Init_thread.3.html)