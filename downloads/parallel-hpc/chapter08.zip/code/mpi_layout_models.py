"""Serial MPI layout models; no MPI communication is executed."""
def layout(n,p):
    if n<0 or p<1:raise ValueError('invalid shape')
    starts=[n*r//p for r in range(p)]
    counts=[n*(r+1)//p-starts[r] for r in range(p)]
    return starts,counts

def check():
    total=0
    for n in range(65):
        for p in range(1,17):
            starts,counts=layout(n,p);a=list(range(n));pieces=[a[b:b+c] for b,c in zip(starts,counts)]
            assert sum(pieces,[])==a
            transformed=[[x+1 for x in part] for part in pieces]
            assert sum(transformed,[])==[x+1 for x in a]
            assert sum(counts)==n and max(counts)-min(counts)<=1
            total+=1
    for rows in range(1,9):
        for pitch in range(2,12):
            for col in range(pitch):
                vector=[col+r*pitch for r in range(rows)]
                grid=[list(range(r*pitch,(r+1)*pitch)) for r in range(rows)]
                assert [grid[r][col] for r in range(rows)]==vector
    print(f'{total} scatter/gather layouts and strided-column checks passed; serial models only.')
if __name__=='__main__':check()
