#include <stdio.h>
#include <stdlib.h>
int main(void) {
    const int n = 10;
    const int ival = 2;
    int ipos = -1;
    int *iarray = malloc((size_t)n * sizeof *iarray);
    if (iarray == NULL) return EXIT_FAILURE;
    for (int i = 0; i < n; ++i) iarray[i] = i;
    for (int i = 0; i < n; ++i) {
        if (iarray[i] == ival) { ipos = i; break; }
    }
    printf("position = %d\n", ipos);
    free(iarray);
    return EXIT_SUCCESS;
}
