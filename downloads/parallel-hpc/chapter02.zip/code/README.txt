原书示例及教学修正版，见各小节代码出处。test_errors.c 故意含错，仅用于诊断演示。未编译运行。
CMakeLists.txt 为教学修正版，要求 POSIX shell、C 编译器、MPI、CMake、ndiff；默认调用原书 mympiapp.ctest。要使用补充的提前失败检查，将测试脚本名替换成 mympiapp_checked.ctest。
