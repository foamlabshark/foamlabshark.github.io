# 第 2 章｜规划并行化

原著：Robert Robey、Yuliana Zamora，Manning，2021。原书 p.35–57 / PDF p.71–93。

核心段落翻译、全部编号小节讲解、7 幅原图及代码语法。较长的 2.1.2 拆为四个阅读单元；这不是逐段全文译本。

## 小节索引

- [第 2 章导读｜规划并行化](#2-intro)
- [2.1 开始一个新项目：准备工作](#2.1)
- [2.1.1 版本控制：为并行代码建立安全保障](#2.1.1)
- [2.1.2 测试套件：先理解数值差异](#2.1.2)
- [2.1.2（续）清单 2.1：C 与 MPI 计时程序](#2.1.2-timers)
- [2.1.2（续）Shell、CMake 与 CTest 的语法](#2.1.2-ctest)
- [2.1.2（续）测试类型、覆盖率与提交测试](#2.1.2-types)
- [2.1.3 查找并修复内存问题](#2.1.3)
- [2.1.4 提高代码可移植性](#2.1.4)
- [2.2 性能分析：找出硬件能力与应用表现的差距](#2.2)
- [2.3 规划：为成功打好基础](#2.3)
- [2.3.1 利用基准测试与 mini-app 探索](#2.3.1)
- [2.3.2 核心数据结构设计与模块化](#2.3.2)
- [2.3.3 算法：面向并行重新设计](#2.3.3)
- [2.4 实现：把规划落实到代码](#2.4)
- [2.5 提交：以质量检查结束一次迭代](#2.5)
- [2.6 进一步探索与本章小结](#2.6)
- [2.6.1 延伸阅读](#2.6.1)
- [2.6.2 练习与参考思路](#2.6.2)

## 术语约定

| 原文 | 译法 | 含义 |
|---|---|---|
|profiling|性能分析|分析应用的时间与资源分布|
|benchmark|基准测试|测量某种特定性能特征|
|mini-app|小型代表应用|保留一类应用的核心操作模式|
|test suite|测试套件|一组配套输入、操作和判定规则|
|regression test|回归测试|检查已有行为是否退化|
|unit test|单元测试|检查小函数或模块|
|commit test|提交测试|提交前可快速运行的关键测试|
|continuous integration|持续集成|自动构建和测试的流程|
|code coverage|代码覆盖率|反映被运行过的代码范围|
|memory leak|内存泄漏|不再使用的分配内存未得到释放|
|uninitialized value|未初始化值|使用前未建立有效值|
|ghost cell|幽灵单元|存放相邻子域边界数据的副本|
|portability|可移植性|跨目标环境构建和正确运行的能力|

<a id="2-intro"></a>
## 第 2 章导读｜规划并行化
原书 p.35–36。

<a id="S001"></a>
**Source:** 原书 p.35 / PDF p.71 · S001

**Original:** Developing a parallel application or making an existing application run in parallel can feel challenging at first. Often, developers new to parallelism are unsure of where to begin and what pitfalls they might encounter. This chapter focuses on a workflow model for developing parallel applications as illustrated in figure 2.1.

**中文:** 刚开始开发并行应用，或把现有应用改为并行运行，可能会让人感到棘手。刚接触并行开发的人往往不清楚应该从哪里开始，也不知道会遇到什么陷阱。本章围绕图 2.1 所示的并行应用开发流程展开。

<a id="F001"></a>
### 图 2.1
**Source:** 原书 p.35 / PDF p.71 · C001
**Placed near:** 第 2 章导读｜规划并行化

![图 2.1](assets/fig2_01.png)

**Original caption:** Our suggested parallel development workflow begins with preparing the application and then repeating four steps to incrementally parallelize an application. This workflow is particularly suited to an agile project management technique.

**中文图注:** 建议的并行开发流程先准备好应用，然后重复四个步骤，以增量方式逐步实现并行化。这种流程尤其适合敏捷项目管理。

**Reading note:** Preparation 是进入循环前的准备；循环依次为 Profile（分析）、Plan（规划）、Implement（实现）、Commit（提交）。一次只改一部分，才能在结果出错时缩小排查范围。

<a id="N001"></a>
### 本章要解决的问题

**讲解：** 假设你已有一个可信的波浪模拟程序。真正的问题不只是给循环加一条并行指令，而是：如何证明结果没被改坏，如何找出值得优化的部分，如何让不同编译器构建成功，以及如何把每次改动变成可追踪的版本。

<a id="N002"></a>
### 沿用第 1 章的火山场景

**讲解：** 原书继续使用图像识别、火山灰羽流和海浪模拟三个应用。它们的成熟程度不同，准备工作也不同：已有用户的应用需要保护现有行为，初创代码需要先建立测试与版本管理。工程流程应服务于这些具体需求。

<a id="N003"></a>
### 这一章的阅读方式

**讲解：** 保留原书 2.1–2.6 及编号子小节。内容较长的 2.1.2 拆为“数值差异、计时程序、测试脚本、测试类型”四个阅读单元；原小节编号仍保留。代码框标明“原书代码”或“教学修正版”，避免混淆出处。


<a id="2.1"></a>
## 2.1 开始一个新项目：准备工作
原书 p.36–37。

<a id="S002"></a>
**Source:** 原书 p.37 / PDF p.73 · S002

**Original:** With version control and code testing in place, you can now tackle the task of cleaning up your code. Good code is easy to modify and extend, and does not exhibit unpredictable behavior. Good, clean code can be ensured with modularity and checks for memory issues.

**中文:** 建立版本控制与代码测试之后，就可以着手清理代码。良好的代码易于修改和扩展，不应表现出不可预测的行为。模块化设计与内存问题检查有助于保证代码清晰、可靠。

<a id="F002"></a>
### 图 2.2
**Source:** 原书 p.37 / PDF p.73 · C002
**Placed near:** 2.1 开始一个新项目：准备工作

![图 2.2](assets/fig2_02.png)

**Original caption:** The recommended preparation components address issues that are important for parallel code development.

**中文图注:** 建议的准备工作包括并行代码开发中的几个重要方面。

**Reading note:** 四项准备依次是版本控制、测试、代码质量与代码可移植性。这里的箭头表示工作流程，不表示后面的工作完成后就可以丢掉前面的保障。

<a id="N004"></a>
### 把四项准备落实到文件

**讲解：** 版本控制保存一次次可恢复的改动；测试保存输入、参考输出和判定规则；代码质量检查发现越界、未初始化和泄漏；可移植性通过另一套编译器或目标环境检验。它们都应进入项目计划，而不是等并行化完成后再补。

<a id="N005"></a>
### 模块化为何重要

**讲解：** 把计算内核写成输入输出明确的函数，才能单独测试、计时和替换实现。例如将五点模板更新封装为 step(old, next)，边界条件、文件读取与绘图留在外层。这样修改线程分工时，不必同时改变整个应用。

<a id="N006"></a>
### 原书强调：准备时间不是浪费

**讲解：** 复杂应用中，准备工作花费的时间可能接近并行化本身。串行代码如果已经存在未定义行为，“让并行结果与串行一致”就不是可靠目标；应先确认基准实现本身可信。


<a id="2.1.1"></a>
## 2.1.1 版本控制：为并行代码建立安全保障
原书 p.37–39。

<a id="S003"></a>
**Source:** 原书 p.37 / PDF p.73 · S003

**Original:** It is inevitable with the many changes that occur during parallelism that you will suddenly find the code is broken or returning different results. Being able to recover from this situation by backing up to a working version is critically important.

**中文:** 并行化过程中会发生大量修改，难免突然发现程序无法正常运行，或返回了不同结果。此时，能够恢复到一个正常工作的版本至关重要。

<a id="S004"></a>
**Source:** 原书 p.39 / PDF p.75 · S004

**Original:** In general, commit messages include a summary and a body. The summary provides a short statement indicating clearly what new changes the commit covers.

**中文:** 通常，提交说明包括摘要和正文。摘要用一句简短的话清楚说明这次提交包含哪些新改动。

<a id="N007"></a>
### 版本控制记录的不只是代码

**讲解：** 原书比较集中式与分布式版本控制，并以 Git 作为常见选项。分布式仓库允许在本地保存历史与提交；是否适合团队还取决于权限、审查与协作方式。不能仅凭“集中式”就保证安全，也不能把“分布式”理解为必须公开代码。

<a id="N008"></a>
### 提交说明怎么写

**讲解：** “修复 bug”无法说明什么发生了变化。更好的写法是：“修复模糊算子 OpenMP 版本的数据竞争”，再解释发生条件、采取的修正和已做的验证。原书示例提到加屏障；这不表示所有竞争都能靠屏障解决，必须先弄清读写依赖。

<a id="K001"></a>
**代码出处：** Git 命令 · 教学补充，文件路径为示例

```text
git status
git diff
git add src/blur.c tests/test_blur.c
git commit -m "Fix data race in the OpenMP blur operator"
```

<a id="N009"></a>
### 命令语法逐项讲解

**讲解：** git status 查看状态；git diff 查看尚未暂存的修改；git add 后面的路径选择本次提交的文件；commit 创建本地历史记录；-m 后的引号包住包含空格的说明。这里没有 push，创建本地提交不等于推送到远端。示例路径需要替换为实际文件，不应直接在不相关的目录中照抄。

<a id="N010"></a>
### 一次提交的合适粒度

**讲解：** 让一次提交对应一个可解释、可验证的变化，例如“把旧值与新值分到两个数组”。不要把算法替换、文件格式改动和多线程迁移混在一次大提交中。是否合并小提交、是否使用评审，由团队流程决定。


<a id="2.1.2"></a>
## 2.1.2 测试套件：先理解数值差异
原书 p.39–41。

<a id="S005"></a>
**Source:** 原书 p.39 / PDF p.75 · S005

**Original:** A test suite is a set of problems that exercise parts of an application to guarantee that related parts of the code still work. Test suites are a necessity for all but the simplest of codes. With each change, you should test to see that the results that you get are the same.

**中文:** 测试套件是一组用来运行应用各部分的问题，以确认相关代码仍然正常工作。除了最简单的程序，测试套件都是必要的。每次修改之后，都应该检查得到的结果是否保持一致。

<a id="S006"></a>
**Source:** 原书 p.40 / PDF p.76 · S006

**Original:** The parallelism process inherently changes the order of operations, which slightly modifies the numerical results. But errors in parallelism also generate small differences.

**中文:** 并行化过程本身会改变运算顺序，从而使数值结果产生轻微变化；然而，并行代码中的错误也可能产生小差异。

<a id="N011"></a>
### 讲解：相同不是无条件逐位相同

**讲解：** 浮点加法不满足严格的结合律。多个线程或进程以不同顺序合并局部和，可能改变末位；这并不自动说明程序有错。但差异小也不等于没有错误，数据竞争同样可能只偶尔造成微小偏差。必须结合数学模型、误差尺度与重复实验判断。

<a id="N012"></a>
### 如何设置比较标准

**讲解：** 教学补充：常用判据为 |x−x_ref| ≤ atol + rtol × |x_ref|。atol 控制接近零的值，rtol 控制相对于参考值的差异。容差应有数值精度和物理量尺度依据，不能因为某次测试失败就随意放大。并检查质量守恒、边界条件、NaN/Inf 等更有意义的指标。

<a id="N013"></a>
### 原书的波高与总质量例子

**讲解：** 原书第 40 页比较了不同编译器及 1/4 个处理器的假想输出：波高只在末几位变化，总质量也出现不同程度的偏移。这些数字本身不足以判定哪组可接受；还需要误差预算和已经验证的物理解。与实验或真实数据比较属于模型有效性验证，与参考实现比较不能替代这一层。

<a id="N014"></a>
### 数值 diff 与普通文本 diff

**讲解：** 普通 diff 按字符比较；数值比较工具允许指定容差。原书介绍 ndiff、Numdiff，以及用于结构化数据的 h5diff。HDF5、NetCDF 应用各自的工具检查内部数组，不应把二进制文件按纯文本读。原书对 NetCDF 的概括需收窄：NetCDF-4 可基于 HDF5，经典 NetCDF 格式并不都基于 HDF5。

<a id="N015"></a>
### 测试能力的边界

**讲解：** 译文保留作者对测试重要性的强调，但有限数量的测试不能证明所有输入都正确。优先覆盖将要并行化的内核、边界情况和不同线程/进程数；再检查多种编译器与优化级别。


<a id="2.1.2-timers"></a>
## 2.1.2（续）清单 2.1：C 与 MPI 计时程序
原书 p.42–43。

<a id="S007"></a>
**Source:** 原书 p.42 / PDF p.78 · S007

**Original:** We’ll use a timer to produce small differences in output from both a serial and a parallel program.

**中文:** 我们将使用计时器，使串行程序和并行程序的输出产生细微差别。

<a id="N016"></a>
### 先弄清示例目的

**讲解：** 清单 2.1 用 sleep(10) 和计时器演示测试系统如何比较带有数值误差的输出。它不是一个加速实验，也不表示休眠可以通过 MPI 自动缩短。下面保留原书代码逻辑，去掉排版行号。TimeIt.c 中使用的成员是 tv_nsec，已按原页图像核对。

<a id="K002"></a>
**代码出处：** C · 原书清单 2.1，TimeIt.c，p.42

```text
#include <unistd.h>
#include <stdio.h>
#include <time.h>
int main(int argc, char *argv[]) {
    struct timespec tstart, tstop, tresult;
    clock_gettime(CLOCK_MONOTONIC, &tstart);
    sleep(10);
    clock_gettime(CLOCK_MONOTONIC, &tstop);
    tresult.tv_sec = tstop.tv_sec - tstart.tv_sec;
    tresult.tv_nsec = tstop.tv_nsec - tstart.tv_nsec;
    printf("Elapsed time is %f secs\n",
           (double)tresult.tv_sec +
           (double)tresult.tv_nsec * 1.0e-9);
}
```

<a id="N017"></a>
### 结构体、成员访问和取地址

**讲解：** struct timespec 定义时间结构，tv_sec 存秒、tv_nsec 存纳秒；点号用于访问结构体成员。&tstart 把变量地址传给 clock_gettime，让函数将读取的时间写入该变量。CLOCK_MONOTONIC 使用单调时钟，适合测量相邻时刻的间隔。

<a id="N018"></a>
### 类型转换与科学计数法

**讲解：** (double) 是显式类型转换；1.0e-9 表示 10 的负 9 次方，把纳秒换算为秒。这里将秒差与纳秒差转换后相加；若跨过整秒边界，纳秒差可以为负，但合成秒数仍可正确表达间隔。若要把结果作为规范化 timespec 继续传递，则应另做进位/借位处理。

<a id="N019"></a>
### 运行环境与省略的健壮性检查

**讲解：** unistd.h、sleep 和 clock_gettime 是此示例的 POSIX 环境用法，不能直接假定原生 Windows 编译器都支持。原书为简洁省略了返回值、信号中断等检查；真实程序需要处理计时调用失败和 sleep 提前返回。

<a id="K003"></a>
**代码出处：** C / MPI · 原书清单 2.1，MPITimeIt.c，pp.42–43

```text
#include <unistd.h>
#include <stdio.h>
#include <mpi.h>
int main(int argc, char *argv[]) {
    int mype;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &mype);
    double t1, t2;
    t1 = MPI_Wtime();
    sleep(10);
    t2 = MPI_Wtime();
    if (mype == 0)
        printf("Elapsed time is %f secs\n", t2 - t1);
    MPI_Finalize();
}
```

<a id="N020"></a>
### argc、argv 与 MPI 初始化

**讲解：** argc 是参数个数，argv 是指向参数字符串的指针数组。MPI_Init(&argc, &argv) 接收它们的地址。MPI_COMM_WORLD 是预定义通信器；MPI_Comm_rank 把当前进程在该通信器中的编号写到 mype。编号从 0 开始，不等于 CPU 核心编号。

<a id="N021"></a>
### if、计时与结束调用

**讲解：** == 比较两边是否相等，= 才是赋值。if (mype == 0) 仅让 rank 0 输出，以免多个进程的文本混杂。MPI_Wtime 返回本地墙钟的秒值；用同一进程前后两次读数做差，不能假定各进程时钟完全同步。MPI_Finalize 结束 MPI 环境。[R8]

<a id="N022"></a>
### 这个输出没有测量什么

**讲解：** 它只打印 rank 0 的休眠间隔，没有计算所有进程中最大的运行时间，也没有测量通信成本或并行效率。即使运行两个 MPI 进程，耗时仍大致为 10 秒，因为两个进程各自休眠。


<a id="2.1.2-ctest"></a>
## 2.1.2（续）Shell、CMake 与 CTest 的语法
原书 p.41–44。

<a id="S008"></a>
**Source:** 原书 p.41 / PDF p.77 · S008

**Original:** CTest is a component of the CMake system. CMake is a configuration system that adapts generated makefiles to different systems and compilers.

**中文:** CTest 是 CMake 系统的组成部分。CMake 是一种配置系统，可针对不同系统和编译器生成相应的构建文件。

<a id="N023"></a>
### 三种工具各做什么

**讲解：** CMake 配置并生成构建系统；编译器和所选构建工具生成可执行程序；CTest 按注册的信息执行测试。原文提到 makefile，但 CMake 还支持其他生成器，不应把 CMake 和 make 当作同一个程序。

<a id="K004"></a>
**代码出处：** Shell · 原书 mympiapp.ctest，p.43

```text
#!/bin/sh
./TimeIt > run0.out
mpirun -n 1 ./MPITimeIt > run1.out
mpirun -n 2 ./MPITimeIt > run2.out
ndiff --relative-error 1.0e-4 run1.out run2.out
test1=$?
ndiff --relative-error 1.0e-4 run0.out run2.out
test2=$?
exit "$(($test1+$test2))"
```

<a id="N024"></a>
### 路径、参数与重定向

**讲解：** #!/bin/sh 指定脚本解释器；./ 表示当前目录；> 将标准输出写到文件并覆盖原内容。mpirun -n 2 请求启动两个进程，不能把 -n 2 看作强制占用两个物理核心。ndiff 的两个文件参数是被比较的输出。

<a id="N025"></a>
### \$?、变量与退出状态

**讲解：** test1=\$? 保存上一条命令的退出码，等号两边不能有空格。\$test1 读取变量，\$((...)) 做整数算术，exit 返回脚本状态。CTest 通常把退出码 0 判为通过，非零判为失败。原书把两次比较的退出码相加；教学中更清楚的写法是遇到任一步失败就明确 exit 1。

<a id="N026"></a>
### 原书校正：容差百分数

**讲解：** 代码中的 1.0e-4 等于 0.0001，即 0.01%。原书第 43 页说明文字写“0.1%”，与代码不一致。本讲义保留代码值，并明确指出文字的百分数错误。

<a id="K005"></a>
**代码出处：** CMake · 教学修正版，对应原书 pp.43–44

```text
cmake_minimum_required(VERSION 3.16)
project(TimeIt LANGUAGES C)
enable_testing()
find_package(MPI REQUIRED COMPONENTS C)
add_executable(TimeIt TimeIt.c)
add_executable(MPITimeIt MPITimeIt.c)
target_link_libraries(MPITimeIt PRIVATE MPI::MPI_C)
add_test(NAME timing_compare
    COMMAND sh ${CMAKE_CURRENT_SOURCE_DIR}/mympiapp.ctest)
set_tests_properties(timing_compare PROPERTIES
    WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})
```

<a id="N027"></a>
### CMake 括号、变量与目标

**讲解：** CMake 使用命令名(参数...)，一般不用分号结束语句。\${变量名} 取变量值；源码目录与构建目录不同。add_executable 的第一个参数是目标名，后面是源文件。find_package 的 REQUIRED 表示找不到 MPI 时报告配置失败；COMPONENTS C 选择 C 接口。

<a id="N028"></a>
### 为什么使用 MPI::MPI_C

**讲解：** 这是 FindMPI 提供的导入目标，携带 MPI 的包含目录和链接要求；PRIVATE 把这些要求用于当前目标。本例用它替代书中的 MPI_INCLUDE_PATH 与 MPI_LIBRARIES。原书排版中的 PUBLIC. 多出句点；不能把这个拼写当作合法的作用域关键字。[R6]

<a id="N029"></a>
### add_test 与工作目录

**讲解：** enable_testing 启用测试注册，add_test 给测试命名并指定命令；WORKING_DIRECTORY 指定执行时的目录，使 ./TimeIt 能找到构建产物。这里通过 sh 启动脚本，前提是 POSIX shell、MPI 和 ndiff 已可用。CTest 的命令注册和工作目录规则见官方文档。[R5]

<a id="K006"></a>
**代码出处：** 命令行 · 教学补充，POSIX 环境

```text
cmake -S . -B build
cmake --build build
cd build
ctest --output-on-failure
ctest -R timing
```

<a id="N030"></a>
### 怎样读这些命令

**讲解：** -S 指源目录，-B 指构建目录；--build 驱动已生成的构建系统；ctest -R timing 按正则表达式筛选测试名；--output-on-failure 显示失败测试的输出。原书的 file(GLOB ...) 配合 foreach/endforeach 自动注册 .ctest 文件；本例显式注册一个测试，便于理解依赖。

<a id="N031"></a>
### 不把计时波动当作数值正确性

**讲解：** 原书承认这个休眠计时测试可能通过，也可能失败。系统负载和调度都会影响耗时。它适合演示测试串联，不适合作为稳定的物理解正确性测试。实际工程应将确定性结果检查与带统计分析的性能测试分开。原脚本还应补上程序运行失败时的提前退出，避免继续比较不完整输出。


<a id="2.1.2-types"></a>
## 2.1.2（续）测试类型、覆盖率与提交测试
原书 p.44–48。

<a id="S009"></a>
**Source:** 原书 p.45 / PDF p.81 · S009

**Original:** While high code coverage is important, for our parallelism efforts, it is more critical that there are tests for the parts of the code you are parallelizing.

**中文:** 虽然较高的代码覆盖率很重要，但对于并行化工作，更关键的是确保准备并行化的那些代码部分有对应测试。

<a id="F003"></a>
### 图 2.3
**Source:** 原书 p.46 / PDF p.82 · C003
**Placed near:** 2.1.2（续）测试类型、覆盖率与提交测试

![图 2.3](assets/fig2_03.png)

**Original caption:** The different test types address different parts of code development to create a high quality code that is always ready to release.

**中文图注:** 不同测试类型针对代码开发的不同环节，共同帮助形成随时可以发布的高质量代码。

**Reading note:** 左上是开发阶段的单元测试，左下是修改阶段的提交测试；提交触发持续集成，修复的问题补充为回归测试。箭头说明反馈关系，而不只是“测试一次就完成”。

<a id="N032"></a>
### 四类测试怎么区分

**讲解：** 单元测试检查小函数或模块。回归测试检查已有行为是否退化。提交测试是一组能快速运行的关键检查，适合提交前执行。持续集成描述自动构建和执行检查的流程，可能同时运行单元与回归测试。这四者不是互斥分类。

<a id="N033"></a>
### 覆盖率不能证明正确性

**讲解：** 覆盖率报告哪些语句被运行过，不代表这些语句在所有情况下都正确。GCC 的 gcov 可收集覆盖信息；应按实际编译器与构建结构定位生成的覆盖文件，不把原书的特定路径拼法当作通用规则。对于并行代码，边界数据、不同分区、空分区和不均匀负载也值得测试。

<a id="N034"></a>
### 金标准文件如何使用

**讲解：** 保存经过确认的参考输出，可以发现新版本与历史版本之间的变化。参考结果不应随着失败自动覆盖；应先解释变化原因，并通过独立检查确认新结果是否正确。参考文件、输入、容差和生成环境应一起记录。

<a id="K007"></a>
**代码出处：** CMake · 教学补充，演示名称筛选与构建依赖

```text
add_test(NAME blur_short_commit COMMAND TimeIt)
add_custom_target(commit_tests
    COMMAND ${CMAKE_CTEST_COMMAND} -R commit --output-on-failure
    DEPENDS TimeIt)
```

<a id="N035"></a>
### 自定义目标语法

**讲解：** add_custom_target 创建一个构建目标；COMMAND 后面是执行命令；DEPENDS TimeIt 使执行该目标前先构建 TimeIt。原书用 <myapp> 作占位符，不能原样当作真实目标。这里的 TimeIt 仍会休眠 10 秒，只演示流程；实际提交测试应选真正快速的检查。

<a id="N036"></a>
### 更大规模的测试系统

**讲解：** 原书介绍 CTS 通过有限数量的工作槽逐步向批处理系统提交测试，避免一次淹没队列。小型本地测试通过，不代表千进程下也可靠；扩展测试需要调度资源，但应尽量在小规模阶段先发现明显问题。

<a id="N037"></a>
### 历史工具说明

**讲解：** 本节书中提到的 CI 服务、编译器工具名和运行频率属于其出版时期的示例。重要的是触发方式、覆盖范围和失败反馈，而不是照搬“所有回归测试都必须夜间运行”的安排。


<a id="2.1.3"></a>
## 2.1.3 查找并修复内存问题
原书 p.48–50。

<a id="S010"></a>
**Source:** 原书 p.48 / PDF p.84 · S010

**Original:** Good code quality is paramount. Parallelizing often causes any code flaw to appear; this might be uninitialized memory or memory overwrites.

**中文:** 良好的代码质量至关重要。并行化往往会使已有缺陷暴露出来，例如读取未初始化内存或错误覆盖内存。

<a id="N038"></a>
### 清单 2.2：下面故意包含错误

**讲解：** 原书用这段程序演示 Valgrind 的诊断。它不是建议使用的实现。需要辨认未初始化变量、数组越界、分配失败未检查，以及忘记释放内存。

<a id="K008"></a>
**代码出处：** C · 原书清单 2.2，故意含错，p.49

```text
#include <stdlib.h>
int main(int argc, char *argv[]) {
    int ipos, ival;
    int *iarray = (int *) malloc(10*sizeof(int));
    if (argc == 2) ival = atoi(argv[1]);
    for (int i = 0; i <= 10; i++) { iarray[i] = ipos; }
    for (int i = 0; i <= 10; i++) {
        if (ival == iarray[i]) ipos = i;
    }
}
```

<a id="N039"></a>
### 指针、malloc 与 sizeof

**讲解：** int *iarray 声明指向 int 的指针；malloc(10*sizeof(int)) 分配容纳 10 个 int 的字节数。下标从 0 到 9，因此 i <= 10 会访问第 11 个元素。sizeof 计算对象或类型的字节数，不需要假设所有机器的 int 都恰好 4 字节。C 中 malloc 返回值不需要显式强制转换，但必须包含 stdlib.h 并检查空指针。

<a id="N040"></a>
### 未初始化问题在哪里

**讲解：** ipos 在第一次写入数组前未被赋值，数组因此得到未定义值。只有 argc == 2 时 ival 才赋值，其他参数数量下它也未初始化。报错可能出现在后面的条件判断，而根源却在更早的数据写入；诊断行号不一定就是最初犯错的位置。

<a id="K009"></a>
**代码出处：** Shell · 原书命令基础上的教学补充，需受支持的 POSIX 环境

```text
gcc -g -O0 -o test test.c
valgrind --leak-check=full --track-origins=yes ./test 2
mpirun -n 2 valgrind --leak-check=full ./myapp
```

<a id="N041"></a>
### 命令参数怎么读

**讲解：** -g 保留调试信息，-O0 关闭优化以方便理解诊断；-o 指定可执行文件名。--leak-check=full 请求详细泄漏信息；--track-origins=yes 可帮助追踪未初始化值的来源。MPI 情况把 valgrind 放在 mpirun 之后，使各进程运行检查器包裹的应用。[R7]

<a id="N042"></a>
### 如何解读原书报告

**讲解：** Invalid write/read 表示非法写入/读取；Conditional jump ... uninitialized value 表示控制决策用到了未定义值；definitely lost 表示已经失去可用于释放该分配块的指针。原书例子报告 40 字节，是该运行环境中 10 个 int 的占用，不能反过来当作所有平台的固定值。

<a id="N043"></a>
### Memcheck 的边界

**讲解：** 它会明显拖慢程序，应先选择短小但能覆盖问题的输入。未发现内存错误不等于没有线程竞争；数据竞争要用相应工具和测试另行检查。支持的平台和指令随工具版本变化，不能机械套用书中关于某编译器的历史建议。


<a id="2.1.4"></a>
## 2.1.4 提高代码可移植性
原书 p.50–51。

<a id="S011"></a>
**Source:** 原书 p.50 / PDF p.86 · S011

**Original:** Compiling with a variety of compilers helps to detect coding errors or identify where code is pushing the “edge” on language interpretations.

**中文:** 使用多种编译器编译，有助于发现编码错误，也能识别代码是否依赖了语言解释中的边缘行为。

<a id="N044"></a>
### 可移植性不是只换一台电脑

**讲解：** 语言标准支持、编译选项、库版本、操作系统接口和硬件指令都影响可移植性。程序在一个编译器上通过，可能只是某种扩展被默认接受；另一种编译器能帮助暴露这种依赖。构建成功后仍需运行测试。

<a id="N045"></a>
### OpenMP 的三种能力

**讲解：** 原书明确区分：SIMD 指令表达向量化；parallel/for 等结构用于 CPU 线程；target 用于设备卸载。支持 CPU OpenMP，并不自动意味着具备完整的 GPU 卸载支持；应核查实际编译器、版本、目标硬件和所用特性。

<a id="N046"></a>
### 按出版语境阅读工具名称

**讲解：** 本节原书讨论 PGI、Intel 编译器、CUDA Fortran 和 Fortran 标准实现情况。这些支持表会随时间变化，网页不把它们重述为当前结论。规划时记录具体版本与需要的语言特性，再用小示例进行验证。


<a id="2.2"></a>
## 2.2 性能分析：找出硬件能力与应用表现的差距
原书 p.51。

<a id="S012"></a>
**Source:** 原书 p.51 / PDF p.87 · S012

**Original:** Once the potential performance is understood, then you can profile your application.

**中文:** 理解潜在性能之后，就可以对应用进行性能分析。

<a id="F004"></a>
### 图 2.4
**Source:** 原书 p.51 / PDF p.87 · C004
**Placed near:** 2.2 性能分析：找出硬件能力与应用表现的差距

![图 2.4](assets/fig2_04.png)

**Original caption:** The purpose of the profiling step is to identify the most important parts of the application code that need to be addressed.

**中文图注:** 性能分析步骤的目的，是识别应用代码中最需要处理的关键部分。

**Reading note:** 先研究性能限制，再用基准测试测量硬件，最后分析应用。三个动作分别回答“受什么约束”“平台能做到多少”“程序时间花在哪里”。

<a id="N047"></a>
### 不要只看 CPU 利用率

**讲解：** 一个程序可让许多核心保持忙碌，却主要在等待内存。需要区分计算吞吐、内存带宽、延迟、同步和通信等限制。原书强调许多科学应用受数据移动限制，但不能未经测量就断言所有应用都属于带宽瓶颈。

<a id="N048"></a>
### 把性能目标写成可验证问题

**讲解：** 例如：目标网格规模下，总时间是多少；模板更新占多少；内存带宽利用率是多少；通信与等待占多少。先测当前版本，再与匹配工作负载的可达性能比较。不同输入规模的热点也可能不同。


<a id="2.3"></a>
## 2.3 规划：为成功打好基础
原书 p.51–52。

<a id="S013"></a>
**Source:** 原书 p.51 / PDF p.87 · S013

**Original:** With the effort that’s required in parallelism, it is sensible to research prior work before starting the implementation step.

**中文:** 考虑到并行化所需的投入，在开始实现之前研究已有工作是明智的。

<a id="F005"></a>
### 图 2.5
**Source:** 原书 p.52 / PDF p.88 · C005
**Placed near:** 2.3 规划：为成功打好基础

![图 2.5](assets/fig2_05.png)

**Original caption:** The planning steps lay the foundation for a successful project.

**中文图注:** 规划步骤为项目成功奠定基础。

**Reading note:** 图中列出研究 mini-app、设计和算法。图内 Design (Chapter 3) 与 Algorithms (Chapter 4) 的编号对应有偏差；以全书目录为准，数据设计主要在第 4 章，并行算法主要在第 5 章。原图保留，说明中指出差异。

<a id="N049"></a>
### 计划需要哪些证据

**讲解：** 把用户目标、代表性输入、现有热点、硬件约束、候选算法和验收方式放在一起。总体项目计划规定范围；每次迭代计划规定这一轮具体改什么、如何测试、如何判断收益。

<a id="N050"></a>
### 研究到可以做决定为止

**讲解：** 找到相似工作后，不只看它宣称的加速比，还要核对数据布局、问题规模、精度和硬件。可执行的 mini-app 有助于检验一种设计在你的目标上是否成立。


<a id="2.3.1"></a>
## 2.3.1 利用基准测试与 mini-app 探索
原书 p.52–53。

<a id="S014"></a>
**Source:** 原书 p.52 / PDF p.88 · S014

**Original:** Benchmarks are intended to highlight a specific characteristic of hardware performance.

**中文:** 基准测试旨在突出硬件性能的某个特定特征。

<a id="N051"></a>
### Benchmark 与 mini-app 的区别

**讲解：** 基准测试通常测某种特定能力，例如连续数组访问的带宽。mini-app 提取一类应用的关键数据与计算模式，方便比较算法和实现方式。前者更像量硬件的一把尺，后者更像缩小后的应用实验。

<a id="N052"></a>
### 原书的三个例子

**讲解：** 连续访问大数组时，作者举 STREAM 为例；迭代矩阵求解可参考 HPCG；跨子域边界交换可参考 MiniGhost。选择它们是因为与待研究的操作相似，不是因为某个分数高就能代表所有应用。

<a id="N053"></a>
### Ghost cell update：为何需要幽灵单元

**讲解：** 每个进程只保存一块网格，但边缘模板还需要邻块的值。因此为邻居数据保留额外单元，通信后更新这些副本。它们不是新增物理区域，而是支持本地计算的数据缓存；交换频率与数据量直接影响扩展性。


<a id="2.3.2"></a>
## 2.3.2 核心数据结构设计与模块化
原书 p.53。

<a id="S015"></a>
**Source:** 原书 p.53 / PDF p.89 · S015

**Original:** The design of data structures has a long ranging impact on your application. This is one of the decisions that needs to be made up front, realizing that changing the design later becomes difficult.

**中文:** 数据结构设计会对应用产生长期影响。这是应该尽早考虑的决策之一，因为后期再修改会变得困难。

<a id="N054"></a>
### 先画数据流，再决定循环

**讲解：** 标出每一步读取哪些数组、写入哪些数组、数据由哪个进程或设备持有，再考虑缓存、通信和文件输出。相同算式可能因为布局不同而表现差异很大。第 4 章将进一步讨论 AoS、SoA 和稀疏存储。

<a id="N055"></a>
### 原书的火山灰模型场景

**讲解：** 材料只分布在网格的一小部分时，为所有单元存满全部材料数据可能浪费内存。稀疏表示可能节约空间，但也会引入索引与间接访问开销。需要结合实际分布和计算模式比较，不能只凭“更省内存”就保证更快。


<a id="2.3.3"></a>
## 2.3.3 算法：面向并行重新设计
原书 p.53–54。

<a id="S016"></a>
**Source:** 原书 p.53 / PDF p.89 · S016

**Original:** As the problem size grows, the 5% soon becomes 20% and then even higher. Soon it is dominating the run time.

**中文:** 随着问题规模增长，原来占 5% 的部分很快会达到 20%，甚至更高，最终主导运行时间。

<a id="N056"></a>
### 原文上下文：小热点可能成为大瓶颈

**讲解：** 作者设定一段算法随数据规模 N 呈二次增长，而其余部分呈线性增长。小算例中它只占 5%，大算例中比例会越来越高。因此除了观察当前占比，还要测量耗时随规模增长的速度。这里 N 是数据规模，不是处理器数。

<a id="N057"></a>
### 手算这个增长过程

**讲解：** 教学补充：在原规模下，二次部分耗时 5，线性部分耗时 95。数据量扩大 4 倍后，分别变成 5×16=80 和 95×4=380，占比约 17.4%；扩大 5 倍后变成 125 与 475，占比约 20.8%。这就解释了书中的趋势。

<a id="N058"></a>
### 修改实现还是换算法

**讲解：** 循环展开或多线程是在既定算法上提速；换用更易并行、增长更慢的算法可能改变长期扩展能力。选择时同时比较数值性质、工作量、通信量和实现成本，而不是只看一次小规模跑分。


<a id="2.4"></a>
## 2.4 实现：把规划落实到代码
原书 p.54–55。

<a id="S017"></a>
**Source:** 原书 p.54 / PDF p.90 · S017

**Original:** The key in this implementation step is to break down the work into manageable chunks and divide out the work among your team members.

**中文:** 实现阶段的关键，是把工作拆成可以管理的小块，并在团队成员之间合理分工。

<a id="F006"></a>
### 图 2.6
**Source:** 原书 p.54 / PDF p.90 · C006
**Placed near:** 2.4 实现：把规划落实到代码

![图 2.6](assets/fig2_06.png)

**Original caption:** The implementation step utilizes parallel languages and skills developed in the rest of the book.

**中文图注:** 实现阶段将使用本书后续章节介绍的并行语言与技能。

**Reading note:** CPU 对应第 6–8 章，GPU 对应第 9–13 章。语言选择服务于性能和规模目标，不是项目开始时一旦决定就永远不能调整。

<a id="N059"></a>
### 三条方向如何选择

**讲解：** 如果目标主要是适度加速，可先研究向量化和共享内存线程；如果首要问题是单节点内存不足，应研究跨节点的分布式内存；若计算模式适合设备并行且需要较大加速，可评估 GPU。这些是规划方向，不是收益保证。

<a id="N060"></a>
### 局部十倍不等于整体十倍

**讲解：** 教学补充：若某函数占总时间 10%，把它加速 10 倍，整体时间只从 1 降为 0.9+0.1/10=0.91，总加速约 1.10 倍。应反复回到整个应用的计时结果，避免只展示漂亮的局部数字。

<a id="N061"></a>
### 允许根据新需求调整方案

**讲解：** 原书中，波浪模拟先通过 OpenMP 和向量化提速，用户随后要求更大规模，单机内存不足，于是团队再考虑 MPI。这是目标变化后的合理调整；新的版本仍要重复准备、分析、测试和提交流程。


<a id="2.5"></a>
## 2.5 提交：以质量检查结束一次迭代
原书 p.55。

<a id="S018"></a>
**Source:** 原书 p.55 / PDF p.91 · S018

**Original:** The commit step finalizes this part of the work with careful checks to verify that code quality and portability are maintained.

**中文:** 提交步骤通过认真检查来完成这一部分工作，确认代码质量和可移植性得到保持。

<a id="F007"></a>
### 图 2.7
**Source:** 原书 p.55 / PDF p.91 · C007
**Placed near:** 2.5 提交：以质量检查结束一次迭代

![图 2.7](assets/fig2_07.png)

**Original caption:** The goal of the commit step is to create a solid rung on the ladder to reaching your end goal.

**中文图注:** 提交步骤的目标，是在通往最终目标的阶梯上建立一个稳固的台阶。

**Reading note:** 检查测试、可移植性与代码质量，然后保存一个可恢复的提交。每个台阶都要站得稳，后续才能在其上继续优化。

<a id="N062"></a>
### 什么叫一次迭代结束

**讲解：** 不仅是“程序能编译”：关键输入结果通过，目标配置可构建，内存或线程问题得到必要检查，性能收益有记录，提交说明解释改动及验证范围。复杂生产应用通常需要更充分的检查。

<a id="N063"></a>
### 把偶发失败纳入流程

**讲解：** 原书波浪模拟在加入 OpenMP 后偶尔崩溃，团队于是把竞争检查纳入提交流程。不要因为重跑一次成功就忽略偶发失败；应保留触发条件并设计回归案例。


<a id="2.6"></a>
## 2.6 进一步探索与本章小结
原书 p.55–57。

<a id="S019"></a>
**Source:** 原书 p.57 / PDF p.93 · S019

**Original:** There is an overall project plan and another separate plan for each iteration of development.

**中文:** 项目需要一份总体计划，也需要为每一次开发迭代分别制定计划。

<a id="N064"></a>
### 本章形成的闭环

**讲解：** 准备阶段建立可信基线；性能分析提供瓶颈证据；规划选择数据结构、算法与并行方式；实现以小步完成；提交保存经检查的版本。然后重新分析，因为最慢的部分可能已经改变。

<a id="N065"></a>
### 质量要求为何随规模增加

**讲解：** 一次运行很少遇到的缺陷，在更多进程、更多循环和更长时间下可能暴露。原书用“千个处理器更容易遇到缺陷”强调规模效应；实际概率取决于事件是否独立，不能无条件按处理器数量精确相乘。

<a id="N066"></a>
### 掌握程度自查

**讲解：** 能解释为何不能只做文本 diff；能读懂 C 的地址传参与数组边界；能区分 CMake 配置、构建与 CTest 执行；能设计一个小而可靠的提交前测试；能说明下次优化的目标由哪个测量结果支持。


<a id="2.6.1"></a>
## 2.6.1 延伸阅读
原书 p.56。

<a id="N067"></a>
### 保留原书阅读线索

**讲解：** Mike McQuaid，Git in Practice（Manning，2014）；Rick Umali，Learn Git in a Month of Lunches（Manning，2015）。两者用于进一步学习 Git 工作流程。

<a id="N068"></a>
### 测试与浮点数

**讲解：** Vladimir Khorikov，Unit Testing Principles, Practices, and Patterns（Manning，2020）。David Goldberg，What every computer scientist should know about floating-point arithmetic，ACM Computing Surveys 23(1)，1991，5–48。这里保留书中的文献线索，未把这些文献全文纳入本章翻译。

<a id="N069"></a>
### 工具语法的核对依据

**讲解：** 本讲义对 CMake 测试注册、MPI 导入目标、MPI_Wtime 和 Valgrind 诊断的补充说明，分别参照资料页中的 R5–R8。原书代码仍按来源标注，现代写法明确标为教学修正版。


<a id="2.6.2"></a>
## 2.6.2 练习与参考思路
原书 p.56。

<a id="N070"></a>
### 练习 1｜把个人科研程序变成团队工具

**讲解：** 题意：将研究生期间的串行波高模拟程序发展为供其他研究者使用的工具，团队另有三位开发者，项目计划应包含什么？参考：先整理唯一可信版本与许可/依赖信息，建立版本管理、参考输入与验证数据，再明确模块边界、构建方式、提交检查及性能目标。分工可以围绕测试与验证、核心算法与数据、构建与性能分析展开，但每次接口改动要共同确认。

<a id="N071"></a>
### 练习 2｜创建一个 CTest 测试

**讲解：** 为一个结果可预期的小函数或程序创建测试；先验证正确版本返回 0，再故意改变一个期望值，确认测试会失败。只看一次绿色通过，无法确定测试是否真的能抓住错误。2.1.2 的计时示例展示注册流程，但正式正确性检查应选稳定结果。

<a id="N072"></a>
### 练习 3｜修复清单 2.2

**讲解：** 原程序存在未定义行为，无法据此恢复唯一“正确业务意图”。以下参考答案明确选择“在数组 0–9 中查找数值 2”的意图，初始化变量，限制下标，检查 malloc，并在结束时释放内存。它是教学修正版，不宣称与原来未定义的行为等价。

<a id="K010"></a>
**代码出处：** C · 练习 3 教学修正版，预期 position = 2

```text
#include <stdio.h>
#include <stdlib.h>
int main(void) {
    const int n = 10;
    const int ival = 2;
    int ipos = -1;
    int *iarray = malloc((size_t)n * sizeof *iarray);
    if (iarray == NULL) return EXIT_FAILURE;
    for (int i = 0; i < n; ++i) iarray[i] = i;
    for (int i = 0; i < n; ++i) {
        if (iarray[i] == ival) { ipos = i; break; }
    }
    printf("position = %d\n", ipos);
    free(iarray);
    return EXIT_SUCCESS;
}
```

<a id="N073"></a>
### 修正版的语法重点

**讲解：** sizeof *iarray 根据指针所指对象的类型计算大小；NULL 用于判断分配是否失败；break 结束最近的循环；free 释放分配的数组；EXIT_SUCCESS 与 EXIT_FAILURE 是标准退出状态宏。未找到目标时保留 ipos = -1，给出明确约定。

<a id="N074"></a>
### 练习 4｜运行 Valgrind

**讲解：** 选一个短小程序，保留调试信息后检查。建议先运行故意含错的清单 2.2，观察越界、未初始化与泄漏报告，再检查修正版。实际诊断依赖平台与工具；本次未在 C/MPI/Valgrind 环境运行这些示例，因此所有输出均标为预期，而非实测。

## 技术核对来源

- [R5 · CMake：add_test](https://cmake.org/cmake/help/latest/command/add_test.html)
- [R6 · CMake：FindMPI](https://cmake.org/cmake/help/latest/module/FindMPI.html)
- [R7 · Valgrind：Memcheck](https://valgrind.org/docs/manual/mc-manual.html)
- [R8 · Open MPI：MPI_Wtime](https://www.open-mpi.org/doc/current/man3/MPI_Wtime.3.php)