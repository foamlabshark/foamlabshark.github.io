# 第 5 章｜并行算法与模式

原著：Robert Robey、Yuliana Zamora，Manning，2021。原书 p.124–169 / PDF p.160–205。

核心段落中英对照、全部编号小节解释、21 幅原图、表 5.1、公式和代码语法。5.A 是 p.153 未编号图的讲义定位标签。不是逐段全文译本。

## 小节索引

- [第 5 章导读｜并行算法与模式](#5-intro)
- [5.1 算法分析：工作量、步数和渐近界](#5.1)
- [5.2 性能模型与算法复杂度](#5.2)
- [5.2（续）线性查找、二分查找与插值语法](#5.2-code)
- [5.3 什么使算法适合并行？](#5.3)
- [5.4 哈希函数、桶与冲突](#5.4)
- [5.5 空间哈希：利用局部性减少候选](#5.5)
- [5.5.1 完美空间哈希：邻居查找](#5.5.1)
- [5.5.1（续）从 C 循环到 OpenCL 工作项](#5.5.1-kernel)
- [5.5.1（续）在两张 AMR 网格间重映射](#5.5.1-remap)
- [5.5.1（续）均匀表格的直接区间定位](#5.5.1-table)
- [5.5.1（续）工作组协作加载与 barrier](#5.5.1-local)
- [5.5.1（续）空间哈希排序](#5.5.1-sort)
- [5.5.2 紧凑哈希与写入优化](#5.5.2)
- [5.5.2（续）非结构网格的面邻居](#5.5.2-faces)
- [5.5.2（续）单次写入的重映射](#5.5.2-remap)
- [5.5.2（续）分层哈希与递归限制](#5.5.2-hierarchy)
- [5.6 前缀和：给不规则数据分配位置](#5.6)
- [5.6.1 步数较少的并行扫描](#5.6.1)
- [5.6.2 工作量高效的并行扫描](#5.6.2)
- [5.6.3 大数组的分块扫描](#5.6.3)
- [5.7 全局求和：精度与结合律](#5.7)
- [5.7（续）长精度、成对与四倍精度求和](#5.7-methods)
- [5.7（续）Kahan 补偿求和的代码与修正](#5.7-compensated)
- [5.7（续）怎样读精度与运行时间表](#5.7-results)
- [5.8 从本章提炼并行算法特征](#5.8)
- [5.9 进一步探索与本章小结](#5.9)
- [5.9.1 延伸阅读](#5.9.1)
- [5.9.2 练习与参考思路](#5.9.2)

## 公式索引

- [E001](#E001) · 原书 p.126 · T_P ≥ max(W/P, S)
- [E002](#E002) · 原书 p.129 · f = (1−x)(1−y)f00 + x(1−y)f10 + (1−x)y f01 + xy f11
- [E003](#E003) · 原书 p.132 · λ = n / k
- [E004](#E004) · 原书 p.147 · b_k = floor((X_i − X_min) / Δ_min)
- [E005](#E005) · 原书 p.157 · y_j = sum(x_i, i = 0 … j−1)

## 术语约定

|原文|译法|说明|
|---|---|---|
|parallel algorithm|并行算法|以并发过程完成问题|
|parallel pattern|并行模式|可复用的并发计算片段|
|work / span|工作量 / 依赖深度|总操作量与最长依赖链|
|hash bucket|哈希桶|映射后的候选存储位置|
|load factor|负载因子|条目数除以桶数|
|perfect hash|完美哈希|对指定键集合不发生冲突|
|open addressing|开放寻址|在表内探测其他存储槽|
|spatial hashing|空间哈希|依据空间信息构造键|
|prefix scan|前缀扫描|生成各位置的累计结果|
|exclusive / inclusive scan|不包含 / 包含当前项的扫描|明确是否计入当前位置|
|compensated summation|补偿求和|追踪舍入偏差以改善精度|
|reproducibility|可复现性|与精度和正确性分别评估|

<a id="5-intro"></a>
## 第 5 章导读｜并行算法与模式
原书 p.124–125。

<a id="S001"></a>
**Source:** 原书 p.124 / PDF p.160 · S001

**Original:** A parallel algorithm is a well-defined, step-by-step computational procedure that emphasizes concurrency to solve a problem.

**中文:** 并行算法是一个定义明确、逐步执行，并强调利用并发性解决问题的计算过程。

<a id="S002"></a>
**Source:** 原书 p.124 / PDF p.160 · S002

**Original:** A parallel pattern is a concurrent, separable fragment of code that occurs in diverse scenarios with some frequency.

**中文:** 并行模式是在多种场景中反复出现、可以分离出来并发执行的代码片段。

<a id="N001"></a>
### 算法与模式的区别

**讲解：** 同一个 scan，作为任务本身可以叫算法，嵌入排序或数据压缩时又是一种模式。判断重点在它承担完整目标还是较大流程中的一个环节。

<a id="N002"></a>
### 本章学习路线

**讲解：** 先比较复杂度和实际成本，再学习空间哈希的邻居查找、重映射、插值与排序，随后理解前缀和怎样分配并行输出位置，最后讨论浮点归约的精度与可复现性。保留全部编号小节；长小节按应用拆开。


<a id="5.1"></a>
## 5.1 算法分析：工作量、步数和渐近界
原书 p.125–126。

<a id="S003"></a>
**Source:** 原书 p.125 / PDF p.161 · S003

**Original:** Algorithmic complexity is a measure of the number of operations that it would take to complete an algorithm.

**中文:** 算法复杂度是对完成算法所需操作数量的一种度量。

<a id="N003"></a>
### 先更正三个记号的含义

**讲解：** O 表示渐近上界，Ω 表示渐近下界，Θ 表示同阶的紧确界。它们不分别等于最坏、最好和平均情况。必须先说明分析的是哪个成本函数，例如最坏情况耗时或期望耗时，再为这个函数写上下界。原书 p.125 的三项对应关系不正确。[R16]

<a id="N004"></a>
### 循环层数不能单独决定复杂度

**讲解：** 双重循环若两层都独立遍历 N 项，总工作量通常为 Θ(N²)；如果内层只遍历固定数邻居，则仍可能是 Θ(N)。二叉搜索单次查询和对 N 个元素各做一次查询也不能混写成同一个复杂度。

<a id="E001"></a>
**Source:** 原书 p.126 / PDF p.162 · E001

$$
T_P\geq\max(W/P,S)
$$

教学补充：W 为总工作量，S 为最长依赖链长度（span），P 为执行资源数量。在理想的单位成本模型下，这是并行时间下界；不含真实通信和存储开销。

<a id="N005"></a>
### 原书术语与通用术语的关系

**讲解：** 作者将 algorithmic complexity 用于总操作数，把 computational/step complexity 用于并行步数，把 time complexity 用于实际硬件成本。这是本书的工作约定，并非普遍统一的术语定义。后文讲解同时说明工作量、依赖深度和实测时间，避免只看“复杂度”三个字。


<a id="5.2"></a>
## 5.2 性能模型与算法复杂度
原书 p.126–128。

<a id="S004"></a>
**Source:** 原书 p.126 / PDF p.162 · S004

**Original:** The biggest difference is that we don’t hide the constant multiplier in front of the algorithm.

**中文:** 最大的区别是：性能模型不会把算法前面的常数因子隐藏起来。

<a id="N006"></a>
### 会议资料包的例子

**讲解：** 逐人从未排序的 N 份资料中查找，全部处理可能需要二次量级工作；先排序再查找，可以利用有序性。真实方案还要计入排序、建立索引、领取次数、队列分工和是否重复使用资料，不只比较一次查找的式子。

<a id="N007"></a>
### 256 项数组：比较次数与缓存行

**讲解：** 若整数为 4 byte、缓存行为 64 byte，256 项占 16 行。线性扫描可以连续访问并预取，二分查找访问路径更跳跃。原书用理想缓存行计数说明常数会改变有限规模的比较；其中“二分恰需 4 次缓存加载”是简化估计，并非每次查询的严格上界。

<a id="N008"></a>
### 平均路径与最慢路径

**讲解：** 一批并行查询可能由慢线程决定阶段结束时间，单次平均成本不一定代表整批成本。但 CPU 线程不必像一个 GPU 执行组一样每条指令锁步；应按具体执行与同步模型分析。


<a id="5.2-code"></a>
## 5.2（续）线性查找、二分查找与插值语法
原书 p.128–129。

<a id="K001"></a>
**代码出处：** C · 原书清单 5.1 的轴区间查找摘录，p.128

```text
for (tt = 0; tt < t_axis_size-2 &&
             temp_array[i] > t_axis[tt+1]; ++tt);
```

<a id="N009"></a>
### 循环末尾的分号不是多余字符

**讲解：** 这里的循环体为空，作用是不断推进 tt。&& 短路求值：先检查边界，再读取下一个轴值。实际应用要求轴有足够长度、单调且无重复区间端点，并明确越界查询是拒绝、截断还是外插。

<a id="K002"></a>
**代码出处：** C · 清单 5.2 的教学改写，n≥2，轴严格递增且查询在范围内

```text
int lo = 0, hi = n - 1;
while (hi - lo > 1) {
    int mid = lo + (hi - lo) / 2;
    if (value >= axis[mid]) lo = mid;
    else hi = mid;
}
/* lo is the lower interval index when value is inside the axis range. */
```

<a id="N010"></a>
### 二分循环的语法

**讲解：** while 在上下界仍隔开时继续；整数除法取中点；每轮缩小区间。lo+(hi-lo)/2 比直接相加更容易避免大整数上界相加溢出。这里返回的是插值区间下界，不是保证查到完全相等的元素。

<a id="E002"></a>
**Source:** 原书 p.129 / PDF p.165 · E002

$$
f=(1-x)(1-y)f_{00}+x(1-y)f_{10}+(1-x)yf_{01}+xyf_{11}
$$

双线性插值的教学记号：x、y 为区间内的归一化比例，而不是原始坐标。四个权重相加为 1；区间内权重非负。

<a id="N011"></a>
### 原清单中的 data(...)

**讲解：** 它表示二维数据访问的宏/封装，而参数 data 又是指针；完整示例需要对应宏定义，不能把省略上下文的调用当作普通 C 函数直接编译。


<a id="5.3"></a>
## 5.3 什么使算法适合并行？
原书 p.130–131。

<a id="S005"></a>
**Source:** 原书 p.130 / PDF p.166 · S005

**Original:** This first example demonstrates how an algorithmic approach that is comparison-free and less synchronous can be easier to implement and can perform better for highly parallel hardware.

**中文:** 第一个例子说明：减少比较和同步的算法方式，可能更容易实现，并在高度并行的硬件上取得更好性能。

<a id="N012"></a>
### 姓氏分桶为什么有效

**讲解：** 按首字母把参与者分到不同队列，可以让不同桶独立处理；拥挤桶再按下一字母细分。它利用了键的结构，接近分桶/基数思路，并不是随便建立一个哈希表就自动排好序。

<a id="N013"></a>
### 不能把比较排序下界扩大到所有算法

**讲解：** Ω(N log N) 的经典下界针对一般比较排序等特定问题模型，不是“所有使用比较的算法”都至少要这么多工作。非比较排序可以利用键的范围或位数，但成本仍依赖桶数量、位数和分布。

<a id="N014"></a>
### 1600 倍来自什么

**讲解：** 书中用 N²/(N/P) 得到 N=100、P=16 时的 1600，是把更换算法与并行化一起计入的理想比值，省略了常数、建桶、同步和负载不均衡。它不是实测，也不是单靠 16 个执行单元就让同一算法加速 1600 倍。


<a id="5.4"></a>
## 5.4 哈希函数、桶与冲突
原书 p.131–132。

<a id="S006"></a>
**Source:** 原书 p.132 / PDF p.168 · S006

**Original:** The load factor is the fraction of the hash that is filled.

**中文:** 负载因子是哈希表中被填充的比例。

<a id="F001"></a>
### 图 5.1
**Source:** 原书 p.131 / PDF p.167 · C001
**Placed near:** 5.4 哈希函数、桶与冲突

![图 5.1](assets/fig5_1.png)

**Original caption:** Hash table to lookup a computer moniker by last name. In ASCII, R is 82 and O is 79. We can then calculate the first hash key with 82 – 64 + 26 + 79 – 4 = 59. The value stored in the hash table is the username, sometimes called a moniker.

**中文图注:** 图中用姓氏查找用户名。原图注用 R=82、O=79 的 ASCII 值解释哈希键，并给出结果 59。

**Reading note:** 原图注最后的“79−4”应为“79−64”，才得到 59；正文必须与图内公式一致。这个玩具函数也不能唯一编码任意姓氏，更不能当作可靠的完美哈希实现。

<a id="N015"></a>
### 键、哈希值与数据值

**讲解：** 哈希函数通常将键映射到哈希码或桶索引；哈希表再通过键比对找到关联数据。原书把“键映射到值”用于直观解释，实施时需要区分桶位置与真正储存的 value。

<a id="E003"></a>
**Source:** 原书 p.132 / PDF p.168 · E003

$$
\lambda=n/k
$$

n 为已存条目数，k 为桶数。完美哈希要求指定键集合在映射中不冲突；最小完美哈希还要求桶数等于键数。

<a id="N016"></a>
### 紧凑并不等于无冲突

**讲解：** 紧凑表减少空间，可能使多个键映到同一个桶，因此需要探测、链式结构等冲突处理，并在查找时验证完整键。负载因子可接受范围依函数、探测方式和工作负载而异，不能把 0.8–0.9 当作通用效率保证。


<a id="5.5"></a>
## 5.5 空间哈希：利用局部性减少候选
原书 p.132–135。

<a id="S007"></a>
**Source:** 原书 p.134 / PDF p.170 · S007

**Original:** Spatial hashing is a technique where the key is based on spatial information.

**中文:** 空间哈希是一种以空间信息构造键的技术。

<a id="F002"></a>
### 图 5.2
**Source:** 原书 p.133 / PDF p.169 · C002
**Placed near:** 5.5 空间哈希：利用局部性减少候选

![图 5.2](assets/fig5_2.png)

**Original caption:** A cell-based AMR mesh for a wave simulation from the CLAMR mini-app. The black squares are the cells and the variously-shaded squares represent the height of a wave radiating outward from the upper right corner.

**中文图注:** CLAMR 波浪模拟中的单元级自适应网格。黑色边界表示单元，颜色表示从右上方传播的波高。

**Reading note:** 细网格集中在需要更高分辨率的区域。几何位置与数据数组位置不再一一对应，因此需要额外的层级、坐标与邻接信息。

<a id="F003"></a>
### 图 5.3
**Source:** 原书 p.134 / PDF p.170 · C003
**Placed near:** 5.5 空间哈希：利用局部性减少候选

![图 5.3](assets/fig5_3.png)

**Original caption:** Computational meshes, particles, and objects mapped onto a spatial hash. The polyhedra of the unstructured mesh and the rectangular cells of the cell-based adaptive refinement mesh can be mapped to a spatial hash for spatial operations. Particles and geometric objects can also benefit from being mapped to a spatial hash to provide information about their spatial locality so that only nearby items need to be considered.

**中文图注:** 计算网格、粒子和几何对象都可映射到空间哈希。这样可利用空间局部性，只考虑附近的候选对象。

**Reading note:** 桶大小与最小网格尺寸或相互作用范围有关。桶太大使候选过多，桶太小则增加查桶和存储成本；任意长程相互作用不能靠固定邻桶范围完整表示。

<a id="N017"></a>
### 线性复杂度需要假设

**讲解：** 若相互作用半径固定、每个邻域的候选数有界，全部粒子处理可接近线性工作量。若所有粒子挤进一个桶，候选配对仍可能退化到二次量级。因此原书“所有空间操作都可线性扩展”的概括需要限定。

<a id="K003"></a>
**代码出处：** 伪代码 · 清单 5.3 的教学展开，p.135

```text
for each particle p:
    for each bucket intersecting p.interaction_region:
        for each candidate q in bucket:
            if q != p and distance(p, q) < cutoff:
                evaluate_interaction(p, q)
```

<a id="N018"></a>
### 不要遗漏和重复计算

**讲解：** 邻桶集合应覆盖整个作用区域；对称粒子对是否只计算一次需要明确，例如使用 q.id>p.id。周期边界、桶边界的负坐标取整以及对象跨桶，也都需要单独规定。


<a id="5.5.1"></a>
## 5.5.1 完美空间哈希：邻居查找
原书 p.135–138。

<a id="S008"></a>
**Source:** 原书 p.137 / PDF p.173 · S008

**Original:** For each cell in the AMR mesh, write the cell number to the hash buckets underlying the cell

**中文:** 对 AMR 网格中的每个单元，把单元编号写入其覆盖的哈希桶。

<a id="F004"></a>
### 图 5.4
**Source:** 原书 p.136 / PDF p.172 · C004
**Placed near:** 5.5.1 完美空间哈希：邻居查找

![图 5.4](assets/fig5_4.png)

**Original caption:** The left neighbor is the lower cell of the two to the left, and the bottom neighbor is the cell to the left of the two below. Similarly, the right neighbor is the lower cell of the two to the right, and the top neighbor is to the left of the two cells above.

**中文图注:** 当一个方向有两个细邻居时，左/右方向记录较低的那个，上/下方向记录较左的那个，另一个可通过已有邻接关系找到。

**Reading note:** 这是本例分级网格与邻居数组的约定，依赖相邻面细化级差至多为 1。不能把四个邻居指针直接用于任意非结构网格。

<a id="F005"></a>
### 图 5.5
**Source:** 原书 p.137 / PDF p.173 · C005
**Placed near:** 5.5.1 完美空间哈希：邻居查找

![图 5.5](assets/fig5_5.png)

**Original caption:** Finding the right neighbor of cell 21 using a spatial perfect hash

**中文图注:** 利用完美空间哈希寻找单元 21 的右邻居。

**Reading note:** 先把每个叶单元编号填入其覆盖的最细桶，再从目标单元右侧采样桶。图中查询列 8、行 3，得到邻居编号 26。

<a id="N019"></a>
### 建表成本也要计入

**讲解：** 令 H 为最细桶总数。初始化和填满桶的成本涉及 H，而不是仅 N 个叶单元。只有 H 与 N 保持适当关系时，才可简化说接近 Θ(N)。高细化级差下，一个粗单元可能覆盖大量桶。

<a id="F006"></a>
### 图 5.6
**Source:** 原书 p.138 / PDF p.174 · C006
**Placed near:** 5.5.1 完美空间哈希：邻居查找

![图 5.6](assets/fig5_6.png)

**Original caption:** The algorithm and parallel speedup total 3,157x. The new algorithm enables the parallel speedup on the GPU.

**中文图注:** 该研究中，换算法与 GPU 并行化合计得到相对基线 3157 倍加速。

**Reading note:** 单核哈希相对原基线是 66 倍，GPU 哈希相对同一基线是 3157 倍；两者相除约 47.83，才是图中后一步的相对提升。不是对完整多核 CPU 与 GPU 的公平硬件比较。

<a id="N020"></a>
### 树搜索仍有价值

**讲解：** k-d tree 的构建、单次查询和全部查询是不同成本。原书把每次查询也写成 O(N log N)，不能作为通用结论；维数、数据分布、查询类型和返回结果数都会影响复杂度。


<a id="5.5.1-kernel"></a>
## 5.5.1（续）从 C 循环到 OpenCL 工作项
原书 p.139–141。

<a id="K004"></a>
**代码出处：** C · 清单 5.4 的教学修正片段，p.139

```text
int *levtable = malloc(((size_t)levmx + 1) * sizeof *levtable);
/* Validate levmx, allocation success and power-of-two range first. */
for (int lev = 0; lev <= levmx; ++lev)
    levtable[lev] = 1 << lev;
```

<a id="N021"></a>
### 原书分配式少了什么

**讲解：** 原文 malloc(levmx+1) 只分配字节数，没有乘 sizeof(int)。修正版按元素大小分配；移位版本仍须限制 lev，保证结果可表示，且不能把负移位或超过类型位宽的移位当成合法操作。

<a id="K005"></a>
**代码出处：** OpenCL C · 清单 5.5 内核主体的教学整理；参数与分配由外层提供

```text
size_t ic = get_global_id(0);
if (ic >= isize) return;
int scale = levtable[levmx - level[ic]];
for (int y = j[ic] * scale; y < (j[ic] + 1) * scale; ++y)
    for (int x = i[ic] * scale; x < (i[ic] + 1) * scale; ++x)
        hash[(size_t)y * imaxsize + x] = (int)ic;
```

<a id="N022"></a>
### 关键字和索引语法

**讲解：** __kernel 标记由主机启动的内核；__global 指向设备全局地址空间；const 限制通过该指针修改数据；get_global_id(0) 取得一维全局工作项编号。每个工作项对应一个单元，因此 CPU 外层单元循环被启动范围替代。

<a id="N023"></a>
### 何时可以没有原子操作

**讲解：** 若叶单元互不重叠、覆盖关系和桶映射正确，不同单元写的桶集合可以互不相交。但压缩桶、重复单元或多线程竞争同一槽位时，就需要正确的并发插入协议，不能直接沿用普通赋值。查询阶段必须在建表完成之后执行。

<a id="N024"></a>
### 边界截断只是本例约定

**讲解：** 清单 5.6/5.7 的 min/max 防止索引出界，却可能在外边界读到自身。物理边界、周期边界和邻居不存在的标志仍需定义；不能将“没有越界”等同于“边界条件正确”。


<a id="5.5.1-remap"></a>
## 5.5.1（续）在两张 AMR 网格间重映射
原书 p.142–143。

<a id="S009"></a>
**Source:** 原书 p.142 / PDF p.178 · S009

**Original:** Fast remaps can permit different physics to be performed on meshes optimized for their individual needs.

**中文:** 快速重映射使不同物理过程能够在各自适合的网格上计算。

<a id="N025"></a>
### 写源网格，查目标网格

**讲解：** 建表阶段写入源网格单元编号；目标单元查询其覆盖的最细桶，找到来源并聚合。二维每加深一级有四个等面积子单元，因此例子按 4 的幂分配源值。

<a id="N026"></a>
### 先明确值是总量还是密度

**讲解：** 若源值是单元总量，可以按交叠面积比例分摊再累积；若是密度、温度等强度量，则通常需要面积加权并按目标面积归一化。原书不同重映射示例使用的 values 含义应分别确认，不要把“求和”和“平均”互换。

<a id="F007"></a>
### 图 5.7
**Source:** 原书 p.143 / PDF p.179 · C007
**Placed near:** 5.5.1（续）在两张 AMR 网格间重映射

![图 5.7](assets/fig5_7.png)

**Original caption:** The speedup of the remap algorithm due to the change of the algorithm from a k-D tree to a hash on a single core of the CPU and then ported to the GPU for a parallel speedup.

**中文图注:** 重映射从 k-d tree 改为单核哈希，再移到 GPU 并行执行后得到进一步加速。

**Reading note:** 图中 21 与 1217 均相对同一旧基线；结果属于原书实验，不是本机测试。清单 5.8 的 value_remap += 也要求输出先初始化或明确已有累积量。


<a id="5.5.1-table"></a>
## 5.5.1（续）均匀表格的直接区间定位
原书 p.143–145。

<a id="S010"></a>
**Source:** 原书 p.144 / PDF p.180 · S010

**Original:** By using the hashing technique, we can find the interval locations by using a simple arithmetic expression with no conditionals.

**中文:** 利用这种哈希方式，可以用一个简单的算术表达式确定区间位置。

<a id="K006"></a>
**代码出处：** C · 清单 5.9 的核心定位表达式，教学变量名

```text
int dd = (int)((density - density_min) / density_step);
int tt = (int)((temperature - temperature_min) / temperature_step);
```

<a id="N027"></a>
### 能直接定位的前提

**讲解：** 轴必须等间隔、步长为正，查询值要符合范围约定。C 浮点转整数对负值向零截断，不等于 floor；上端点还可能算到最后一个节点而使 dd+1 越界。通用实现应先检查范围，再将区间索引限制在 0 到 n−2。

<a id="F008"></a>
### 图 5.8
**Source:** 原书 p.144 / PDF p.180 · C008
**Placed near:** 5.5.1（续）均匀表格的直接区间定位

![图 5.8](assets/fig5_8.png)

**Original caption:** The algorithms used for table lookup show a large speedup for the hash algorithm on the GPU.

**中文图注:** 表格查询实验中，GPU 哈希版本取得较大的相对加速。

**Reading note:** 线性与二分在这个小表上很接近，但不意味着二分永远无效。批量规模、缓存驻留、分支和插值本身的成本都会影响比较。

<a id="N028"></a>
### 坐标查找与插值是两个阶段

**讲解：** 先找到四个包围节点，再计算 x、y 比例并加权。非均匀轴不能直接用一个固定步长代替查找；查找方式变化也不应改变插值边界和数据布局。


<a id="5.5.1-local"></a>
## 5.5.1（续）工作组协作加载与 barrier
原书 p.145–146。

<a id="K007"></a>
**代码出处：** OpenCL C · 清单 5.10 的教学修正版，缓冲区参数由内核签名提供

```text
size_t tid = get_local_id(0);
size_t wgs = get_local_size(0);
size_t gid = get_global_id(0);
for (size_t k = tid; k < xaxis_size; k += wgs)
    xaxis[k] = xaxis_buffer[k];
for (size_t k = tid; k < yaxis_size; k += wgs)
    yaxis[k] = yaxis_buffer[k];
for (size_t k = tid; k < dsize; k += wgs)
    data[k] = data_buffer[k];
barrier(CLK_LOCAL_MEM_FENCE);
if (gid < isize) {
    /* Interpolate using the now-initialized local arrays. */
}
```

<a id="N029"></a>
### 全局编号与局部编号

**讲解：** tid 是组内编号，wgs 是本组大小，gid 是全局编号；k+=wgs 让工作项分担整个数组。__local 缓冲区由组内工作项共享，需要主机配置足够空间；它不是普通私有局部变量。

<a id="N030"></a>
### 屏障前不要让部分工作项提前退出

**讲解：** 如果同组某个工作项执行 barrier，其他参与工作项也必须以规范要求到达该屏障。先协作加载并同步，再用 gid<isize 保护输出。把越界 return 放到这个 barrier 前，可能使尾组行为不合法。[R18]

<a id="N031"></a>
### 原清单两处需修正

**讲解：** 签名使用 dsize，循环却出现 d_size，应统一。原轴加载使用 if(tid<axis_size)，隐含工作组至少覆盖整个轴；上面的步进循环也能处理轴长大于工作组的情况。双精度和 local 存储容量还需查询目标设备支持。


<a id="5.5.1-sort"></a>
## 5.5.1（续）空间哈希排序
原书 p.146–149。

<a id="E004"></a>
**Source:** 原书 p.147 / PDF p.183 · E004

$$
b_k=\left\lfloor\frac{X_i-X_{min}}{\Delta_{min}}\right\rfloor
$$

利用已知的坐标范围和最小间距分桶。保证无冲突需要相应数据条件和正确的浮点/边界处理；重复坐标不能直接用单槽覆盖。

<a id="F009"></a>
### 图 5.9
**Source:** 原书 p.147 / PDF p.183 · C009
**Placed near:** 5.5.1（续）空间哈希排序

![图 5.9](assets/fig5_9.png)

**Original caption:** Sorting using a spatial perfect hash. This method stores the value in the hash with a bucket, but it could also store the index location of the value in the original array. Note that the bucket size of 2 with a range of 0 to 24 is indicated by the small numbers on the left of the hash table.

**中文图注:** 将空间值写入有序桶后，可按桶序读出；也可存原数组下标，再据下标重排其他字段。图中桶宽为 2。

**Reading note:** 这是一种利用值域结构的专用排序。若 K 个桶远多于 N 个元素，初始化和扫桶的 Θ(K) 成本不能隐藏，整体通常要按 N+K 分析。

<a id="N032"></a>
### 清单 5.11 的容量与哨兵

**讲解：** 若 max_val 表示实际最大键而非排他上界，桶数通常需要 floor((max−min)/step)+1；否则最大值可能越界。memset(hash,-1,...) 是填字节的惯用写法，不是逐元素整数赋值的定义；更清晰的教学写法是逐槽设为 -1。

<a id="F010"></a>
### 图 5.10
**Source:** 原书 p.149 / PDF p.185 · C010
**Placed near:** 5.5.1（续）空间哈希排序

![图 5.10](assets/fig5_10.png)

**Original caption:** Our spatial hash sort shows a speedup on a single core of the CPU and a further parallel speedup on the GPU. Our sort is 6x faster than the current fastest sort.

**中文图注:** 原书空间哈希排序在单核 CPU 和 GPU 上相对所选基线都取得加速，图示单核约 5.9 倍。

**Reading note:** 图注“当前最快”只属于当时测试和数据条件，不能用于今天的通用排序排名。专用数据约束与通用算法也应在比较中说清。

<a id="N033"></a>
### 为什么还需要前缀和

**讲解：** 并行读桶时，各线程不能共同无同步地执行 count++ 来决定输出位置。可先标记非空桶，再对标记做 exclusive scan，把每个有效桶映射到唯一的紧凑输出位置。


<a id="5.5.2"></a>
## 5.5.2 紧凑哈希与写入优化
原书 p.149–152。

<a id="S011"></a>
**Source:** 原书 p.150 / PDF p.186 · S011

**Original:** The inverse of the size multiplier is known as the hash load factor and is defined as the number of filled hash table entries divided by the hash table size.

**中文:** 表大小倍数的倒数对应负载因子，即有效条目数除以哈希表大小。

<a id="F011"></a>
### 图 5.11
**Source:** 原书 p.150 / PDF p.186 · C011
**Placed near:** 5.5.2 紧凑哈希与写入优化

![图 5.11](assets/fig5_11.png)

**Original caption:** Optimizing the neighbor-finding calculation using the perfect spatial hash by reducing the number of writes and reads

**中文图注:** 通过减少写入和读取次数优化完美空间哈希的邻居查找。

**Reading note:** 如果查询只采样边界，就不必填内部桶；进一步利用几何规则可减少到角点或一个代表点，但读阶段需要补充探测规则。减少写入不是无条件删掉数据。

<a id="F012"></a>
### 图 5.12
**Source:** 原书 p.150 / PDF p.186 · C012
**Placed near:** 5.5.2 紧凑哈希与写入优化

![图 5.12](assets/fig5_12.png)

**Original caption:** This sequence from left to right shows the storing of spatial data in a perfect spatial hash, compressing it into a smaller hash and then, where there is a collision, looking for the next available empty slot to store it.

**中文图注:** 从左到右：将空间数据存入完美哈希，压缩到更小的表，再为冲突条目寻找另一个空槽。

**Reading note:** 6 项进入 8 桶时，负载为 6/8=0.75，空闲比例为 2/8=0.25；原图右侧“10/16=.25”的分式是错误标注。

<a id="N034"></a>
### 线性、二次与双重探测

**讲解：** 线性探测尝试后续槽；二次探测使用平方偏移；双重哈希使用另一个函数决定步距。插入和查询必须采用一致的探测序列。二次或双重探测还需要合适的表长与参数，不能假定任何取模序列都遍历全部桶。

<a id="N035"></a>
### 并发冲突需要协议

**讲解：** 多个工作项同时发现空槽时，普通赋值会发生争用。需要原子占槽、键值发布顺序和读写阶段的正确配合；图示的顺序探测逻辑不能直接当作完整并发哈希实现。

<a id="F013"></a>
### 图 5.13
**Source:** 原书 p.152 / PDF p.188 · C013
**Placed near:** 5.5.2 紧凑哈希与写入优化

![图 5.13](assets/fig5_13.png)

**Original caption:** The optimized versions shown for the CPU and GPU correspond to the methods shown in figure 5.11. Compact is the CPU compact, and G Comp is the GPU compact for the last method in each set. The compact method is faster than the original perfect hash, requiring considerably less memory. At higher levels of refinement, the methods that reduce the number of writes show some performance benefit as well.

**中文图注:** CPU/GPU 的优化版本对应图 5.11。紧凑版本减少内存，较高细化程度下，减少写入也有收益。

**Reading note:** 各柱都相对旧 k-d tree 基线。另需修正正文的尺度描述：二维中相差 L 级的粗单元覆盖 4^L 个最细桶；L=6 时为 4096，而不是 64，后者更像一维长度比。


<a id="5.5.2-faces"></a>
## 5.5.2（续）非结构网格的面邻居
原书 p.152–153。

<a id="F021"></a>
### 图 5.A
**Source:** 原书 p.153 / PDF p.189 · C021
**Placed near:** 5.5.2（续）非结构网格的面邻居

![图 5.A](assets/fig5_A.png)

**Original caption:** Finding the neighbor for each face of each cell using a spatial hash. Each face writes to one of two bins in the spatial hash. If the face is towards the left and up from center, it writes to the first bin. If towards the right and down, it writes to the second. In the read pass, it looks to see if the other bin has been filled and if it is, that cell number is its neighbor. (Graphic and algorithm courtesy of Rachel Robey.)

**中文图注:** 通过面的空间位置和两侧槽位寻找共享该面的单元。读取时检查对侧槽是否有单元编号。图与算法由 Rachel Robey 提供。

**Reading note:** 5.A 为 p.153 未编号图的讲义标签。不同面中心可能落在同一桶，面中心也不能总是唯一标识几何面；实际实现仍需完整键、冲突处理和几何一致性检查。

<a id="N036"></a>
### 适用边界

**讲解：** 示例意在展示邻接的空间匹配思路。复杂非凸、多面共享、悬挂面或周期连接情形不能只靠一个“左上/右下”判断覆盖；保留并验证网格拓扑约束，才能决定何时可即时重算邻居。


<a id="5.5.2-remap"></a>
## 5.5.2（续）单次写入的重映射
原书 p.153–156。

<a id="F014"></a>
### 图 5.14
**Source:** 原书 p.153 / PDF p.189 · C014
**Placed near:** 5.5.2（续）单次写入的重映射

![图 5.14](assets/fig5_14.png)

**Original caption:** A single write, multiple read implementation of a spatial hash remap. The first query is where a cell of the same size from the input mesh would write, and then if no value is found, the next query looks for where a cell at the next coarser level would write.

**中文图注:** 单次写入、多次读取的重映射：先查询同级单元的代表位置，若未找到，再尝试更粗层级的位置。

**Reading note:** 每个源单元只写左下角代表点，节省写入；目标单元可能需要向粗层寻找，或对更细子单元递归聚合。

<a id="K008"></a>
**代码出处：** C/C++ · 清单 5.12–5.14 的移位摘录，pp.154–155

```text
#define two_to_the(shift) (1u << (shift))
ii >>= lev_diff;
ii <<= lev_diff;
```

<a id="N037"></a>
### 移位语法与前提

**讲解：** 1u 是无符号整数常量；左移表示乘 2 的幂，但位数不能超出类型宽度。先右移再左移可清除低位，将坐标对齐到更粗网格。还要保证层级差非负，尺寸乘法不溢出。

<a id="N038"></a>
### 哨兵不能当数组下标

**讲解：** 清单读到 probe<0 时继续向粗层搜索，但离开循环后必须确认 probe 已找到，再访问 level[probe]。对覆盖不完整的输入或不匹配区域，缺少这个检查会越界。递归子单元读取也需要存在性和最大深度约束。

<a id="N039"></a>
### 平均与守恒

**讲解：** 原书 finer 分支递归求四个子区平均，适合其等面积、强度量示例。若存的是总量，应采用相应守恒汇总；非等面积情况也不能固定除以 4。


<a id="5.5.2-hierarchy"></a>
## 5.5.2（续）分层哈希与递归限制
原书 p.156–157。

<a id="F015"></a>
### 图 5.15
**Source:** 原书 p.156 / PDF p.192 · C015
**Placed near:** 5.5.2（续）分层哈希与递归限制

![图 5.15](assets/fig5_15.png)

**Original caption:** A hierarchical hash table with a separate hash for each level. When a write is done in one of the finer levels, a sentinel value is placed in each level above to form a “breadcrumb” trail to inform queries that there is data at finer levels.

**中文图注:** 每个细化层级有一张哈希表；在细层写入后，向上层留下哨兵标记，提示查询继续下降到更细数据。

**Reading note:** 标记编码的是“这里还有子层信息”，不同于普通空槽。只有保证所有可达查询位置均被定义，才可省去某些整表初始化；不能读取未初始化内存并猜测它是哨兵。

<a id="N040"></a>
### 不能由一次运行成功推断可移植递归

**讲解：** 原书报告有限深度递归在其测试 GPU 上可运行。但 OpenCL C 规范不支持递归；编译器可能做了静态展开，某次成功不构成语言保证。应检查目标编程模型，必要时改为显式栈或逐层遍历。[R18]


<a id="5.6"></a>
## 5.6 前缀和：给不规则数据分配位置
原书 p.157–158。

<a id="S012"></a>
**Source:** 原书 p.157 / PDF p.193 · S012

**Original:** Many computations with irregular sizes need to know where to start writing to be able to operate in parallel.

**中文:** 许多处理不规则大小数据的计算，需要先知道从哪里开始写，才能并行执行。

<a id="E005"></a>
**Source:** 原书 p.157 / PDF p.193 · E005

$$
y_j=\sum_{i=0}^{j-1}x_i
$$

原书 exclusive scan：不含当前位置的累计和。空前缀定义为加法单位元 0。若将上界改为 j，则为 inclusive scan。

<a id="F016"></a>
### 图 5.16
**Source:** 原书 p.157 / PDF p.193 · C016
**Placed near:** 5.6 前缀和：给不规则数据分配位置

![图 5.16](assets/fig5_16.png)

**Original caption:** The array x gives the number of particles in each cell. The exclusive and inclusive scan of an array gives the starting and ending address in the global data set.

**中文图注:** x 表示各单元粒子数，exclusive 与 inclusive scan 给出各块的起始与结束位置。

**Reading note:** 按零起点半开区间表示，块 j 占用 [exclusive[j], inclusive[j])。非空块的最后一个实际下标是 inclusive[j]−1；数量为 0 时区间为空。

<a id="K009"></a>
**代码出处：** C · 清单 5.15 教学整理，增加空数组保护

```text
if (n > 0) {
    y[0] = x[0];
    for (int i = 1; i < n; ++i)
        y[i] = y[i-1] + x[i];
}
```

<a id="N041"></a>
### 这个循环不能直接分给独立线程

**讲解：** 第 i 项依赖第 i−1 项刚计算的结果。直接加 parallel for 会破坏依赖；需要重新组织计算，而不是只改变语法。计数数组还应避免整数溢出。

### 前缀和与输出区间演示

输入 1–32 个非负整数。展示 inclusive、exclusive、半开输出区间和步长翻倍的中间结果；这是教学模拟，不是 GPU 性能测试。

交互版本见网页小节 5.6。展示 inclusive/exclusive、输出半开区间与分轮计算。


<a id="5.6.1"></a>
## 5.6.1 步数较少的并行扫描
原书 p.158。

<a id="S013"></a>
**Source:** 原书 p.158 / PDF p.194 · S013

**Original:** A step-efficient algorithm uses the fewest number of steps. But this might not be the fewest number of operations because a different number of operations is possible with each step.

**中文:** 步数高效的算法强调较少的阶段，但未必使用最少操作，因为每个阶段可以完成不同数量的操作。

<a id="F017"></a>
### 图 5.17
**Source:** 原书 p.158 / PDF p.194 · C017
**Placed near:** 5.6.1 步数较少的并行扫描

![图 5.17](assets/fig5_17.png)

**Original caption:** The step-efficient inclusive scan uses O(log2n) steps to compute a prefix sum in parallel.

**中文图注:** 步长翻倍的 inclusive scan 用对数级阶段计算前缀和。

**Reading note:** 每轮读取上一轮的快照，距离依次为 1、2、4……。不能在同一轮让后面的元素读到已更新的新值；并行实现需要正确的临时存储和同步。

<a id="N042"></a>
### 8 个元素数一遍

**讲解：** 三轮分别做 7、6、4 次加法，共 17 次；串行只需 7 次。这种方案用更多工作换取较短的依赖深度，工作量约 Θ(n log n)，阶段数 Θ(log n)。


<a id="5.6.2"></a>
## 5.6.2 工作量高效的并行扫描
原书 p.159–160。

<a id="S014"></a>
**Source:** 原书 p.159 / PDF p.195 · S014

**Original:** The work-efficient parallel scan operation uses two sweeps through the arrays.

**中文:** 工作量高效的并行扫描需要对数组进行两次方向相反的遍历。

<a id="F018"></a>
### 图 5.18
**Source:** 原书 p.159 / PDF p.195 · C018
**Placed near:** 5.6.2 工作量高效的并行扫描

![图 5.18](assets/fig5_18.png)

**Original caption:** The upsweep phase of the work-efficient scan shown from top to bottom, which has far fewer operations than the step-efficient scan. Essentially, every other value is left unmodified.

**中文图注:** 工作量高效扫描的 upsweep 将局部和逐层向树根聚合，所需操作少于全体逐轮更新的方式。

**Reading note:** 8 项上扫做 4+2+1=7 次加法，根节点保存全和。图中保留的中间信息将用于下扫。

<a id="F019"></a>
### 图 5.19
**Source:** 原书 p.159 / PDF p.195 · C019
**Placed near:** 5.6.2 工作量高效的并行扫描

![图 5.19](assets/fig5_19.png)

**Original caption:** The downsweep phase of the work-efficient exclusive scan operation has far fewer operations than the step-efficient scan.

**中文图注:** 下扫阶段把各子树的前缀偏移传回叶端，得到 exclusive scan。

**Reading note:** 先把根的偏移设为 0；左子树继承父偏移，右子树得到父偏移加左子树总和。8 项下扫再做 7 次加法，共 14 次，但有约 6 个阶段。[R17]

<a id="N043"></a>
### 非二次幂与运算性质

**讲解：** 教学实现可用加法单位元 0 补到下一次 2 的幂，再截回原长度。一般 scan 依赖结合运算和相应单位元；浮点加法并非严格结合，因此树形顺序可能改变末位。空数组需要明确处理。


<a id="5.6.3"></a>
## 5.6.3 大数组的分块扫描
原书 p.160–161。

<a id="F020"></a>
### 图 5.20
**Source:** 原书 p.160 / PDF p.196 · C020
**Placed near:** 5.6.3 大数组的分块扫描

![图 5.20](assets/fig5_20.png)

**Original caption:** The large array scan proceeds in three stages and as three kernels for the GPU. The first stage does a reduction sum to an intermediate array. The second stage does a scan to create the offsets for the work groups. Then the third phase scans the original array and applies the work group offsets to get the scan results for each element of the array.

**中文图注:** 大数组扫描先生成各工作组的块和，再扫描块和得到块偏移，最后将块内前缀与块偏移合并。原书用三个 GPU 内核说明这一流程。

**Reading note:** 如果块和数组仍然太大，也需要递归分块或多层处理，不能只在每个块中独立 scan 就得到全局偏移。内核间执行次序也必须保证。

<a id="N044"></a>
### 局部下标与全局下标

**讲解：** 若某块的总前缀偏移为 40，块内 exclusive 结果为 [0,3,7]，全局起点就是 [40,43,47]。块内算法决定相对位置，块和扫描决定各块之间的位置。

<a id="N045"></a>
### 库与硬件限制

**讲解：** 原书列出当时 CUDA/OpenCL 扫描库及自带示例；正式项目应核对所用库的维护状态、类型支持和执行约定。工作组可用大小依设备、内核资源和编程模型而定，1024 不是所有设备或所有内核的保证。


<a id="5.7"></a>
## 5.7 全局求和：精度与结合律
原书 p.161–163。

<a id="S015"></a>
**Source:** 原书 p.161 / PDF p.197 · S015

**Original:** Changing the order of additions changes the answer in finite-precision arithmetic.

**中文:** 在有限精度算术中，改变加法顺序可能改变结果。

<a id="K010"></a>
**代码出处：** Python 3 · 原书灾难性消去示例的语法更新，p.161

```text
x = 12.15692174374373 - 12.15692174374372
print(x)
```

<a id="N046"></a>
### 相消不等于凭空产生随机位

**讲解：** 两个十进制字面量先被近似为二进制浮点数，随后相减；当真差很小时，输入近似误差会在相对意义上被放大。某些接近浮点数的减法本身可以精确完成，不能笼统说每次相消都由减法额外创造了噪声。

<a id="N047"></a>
### 更精确与更可复现是两回事

**讲解：** 固定顺序有助于可复现，但可能仍不够精确；增加精度可降低误差，但一般不保证任意排列或任意进程数下逐位相同。串行结果也不是天然真值，更不能把所有并行差异都归咎于舍入，遗漏幽灵单元更新同样会造成小偏差。


<a id="5.7-methods"></a>
## 5.7（续）长精度、成对与四倍精度求和
原书 p.163–166。

<a id="K011"></a>
**代码出处：** C · 清单 5.16 的核心操作整理

```text
long double acc = 0.0L;
for (long i = 0; i < ncells; ++i)
    acc += (long double)var[i];
return (double)acc;
```

<a id="N048"></a>
### 强制转换与可移植性

**讲解：** 输入仍是 double，把它提升到 long double 并不能恢复输入已丢失的位，但可减少累加过程的新误差。最终转回 double 又会舍入。long double 的精度由平台与编译器决定，不能只凭名字或 sizeof 推断有效尾数位数。

<a id="N049"></a>
### 成对求和

**讲解：** 先相加邻近值，再逐层合并，依赖深度较短，并通常有较好的误差增长性质。但不保证对任意正负混合数据都更准确。清单 5.17 隐含二次幂长度，奇数长度、0 和 1 项需要另行处理。

<a id="K012"></a>
**代码出处：** C 扩展 · 清单 5.20 的核心操作整理，p.166

```text
__float128 acc = 0.0;
for (long i = 0; i < ncells; ++i)
    acc += (__float128)var[i];
return (double)acc;
```

<a id="N050"></a>
### 类型扩展的边界

**讲解：** __float128 不是所有 C 编译器和目标都提供的标准通用类型。是否软件实现、如何链接、输出和计时需查具体工具链。表中的 Quad double 与源码 __float128 也不应被直接理解成任意一种“四个 double 展开”算法。


<a id="5.7-compensated"></a>
## 5.7（续）Kahan 补偿求和的代码与修正
原书 p.164–166。

<a id="N051"></a>
### 原清单的错误要先排除

**讲解：** p.165 清单 5.18 将 corrected_next_term 算出后，new_sum 却写成 local.sum + local.correction，未加入当前输入项。该行会使算法失去预期含义。以下采用常见的减补偿量写法，完整更新 sum 和 c，明确属于教学修正版。

<a id="K013"></a>
**代码出处：** C · Kahan 教学修正版，对照清单 5.18；未在本环境编译

```text
double kahan_sum(const double *a, long n) {
    double sum = 0.0, c = 0.0;
    for (long i = 0; i < n; ++i) {
        double y = a[i] - c;
        double t = sum + y;
        c = (t - sum) - y;
        sum = t;
    }
    return sum;
}
```

<a id="N052"></a>
### 每个变量承担什么

**讲解：** y 是扣除上一轮舍入偏差后的输入；t 是新的浮点和；(t−sum)−y 估计本轮舍入造成的差；c 将这个差带到下一轮。括号和执行顺序是算法的一部分，不能任意代数化简。

<a id="N053"></a>
### 优化与精度的边界

**讲解：** 允许重新结合浮点表达式的激进选项可能破坏补偿过程。Kahan 并不等于对所有输入“精度翻倍”，也不恢复普通浮点加法的严格结合律。原书 Knuth/TwoSum 类方法把加法结果分解为主值与误差，但其后续累积和异常数处理仍需分析。

<a id="N054"></a>
### 用于学习的反例

**讲解：** 顺序累加 [1e16,1,1,-1e16] 常丢掉两个 1；正确 Kahan 可在此例得到 2。但对 [1e16,1,-1e16]，同一 Kahan 写法仍可能得到 0，而更稳健的求和方法可得到 1。不能从一组成功样例推导普遍精确性。


<a id="5.7-results"></a>
## 5.7（续）怎样读精度与运行时间表
原书 p.166–167。

<a id="F022"></a>
### 表 5.1
**Source:** 原书 p.167 / PDF p.203 · C022
**Placed near:** 5.7（续）怎样读精度与运行时间表

![图 5.T1](assets/fig5_T1.png)

**Original caption:** Precision and run-time results for various global sum techniques

**中文图注:** 不同全局求和方法的精度与运行时间结果。

**Reading note:** 原书表 5.1，内部键 5.T1 仅用于定位。它反映书中特定输入、编译与测量条件；表头未明确误差定义及时间单位，不能擅自扩展成通用误差保证。

<a id="N055"></a>
### 表中 0.0 代表什么

**讲解：** 它只能表示与该参考答案按所用比较方式得到零误差，不证明对所有数据都精确。原书用 ncells/2×0.1 + ncells/2×1e−10 构造参考式，若仍用有限精度计算，该参考自身也受表示和舍入影响。

<a id="N056"></a>
### 如何做可靠对照

**讲解：** 可分别比较输入浮点值的高精度和、原始十进制模型的精确和，以及最终 double 舍入结果，它们不是同一目标。Python math.fsum 使用更细致的部分和累计，适合作为学习对照之一，但仍有浮点与平台边界。[R19]

<a id="N057"></a>
### 跨进程还有什么工作

**讲解：** 各进程先算局部和，再合并局部结果；合并顺序、补偿量如何传递以及归约树是否固定，都影响结果。更准确的局部求和不能自动保证跨进程逐位复现；第 8 章再结合 MPI 讨论。


<a id="5.8"></a>
## 5.8 从本章提炼并行算法特征
原书 p.167。

<a id="N058"></a>
### 两种局部性

**讲解：** 缓存局部性使一起使用的数据在内存上靠近；算法局部性使计算只访问真正相关的对象。空间分桶减少候选对数，是第二种局部性的典型例子，不只是把同样多的比较搬得更快。

<a id="N059"></a>
### 减少协调、分支与不均匀工作

**讲解：** 把可独立的工作暴露出来，避免不必要同步，减少难以预测的分支，并观察各工作项的工作量差异。异步不表示可以忽略数据依赖，也不表示所有共享写入都不需要原子或阶段同步。

<a id="N060"></a>
### 提高算术强度与改善数值质量

**讲解：** 额外计算有时可减少搬运或提高精度，但并非“浮点运算总是免费”。收益取决于瓶颈、寄存器压力和依赖链。精度、复现、时间和内存应一起评估。


<a id="5.9"></a>
## 5.9 进一步探索与本章小结
原书 p.167–169。

<a id="S016"></a>
**Source:** 原书 p.167 / PDF p.203 · S016

**Original:** But there are also many known techniques that have not been widely disseminated or used.

**中文:** 也有许多已知技术尚未得到广泛传播或应用。

<a id="N061"></a>
### 选择算法时保留假设

**讲解：** 明确键的范围、桶数量、几何规则、候选密度和输出目标，再谈复杂度。空间哈希不是适用于所有空间操作的无条件线性方案；排序专用约束也不能在比较性能时隐去。

<a id="N062"></a>
### 第一部分到此完成

**讲解：** 第 1–5 章建立并行思想、工程流程、性能测量、数据布局和算法模式的基础。后续 CPU/GPU 章节将在这些概念上介绍具体接口；此时应能解释一个循环的读写依赖、数据成本和数值目标。


<a id="5.9.1"></a>
## 5.9.1 延伸阅读
原书 p.168–169。

<a id="N063"></a>
### 保留原书文献线索

**讲解：** Cormen 等《Introduction to Algorithms》第三版；McCool、Robison、Reinders 的 Structured Parallel Programming；Mattson 等的 Patterns for Parallel Programming。空间哈希可查 Robey 等（2013）、Tumblin 等（2015）和 Collom 等（2018）的相关论文。

<a id="N064"></a>
### 数值一致性与补充核对

**讲解：** 原书还列出 Robey 等关于并行数值一致性和生产物理应用复现的研究。讲义的渐近记号依据 MIT 算法课程，scan 依据 Blelloch 的资料，OpenCL 约束以 Khronos 规范为准，Python 对照见 math.fsum 文档。链接列在资料页。


<a id="5.9.2"></a>
## 5.9.2 练习与参考思路
原书 p.169。

<a id="N065"></a>
### 练习 1｜1 mm 粒子相互作用

**讲解：** 令桶边长与截止距离相匹配，把粒子按坐标分桶，再遍历覆盖作用球的邻桶候选并做精确距离判断。3D 等宽桶取边长 1 mm 时通常需要检查本桶与周围 26 桶。只有邻域占据数受控等条件成立，才可说期望工作量近线性；最坏情况仍可能二次。

<a id="N066"></a>
### 练习 2｜邮政系统的类比

**讲解：** 邮编和分拣中心把邮件分到局部区域，再逐层细分。这体现分桶和分层索引，但地址规范、冲突处理与路由不等于一个简单整数哈希函数。

<a id="N067"></a>
### 练习 3｜MapReduce 与哈希

**讲解：** Map 产生键值，shuffle/group 将同键数据汇集，reduce 聚合。哈希可用于分区或分组，是流程中的一个实现工具；空间哈希则依空间关系限制候选。两者不是互相替代的同一算法。

<a id="N068"></a>
### 练习 4｜AMR 中固定观测点

**讲解：** 保存浮标/设施的物理坐标，网格变化后重新定位覆盖该点的叶单元，按边界约定和插值方式提取波高。不要长期保存一个会随重排改变的数组下标。应考虑落在单元界面上的点、区域外点和多级细化的映射。

<a id="N069"></a>
### 配套可运行练习

**讲解：** 资料包中的 algorithm_examples.py 用小数据验证串行与树形 scan、奇数长度、空输入、有效输出区间、直接分桶排序以及补偿求和示例。它是教学 Python 实现，不是 GPU 并行程序或硬件性能测试。


## 技术核对来源

- [R16 · MIT 6.006：渐近记号](https://live.ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/c6d8f06c6f11e3342633dec85498f551_MIT6_006S20_r01.pdf)
- [R17 · Blelloch：Prefix Sums and Their Applications](https://www.cs.cmu.edu/~guyb/papers/Ble93.pdf)
- [R18 · Khronos：OpenCL C 规范](https://registry.khronos.org/OpenCL/specs/unified/html/OpenCL_C.html)
- [R19 · Python：math.fsum](https://docs.python.org/3/library/math.html#math.fsum)