"""Small teaching checks; not a GPU implementation or performance benchmark."""
import math

def exclusive_serial(xs):
    out, running = [], 0
    for x in xs:
        out.append(running)
        running += x
    return out

def inclusive_hillis(xs):
    values = list(xs)
    distance = 1
    while distance < len(values):
        old = values.copy()
        for i in range(distance, len(values)):
            values[i] = old[i] + old[i-distance]
        distance *= 2
    return values

def exclusive_blelloch(xs):
    n = len(xs)
    if n == 0:
        return []
    size = 1 << (n-1).bit_length()
    values = list(xs) + [0] * (size-n)
    distance = 1
    while distance < size:
        for right in range(2*distance-1, size, 2*distance):
            values[right] += values[right-distance]
        distance *= 2
    values[-1] = 0
    distance = size // 2
    while distance:
        for right in range(2*distance-1, size, 2*distance):
            left = right-distance
            saved = values[left]
            values[left] = values[right]
            values[right] += saved
        distance //= 2
    return values[:n]

def direct_bucket_sort(keys, step):
    if step <= 0:
        raise ValueError('step must be positive')
    if not keys:
        return []
    minimum, maximum = min(keys), max(keys)
    buckets = [None] * ((maximum-minimum)//step + 1)
    for key in keys:
        index = (key-minimum)//step
        if buckets[index] is not None:
            raise ValueError('collision: single-entry bucket assumption fails')
        buckets[index] = key
    return [x for x in buckets if x is not None]

def naive_sum(xs):
    result = 0.0
    for x in xs:
        result += x
    return result

def kahan_sum(xs):
    result, correction = 0.0, 0.0
    for x in xs:
        y = x-correction
        temp = result+y
        correction = (temp-result)-y
        result = temp
    return result

def run_checks():
    example = [3,4,6,3,8,7,5,4]
    assert exclusive_serial(example) == [0,3,7,13,16,24,31,36]
    assert inclusive_hillis(example) == [3,7,13,16,24,31,36,40]
    cases = [[],[0],[7],[0,0,0],[2,0,3],list(range(9)),example]
    for xs in cases:
        prefix = exclusive_serial(xs)
        assert exclusive_blelloch(xs) == prefix
        assert inclusive_hillis(xs) == [p+x for p,x in zip(prefix,xs)]
        for i in range(1,len(xs)):
            assert prefix[i] == prefix[i-1]+xs[i-1]
    keys = [8,21,16,18,13,0,5,10,23,2]
    assert direct_bucket_sort(keys,2) == sorted(keys)
    assert direct_bucket_sort([0,2,4],2) == [0,2,4]
    try:
        direct_bucket_sort([1,1],2)
    except ValueError:
        pass
    else:
        raise AssertionError('collision was not rejected')
    values = [1e16,1.0,1.0,-1e16]
    assert naive_sum(values) == 0.0
    assert kahan_sum(values) == math.fsum(values) == 2.0
    counterexample = [1e16,1.0,-1e16]
    assert kahan_sum(counterexample) == 0.0
    assert math.fsum(counterexample) == 1.0
    print('scan, bucket boundaries, collisions and summation checks passed')

if __name__ == '__main__':
    run_checks()
