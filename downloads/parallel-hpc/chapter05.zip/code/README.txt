algorithm_examples.py 为教学 Python，检查 scan、桶边界、冲突和求和。C/OpenCL 片段未编译，不应把 commands_and_fragments.txt 整份当作脚本执行。

已运行 algorithm_examples.py，所有内置检查通过；不是 GPU 性能测试。
