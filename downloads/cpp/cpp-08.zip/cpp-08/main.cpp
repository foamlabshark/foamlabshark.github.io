#include <iostream>
#include <memory>

class BoundaryValue
{
public:
    virtual ~BoundaryValue() = default;
    virtual double value(double time) const = 0;
};

class FixedValue : public BoundaryValue
{
    double value_;

public:
    explicit FixedValue(double value) : value_(value) {}
    double value(double) const override
    {
        return value_;
    }
};

class RampValue : public BoundaryValue
{
    double initial_;
    double rate_;

public:
    RampValue(double initial, double rate)
    : initial_(initial), rate_(rate) {}

    double value(double time) const override
    {
        return initial_ + rate_*time;
    }
};

void printAtTime(const BoundaryValue& boundary, double time)
{
    std::cout << boundary.value(time) << '\n';
}

int main()
{
    FixedValue fixed(3.0);
    std::cout << "fixed: ";
    printAtTime(fixed, 2.0);

    std::unique_ptr<BoundaryValue> ramp = std::make_unique<RampValue>(1.0, 0.5);
    std::cout << "ramp: ";
    printAtTime(*ramp, 2.0);
    return 0;
}
