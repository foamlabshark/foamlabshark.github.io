#include <iostream>

int main()
{
    double residual = 1.0;
    const double tolerance = 0.01;
    const int maxIterations = 10;
    int iteration = 0;

    while (residual > tolerance && iteration < maxIterations)
    {
        residual *= 0.5;
        ++iteration;
        std::cout << iteration << ' ' << residual << '\n';
    }

    if (residual <= tolerance)
    {
        std::cout << "Converged after " << iteration << " iterations.\n";
    }
    else
    {
        std::cout << "Reached the iteration limit.\n";
    }
    return 0;
}
