#include <iostream>

void scaleValue(double value)
{
    value *= 2.0;
    std::cout << "inside value = " << value << '\n';
}

void scaleReference(double& value)
{
    value *= 2.0;
}

int main()
{
    double speed = 1.0;
    scaleValue(speed);
    std::cout << "after value = " << speed << '\n';
    scaleReference(speed);
    std::cout << "after reference = " << speed << '\n';

    double* pointer = &speed;
    *pointer = 3.0;
    const double& readOnly = speed;
    std::cout << "through pointer = " << speed << '\n';
    std::cout << "read-only view = " << readOnly << '\n';
    return 0;
}
