#include <iostream>

int main()
{
    std::cout << "FoamLab C++" << '\n';
    std::cout << "Learning to write a program." << '\n';
    return 0;
}
