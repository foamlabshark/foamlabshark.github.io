#include <iostream>
#include <stdexcept>

class Cell
{
private:
    double volume_;
    double density_;

public:
    Cell(double volume, double density)
    : volume_(volume), density_(density)
    {
        if (volume_ <= 0.0 || density_ <= 0.0)
        {
            throw std::invalid_argument("Volume and density must be positive.");
        }
    }

    double mass() const
    {
        return volume_*density_;
    }

    void setDensity(double density)
    {
        if (density <= 0.0)
        {
            throw std::invalid_argument("Density must be positive.");
        }
        density_ = density;
    }
};

int main()
{
    Cell cell(0.001, 1000.0);
    std::cout << "mass = " << cell.mass() << " kg\n";
    cell.setDensity(800.0);
    std::cout << "new mass = " << cell.mass() << " kg\n";
    return 0;
}
