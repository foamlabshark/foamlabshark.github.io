#include <iostream>
#include <map>
#include <string>
#include <vector>

template<class T>
T sumValues(const std::vector<T>& values)
{
    T total{};
    for (const T& value : values)
    {
        total += value;
    }
    return total;
}

int main()
{
    const std::vector<int> counts{1, 2, 3};
    const std::vector<double> speeds{0.5, 1.5, 2.0};
    const std::map<std::string, double> properties
    {
        {"nu", 0.01},
        {"rho", 1000.0}
    };

    std::cout << "integer sum = " << sumValues(counts) << '\n';
    std::cout << "floating sum = " << sumValues(speeds) << '\n';
    std::cout << "nu = " << properties.at("nu") << '\n';
    return 0;
}
