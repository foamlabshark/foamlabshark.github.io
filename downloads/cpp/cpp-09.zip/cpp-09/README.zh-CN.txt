C++ 09 · 模板、容器与泛型函数

文件采用 UTF-8 编码，示例使用标准 C++17。

在本目录执行：
g++ -std=c++17 -Wall -Wextra -Wpedantic main.cpp -o lesson
./lesson

Windows 可将输出文件名改为 lesson.exe，然后运行 ./lesson.exe。

预期输出：
integer sum = 6
floating sum = 4
nu = 0.01

中文讲解与代码：FoamLab。
