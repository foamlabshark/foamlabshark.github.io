C++ 02 · 变量、类型与数值运算

文件采用 UTF-8 编码，示例使用标准 C++17。

在本目录执行：
g++ -std=c++17 -Wall -Wextra -Wpedantic main.cpp -o lesson
./lesson

Windows 可将输出文件名改为 lesson.exe，然后运行 ./lesson.exe。

预期输出：
Re = 10000.0000
dx = 0.0003 m
3/2 = 1
3/2.0 = 1.5000

中文讲解与代码：FoamLab。
