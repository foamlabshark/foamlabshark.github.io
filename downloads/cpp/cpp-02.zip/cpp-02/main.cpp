#include <iomanip>
#include <iostream>

int main()
{
    const double velocity = 1.0;
    const double diameter = 0.01;
    const double viscosity = 1e-6;
    const double reynolds = velocity*diameter/viscosity;
    const int cells = 40;
    const double spacing = diameter/cells;

    std::cout << std::fixed << std::setprecision(4);
    std::cout << "Re = " << reynolds << '\n';
    std::cout << "dx = " << spacing << " m\n";
    std::cout << "3/2 = " << 3/2 << '\n';
    std::cout << "3/2.0 = " << 3/2.0 << '\n';
    return 0;
}
