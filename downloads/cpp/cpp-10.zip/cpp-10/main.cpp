#include "statistics.hpp"
#include <exception>
#include <fstream>
#include <iostream>
#include <vector>

int main()
{
    std::ifstream input("samples.dat");
    if (!input)
    {
        std::cerr << "Cannot open samples.dat\n";
        return 1;
    }

    std::vector<double> values;
    double value = 0.0;
    while (true)
    {
        input >> std::ws;
        if (input.eof())
        {
            break;
        }
        if (!(input >> value))
        {
            std::cerr << "Input contains an invalid number.\n";
            return 1;
        }
        values.push_back(value);
    }

    try
    {
        const double mean = meanValue(values);
        std::cout << "Count: " << values.size() << '\n';
        std::cout << "Mean: " << mean << '\n';
    }
    catch (const std::exception& error)
    {
        std::cerr << error.what() << '\n';
        return 1;
    }
    return 0;
}
