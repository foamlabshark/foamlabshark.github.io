#ifndef FOAMLAB_STATISTICS_HPP
#define FOAMLAB_STATISTICS_HPP

#include <vector>

double meanValue(const std::vector<double>& values);

#endif
