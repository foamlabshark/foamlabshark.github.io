#include "statistics.hpp"
#include <stdexcept>

double meanValue(const std::vector<double>& values)
{
    if (values.empty())
    {
        throw std::invalid_argument("The input data is empty.");
    }
    double total = 0.0;
    for (double value : values)
    {
        total += value;
    }
    return total/static_cast<double>(values.size());
}
