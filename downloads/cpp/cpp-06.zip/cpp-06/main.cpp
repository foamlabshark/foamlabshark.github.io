#include <iostream>
#include <string>
#include <vector>

int main()
{
    const std::string caseName = "channel";
    std::vector<double> speeds{1.0, 2.0, 3.0};
    speeds.push_back(4.0);

    double total = 0.0;
    for (double speed : speeds)
    {
        total += speed;
    }
    const double mean = total/static_cast<double>(speeds.size());

    std::cout << "Case: " << caseName << '\n';
    std::cout << "Count: " << speeds.size() << '\n';
    std::cout << "First: " << speeds.at(0) << '\n';
    std::cout << "Mean: " << mean << '\n';
    return 0;
}
