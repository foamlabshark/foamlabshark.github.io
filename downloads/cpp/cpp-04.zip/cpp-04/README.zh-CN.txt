C++ 04 · 函数、参数与作用域

文件采用 UTF-8 编码，示例使用标准 C++17。

在本目录执行：
g++ -std=c++17 -Wall -Wextra -Wpedantic main.cpp -o lesson
./lesson

Windows 可将输出文件名改为 lesson.exe，然后运行 ./lesson.exe。

预期输出：
Co = 0.2
Co with half dt = 0.1

中文讲解与代码：FoamLab。
