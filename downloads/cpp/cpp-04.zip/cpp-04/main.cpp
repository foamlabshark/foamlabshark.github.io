#include <iostream>

double courant(double speed, double deltaT, double spacing)
{
    const double distance = speed*deltaT;
    return distance/spacing;
}

int main()
{
    const double speed = 2.0;
    const double deltaT = 0.001;
    const double spacing = 0.01;

    const double coarseStep = courant(speed, deltaT, spacing);
    const double fineStep = courant(speed, deltaT/2.0, spacing);
    std::cout << "Co = " << coarseStep << '\n';
    std::cout << "Co with half dt = " << fineStep << '\n';
    return 0;
}
