"""Run selected complete cases; preserve their inputs and existing results."""
from pathlib import Path
import json,subprocess,sys,time
root=Path(__file__).resolve().parent
manifest=json.loads((root/'case-manifest.json').read_text())
args=sys.argv[1:]
if args==['--all']:
 selected=[r['path'] for r in manifest if r['includeInAll']]
elif args:selected=args
else:selected=['cases/diffusion-20','cases/source-20','cases/gradient-skew','cases/decay-euler','cases/diffusion-transient']
report=[]
for name in selected:
 case=(root/name).resolve()
 if not case.is_relative_to(root) or not (case/'Allrun').is_file():
  raise SystemExit('Not a packaged case: '+name)
 print('Running '+name,flush=True);start=time.time()
 result=subprocess.run(['sh','Allrun'],cwd=case)
 report.append(dict(path=name,exit=result.returncode,seconds=time.time()-start))
 (root/'run-report.json').write_text(json.dumps(report,indent=2)+'\n')
 if result.returncode:raise SystemExit(result.returncode)
