# 弯管上的解析场检查

对应第 7 章练习 2。环形弯管转角 90°，内半径 0.5 m、外半径 1 m、厚度 0.1 m；径向 20、周向 40、厚度方向 1 层，共 800 单元。

在代码包根目录运行 `sh Allwmake` 后，执行 `sh cases/mesh-notebook-elbow/Allrun`。
程序在单元中心和边界面心设置 `10*x*y+5*y*y`，比较数值梯度与解析梯度 `(10*y,10*x+10*y,0)`。
`notebook/cells.txt`、`faces.csv`、`patches.txt` 分别记录单元连接、面几何与边界；`quadratic-*-summary.txt` 记录误差。
