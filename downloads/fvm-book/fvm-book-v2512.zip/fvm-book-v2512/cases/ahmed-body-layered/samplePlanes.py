"""Write a postProcess dictionary for centre-plane and wake-section samples."""
from pathlib import Path
def grid(name,points):
 return name+'\n{\n    type cloud;\n    axis xyz;\n    points\n    (\n'+''.join('        ('+' '.join(f'{v:.8g}' for v in p)+')\n' for p in points)+'    );\n}\n'
centre=[(-.25+2.6*i/180,.00001,.005+.695*j/65) for j in range(66) for i in range(181)]
wake=[(1.3,.00001+.5*i/70,.005+.695*j/65) for j in range(66) for i in range(71)]
s='FoamFile\n{\n    version 2.0;\n    format ascii;\n    class dictionary;\n    object samplePostProcDict;\n}\nfunctions\n{\n    samplePlanes\n    {\n        type sets;\n        libs (sampling);\n        interpolationScheme cellPoint;\n        setFormat raw;\n        fields (U p k nut);\n        sets\n        (\n'+grid('centre',centre)+grid('wake',wake)+'        );\n    }\n}\n'
s=s.replace('functions\n{\n', 'functions\n{\n    loadSampleFields\n    {\n        type readFields;\n        libs (fieldFunctionObjects);\n        fields (U p k nut);\n    }\n',1)
Path('system/samplePostProcDict').write_text(s)
