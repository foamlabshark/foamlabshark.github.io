# 线性代数练习

在程序包根目录运行 `./Allwmake`，然后运行：

```bash
fvmAlgebraNotebook cases/algebra-notebook/example.txt jacobi 5
fvmAlgebraNotebook cases/algebra-notebook/e1a.txt lu 1
fvmAlgebraNotebook cases/algebra-notebook/e8a.txt ilu 3
fvmAlgebraNotebook cases/algebra-notebook/e8a.txt dilu 3
fvmAlgebraNotebook cases/algebra-notebook/e10a.txt pcg 2
fvmAlgebraNotebook cases/algebra-notebook/e2b.txt gs 1000 0.1
```

参数依次为输入、方法、最大轮数和可选的未归一化最大残差阈值。方法有 lu、ilu、dilu、jacobi、gs、pcg；pcg 使用对角预条件。输入第一行是阶数，随后 N×N 个系数和 N 个右端值。e4 与 e6 用于分解检查，右端为零，程序仍输出因子或修正对角；可指定轮数 0 只查看分解。

factor_i 为原位 LU 存储第 i 行，主对角及上三角属于 U，严格下三角为 L 的乘数，L 的单位对角不存储。diagonal 为原对角或 DILU 修正对角。x_n 是第 n 轮结果，residual_n 是真实最大残差。

部分原书练习的 Jacobi 或 Gauss–Seidel 不收敛。程序在残差超过 1e30 时停止增长记录；退出码为 0 仅说明算法执行完成，不能代替残差判据。

这些小矩阵程序用于逐项检查算法。网格方程使用 fvmBookFoam 及 fvSolution 中的原生 lduMatrix 求解器。
