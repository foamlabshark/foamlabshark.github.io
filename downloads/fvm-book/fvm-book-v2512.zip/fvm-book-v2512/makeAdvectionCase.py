#!/usr/bin/env python3
"""Generate complete native v2512 cases for Chapters 11-12 (standard library only)."""
from pathlib import Path
import argparse

p=argparse.ArgumentParser()
p.add_argument('problem',choices=['oblique','polynomial','smith-hutton'])
p.add_argument('scheme',choices=['upwind','QUICK','bookSOU','bookQUICK',
    'Minmod','MUSCL','SuperBee','vanLeer',
    'bookSMART','bookSMART_TVD','bookSTOIC','bookOSHER','bookMINMOD',
    'bookMUSCL','bookSUPERBEE','bookBoundedCD','bookSmoothCD'])
p.add_argument('cells',type=int,help='Cells along y; polynomial requires a multiple of 3')
p.add_argument('directory',type=Path)
a=p.parse_args()
if a.cells<2 or (a.problem=='polynomial' and a.cells%3) or (a.problem=='smith-hutton' and a.cells%2):
    p.error('cells must be >=2; polynomial cells divisible by 3, smith-hutton cells even')
root=a.directory
if (root/'constant/polyMesh').exists() or (root/'solution.csv').exists():
    p.error('Use a new directory so that an existing mesh or result is not overwritten')
for name in ['0','constant','system']: (root/name).mkdir(parents=True,exist_ok=True)

def header(name,cls='dictionary'):
    return 'FoamFile\n{\n    version 2.0;\n    format ascii;\n    class '+cls+';\n    object '+name+';\n}\n'
def put(name,body,cls='dictionary'):
    (root/name).write_bytes((header(Path(name).name,cls)+body).encode())

if a.problem=='oblique':
    xs=[0,1]; nx=[a.cells]; vel=(2,1,0)
    bottom=['inletZero']; top=['outlet']; left='inletOne';right='outlet'
elif a.problem=='polynomial':
    xs=[0,1/3,2/3,1];nx=[a.cells//3]*3;vel=(0,0,0)
    bottom=['noFlux']*3;top=['inletTen','inletZero','inletZero'];left='noFlux';right='outlet'
else:
    xs=[-1,-.5,0,1];nx=[a.cells//2,a.cells//2,a.cells];vel=(0,0,0)
    bottom=['inletTen','inletZero','outlet'];top=['noFlux']*3;left=right='noFlux'
vertices=[(x,y,z) for z in [0,.1] for y in [0,1] for x in xs]
nv=len(xs)
idx=lambda i,j,k:k*2*nv+j*nv+i
patches={}
def face(patch,ids): patches.setdefault(patch,[]).append(ids)
blocks=[]
for i,n in enumerate(nx):
    v=[idx(i,0,0),idx(i+1,0,0),idx(i+1,1,0),idx(i,1,0),
       idx(i,0,1),idx(i+1,0,1),idx(i+1,1,1),idx(i,1,1)]
    blocks.append('    hex ('+' '.join(map(str,v))+f') ({n} {a.cells} 1) simpleGrading (1 1 1)')
    face(bottom[i],[v[k] for k in [0,1,5,4]])
    face(top[i],[v[k] for k in [3,7,6,2]])
    face('frontAndBack',[v[k] for k in [0,3,2,1]])
    face('frontAndBack',[v[k] for k in [4,5,6,7]])
    if i==0:face(left,[v[k] for k in [0,4,7,3]])
    if i==len(nx)-1:face(right,[v[k] for k in [1,2,6,5]])
mesh='scale 1;\nvertices\n(\n'+''.join('    ('+' '.join(f'{x:.17g}' for x in v)+')\n' for v in vertices)+');\nblocks\n(\n'
mesh+='\n'.join(blocks)+'\n);\nedges ();\nboundary\n(\n'
for name,faces in patches.items():
    mesh+=f'    {name}\n    {{\n        type '+('empty' if name=='frontAndBack' else 'patch')+';\n        faces\n        (\n'
    mesh+=''.join('            ('+' '.join(map(str,f))+')\n' for f in faces)+'        );\n    }\n'
put('system/blockMeshDict',mesh+');\nmergePatchPairs ();\n')

c='dimensions [0 0 0 0 0 0 0];\ninternalField uniform 0;\nboundaryField\n{\n'
u='dimensions [0 1 -1 0 0 0 0];\ninternalField uniform ('+' '.join(map(str,vel))+');\nboundaryField\n{\n'
for name in patches:
    c+=f'    {name}\n    {{\n'
    u+=f'    {name}\n    {{\n'
    if name=='frontAndBack':
        c+='        type empty;\n';u+='        type empty;\n'
    else:
        value={'inletOne':1,'inletTen':10,'inletZero':0}.get(name)
        c+=('        type zeroGradient;\n' if value is None else
            f'        type fixedValue;\n        value uniform {value};\n')
        u+='        type fixedValue;\n        value uniform ('+' '.join(map(str,vel))+');\n'
    c+='    }\n';u+='    }\n'
put('0/c',c+'}\n','volScalarField');put('0/U',u+'}\n','volVectorField')
profile={'oblique':'read','polynomial':'polynomial','smith-hutton':'smithHutton'}[a.problem]
put('constant/transportProperties',f'''D [0 2 -1 0 0 0 0] 0;
decay [0 0 -1 0 0 0 0] 0;
source [0 0 -1 0 0 0 0] 0;
velocityProfile {profile};
steadyTolerance 1e-8;
''')
scheme=a.scheme+(' grad(c)' if a.scheme in ['bookSOU','bookQUICK'] else '')
if a.scheme=='QUICK': scheme='deferredCorrection QUICK'
if a.scheme in ['Minmod','MUSCL','SuperBee','vanLeer']:
    scheme='deferredCorrection '+a.scheme
if a.scheme.startswith('book') and a.scheme not in ['bookSOU','bookQUICK']:
    kind=a.scheme[4:]
    if kind=='BoundedCD':kind='boundedCD'
    if kind=='SmoothCD':kind='smoothCD'
    scheme='bookHR '+kind+' grad(c)'
put('system/fvSchemes',f'''ddtSchemes
{{
    default steadyState;
}}
gradSchemes
{{
    default Gauss linear;
}}
divSchemes
{{
    default none;
    div(phi,c) Gauss {scheme};
}}
laplacianSchemes
{{
    default Gauss linear corrected;
}}
interpolationSchemes
{{
    default linear;
}}
snGradSchemes
{{
    default corrected;
}}
''')
put('system/fvSolution','''solvers
{
    c
    {
        solver PBiCGStab;
        preconditioner DILU;
        tolerance 1e-14;
        relTol 0;
    }
}
SIMPLE
{
    nNonOrthogonalCorrectors 0;
}
relaxationFactors
{
    equations
    {
        c 0.7;
    }
}
'''.replace('c 0.7;', 'c 0.4;' if a.scheme=='QUICK' else
    'c 0.35;' if a.scheme not in ['upwind','bookSOU','bookQUICK'] else 'c 0.7;'))
put('system/controlDict','''application fvmBookFoam;
startFrom startTime;
startTime 0;
stopAt endTime;
endTime 5000;
deltaT 1;
writeControl timeStep;
writeInterval 5000;
purgeWrite 1;
writeFormat ascii;
writePrecision 12;
writeCompression off;
timeFormat general;
timePrecision 10;
runTimeModifiable false;
libs ("libbookInterpolation.so");
''')
(root/'Allrun').write_bytes(b'''#!/bin/sh
set -eu
cd "$(dirname "$0")"
blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
fvmBookFoam -inspect > log.fvmBookFoam 2>&1
cat convergence.txt
''')
print(root)
