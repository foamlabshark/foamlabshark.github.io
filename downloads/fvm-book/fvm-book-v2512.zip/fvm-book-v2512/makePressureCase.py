"""Complete native v2512 pressure/velocity cases; standard-library only."""
from pathlib import Path
import math,json

def header(obj,cls='dictionary'):
    return 'FoamFile\n{\n    version 2.0;\n    format ascii;\n    class '+cls+';\n    object '+obj+';\n}\n\n'

def block(name,body):
    return name+'\n{\n'+''.join('    '+s+'\n' for s in body)+'}\n'

def create(path,kind='channel',algorithm='SIMPLE',n=24,alphaU=.7,alphaP=.3,dt=.01,nCorrectors=2):
    path=Path(path)
    for d in ['0','constant','system']:(path/d).mkdir(parents=True,exist_ok=True)
    def write(f,s): (path/f).write_bytes(s.encode())
    vortex=kind=='vortex';cavity=kind=='cavity'
    L=2*math.pi if vortex else (1 if cavity else 2)
    H=L if vortex else 1;z=.1;nx=n if vortex or cavity else 2*n;ny=n
    verts=[(0,0,0),(L,0,0),(L,H,0),(0,H,0),(0,0,z),(L,0,z),(L,H,z),(0,H,z)]
    faces={'left':'(0 4 7 3)','right':'(1 2 6 5)','bottom':'(0 1 5 4)','top':'(3 7 6 2)','frontAndBack':'(0 3 2 1)\n        (4 5 6 7)'}
    partners={'left':'right','right':'left','bottom':'top','top':'bottom'}
    boundaries=[]
    for name,face in faces.items():
        ty='empty' if name=='frontAndBack' else ('cyclic' if vortex else ('wall' if cavity or name in ['top','bottom'] else 'patch'))
        lines=['type '+ty+';']
        if ty=='cyclic':lines+=['neighbourPatch '+partners[name]+';','transform translational;',
            'separationVector '+{'left':f'({L} 0 0)','right':f'({-L} 0 0)','bottom':f'(0 {H} 0)','top':f'(0 {-H} 0)'}[name]+';']
        lines+=['faces','(', '    '+face,');']
        boundaries.append(block(name,lines))
    mesh=header('blockMeshDict')+'scale 1;\nvertices\n(\n'
    mesh+=''.join('    ('+' '.join(f'{a:.16g}' for a in v)+')\n' for v in verts)+');\n'
    mesh+=f'blocks\n(\n    hex (0 1 2 3 4 5 6 7) ({nx} {ny} 1) simpleGrading (1 1 1)\n);\nedges ();\nboundary\n(\n'
    mesh+='\n'.join(boundaries)+');\nmergePatchPairs ();\n'
    write('system/blockMeshDict',mesh)
    vals=[];pvals=[]
    for j in range(ny):
        y=H*(j+.5)/ny
        for i in range(nx):
            x=L*(i+.5)/nx
            vals.append((math.sin(x)*math.cos(y),-math.cos(x)*math.sin(y),0) if vortex else (0,0,0))
            pvals.append(.25*(math.cos(2*x)+math.cos(2*y)) if vortex else 0)
    def nonuniform(data,typ):
        return 'nonuniform List<'+typ+'>\n'+str(len(data))+'\n(\n'+''.join('    '+('('+' '.join(f'{v:.16g}' for v in a)+')' if typ=='vector' else f'{a:.16g}')+'\n' for a in data)+');'
    for field,cls,dims,data,typ in [('U','volVectorField','[0 1 -1 0 0 0 0]',vals,'vector'),
                                   ('p','volScalarField','[0 2 -2 0 0 0 0]',pvals,'scalar')]:
        patches=[]
        for name in faces:
            if name=='frontAndBack':body=['type empty;']
            elif vortex:body=['type cyclic;']
            elif field=='p':
                body=['type fixedValue;','value uniform 0;'] if name=='right' and not cavity else ['type zeroGradient;']
            elif cavity:
                body=['type fixedValue;','value uniform '+('(1 0 0)' if name=='top' else '(0 0 0)')+';']
            elif name=='left':
                speed=[(6*((j+.5)/ny)*(1-(j+.5)/ny),0,0) for j in range(ny)]
                body=['type fixedValue;','value '+nonuniform(speed,'vector')]
            elif name=='right':body=['type zeroGradient;']
            else:body=['type fixedValue;','value uniform (0 0 0);']
            patches.append(block(name,body))
        write('0/'+field,header(field,cls)+'dimensions '+dims+';\ninternalField '+nonuniform(data,typ)+'\nboundaryField\n{\n'+'\n'.join(patches)+'}\n')
    steady=not algorithm.startswith('PISO')
    write('system/controlDict',header('controlDict')+
        f'application fvmPressureNotebook;\nstartFrom startTime;\nstartTime 0;\nstopAt endTime;\nendTime {6000 if steady else .5};\ndeltaT {1 if steady else dt};\nwriteControl timeStep;\nwriteInterval {6000 if steady else round(.5/dt)};\nwriteFormat ascii;\nwritePrecision 15;\ntimePrecision 12;\nrunTimeModifiable false;\n')
    write('constant/flowProperties',header('flowProperties')+
        f'nu [0 2 -1 0 0 0 0] {.01 if cavity else .1};\nalgorithm {algorithm};\nalphaU {alphaU};\nalphaP {alphaP};\nnCorrectors {nCorrectors};\nnNonOrthogonalCorrectors 0;\nsteadyTolerance 1e-8;\n')
    write('system/fvSchemes',header('fvSchemes')+
        block('ddtSchemes',['default '+('steadyState' if steady else 'Euler')+';'])+
        block('gradSchemes',['default Gauss linear;'])+
        block('divSchemes',['default none;','div(phi,U) Gauss linear;'])+
        block('laplacianSchemes',['default Gauss linear corrected;'])+
        block('interpolationSchemes',['default linear;'])+
        block('snGradSchemes',['default corrected;'])+
        block('fluxRequired',['default no;','p;','pp;']))
    pressure=['solver PCG;','preconditioner DIC;','tolerance 1e-12;','relTol 0;','maxIter 10000;','log 0;']
    write('system/fvSolution',header('fvSolution')+'solvers\n{\n'+block('p',pressure)+block('pp',pressure)+
        block('U',['solver PBiCGStab;','preconditioner DILU;','tolerance 1e-12;','relTol 0;','maxIter 10000;','log 0;'])+'}\n')
    write('Allrun','#!/bin/sh\nset -eu\ncd "$(dirname "$0")"\nblockMesh > log.blockMesh 2>&1\ncheckMesh > log.checkMesh 2>&1\nfvmPressureNotebook > log.solve 2>&1\n')
    write('case.json',json.dumps(dict(kind=kind,algorithm=algorithm,n=n,nx=nx,ny=ny,L=L,H=H,nu=.01 if cavity else .1,
        alphaU=alphaU,alphaP=alphaP,dt=dt,nCorrectors=nCorrectors),indent=2)+'\n')

CASES=[
 ('channel-SIMPLE','channel','SIMPLE',24,.7,.3,.01,2),
 ('channel-SIMPLEC','channel','SIMPLEC',24,.7,1,.01,2),
 ('channel-correction','channel','correction',24,.7,.3,.01,2),
 ('cavity-SIMPLE','cavity','SIMPLE',24,.7,.3,.01,2),
 ('cavity-SIMPLEC','cavity','SIMPLEC',24,.7,1,.01,2),
 ('cavity-correction','cavity','correction',24,.7,.3,.01,2),
 ('vortex-PISO-2','vortex','PISO',32,1,1,.01,2),
 ('vortex-PISO-3','vortex','PISO',32,1,1,.01,3),
 ('vortex-PISO-correction-2','vortex','PISO-correction',32,1,1,.01,2),
 ('vortex-PISO-correction-3','vortex','PISO-correction',32,1,1,.01,3),
]
if __name__=='__main__':
    for name,*args in CASES:create(Path(__file__).parent/'cases/pressure'/name,*args)
