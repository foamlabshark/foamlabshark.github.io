"""Generate the complete fixed-mesh Chapter 13 native OpenFOAM cases."""
from pathlib import Path
import argparse

def header(name,cls='dictionary'):
    return ('FoamFile\n{\n    version 2.0;\n    format ascii;\n'
            f'    class {cls};\n    object {name};\n}}\n\n')

def create(directory,problem,scheme,steps,density_slope=0):
    root=Path(directory)
    def write(name,text):
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(text.replace('\r\n','\n').encode())
    rod=problem!='cooling'
    length=.03 if rod else 1
    initial=273 if rod else 1
    diffusivity=55/(7000*400) if rod else 0
    decay=0 if rod else 1
    # Two cells in x. The transverse dimensions are irrelevant for 1D solutions.
    vertices=[(0,0,0),(length,0,0),(length,.01,0),(0,.01,0),
              (0,0,.01),(length,0,.01),(length,.01,.01),(0,.01,.01)]
    v='\n'.join('    ('+' '.join(map(str,x))+')' for x in vertices)
    faces={'left':['(0 4 7 3)'],'right':['(1 2 6 5)'],
           'sides':['(0 1 5 4)','(3 7 6 2)','(0 3 2 1)','(4 5 6 7)']}
    boundary=''
    for patch,ff in faces.items():
        boundary+=f'    {patch}\n    {{\n        type patch;\n        faces\n        (\n'
        boundary+=''.join('            '+f+'\n' for f in ff)
        boundary+='        );\n    }\n'
    write('system/blockMeshDict',header('blockMeshDict')+
          f'convertToMeters 1;\nvertices\n(\n{v}\n);\nblocks\n(\n'
          '    hex (0 1 2 3 4 5 6 7) (2 1 1) simpleGrading (1 1 1)\n'
          ');\nedges ();\nboundary\n(\n'+boundary+');\nmergePatchPairs ();\n')
    left='type zeroGradient;'
    right='type zeroGradient;'
    if problem in ('rod-robin','rod-mixed'):
        fraction=400*.015/(2*55+400*.015)
        right=f'''type mixed;
        refValue uniform 330;
        refGradient uniform 0;
        valueFraction uniform {fraction:.17g};
        value uniform 273;'''
    if problem=='rod-fixed':
        right='type fixedValue;\n        value uniform 330;'
    if problem=='rod-mixed':
        left='type fixedValue;\n        value uniform 260;'
    write('0/c',header('c','volScalarField')+
          f'dimensions [0 0 0 0 0 0 0];\ninternalField uniform {initial};\n'
          f'boundaryField\n{{\n    left\n    {{\n        {left}\n    }}\n'
          f'    right\n    {{\n        {right}\n    }}\n'
          '    sides\n    {\n        type zeroGradient;\n    }\n}\n')
    write('constant/transportProperties',header('transportProperties')+
          f'D [0 2 -1 0 0 0 0] {diffusivity:.17g};\n'
          f'decay [0 0 -1 0 0 0 0] {decay};\n'
          f'densitySlope {density_slope};\nstepSizes\n(\n'+
          ''.join(f'    {h:.17g}\n' for h in steps)+');\n')
    write('system/controlDict',header('controlDict')+
          'application fvmTimeNotebook;\nstartFrom startTime;\nstartTime 0;\n'
          f'stopAt endTime;\nendTime {sum(steps):.17g};\ndeltaT {steps[0]:.17g};\n'
          'writeControl timeStep;\nwriteInterval 1;\nwriteFormat ascii;\n'
          'writePrecision 15;\ntimeFormat general;\ntimePrecision 12;\n'
          'runTimeModifiable false;\n')
    write('system/fvSchemes',header('fvSchemes')+
          f'ddtSchemes\n{{\n    default {scheme};\n}}\n'
          'gradSchemes\n{\n    default Gauss linear;\n}\n'
          'divSchemes\n{\n    default none;\n}\n'
          'laplacianSchemes\n{\n    default Gauss linear orthogonal;\n}\n'
          'interpolationSchemes\n{\n    default linear;\n}\n'
          'snGradSchemes\n{\n    default orthogonal;\n}\n')
    write('system/fvSolution',header('fvSolution')+
          'solvers\n{\n    c\n    {\n        solver PCG;\n'
          '        preconditioner DIC;\n        tolerance 1e-13;\n'
          '        relTol 0;\n    }\n}\n')
    write('Allrun','#!/bin/sh\nset -eu\ncd "$(dirname "$0")"\n'
          'blockMesh > log.blockMesh 2>&1\ncheckMesh > log.checkMesh 2>&1\n'
          'fvmTimeNotebook > log.solve 2>&1\n')

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('problem',choices=['cooling','rod-robin','rod-fixed','rod-mixed'])
    p.add_argument('scheme')
    p.add_argument('directory')
    p.add_argument('--steps',nargs='+',type=float,default=[.1,.1,.1])
    p.add_argument('--density-slope',type=float,default=0)
    a=p.parse_args()
    create(a.directory,a.problem,a.scheme,a.steps,a.density_slope)
