# OpenFOAM中的有限体积法：原生程序与算例

环境为 Linux、OpenCFD OpenFOAM v2512，需安装开发头文件、`wmake` 和 Python 3。先加载 OpenFOAM 环境，再把本包解压到 Linux 本地文件系统。

## 编译与运行

```bash
sh Allwmake
sh cases/diffusion-20/Allrun
```

第一条编译课程的求解器、检查程序和运行时模型库；第二条生成网格并求解两端分别为 1、0 的稳态扩散问题。其他案例同样进入其目录执行 `sh Allrun`，日志保存在案例目录。

```bash
sh Allrun
sh Allrun --all
sh Allrun cases/turbulence/channel-kOmegaSST
```

不带参数时运行五组基础算例。`--all` 运行 `case-manifest.json` 中已通过检查的配置，包括嵌套目录；耗时较长。也可以传入一个或多个具体案例路径。运行结果另存为 `run-report.json`，已有的验证数据保留在 `verification`。

运行前使用新的解压副本或复制案例，可保留上一次计算。部分 OpenFOAM `RunFunctions` 会跳过已有日志对应的步骤；需要重算时应先归档该案例的旧结果与日志。`Allrun` 不自动删除已有计算。

正文中的路径相对于本目录。逐节代码索引见 [COURSE-MAP.md](COURSE-MAP.md)，每项列出讲解位置、实现文件与检查对象。

## 章节与文件

|章节|程序和目录|学习内容与输出|
|---|---|---|
|2—6|`fvmBookFoam`；`diffusion-*`、`source-*`、`gradient-skew`|守恒、扩散、源项与解析梯度；输出字段、几何、面连接和矩阵|
|6—7|`fvmMeshNotebook`；`mesh-notebook`、`mesh-notebook-lshape`、`mesh-notebook-elbow`|owner/neighbour、面积闭合、弯管与 L 形区域梯度；`-layout-check` 核对面场和历史时间层；输出 `notebook`|
|8|`fvmDiffusionNotebook`；`diffusion-exercises/*`|三种非正交分解、四轮迭代、混合边界；输出每轮变化、最终场和边界通量|
|9、11|`bookInterpolation`；`oblique-*`、`polynomial-*`、`smith-hutton-*`|面重构、斜向阶跃、曲线输运与旋转输运|
|10|`fvmAlgebraNotebook`；`algebra-notebook`|矩阵系数、迭代、残差和小矩阵练习|
|12|`bookInterpolation`、`fvmHRNotebook`；同名前缀的高分辨率案例|NVD、TVD、SMART、OSHER、MUSCL 等；收敛场、有界性与失败对照记录|
|13|`fvmTimeNotebook`；`time/*`、`decay-*`、`diffusion-transient`|时间推进、变步长、稳定性和时间误差|
|14|`fvmSourceNotebook`；`sources/*`|源项线性化与 FitzHugh–Nagumo 反应扩散|
|15|`fvmPressureNotebook`；`pressure/*`、`cavity`|SIMPLE、SIMPLEC、PISO、压力增量、通道与涡场|
|16|`fvmCompressibleNotebook`、`bookCompressibleBoundary`；`compressible/*`|喷管、可压缩压力修正、质量通量、等熵关系与网格比较|
|17|`fvmWallDistanceNotebook`、`bookLimitedKEpsilon`；`turbulence/*`|Poisson 壁距、标准模型与时间尺度限制模型|
|18|`bookBoundaryConditions`、`fvmBoundaryNotebook`；`boundaries/*`|旋转壁面的值、梯度和矩阵系数|
|19|`ahmed-body`、`ahmed-body-layered`|25° Ahmed 钝体；网格、壁面层、力系数和流场采样|
|附录|各程序的 `Make`、`0`、`constant`、`system`|由原生网格、场、矩阵和时间对象组织完整求解过程|

`backward-step`、`compressible-bend` 和 `coded-inlet` 另用于观察现成流动求解器及动态边界。各案例的 `SOURCE.txt` 或几何来源文件记录来源。

## 变量、矩阵与误差

`fvmBookFoam` 求解

```text
dc/dt + div(U c) - div(D grad c) + decay*c = source
```

`c` 无量纲，`D` 单位 m²/s，`decay` 和 `source` 单位 s⁻¹；`steadyState` 关闭时间项。`matrix.txt` 中内部 `diag/upper/lower` 与边界系数分开保存，不能把裸 `diag` 当作已加入所有边界贡献的完整矩阵。

`diffusion-*` 的解析解为 `1-x`，`source-*` 的解析解为 `x(1-x)`。`gradient-skew` 用 `1+2x+3y` 检查梯度，`decay-*` 用 `exp(-t)` 比较时间推进，`diffusion-transient` 用 `sin(pi*x)*exp(-0.1*pi²*t)` 检查瞬态扩散。

`fvmDiffusionNotebook` 以单位扩散系数装配三种分解；给定值边界的显式修正使用相邻单元梯度。其离散选择在第 8 章说明，不能将不同分解下的有限网格结果强行视为相同。

## 实际运行记录

`verification` 保存日志、原始数据、独立误差检查和各组 `report.json`。稳态程序的 `Time` 是迭代编号，瞬态程序的时间是物理秒数；壁距、矩阵和边界程序则是算子检查。

`verification/structure` 保存弯管梯度、L 形网格的面场与历史层检查，以及 20 单元扩散矩阵的实际输出。`independent-numerics.json` 保存第 8 章 Gauss–Seidel 迭代与第 13 章隐式梯形温度表的独立计算结果。

高分辨率格式中有五组不收敛对照，网页保留其原因和残差记录。它们不参加 `--all` 的成功配置队列，但仍可按路径单独运行。可压缩高阶试验位于 `experiments/compressible/diverging-limited-160`，达到最大迭代数仍未满足残差要求，未作为收敛结果绘图。

Ahmed 基准网格为 39369 单元、259 轮；带壁面层的网格为 190147 单元、433 轮，末轮 Cd 约 0.543740，车体平均 y+ 约 59。地面与局部车体的壁面分辨率、离散格式及尾流网格仍影响预测，正文分别分析迭代收敛与流场精度。

`ahmed-body-layered/Allrun` 求解后自动生成采样点，并输出中心面和尾流横截面。原始采样值与力系数同时保存在验证目录，可直接在 ParaView 中读取完整场继续分析。

## 来源与许可证

课程代码为 GPL-3.0-or-later。由 OpenFOAM 源码修改的模型保留原始版权和许可证；`bookLimitedKEpsilon` 的来源与改动散列在对应目录及验证记录中。STL 来源和固定版本见 `geometry/SOURCE.json` 与各案例 `SOURCE.txt`。
