# OpenFOAM中的有限体积法 配套程序

环境：OpenCFD OpenFOAM v2512，Linux，带 wmake 与开发头文件。

在已加载 OpenFOAM 的终端，将本目录复制到 Linux 本地文件系统，执行 `sh Allrun`。
只编译求解器：`sh Allwmake`。单独运行：`sh cases/diffusion-20/Allrun`。
每个案例包含完整的 0、constant、system。结果在相应时间目录中；solution.csv 保存末时刻单元中心与浓度，geometry.csv 保存体积与中心，internal-faces.csv 保存内面的拓扑与面积向量。

fvmBookFoam 求解 dc/dt + div(U c) - div(D grad c) + decay*c = source。
c 无量纲；D 单位 m²/s；decay 和 source 单位 s⁻¹。steadyState 关闭时间项。
matrix.txt 的 diag/upper/lower 是求解前内部系数，边界系数另列，不能把裸 diag 当作施加边界后的完整矩阵。
gradient.csv 使用解析线性场 1+2x+3y，正确梯度为 (2,3,0) m⁻¹。

diffusion-*：两端 1 和 0，解析解 1-x。
source-*：两端 0，D=1，源项 2，解析解 x(1-x)，用于网格误差分析。
gradient-skew：倾斜网格上的线性场梯度测试。
advection-*：入口阶跃，U=1 m/s，D=0.0001 m²/s，运行到 0.5 s，对比迎风与 vanLeer。
decay-*：封闭均匀衰减，解析解 exp(-t)，对比 Euler 与 backward。
diffusion-transient：两端为零，初始 sin(pi*x)，解析解 sin(pi*x)*exp(-0.1*pi²*t)。

代码由 FoamLab 编写，许可证 GPL-3.0-or-later。OpenFOAM 库及由官方教程复制的文件保留其原始许可证和来源。

cavity：边长 0.1 m、顶盖 1 m/s、运动黏度 0.001 m²/s，Re=100，运行至 2 s。
backward-step：v2512 pitzDaily 的稳态台阶流，使用 simpleFoam；来源在案例内 SOURCE.txt。
compressible-bend：v2512 squareBend 的可压缩弯管流，使用 rhoSimpleFoam；预处理所需采样几何已放在 constant/triSurface。
coded-inlet：codedFixedValue 动态编译标量入口，c=1-exp(-t/0.1)，运行至 0.5 s。
ahmed-body：25° Ahmed 车体，半域、40 m/s、标准 k-epsilon，原书第 19 章的 v2512 实现；STL 来源与固定版本见 geometry/SOURCE.json。

verification/report.json 汇总网格、终止时刻和误差；各子目录保留对应日志和数据。稳态算法的 Time 表示迭代步，不是物理秒数。gradient-skew 的验证对象是解析梯度，两次标量迭代只用于展示矩阵。
Ahmed 基准网格在第 259 轮满足残差控制，Cd 约 0.609672；车体平均 y+ 约 673。应在启用壁面层、改善近壁与尾流分辨率并完成网格研究后，再与实验比较阻力。

修改初值后再次运行时，先确认 controlDict 的 startFrom 为 startTime；需要保留旧结果时复制整个案例。RunFunctions 管理的步骤若发现已有日志会跳过，compressible-bend 更改预处理设置后应将旧 log.blockMesh、log.surfaceMeshExtract、log.surfaceTransformPoints、log.surfaceRefineRedGreen 移走再运行。
