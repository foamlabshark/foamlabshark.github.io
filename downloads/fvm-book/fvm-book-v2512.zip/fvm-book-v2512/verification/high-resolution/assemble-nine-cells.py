"""Reassemble the Chapter 12 nine-cell NWF and DWF systems from verified fields.

Coordinates use a unit-depth 2D domain. Uses only the Python standard library.
Cells are numbered left-to-right, top-to-bottom as in the textbook.
"""
from pathlib import Path
import csv,json
ROOT=Path(__file__).resolve().parent
def value(name):
    c=[0.0]*9
    with (ROOT/name/'solution.csv').open() as f:
        for row in csv.DictReader(f):
            vals=list(map(float,row.values()));x,y,v=vals[:3]
            i=round(3*x-.5);j=round(3*y-.5)
            c[(2-j)*3+i]=v
    return c
def assemble(name,method):
    c=value(name);h=1/3
    idx=lambda i,j:(2-j)*3+i
    g=[]
    for k in range(9):
        j=2-k//3;i=k%3
        w=(c[k]+c[idx(i-1,j)])/2 if i else c[k]
        e=(c[k]+c[idx(i+1,j)])/2 if i<2 else c[k]
        b=(c[k]+c[idx(i,j-1)])/2 if j else c[k]
        t=(c[k]+c[idx(i,j+1)])/2 if j<2 else (10 if i==0 else 0)
        g.append(((e-w)/h,(t-b)/h))
    A=[[0.0]*9 for _ in range(9)];b=[0.0]*9;faces=[]
    for j in range(3):
        for i in range(3):
            o=idx(i,j);xc=(i+.5)*h;yc=(j+.5)*h
            if i==2:A[o][o]+=2*yc*h
            if j==2:b[o]+=2*xc*h*(10 if i==0 else 0)
            candidates=[]
            if i<2:candidates.append((idx(i+1,j),2*yc*((i+1)*h)**2*h,(h,0)))
            if j<2:candidates.append((idx(i,j+1),-2*xc*((j+1)*h)**2*h,(0,h)))
            for n,m,d in candidates:
                u,v=(o,n) if m>=0 else (n,o)
                du=d if m>=0 else (-d[0],-d[1])
                far=c[v]-2*sum(a*z for a,z in zip(g[u],du))
                delta=c[v]-far;s=(c[u]-far)/delta if abs(delta)>1e-13 else 0
                if method=='NWF':
                    if not 0<s<1:l,k=1,0
                    elif s<1/3:l,k=2,0
                    elif s<.5:l,k=.5,.5
                    elif s<2/3:l,k=1.5,0
                    else:l,k=0,1
                    explicit=(1-l-k)*far
                else:
                    r=(c[u]-far)/(c[v]-c[u]) if abs(c[v]-c[u])>1e-13 else 0
                    psi=max(0,min(2*r,(1+r)/2,2));k=.5*psi;l=1-k;explicit=0
                for row,sgn in [(o,1),(n,-1)]:
                    A[row][u]+=sgn*m*l;A[row][v]+=sgn*m*k;b[row]-=sgn*m*explicit
                faces.append(dict(owner=o+1,neighbour=n+1,massFlux=m,
                    upstream=u+1,downstream=v+1,virtualUp=far,s=s,
                    upWeight=l,downWeight=k,explicit=explicit))
    residual=max(abs(sum(x*y for x,y in zip(row,c))-rhs) for row,rhs in zip(A,b))
    assert residual<2e-8,(name,residual)
    return dict(numbering='left-to-right, top-to-bottom',method=method,c=c,
        A=A,b=b,maxEquationResidual=residual,faces=faces)
out={m:assemble(n,m) for m,n in [('NWF','polynomial-bookSUPERBEE-3'),('DWF','polynomial-MUSCL-3')]}
(ROOT/'nine-cell-matrices.json').write_text(json.dumps(out,indent=2),encoding='utf8')
for m,v in out.items():
    print(m,'residual',v['maxEquationResidual'])
    for row,rhs in zip(v['A'],v['b']):print(' '.join(f'{a:9.6f}' for a in row),'|',f'{rhs:9.6f}')
