"""Independent Chapter 13 algebra and native time-matrix checks.

Uses only Python's standard library. All values are recomputed from coefficients,
not copied from the OpenFOAM CSV outputs.
"""
from pathlib import Path
import json,csv,math
ROOT=Path(__file__).resolve().parent

def solve(A,b):
    det=A[0][0]*A[1][1]-A[0][1]*A[1][0]
    return [(b[0]*A[1][1]-A[0][1]*b[1])/det,
            (A[0][0]*b[1]-b[0]*A[1][0])/det]

def operator(problem):
    if problem=='cooling':return [[1.,0.],[0.,1.]],[0.,0.]
    dx=.015;k=55;capacity=7000*400*dx
    G=k/dx
    left=2*k/dx if problem=='rod-mixed' else 0
    right=2*k/dx if problem=='rod-fixed' else 1/(dx/(2*k)+1/400)
    return [[(G+left)/capacity,-G/capacity],
            [-G/capacity,(G+right)/capacity]], [left*260/capacity,right*330/capacity]

def product(A,v):
    return [sum(a*b for a,b in zip(row,v)) for row in A]

def integrate(problem,method,steps,finite_volume=False):
    A,b=operator(problem);initial=1 if problem=='cooling' else 273
    old=[float(initial)]*2;older=old[:];out=[];time=0
    for n,h in enumerate(steps):
        k=steps[n-1] if n else h
        ell=steps[n-2] if n>1 else steps[0]
        if finite_volume and n: time+=(h+k)/2
        else: time+=h
        if method=='FE':
            v=[old[i]+h*(b[i]-product(A,old)[i]) for i in range(2)]
        elif method=='Euler' or n==0:
            v=solve([[A[i][j]+(1/h if i==j else 0) for j in range(2)] for i in range(2)],
                    [b[i]+old[i]/h for i in range(2)])
        elif method=='backward':
            if finite_volume:
                ca=(1+h/(h+k))/h
                cb=-(1+h/(h+k)+k/(k+ell))/h
                cc=k/(h*(k+ell))
            else:
                ca=1/h+1/(h+k);cb=-(1/h+1/k);cc=h/(k*(h+k))
            v=solve([[A[i][j]+(ca if i==j else 0) for j in range(2)] for i in range(2)],
                    [b[i]-cb*old[i]-cc*older[i] for i in range(2)])
        elif method=='LF':
            if finite_volume:
                ca=1/(h+k);cb=(h/(h+k)-ell/(k+ell))/k;cc=-1/(k+ell)
            else:
                ca=k/(h*(h+k));cb=(h-k)/(h*k);cc=-h/(k*(h+k))
            v=[(b[i]-product(A,old)[i]-cb*old[i]-cc*older[i])/ca for i in range(2)]
        elif method.startswith('CrankNicolson'):
            alpha=float(method.split()[1]);ca=(1+alpha)/h
            v=solve([[A[i][j]+(ca if i==j else 0) for j in range(2)] for i in range(2)],
                    [ca*old[i]-alpha*product(A,old)[i]+(1+alpha)*b[i] for i in range(2)])
        else:raise ValueError(method)
        out.append(dict(time=time,values=v))
        older,old=old,v
    return out

def main():
    report=json.loads((ROOT/'native-runs.json').read_text())
    checks=[];worst=0
    for case in report['cases']:
        assert case['exit']==0,case['name']
        expected=integrate(case['problem'],case['scheme'],case['steps'])
        rows=list(csv.DictReader((ROOT/case['name']/'time-values.csv').open()))
        assert len(rows)==2*len(expected)
        err=0;matrix_error=0;balance=0
        A,b=operator(case['problem'])
        for row in rows:
            n=int(row['step'])-1;i=int(row['cell']);h=case['steps'][n]
            rho=1+case['density']*expected[n]['time']
            value=expected[n]['values'][i]/rho if case['problem']=='cooling' else expected[n]['values'][i]
            err=max(err,abs(float(row['c'])-value)/max(1,abs(value)))
            if not n or case['scheme']=='Euler':ca=1/h
            elif case['scheme']=='backward':ca=1/h+1/(h+case['steps'][n-1])
            else:ca=(1+float(case['scheme'].split()[1]))/h
            matrix_error=max(matrix_error,abs(float(row['ddtDiagPerVolume'])-ca*rho)/max(1,ca*rho))
            # At the converged new field, history equals a*q + A*q - b.
            q=expected[n]['values']
            expected_history=ca*q[i]+product(A,q)[i]-b[i]
            matrix_error=max(matrix_error,abs(float(row['ddtSourcePerVolume'])-expected_history)/max(1,abs(expected_history)))
            balance=max(balance,abs(float(row['balance'])))
        worst=max(worst,err,matrix_error)
        checks.append(dict(name=case['name'],fieldError=err,matrixError=matrix_error,balance=balance))
    exercises={}
    for method in ['FE','Euler']:
        exercises['exercise1-'+method]=integrate('rod-robin',method,[20]*3)
    for name,steps,fv in [('uniform',[20]*3,False),('variableFD',[10,20,30],False),('variableFV',[10,20,30],True)]:
        exercises['exercise2-'+name]=integrate('rod-fixed','backward',steps,fv)
        exercises['exercise3-LF-'+name]=integrate('rod-mixed','LF',steps,fv)
    exercises['exercise3-nativeCN-uniform']=integrate('rod-mixed','CrankNicolson 1',[20]*3)
    exercises['exercise3-nativeCN-variable']=integrate('rod-mixed','CrankNicolson 1',[10,20,30])
    identities=[]
    for h,k in [(.1,.1),(.2,.1),(.1,.3),(10,20)]:
        ts=[0,-h,-h-k];coeff=[1/h+1/(h+k),-(1/h+1/k),h/(k*(h+k))]
        for power in range(3):
            approx=sum(c*t**power for c,t in zip(coeff,ts))
            exact=1 if power==1 else 0
            assert abs(approx-exact)<1e-11,(h,k,power,approx)
            identities.append(dict(h=h,k=k,power=power,error=abs(approx-exact)))
    out=dict(maxRelativeError=worst,nativeChecks=checks,polynomialChecks=identities,exercises=exercises)
    (ROOT/'report.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
    print(json.dumps(out,indent=2))
    assert worst<1e-10,worst

if __name__=='__main__':main()
