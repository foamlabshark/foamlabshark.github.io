"""Independent network solution and pressure-increment matrix checks."""
from pathlib import Path
import json
import numpy as np
r=Path(__file__).parent/'exercises';report={}
d=np.genfromtxt(r/'gas-network.csv',delimiter=',',names=True)
# Solve for squared pressures directly instead of repeating Newton's iteration.
A=np.array([[1.4+1.2+1.8,-1.2,-1.8],[-1.2,1.2+1.2+1.6,-1.6],[-1.8,-1.6,1.8+1.6]])
b=np.array([1.4*350**2,1.2*400**2,-25*4000])
exact=np.sqrt(np.linalg.solve(A,b));got=np.array([d[-1][k] for k in ['p3','p4','p5']])
assert np.max(abs(exact-got))<1e-9
report['network']=dict(pressures=got.tolist(),maxPressureError=float(np.max(abs(exact-got))),massResidual=float(d[-1]['maxMassResidual']))
for name in ['subsonic','supersonic']:
 a=np.genfromtxt(r/f'nozzle-{name}-matrices.csv',delimiter=',',names=True)
 f=np.genfromtxt(r/f'nozzle-{name}-three.csv',delimiter=',',names=True)
 errors=[]
 for it in [1,2,3]:
  rows=a[a['iteration']==it]
  M=np.column_stack([rows[k] for k in ['a0','a1','a2']]);rhs=rows['b'];x=rows['pPrime']
  errors.append(float(np.max(abs(M@x-rhs))))
  assert np.max(abs(np.linalg.solve(M,rhs)-x))<1e-8
 assert max(errors)<1e-9 and np.max(abs(f['linearMassResidual']))<1e-10
 assert np.all(f['p']>0) and np.all(f['T']>0)
 report[name]=dict(maxMatrixResidual=max(errors),maxLinearMassResidual=float(np.max(abs(f['linearMassResidual']))))
(r/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
