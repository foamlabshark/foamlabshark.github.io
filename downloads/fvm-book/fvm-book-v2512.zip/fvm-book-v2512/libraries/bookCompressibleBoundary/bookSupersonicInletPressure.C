#include "fixedValueFvPatchFields.H"
#include "addToRunTimeSelectionTable.H"
#include "volFields.H"
namespace Foam
{
// Fixed thermodynamic pressure for the convective pressure term; no
// pressure-Laplacian flux correction at a fully prescribed supersonic inlet.
class bookSupersonicInletPressureFvPatchScalarField
:
    public fixedValueFvPatchScalarField
{
    using Base=fixedValueFvPatchScalarField;
public:
    TypeName("bookSupersonicInletPressure");
    bookSupersonicInletPressureFvPatchScalarField
    (const fvPatch& p,const DimensionedField<scalar,volMesh>& i):Base(p,i){}
    bookSupersonicInletPressureFvPatchScalarField
    (const fvPatch& p,const DimensionedField<scalar,volMesh>& i,const dictionary& d):Base(p,i,d){}
    bookSupersonicInletPressureFvPatchScalarField
    (const bookSupersonicInletPressureFvPatchScalarField& f,const fvPatch& p,
     const DimensionedField<scalar,volMesh>& i,const fvPatchFieldMapper& m):Base(f,p,i,m){}
    bookSupersonicInletPressureFvPatchScalarField
    (const bookSupersonicInletPressureFvPatchScalarField& f):Base(f){}
    bookSupersonicInletPressureFvPatchScalarField
    (const bookSupersonicInletPressureFvPatchScalarField& f,const DimensionedField<scalar,volMesh>& i):Base(f,i){}
    virtual tmp<fvPatchScalarField> clone() const
    {return fvPatchScalarField::Clone(*this);}
    virtual tmp<fvPatchScalarField> clone(const DimensionedField<scalar,volMesh>& i) const
    {return fvPatchScalarField::Clone(*this,i);}
    virtual tmp<scalarField> gradientInternalCoeffs() const
    {return tmp<scalarField>::New(size(),scalar(0));}
    virtual tmp<scalarField> gradientBoundaryCoeffs() const
    {return tmp<scalarField>::New(size(),scalar(0));}
};
makePatchTypeField(fvPatchScalarField,bookSupersonicInletPressureFvPatchScalarField);
}
