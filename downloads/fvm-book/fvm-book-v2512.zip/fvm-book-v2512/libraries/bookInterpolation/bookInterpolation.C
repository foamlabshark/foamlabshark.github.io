/* FoamLab textbook interpolation exercises; GPL-3.0-or-later. */
#include "fvCFD.H"
#include "upwind.H"
#include "surfaceInterpolationScheme.H"
#include "addToRunTimeSelectionTable.H"
#include "bookHRFunctions.H"

namespace Foam
{
typedef surfaceInterpolationScheme<scalar> scalarInterpolation;

class bookGeometric : public scalarInterpolation
{
    static scalar weight(const scalar a, const scalar b)
    {
        if (a<0 || b<0)
            FatalErrorInFunction<<"Geometric average requires nonnegative values"
                <<exit(FatalError);
        const scalar sa=sqrt(a), sb=sqrt(b);
        return sa+sb>VSMALL ? sb/(sa+sb) : 0.5;
    }
public:
    TypeName("bookGeometric");
    bookGeometric(const fvMesh& mesh,Istream&) : scalarInterpolation(mesh) {}
    bookGeometric(const fvMesh& mesh,const surfaceScalarField&,Istream&)
    : scalarInterpolation(mesh) {}

    virtual tmp<surfaceScalarField> weights(const volScalarField& vf) const
    {
        tmp<surfaceScalarField> tw
        (
            new surfaceScalarField
            (
                IOobject("bookGeometricWeights",mesh().time().timeName(),mesh(),
                    IOobject::NO_READ,IOobject::NO_WRITE,IOobject::NO_REGISTER),
                mesh(),dimensionedScalar(dimless,0.5)
            )
        );
        surfaceScalarField& w=tw.ref();
        forAll(mesh().neighbour(),f)
            w[f]=weight(vf[mesh().owner()[f]],vf[mesh().neighbour()[f]]);
        forAll(w.boundaryField(),p)
        {
            if (vf.boundaryField()[p].coupled())
            {
                const scalarField nei(vf.boundaryField()[p].patchNeighbourField());
                const labelUList& own=mesh().boundary()[p].faceCells();
                forAll(nei,f) w.boundaryFieldRef()[p][f]=weight(vf[own[f]],nei[f]);
            }
        }
        return tw;
    }
    virtual tmp<surfaceScalarField> interpolate(const volScalarField& vf) const
    {
        return scalarInterpolation::interpolate(vf,weights(vf));
    }
};

class bookSOU : public upwind<scalar>
{
    word gradientName_;
    static vector faceGradient
    (
        const vector& go,const vector& gn,const vector& d,
        const scalar delta,const scalar lambda
    )
    {
        const vector g=lambda*go+(1-lambda)*gn;
        return g+d*(delta-(g&d))/magSqr(d);
    }
protected:
    virtual scalar centreFactor() const {return 2;}
    virtual scalar faceFactor() const {return -1;}
public:
    TypeName("bookSOU");
    bookSOU(const fvMesh& mesh,Istream& is)
    : upwind<scalar>(mesh,is),gradientName_(is) {}
    bookSOU(const fvMesh& mesh,const surfaceScalarField& flux,Istream& is)
    : upwind<scalar>(mesh,flux,is),gradientName_(is) {}
    virtual bool corrected() const {return true;}
    virtual tmp<surfaceScalarField> correction(const volScalarField& vf) const
    {
        const fvMesh& m=this->mesh();
        const volVectorField grad(fvc::grad(vf,gradientName_));
        const surfaceScalarField& lambda=m.surfaceInterpolation::weights();
        tmp<surfaceScalarField> t
        (
            new surfaceScalarField
            (
                IOobject("bookSOUCorrection",m.time().timeName(),m,
                    IOobject::NO_READ,IOobject::NO_WRITE,IOobject::NO_REGISTER),
                m,dimensionedScalar(vf.dimensions(),0)
            )
        );
        surfaceScalarField& corr=t.ref();
        forAll(m.neighbour(),f)
        {
            const label o=m.owner()[f],n=m.neighbour()[f];
            const vector d=m.C()[n]-m.C()[o];
            const vector gf=faceGradient(grad[o],grad[n],d,vf[n]-vf[o],lambda[f]);
            const label u=this->faceFlux_[f]>=0 ? o:n;
            corr[f]=(centreFactor()*grad[u]+faceFactor()*gf)&(m.Cf()[f]-m.C()[u]);
        }
        forAll(corr.boundaryField(),p)
        {
            if (!vf.boundaryField()[p].coupled()) continue;
            const scalarField vn(vf.boundaryField()[p].patchNeighbourField());
            const vectorField gn(grad.boundaryField()[p].patchNeighbourField());
            const vectorField d(m.boundary()[p].delta());
            const labelUList& own=m.boundary()[p].faceCells();
            forAll(own,f)
            {
                const label o=own[f];
                const vector gf=faceGradient(grad[o],gn[f],d[f],vn[f]-vf[o],
                    lambda.boundaryField()[p][f]);
                const bool out=this->faceFlux_.boundaryField()[p][f]>=0;
                const vector gu=out ? grad[o]:gn[f];
                const vector du=m.Cf().boundaryField()[p][f]-m.C()[o]-(out?vector::zero:d[f]);
                corr.boundaryFieldRef()[p][f]=(centreFactor()*gu+faceFactor()*gf)&du;
            }
        }
        return t;
    }
};

class bookQUICK : public bookSOU
{
protected:
    virtual scalar centreFactor() const {return 0.5;}
    virtual scalar faceFactor() const {return 0.5;}
public:
    TypeName("bookQUICK");
    bookQUICK(const fvMesh& mesh,Istream& is) : bookSOU(mesh,is) {}
    bookQUICK(const fvMesh& mesh,const surfaceScalarField& flux,Istream& is)
    : bookSOU(mesh,flux,is) {}
};

class bookHR : public upwind<scalar>
{
    word scheme_,gradientName_;
    void checkScheme() const
    {
        if (scheme_!="SMART" && scheme_!="SMART_TVD" && scheme_!="STOIC"
            && scheme_!="OSHER" && scheme_!="MINMOD" && scheme_!="MUSCL"
            && scheme_!="SUPERBEE" && scheme_!="boundedCD" && scheme_!="smoothCD")
            FatalErrorInFunction<<"Unknown textbook HR scheme "<<scheme_
                <<exit(FatalError);
    }
public:
    TypeName("bookHR");
    bookHR(const fvMesh& m,Istream& is)
    : upwind<scalar>(m,is),scheme_(is),gradientName_(is) {checkScheme();}
    bookHR(const fvMesh& m,const surfaceScalarField& flux,Istream& is)
    : upwind<scalar>(m,flux,is),scheme_(is),gradientName_(is) {checkScheme();}
    virtual bool corrected() const {return true;}
    virtual tmp<surfaceScalarField> correction(const volScalarField& vf) const
    {
        const fvMesh& m=this->mesh();
        const volVectorField g(fvc::grad(vf,gradientName_));
        tmp<surfaceScalarField> t
        (
            new surfaceScalarField
            (
                IOobject("bookHRCorrection",m.time().timeName(),m,
                    IOobject::NO_READ,IOobject::NO_WRITE,IOobject::NO_REGISTER),
                m,dimensionedScalar(vf.dimensions(),0)
            )
        );
        surfaceScalarField& c=t.ref();
        forAll(m.neighbour(),f)
        {
            const label o=m.owner()[f],n=m.neighbour()[f];
            const bool out=this->faceFlux_[f]>=0;
            const label u=out?o:n,d=out?n:o;
            const scalar vu=vf[d]-2*(g[u]&(m.C()[d]-m.C()[u]));
            c[f]=bookHRFunctions::correction(scheme_,vf[u],vf[d],vu);
        }
        forAll(c.boundaryField(),p)
        {
            if (!vf.boundaryField()[p].coupled()) continue;
            const scalarField vn(vf.boundaryField()[p].patchNeighbourField());
            const vectorField gn(g.boundaryField()[p].patchNeighbourField());
            const vectorField delta(m.boundary()[p].delta());
            const labelUList& own=m.boundary()[p].faceCells();
            forAll(own,f)
            {
                const label o=own[f];
                const bool out=this->faceFlux_.boundaryField()[p][f]>=0;
                const scalar u=out?vf[o]:vn[f],d=out?vn[f]:vf[o];
                const vector gu=out?g[o]:gn[f],du=out?delta[f]:-delta[f];
                const scalar vu=d-2*(gu&du);
                c.boundaryFieldRef()[p][f]=bookHRFunctions::correction(scheme_,u,d,vu);
            }
        }
        return t;
    }
};

defineTypeNameAndDebug(bookHR,0);
addToRunTimeSelectionTable(scalarInterpolation,bookHR,Mesh);
addToRunTimeSelectionTable(scalarInterpolation,bookHR,MeshFlux);
defineTypeNameAndDebug(bookGeometric,0);
addToRunTimeSelectionTable(scalarInterpolation,bookGeometric,Mesh);
addToRunTimeSelectionTable(scalarInterpolation,bookGeometric,MeshFlux);
defineTypeNameAndDebug(bookSOU,0);
addToRunTimeSelectionTable(scalarInterpolation,bookSOU,Mesh);
addToRunTimeSelectionTable(scalarInterpolation,bookSOU,MeshFlux);
defineTypeNameAndDebug(bookQUICK,0);
addToRunTimeSelectionTable(scalarInterpolation,bookQUICK,Mesh);
addToRunTimeSelectionTable(scalarInterpolation,bookQUICK,MeshFlux);
}
