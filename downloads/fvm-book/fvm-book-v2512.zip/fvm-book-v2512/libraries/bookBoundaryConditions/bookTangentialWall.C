// Chapter 18: boundary-gradient coefficients for a projected tangential traction.
// The face velocity remains prescribed. Use with the matching traction operator.
#include "fixedValueFvPatchFields.H"
#include "addToRunTimeSelectionTable.H"
#include "volFields.H"
namespace Foam
{
class bookTangentialWallFvPatchVectorField : public fixedValueFvPatchVectorField
{
    using Base=fixedValueFvPatchVectorField;
public:
    TypeName("bookTangentialWall");
    bookTangentialWallFvPatchVectorField
    (const fvPatch& p,const DimensionedField<vector,volMesh>& i):Base(p,i){}
    bookTangentialWallFvPatchVectorField
    (const fvPatch& p,const DimensionedField<vector,volMesh>& i,const dictionary& d):Base(p,i,d){}
    bookTangentialWallFvPatchVectorField
    (const bookTangentialWallFvPatchVectorField& f,const fvPatch& p,
     const DimensionedField<vector,volMesh>& i,const fvPatchFieldMapper& m):Base(f,p,i,m){}
    bookTangentialWallFvPatchVectorField
    (const bookTangentialWallFvPatchVectorField& f):Base(f){}
    bookTangentialWallFvPatchVectorField
    (const bookTangentialWallFvPatchVectorField& f,const DimensionedField<vector,volMesh>& i):Base(f,i){}
    virtual tmp<fvPatchVectorField> clone() const
    {return fvPatchVectorField::Clone(*this);}
    virtual tmp<fvPatchVectorField> clone(const DimensionedField<vector,volMesh>& i) const
    {return fvPatchVectorField::Clone(*this,i);}
    virtual tmp<vectorField> gradientInternalCoeffs() const
    {
        const vectorField n(patch().nf());
        return -(vector::one-cmptMultiply(n,n))*patch().deltaCoeffs();
    }
    virtual tmp<vectorField> gradientBoundaryCoeffs() const
    {
        const vectorField n(patch().nf());
        const vectorField Uc(patchInternalField());
        const vectorField Uw(*this);
        const vectorField wallT(Uw-(Uw&n)*n);
        const vectorField cross(n*(n&Uc)-cmptMultiply(cmptMultiply(n,n),Uc));
        return patch().deltaCoeffs()*(wallT+cross);
    }
    virtual tmp<vectorField> snGrad() const
    {
        return cmptMultiply(gradientInternalCoeffs()(),patchInternalField()())
              +gradientBoundaryCoeffs()();
    }
    virtual tmp<vectorField> snGrad(const scalarField& dc) const
    {
        const vectorField n(patch().nf());
        const vectorField du(*this-patchInternalField());
        return dc*(du-(du&n)*n);
    }
};
makePatchTypeField(fvPatchVectorField,bookTangentialWallFvPatchVectorField);
}
