"""Run a complete case, using first-order startup before a high-order solve."""
from pathlib import Path
import subprocess,json,time,re,sys
case=Path.cwd();spec=json.loads((case/'case.json').read_text());start=time.time();steps={}
def run(command,log):
 with (case/log).open('w') as f:
  r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 steps[log]=r.returncode
 if r.returncode:raise RuntimeError(log)
try:
 run(['blockMesh'],'log.blockMesh')
 run(['checkMesh'],'log.checkMesh')
 if spec.get('highOrder'):
  final=(case/'system/fvSchemes.highOrder').read_text()
  (case/'system/fvSchemes').write_text(final.replace('limitedLinearV 1','upwind').replace('limitedLinear 1','upwind'))
  run(['rhoSimpleFoam'],'log.startup')
  if 'SIMPLE solution converged' not in (case/'log.startup').read_text():raise RuntimeError('startup did not converge')
  dirs=[p for p in case.iterdir() if p.is_dir() and re.fullmatch(r'\d+(?:\.\d+)?',p.name)]
  latest=max(float(p.name) for p in dirs)
  (case/'system/fvSchemes').write_text(final)
  c=(case/'system/controlDict').read_text()
  c=re.sub(r'startFrom\s+\w+;', 'startFrom latestTime;',c)
  c=re.sub(r'endTime\s+[\d.]+;',f'endTime {latest+32000:g};',c)
  (case/'system/controlDict').write_text(c)
  # The corrected high-order fluxes need a smaller nonlinear update.
  f=case/'system/fvSolution';s=f.read_text().replace('U 0.5;','U 0.15;').replace('h 0.5;','h 0.15;')
  f.write_text(s)
 run(['rhoSimpleFoam'],'log.rhoSimpleFoam')
 if 'SIMPLE solution converged' not in (case/'log.rhoSimpleFoam').read_text():raise RuntimeError('residual criteria not reached')
 status=0
except RuntimeError as e:
 print(str(e));status=1
(case/'run-status.json').write_text(json.dumps(dict(exit=status,steps=steps,seconds=time.time()-start)))
sys.exit(status)
