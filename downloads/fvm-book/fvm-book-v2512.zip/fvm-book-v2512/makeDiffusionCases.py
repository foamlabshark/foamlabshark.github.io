from pathlib import Path
import math,json
from makeCompressibleCases import header,block
P=Path(__file__).parent
def make(path,kind,method):
 path=Path(path)
 def write(name,s):
  p=path/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
 n=2 if kind=='four' else 50
 verts=[(0,0),(1,0),(1.6,.8),(.6,.8)] if kind=='four' else [(0,0),(1,0),(2,math.sqrt(3)),(1,math.sqrt(3))]
 verts=[(x,y,z) for z in [0,.1] for x,y in verts]
 mesh=header('blockMeshDict')+'scale 1;\nvertices\n(\n'+''.join('    ('+' '.join(f'{x:.16g}' for x in v)+')\n' for v in verts)+');\nblocks\n(\n'+f'    hex (0 1 2 3 4 5 6 7) ({n} {n} 1) simpleGrading (1 1 1)\n'+');\nedges ();\nboundary\n(\n'
 faces={'left':['(0 4 7 3)'],'right':['(1 2 6 5)'],'bottom':['(0 1 5 4)'],'top':['(3 7 6 2)'],'frontAndBack':['(0 3 2 1)','(4 5 6 7)']}
 for name,fs in faces.items():mesh+=block(name,['type '+('empty' if name=='frontAndBack' else 'patch')+';','faces','(']+['    '+f for f in fs]+[');'])
 mesh+=');\nmergePatchPairs ();\n'
 if kind=='lshape':mesh=(P/'cases/mesh-notebook-lshape/system/blockMeshDict').read_text()
 write('system/blockMeshDict',mesh)
 vals={'left':30,'bottom':20,'right':None,'top':None} if kind=='four' else {'left':273,'bottom':273,'right':320,'top':320}
 if kind=='lshape':vals={'patch1':1,'patch2':0,'patch3':None,'patch4':'mixed'}
 s=header('T','volScalarField')+'dimensions [0 0 0 1 0 0 0];\ninternalField uniform '+('25' if kind=='four' else '.5' if kind=='lshape' else '296.5')+';\nboundaryField\n{\n'
 for name,v in vals.items():
  entries=['type zeroGradient;'] if v is None else ['type mixed;','refValue uniform 0.5;','refGradient uniform 0;','valueFraction uniform 0.5;','value uniform 0.5;'] if v=='mixed' else ['type fixedValue;',f'value uniform {v};']
  s+=block(name,entries)
 s+=block('frontAndBack',['type empty;'])+'}\n';write('0/T',s)
 write('system/controlDict',header('controlDict')+'application fvmDiffusionNotebook;\nstartFrom startTime;\nstartTime 0;\nstopAt endTime;\nendTime 1;\ndeltaT 1;\nwriteControl timeStep;\nwriteInterval 1;\nwritePrecision 15;\n')
 write('system/fvSchemes',header('fvSchemes')+block('ddtSchemes',['default steadyState;'])+block('gradSchemes',['default Gauss linear;'])+block('divSchemes',['default none;'])+block('laplacianSchemes',['default Gauss linear corrected;'])+block('interpolationSchemes',['default linear;'])+block('snGradSchemes',['default corrected;']))
 write('system/fvSolution',header('fvSolution')+'solvers\n{\n'+block('T',['solver PCG;','preconditioner DIC;','tolerance 1e-13;','relTol 0;','maxIter 10000;'])+'}\n')
 write('system/notebookDict',header('notebookDict')+f'decomposition {method};\nrelaxation '+('0.9' if kind=='skew' else '1')+';\niterations 10000;\n')
 write('case.json',json.dumps(dict(kind=kind,decomposition=method),indent=2)+'\n')
 write('Allrun','#!/bin/sh\nset -eu\ncd "$(dirname "$0")"\nblockMesh > log.blockMesh 2>&1\ncheckMesh > log.checkMesh 2>&1\nfvmDiffusionNotebook > log.fvmDiffusionNotebook 2>&1\n')
CASES=[(kind+'-'+method,kind,method) for kind in ['four','skew'] for method in ['minimum','equal','over']]+[('lshape-mixed','lshape','over')]
if __name__=='__main__':
 for n,k,m in CASES:make(P/'cases/diffusion-exercises'/n,k,m)
