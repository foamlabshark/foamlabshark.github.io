"""Chapter 14 FitzHugh-Nagumo, 4 x 4 domain, native OpenFOAM v2512."""
from pathlib import Path
import argparse
from makeTimeCase import header

def create(directory,scheme='Euler',cells=100,end=5,dt=1e-4):
    root=Path(directory)
    def write(name,body):
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(body.replace('\r\n','\n').encode())
    write('system/blockMeshDict',header('blockMeshDict')+f'''
convertToMeters 1;
vertices
(
    (0 0 0)
    (4 0 0)
    (4 4 0)
    (0 4 0)
    (0 0 0.04)
    (4 0 0.04)
    (4 4 0.04)
    (0 4 0.04)
);
blocks
(
    hex (0 1 2 3 4 5 6 7) ({cells} {cells} 1) simpleGrading (1 1 1)
);
edges ();
boundary
(
    walls
    {{
        type patch;
        faces
        (
            (0 4 7 3)
            (1 2 6 5)
            (0 1 5 4)
            (3 7 6 2)
        );
    }}
    frontAndBack
    {{
        type empty;
        faces
        (
            (0 3 2 1)
            (4 5 6 7)
        );
    }}
);
mergePatchPairs ();
''')
    for name in ['c','u']:
        write('0/'+name,header(name,'volScalarField')+'''
dimensions [0 0 0 0 0 0 0];
internalField uniform 0;
boundaryField
{
    walls
    {
        type zeroGradient;
    }
    frontAndBack
    {
        type empty;
    }
}
''')
    write('constant/reactionProperties',header('reactionProperties')+'''
a [0 2 -1 0 0 0 0] 2.8e-4;
b [0 2 -1 0 0 0 0] 5e-3;
tau 0.1;
rate [0 0 -1 0 0 0 0] 1;
kappa [0 0 -1 0 0 0 0] -0.005;
seed 1426;
outerTolerance 1e-9;
maxOuterCorrectors 20;
''')
    write('system/controlDict',header('controlDict')+f'''
application fvmSourceNotebook;
startFrom startTime;
startTime 0;
stopAt endTime;
endTime {end:.17g};
deltaT {dt:.17g};
writeControl timeStep;
writeInterval {max(1,round(.5/dt))};
writeFormat ascii;
writePrecision 14;
timeFormat general;
timePrecision 12;
runTimeModifiable false;
''')
    write('system/fvSchemes',header('fvSchemes')+f'''
ddtSchemes
{{
    default {scheme};
}}
gradSchemes
{{
    default Gauss linear;
}}
divSchemes
{{
    default none;
}}
laplacianSchemes
{{
    default Gauss linear orthogonal;
}}
interpolationSchemes
{{
    default linear;
}}
snGradSchemes
{{
    default orthogonal;
}}
''')
    write('system/fvSolution',header('fvSolution')+'''
solvers
{
    "(c|u)"
    {
        solver PCG;
        preconditioner DIC;
        tolerance 1e-12;
        relTol 0;
        log 0;
    }
}
''')
    write('Allrun','#!/bin/sh\nset -eu\ncd "$(dirname "$0")"\n'
          'blockMesh > log.blockMesh 2>&1\ncheckMesh > log.checkMesh 2>&1\n'
          'fvmSourceNotebook > log.solve 2>&1\n')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('directory')
    p.add_argument('--scheme',default='Euler');p.add_argument('--cells',type=int,default=100)
    p.add_argument('--end',type=float,default=5);p.add_argument('--dt',type=float,default=1e-4)
    a=p.parse_args();create(a.directory,a.scheme,a.cells,a.end,a.dt)
