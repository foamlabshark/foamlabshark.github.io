# 课程与代码对照

以下路径均相对于代码包根目录。各节说明指出应阅读的对象、算法步骤与输出数据。

## 1.1

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-01-01)

从一个完整程序了解计算流程，参见代码 `applications/fvmBookFoam/fvmBookFoam.C`：先读取网格和场，再构造面通量、装配标量方程，最后求解并写出结果。可从 `cases/diffusion-20/Allrun` 启动两端给定值的稳态扩散算例。正文中的路径均相对于[配套代码包](/downloads/fvm-book/fvm-book-v2512.zip)解压后的根目录。

## 1.2

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-01-02)

参见代码 `applications/fvmBookFoam/fvmBookFoam.C` 中的 `fvScalarMatrix cEqn`。`ddt`、`div`、`laplacian` 和 `Sp` 分别对应积累、对流、扩散和线性消耗；后面的 `balance` 用计算后的场重新检查完整离散收支。

## 2.2

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-02-02)

本节的点积和叉积可与网格几何联系起来。参见代码 `applications/fvmMeshNotebook/fvmMeshNotebook.C` 中 `mesh.Sf()` 与 `faceQ` 的乘积：面积向量确定外法向，标量面值与面积向量相乘得到各面的梯度贡献。

## 2.2.6

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-02-02)

参见代码 `applications/fvmMeshNotebook/fvmMeshNotebook.C` 中的 `probeValue()` 与 `exactGradient()`。两者分别给出多项式标量场及其解析梯度，可将求导结果与后面的离散梯度逐单元比较。

## 2.5.4

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-02-05)

散度定理的离散核对见代码 `applications/fvmMeshNotebook/fvmMeshNotebook.C` 中的 `closure` 和 `manual`：前者累加单元外法向面积向量，后者累加标量面值乘面积向量，再除以单元体积。

## 3.4

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-03-04)

连续性在离散程序中表现为面通量收支。参见代码 `applications/fvmBookFoam/fvmBookFoam.C` 中 `fvc::div(phi)` 的检查；压力耦合程序 `applications/fvmPressureNotebook/fvmPressureNotebook.C` 还分别记录校正前后的 `massBefore` 与 `massAfter`。

## 3.7

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-03-07)

通用输运方程的可运行实现见代码 `applications/fvmBookFoam/fvmBookFoam.C` 中的 `cEqn`。本程序求解无量纲标量 `c`，扩散率、消耗系数和体源从 `cases/source-20/constant/transportProperties` 读取；先令速度和消耗为零，即可单独观察扩散与源项。

## 4.1

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-04-01)

局部系数进入全局矩阵的过程，参见代码 `applications/fvmDiffusionNotebook/fvmDiffusionNotebook.C` 的内部面循环。每个面同时更新两侧单元的 `diag`、共享的 `upper` 及两侧 `source`；第 8 章将逐项推导这些系数。

## 5.2.4

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-05-02)

参见代码 `applications/fvmDiffusionNotebook/fvmDiffusionNotebook.C` 中 `forAll(nei,fi)`：同一内部面的显式修正以相反符号写入两行右端，扩散系数则同时进入两侧对角元和面邻接项。

## 5.3

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-05-03)

边界贡献的实际存储见代码 `applications/fvmBookFoam/fvmBookFoam.C` 的 `-inspect` 分支。输出的 `matrix.txt` 分别列出内部矩阵和 `internalCoeffs`、`boundaryCoeffs`，核对手算边界系数时应同时读取这两组数据。

## 5.5

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-05-05)

参见代码 `applications/fvmTimeNotebook/fvmTimeNotebook.C` 中 `fvm::ddt(rho,c)`。程序在每一步记录单位体积的时间项对角元和历史源项，可在 `cases/time/cooling-Euler-variable/constant/transportProperties` 中修改时间步序列，观察储存项系数随步长变化。

## 5.10.2

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-05-10)

本表中的对象可在 `applications/fvmBookFoam/fvmBookFoam.C` 中依次找到：`createMesh.H` 创建网格，`volScalarField` 读取 `c`，`fvc::flux(U)` 创建面通量，`fvScalarMatrix` 装配并求解方程。编译依赖见 `applications/fvmBookFoam/Make/options`。

## 5.12

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-05-12)

本节矩阵检查使用 `cases/diffusion-20/Allrun` 与 `applications/fvmBookFoam/fvmBookFoam.C`。脚本生成网格并以 `-inspect` 运行求解器；核对案例目录中的 `geometry.csv`、`internal-faces.csv` 和 `matrix.txt`，即可把单元位置、面连接及代数系数对应起来。

## 6.4

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-06-04)

参见代码 `applications/fvmMeshNotebook/fvmMeshNotebook.C` 写入 `cells.txt`、`faces.csv` 和 `patches.txt` 的三段循环。它们分别给出单元的组成面与邻居、面的两侧单元、边界分组及起始面号。运行入口为 `cases/mesh-notebook/Allrun`，输出在该案例的 `notebook` 目录。

## 6.5

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-06-05)

几何量的读取和闭合检查见代码 `applications/fvmMeshNotebook/fvmMeshNotebook.C`：`faceAreas()`、`faceCentres()`、`cellVolumes()` 分别提供面积向量、面中心和单元体积，`closure` 按两侧单元的法向符号累加面积向量。

## 6.6.1

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-06-06)

参见代码 `applications/fvmMeshNotebook/fvmMeshNotebook.C` 开头的 `createMesh.H` 及随后对 `mesh` 的访问。网格输入由 `cases/mesh-notebook/system/blockMeshDict` 生成；改变网格后，输出的面中心、体积和连接表会随之更新。

## 6.8

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-06-08)

本节可直接运行 `cases/mesh-notebook/Allrun` 和 `cases/mesh-notebook-lshape/Allrun`，分别检查矩形区域与 L 形区域。代码 `applications/fvmMeshNotebook/fvmMeshNotebook.C` 输出的 `relativeClosureMax` 衡量面积闭合，`totalVolume` 可与几何尺寸独立核对。

## 7.1.1

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-07-01)

对应完整算例位于 `cases/cavity/Allrun`。先查看 `cases/cavity/0/U` 中的顶盖速度和各壁面类型，再沿 `Allrun` 中的顺序生成网格、检查网格并启动流动计算。

## 7.1.6

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-07-01)

参见代码 `applications/fvmMeshNotebook/fvmMeshNotebook.C` 的 `manual` 数组：内部面贡献加到 owner、从 neighbour 扣除，边界面只进入相邻内部单元，最后逐单元除以体积。`manualVsNativeMax` 比较这一面循环与所选原生梯度算子的结果。

## 7.2.4

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-07-02)

参见代码 `applications/fvmBookFoam/fvmBookFoam.C` 中输出 `cEqn.upper()`、`cEqn.lower()` 的位置；它们的面编号可在同一次运行生成的 `internal-faces.csv` 中查询。

## 7.5

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-07-05)

解析场、手工面循环与原生梯度的对照均在 `applications/fvmMeshNotebook/fvmMeshNotebook.C`。运行 `cases/mesh-notebook-lshape/Allrun` 后，每种场和梯度方法各有一份日志；`notebook` 中的梯度 CSV 列出计算值、解析值及误差。

## 8.3

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-08-03)

混合边界的配套输入见 `cases/diffusion-exercises/lshape-mixed/0/T`，装配见 `applications/fvmDiffusionNotebook/fvmDiffusionNotebook.C` 的 `mixedFvPatchScalarField` 分支。程序将 `valueFraction`、参考值和几何距离组合为对角贡献及已知右端，并在 `boundary-flux.csv` 中汇总外向通量。

## 8.6

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-08-06)

参见代码 `applications/fvmDiffusionNotebook/fvmDiffusionNotebook.C` 中的 `split` 函数。`minimum`、`equal`、`over` 分别计算三种隐式面积向量，其余部分进入显式非正交修正。选择项位于 `cases/diffusion-exercises/skew-over/system/notebookDict`。

## 8.9

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-08-09)

参见代码 `applications/fvmDiffusionNotebook/fvmDiffusionNotebook.C` 中的 `eq.relax(relax)`：松弛作用在求解前的矩阵上；求解后，`change` 记录新旧温度之差。由 `cases/diffusion-exercises/four-over/system/notebookDict` 中的 `relaxation` 改变松弛因子，可比较迭代速度。

## 8.10

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-08-10)

完整扩散装配见 `applications/fvmDiffusionNotebook/fvmDiffusionNotebook.C`。先阅读内部面循环，再阅读边界循环，最后追踪 `eq.solve()` 与通量输出。算例 `cases/diffusion-exercises/four-minimum/Allrun` 固定几何、初值和分解方法，便于逐轮核对。

## 8.12

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-08-12)

本节倾斜网格练习对应 `cases/diffusion-exercises/four-equal/Allrun`，混合边界练习对应 `cases/diffusion-exercises/lshape-mixed/Allrun`。网格尺寸写在各自的 `system/blockMeshDict`，温度边界在 `0/T`；程序 `applications/fvmDiffusionNotebook/fvmDiffusionNotebook.C` 同时输出第四轮温度、最终温度和边界通量。

## 9.2

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-09-02)

Gauss 累加的完整实现见 `applications/fvmMeshNotebook/fvmMeshNotebook.C` 中的 `manual` 循环；面值由 `fvc::interpolate(q)` 得到。将这段循环与本节公式对应，可看清插值误差在哪一步进入梯度。

## 9.3

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-09-03)

参见代码 `applications/fvmMeshNotebook/fvmMeshNotebook.C` 的 `method == "leastSquares"` 分支。它通过 `fv::gradScheme<scalar>::New` 选择原生最小二乘梯度，再调用 `exactGradient()` 检查误差。

## 9.4

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-09-04)

参见代码 `applications/fvmMeshNotebook/fvmMeshNotebook.C` 的 `averageFace`、`corrected` 和 `faceGradient` 输出段。修正只改变连心方向的分量，CSV 同时列出平均梯度、修正梯度和面中心的解析梯度。

## 9.5

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-09-05)

本节完整程序为 `applications/fvmMeshNotebook/fvmMeshNotebook.C`，编译入口为 `applications/fvmMeshNotebook/Make/files`。不同梯度方法的运行组合已写在 `cases/mesh-notebook/Allrun`，可对同一解析场逐项比较。

## 10.2

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-10-02)

参见代码 `applications/fvmAlgebraNotebook/fvmAlgebraNotebook.C` 的 `factor()` 与 `applyLU()`：前者执行消元并保存因子，后者执行前代和回代。开启 `incomplete` 时保留原矩阵的零元结构，对应本章后续讨论的 ILU(0)。

## 10.3

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-10-03)

参见代码 `applications/fvmAlgebraNotebook/fvmAlgebraNotebook.C` 的 `apply()` 及主循环：`jacobi`、`gs`、`dilu` 和 `ilu` 使用不同的修正计算，主循环记录残差与迭代结果；`pcg` 分支另计算搜索方向和步长。

## 10.5

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-10-05)

原生矩阵的求解入口在 `applications/fvmBookFoam/fvmBookFoam.C` 的 `cEqn.solve()`，求解器和平滑器选择在 `cases/diffusion-20/system/fvSolution`。小矩阵的逐步算法另见 `applications/fvmAlgebraNotebook/fvmAlgebraNotebook.C`，可先核对手算结果，再比较原生求解器日志。

## 11.5

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-11-05)

参见代码 `libraries/bookInterpolation/bookInterpolation.C` 的 `bookSOU` 与 `bookQUICK`。两者共用迎风隐式权重，分别通过 `centreFactor()`、`faceFactor()` 组织梯度修正，返回重构面值与迎风面值之差。

## 11.6

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-11-06)

二维斜向输运对应 `cases/oblique-upwind-20/Allrun`，旋转输运对应 `cases/smith-hutton-upwind-20/Allrun`。速度场的 `polynomial` 与 `smithHutton` 分支在 `applications/fvmBookFoam/fvmBookFoam.C`；程序在面中心直接计算速度与面积向量的点积，保持所给网格上的离散连续性。

## 11.8

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-11-08)

参见代码 `libraries/bookInterpolation/bookInterpolation.C` 的 `bookSOU::correction()`：先确定上游单元，再计算高阶梯度贡献。迎风部分形成隐式矩阵，高阶差值经格式的 `correction` 接口加入显式修正。

## 11.9

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-11-09)

格式实现位于 `libraries/bookInterpolation/bookInterpolation.C`，动态库编译设置位于 `libraries/bookInterpolation/Make/files`；案例 `cases/oblique-bookSOU-20/system/fvSchemes` 的 `div(phi,c)` 选择 `bookSOU`。求解器 `applications/fvmBookFoam/fvmBookFoam.C` 通过 `fvm::div(phi,c)` 调用这一格式。

## 12.1

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-12-01)

归一化面值函数见代码 `libraries/bookInterpolation/bookHRFunctions.H` 的 `normalized()`；从实际场恢复高阶差值的过程见同文件 `correction()`。可同时追踪 `up`、`down` 和 `virtualUp` 三个输入与本节符号的关系。

## 12.3

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-12-03)

本节分段格式集中在 `libraries/bookInterpolation/bookHRFunctions.H` 的 `normalized()`。逐项查看 `SMART`、`STOIC`、`OSHER`、`MINMOD`、`MUSCL` 和 `SUPERBEE` 分支，可将区间端点与分段直线对应起来。

## 12.5

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-12-05)

参见代码 `libraries/bookInterpolation/bookHRFunctions.H` 的 `smartLimiter()` 与 `SMART_TVD` 分支。检查程序 `applications/fvmHRNotebook/fvmHRNotebook.C` 在不同尺度、正负号和归一化变量下比较 NVF 与 TVD 的重构差值，并输出等价性误差。

## 12.6

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-12-06)

参见代码 `libraries/bookInterpolation/bookInterpolation.C` 的 `bookHR::correction()`：`faceFlux_` 确定上下游，梯度投影构造 `vu`，再调用 `libraries/bookInterpolation/bookHRFunctions.H` 恢复高阶通量修正。

## 12.10

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-12-10)

完整链条由 `libraries/bookInterpolation/bookInterpolation.C`、`libraries/bookInterpolation/bookHRFunctions.H` 和 `applications/fvmBookFoam/fvmBookFoam.C` 组成：格式类取得场与梯度，分段函数计算面值，输运求解器装配方程。运行输入可从 `cases/oblique-bookSMART-20/Allrun` 开始。

## 13.2

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-13-02)

参见代码 `applications/fvmTimeNotebook/fvmTimeNotebook.C`：`timeMatrix` 单独保存 `fvm::ddt(rho,c)` 的矩阵，随后与扩散、消耗项合并。时间格式由 `cases/time/cooling-backward-0.1/system/fvSchemes` 选择，可在 `time-values.csv` 中核对每个时间层的系数。

## 13.4

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-13-04)

参见代码 `applications/fvmTimeNotebook/fvmTimeNotebook.C` 的 `runTime.setDeltaT(steps[step],false)`。步长序列来自 `cases/time/cooling-backward-variable/constant/transportProperties`；程序在改变密度前先调用 `oldTime()` 保存历史场，输出每一步的对角系数和历史项。

## 13.5

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-13-05)

原生时间矩阵的配套检查程序为 `applications/fvmTimeNotebook/fvmTimeNotebook.C`。固定步长冷却例从 `cases/time/cooling-Euler-0.1/Allrun` 运行，变步长例从 `cases/time/cooling-backward-variable/Allrun` 运行；对照 `time-values.csv` 的 `ddtDiagPerVolume`、`ddtSourcePerVolume` 与本节系数。

## 14.1

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-14-01)

参见代码 `applications/fvmSourceNotebook/fvmSourceNotebook.C` 的 `-audit` 分支：它分别构造 `fvm::Sp` 与 `fvm::SuSp`，将矩阵实际贡献、预期值和误差写入 `source-audit.csv`。正负源系数可据此逐项核对。

## 14.2

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-14-02)

矩阵松弛与场松弛的对照见 `applications/fvmSourceNotebook/fvmSourceNotebook.C` 的 `A.relax(.5)`、`c.storePrevIter()` 和 `c.relax(.25)`。输出分别检查对角元、右端及更新后场值，说明两种松弛改变的是不同对象。

## 14.5

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-14-05)

参见代码 `applications/fvmSourceNotebook/fvmSourceNotebook.C` 中 `cEqn`、`uEqn` 与重新装配的 `checkC`、`checkU`。前两者推进反应扩散方程，后两者以更新后的场检查非线性平衡；物性与反应系数见 `cases/sources/reaction-Euler/constant/reactionProperties`。

## 15.4

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-15-04)

参见代码 `applications/fvmPressureNotebook/fvmPressureNotebook.C` 的 `correction` 分支：面压力差与插值压力梯度的差进入 `phi`，松弛历史由 `phi.prevIter()` 和 `U.prevIter()` 提供；这几项共同构造压力修正前的面通量。

## 15.5

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-15-05)

参见代码 `applications/fvmPressureNotebook/fvmPressureNotebook.C` 中 `ppEqn` 的装配与 `phi -= ppEqn.flux()`。压力增量求解完成后，程序使用同一矩阵的面通量校正连续性，再更新压力与单元速度。

## 15.7

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-15-07)

SIMPLE、SIMPLEC 与 PISO 的分支见 `applications/fvmPressureNotebook/fvmPressureNotebook.C`。`consistent` 控制 SIMPLEC 的 `rAtU` 修正，`transient` 控制时间项与多次压力校正；算例选择写在 `cases/pressure/channel-SIMPLEC/constant/flowProperties` 的 `algorithm` 中。

## 15.9

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-15-09)

参见代码 `applications/fvmPressureNotebook/fvmPressureNotebook.C` 中的 `prevIter()` 和 `fvc::ddtCorr(U,phi)`。前者保存松弛历史，后者为瞬态预测通量补充时间离散修正；PISO 算例入口为 `cases/pressure/vortex-PISO-2/Allrun`。

## 15.10

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-15-10)

完整实现见 `applications/fvmPressureNotebook/fvmPressureNotebook.C`。建议依次阅读 `UEqn`、预测通量、`pEqn` 或 `ppEqn`、速度与面通量更新，最后检查 `pressure-history.csv` 的校正前后质量误差及未松弛动量残差。通道算例入口为 `cases/pressure/channel-correction/Allrun`。

## 16.5

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-16-05)

小规模压力修正矩阵见代码 `applications/fvmCompressibleNotebook/fvmCompressibleNotebook.C` 的 `nozzle()`。程序分别保存亚声速与超声速的矩阵、场量和迭代过程，可将每个密度修正与速度修正系数对应到三单元喷管。

## 16.8

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-16-08)

超声速入口的配套边界实现见 `libraries/bookCompressibleBoundary/bookSupersonicInletPressure.C`：固定静压参与对流值系数，两组梯度系数返回零。使用位置见 `cases/compressible/diverging-supersonic/0/p`，并与同一案例的 `0/U`、`0/T` 一起确定入口状态。

## 16.9

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-16-09)

完整原生喷管算例从 `cases/compressible/converging-subsonic/Allrun` 或 `cases/compressible/diverging-supersonic/Allrun` 运行。热物性见各自的 `constant/thermophysicalProperties`，格式及压力求解设置在 `system`；三单元推导的独立实现位于 `applications/fvmCompressibleNotebook/fvmCompressibleNotebook.C`。

## 17.5

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-17-05)

时间尺度限制模型的配套实现见 `libraries/bookLimitedKEpsilon/bookLimitedKEpsilon.C` 的 `correctNut()`。其中 `timeScale` 将湍流时间尺度与应变时间尺度比较，再由 `Cmu_*k_*timeScale` 得到湍流运动黏度；模型选择见 `cases/turbulence/channel-limitedKEpsilon/constant/turbulenceProperties`。

## 17.7

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-17-07)

参见代码 `libraries/bookLimitedKEpsilon/bookLimitedKEpsilon.C` 的 `correct()`：`epsilonEqn` 与 `kEqn` 分别装配耗散率和湍动能方程，时间、对流、扩散、产生与消耗项可逐项对照本节推导。

## 17.8

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-17-08)

壁面配置可对照 `cases/turbulence/channel-kEpsilon/0/k`、`cases/turbulence/channel-kEpsilon/0/epsilon` 和 `cases/turbulence/channel-kEpsilon/0/nut`。这些文件分别设置湍动能、耗散率和湍流黏度的边界；SST 的对应配置则见 `cases/turbulence/channel-kOmegaSST/0/omega`。

## 17.9

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-17-09)

参见代码 `applications/fvmWallDistanceNotebook/fvmWallDistanceNotebook.C`：先求解辅助场 `psi` 的 Poisson 方程，再由 `gradPsi` 重构壁距，最后与 `wallDist::New(mesh).y()` 及通道解析壁距比较。运行入口为 `cases/turbulence/distance-40/Allrun`，误差写入 `wall-distance.csv`。

## 17.10

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-17-10)

自定义模型的类声明、实现与注册分别在 `libraries/bookLimitedKEpsilon/bookLimitedKEpsilon.H`、`libraries/bookLimitedKEpsilon/bookLimitedKEpsilon.C`、`libraries/bookLimitedKEpsilon/register.C`。算例 `cases/turbulence/channel-limitedKEpsilon/Allrun` 加载该库并选择模型；标准模型对照可查看相邻的 `channel-kEpsilon` 与 `channel-kOmegaSST` 目录。

## 18.2

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-18-02)

四组边界系数的检查见 `applications/fvmBoundaryNotebook/fvmBoundaryNotebook.C`。程序分别调用面值和梯度接口，再读取负 Laplacian 的边界矩阵贡献；旋转 17° 的输入在 `cases/boundaries/rotated-17/0/U`，可同时检查坐标方向与系数符号。

## 18.3

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-18-03)

切向投影边界的完整类位于 `libraries/bookBoundaryConditions/bookTangentialWall.C`。重点对照 `gradientInternalCoeffs()`、`gradientBoundaryCoeffs()` 和 `snGrad()`：它们将隐式分量、交叉分量与实际法向梯度保持一致。

## 18.4

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-18-04)

参见代码 `applications/fvmBoundaryNotebook/fvmBoundaryNotebook.C` 中 `boundary-coefficients.csv` 与 `scalar-coefficients.csv` 的输出循环。对应案例 `cases/boundaries/rotated-45/Allrun` 先设置旋转网格与边界，再读取场、求值并检查矩阵贡献。

## 19.2

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-19-02)

当前几何文件见 `cases/ahmed-body-layered/constant/triSurface/ahmed.stl`，尺寸和来源记录见 `cases/ahmed-body-layered/SOURCE.txt`。背景域由 `cases/ahmed-body-layered/system/blockMeshDict` 定义，车体表面加密及壁面层由 `cases/ahmed-body-layered/system/snappyHexMeshDict` 设置。

## 19.3

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-19-03)

本节操作顺序完整写在 `cases/ahmed-body-layered/Allrun`。速度边界见 `cases/ahmed-body-layered/0/U`，湍流模型见 `cases/ahmed-body-layered/constant/turbulenceProperties`，力系数及输出控制见 `cases/ahmed-body-layered/system/controlDict`；后处理由 `cases/ahmed-body-layered/samplePlanes.py` 创建采样位置并生成 `system/samplePostProcDict`，再由 `postProcess` 读取最终流场。

## A.2

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-21-02)

参见代码 `applications/fvmBookFoam/fvmBookFoam.C` 的主函数。初始化之后进入 `simple.loop()`，在 `correctNonOrthogonal()` 中重新装配并求解，再写出当前时刻；相应瞬态案例见 `cases/diffusion-transient/Allrun`。

## A.3

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-21-03)

网格读取后的访问代码见 `applications/fvmBookFoam/fvmBookFoam.C` 的 `-inspect` 分支。需要完整的单元—面连接检查时，可继续阅读 `applications/fvmMeshNotebook/fvmMeshNotebook.C` 中输出 `cells.txt` 与 `faces.csv` 的循环。

## A.4

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-21-04)

参见代码 `applications/fvmBookFoam/fvmBookFoam.C` 的 `IOdictionary props`、三个 `dimensionedScalar` 和 `cEqn`。字典实例见 `cases/source-20/constant/transportProperties`；格式选择见 `cases/source-20/system/fvSchemes`，求解与松弛设置见 `cases/source-20/system/fvSolution`。

## A.5

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-21-05)

场构造与初值读取见 `applications/fvmBookFoam/fvmBookFoam.C` 中 `volScalarField c`、`volVectorField U`。输入文件分别为 `cases/diffusion-transient/0/c` 与 `cases/diffusion-transient/0/U`，其中的 `internalField` 和 `boundaryField` 决定内部初值及边界状态。

## A.6

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-21-06)

参见代码 `applications/fvmBookFoam/fvmBookFoam.C` 的 `cEqn.relax()`、`cEqn.solve()` 和 `balance`。若要逐项核对松弛前后矩阵及残差，使用 `applications/fvmSourceNotebook/fvmSourceNotebook.C` 的 `-audit` 分支。

## A.7

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-21-07)

CSV 输出见 `applications/fvmBookFoam/fvmBookFoam.C` 中的 `geometry`、`faces`、`grad` 和 `values`；三维流动采样示例见 `cases/ahmed-body-layered/samplePlanes.py`。后者生成中心面与尾流截面的采样字典，由案例 `Allrun` 调用后处理输出数据。

## A.8

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-21-08)

面值及梯度位置转换可对照 `applications/fvmMeshNotebook/fvmMeshNotebook.C` 的 `faceQ`、`averageFace` 和 `corrected`。自定义对流面值的类接口见 `libraries/bookInterpolation/bookInterpolation.C`，其中 `weights()` 与 `correction()` 分别提供隐式权重和附加修正。

## A.9

[打开课程](https://foamlabshark.github.io/read/?slug=fvm-book-21-09)

批量运行入口为 `Allrun`，案例清单在 `case-manifest.json`。先按正文给出的案例路径运行一组，再读取 `verification` 中对应的验证记录；修改算法后可据此比较数值结果与误差。
