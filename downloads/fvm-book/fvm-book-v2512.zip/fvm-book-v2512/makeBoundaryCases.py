from pathlib import Path
import math,json
from makeCompressibleCases import header,block
def make(path,angle):
 path=Path(path)
 def write(name,s):
  p=path/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
 def rotate(v):
  x,y,z=v;a=math.radians(angle);b=a*.7
  xx=x*math.cos(a)-y*math.sin(a);yy=x*math.sin(a)+y*math.cos(a)
  return xx,yy*math.cos(b)-z*math.sin(b),yy*math.sin(b)+z*math.cos(b)
 verts=[rotate(v) for v in [(0,0,0),(1,0,0),(1,1,0),(0,1,0),(0,0,1),(1,0,1),(1,1,1),(0,1,1)]]
 faces=['(0 4 7 3)','(1 2 6 5)','(0 1 5 4)','(3 7 6 2)','(0 3 2 1)','(4 5 6 7)']
 mesh=header('blockMeshDict')+'scale 1;\nvertices\n(\n'+''.join('    ('+' '.join(f'{x:.16g}' for x in v)+')\n' for v in verts)+');\nblocks\n(\n    hex (0 1 2 3 4 5 6 7) (1 1 1) simpleGrading (1 1 1)\n);\nedges ();\nboundary\n(\n'
 for i,face in enumerate(faces):mesh+=block('wall'+str(i),['type wall;','faces','(',f'    {face}',');'])
 write('system/blockMeshDict',mesh+');\nmergePatchPairs ();\n')
 for field in ['U','T']:
  s=header(field,'volVectorField' if field=='U' else 'volScalarField')+('dimensions [0 1 -1 0 0 0 0];\ninternalField uniform (1 2 3);\n' if field=='U' else 'dimensions [0 0 0 1 0 0 0];\ninternalField uniform 5;\n')+'boundaryField\n{\n'
  for i in range(6):
   if field=='U':ls=['type bookTangentialWall;','value uniform (0.3 -0.2 0.1);']
   elif i%4==0:ls=['type fixedValue;','value uniform 3;']
   elif i%4==1:ls=['type zeroGradient;']
   elif i%4==2:ls=['type fixedGradient;','gradient uniform 2;']
   else:ls=['type mixed;','refValue uniform 8;','refGradient uniform 2;','valueFraction uniform 0.3;','value uniform 5;']
   s+=block('wall'+str(i),ls)
  write('0/'+field,s+'}\n')
 write('system/controlDict',header('controlDict')+'application fvmBoundaryNotebook;\nstartFrom startTime;\nstartTime 0;\nstopAt endTime;\nendTime 1;\ndeltaT 1;\nwriteControl timeStep;\nwriteInterval 1;\nlibs ("libbookBoundaryConditions.so");\n')
 write('system/fvSchemes',header('fvSchemes')+block('ddtSchemes',['default steadyState;'])+block('gradSchemes',['default Gauss linear;'])+block('divSchemes',['default none;'])+block('laplacianSchemes',['default Gauss linear orthogonal;'])+block('interpolationSchemes',['default linear;'])+block('snGradSchemes',['default orthogonal;']))
 write('system/fvSolution',header('fvSolution')+'solvers {}\n')
 write('case.json',json.dumps(dict(angleZ=angle,angleX=angle*.7,checks='Boundary operators on rotated orthogonal cells; no physical flow solve.'),indent=2)+'\n')
 write('Allrun','#!/bin/sh\nset -eu\ncd "$(dirname "$0")"\nblockMesh > log.blockMesh 2>&1\ncheckMesh > log.checkMesh 2>&1\nfvmBoundaryNotebook > log.fvmBoundaryNotebook 2>&1\n')
CASES=[('rotated-'+str(a),a) for a in [0,17,45,80]]
if __name__=='__main__':
 for n,a in CASES:make(Path(__file__).parent/'cases/boundaries'/n,a)
