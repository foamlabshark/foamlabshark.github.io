"""Channel wall-distance and developing RANS cases for Chapter 17."""
from pathlib import Path
import json
from makeCompressibleCases import header,block

def make(path,model='distance',ny=40):
 path=Path(path)
 def write(name,s):
  p=path/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
 L=2 if model=='distance' else 10
 nx=8 if model=='distance' else 120
 vertices=[(0,0,0),(L,0,0),(L,1,0),(0,1,0),(0,0,.1),(L,0,.1),(L,1,.1),(0,1,.1)]
 patches=dict(inlet=['(0 4 7 3)'],outlet=['(1 2 6 5)'],walls=['(0 1 5 4)','(3 7 6 2)'],frontAndBack=['(0 3 2 1)','(4 5 6 7)'])
 mesh=header('blockMeshDict')+'scale 1;\nvertices\n(\n'+''.join('    ('+' '.join(map(str,v))+')\n' for v in vertices)+');\n'
 mesh+=f'blocks\n(\n    hex (0 1 2 3 4 5 6 7) ({nx} {ny} 1) simpleGrading (1 1 1)\n);\nedges ();\nboundary\n(\n'
 for name,faces in patches.items():
  typ='wall' if name=='walls' else 'empty' if name=='frontAndBack' else 'patch'
  mesh+=block(name,['type '+typ+';','faces','(',*['    '+f for f in faces],');'])
 write('system/blockMeshDict',mesh+');\nmergePatchPairs ();\n')
 fields=[('psi','[0 2 0 0 0 0 0]','0')] if model=='distance' else [
 ('p','[0 2 -2 0 0 0 0]','0'),('U','[0 1 -1 0 0 0 0]','(1 0 0)'),
 ('k','[0 2 -2 0 0 0 0]','0.00375'),('nut','[0 2 -1 0 0 0 0]','0')]
 if model in ['kEpsilon','bookLimitedKEpsilon']:fields.append(('epsilon','[0 2 -3 0 0 0 0]','0.003773364712'))
 if model=='kOmegaSST':fields.append(('omega','[0 0 -1 0 0 0 0]','11.1803398875'))
 for field,dim,initial in fields:
  s=header(field,'volVectorField' if field=='U' else 'volScalarField')+f'dimensions {dim};\ninternalField uniform {initial};\nboundaryField\n{{\n'
  for patch in patches:
   if patch=='frontAndBack':ls=['type empty;']
   elif model=='distance':ls=['type fixedValue;','value uniform 0;'] if patch=='walls' else ['type zeroGradient;']
   elif field=='nut':
    ls=['type nutkWallFunction;','value uniform 0;'] if patch=='walls' else ['type calculated;','value uniform 0;']
   elif patch=='walls':
    typ=dict(p='zeroGradient',U='noSlip',k='kqRWallFunction',epsilon='epsilonWallFunction',omega='omegaWallFunction')[field]
    ls=['type '+typ+';']+([f'value uniform {initial};'] if field in ['k','epsilon','omega'] else [])
   elif patch=='inlet':ls=['type zeroGradient;'] if field=='p' else ['type fixedValue;',f'value uniform {initial};']
   else:ls=['type fixedValue;','value uniform 0;'] if field=='p' else ['type zeroGradient;']
   s+=block(patch,ls)
  write('0/'+field,s+'}\n')
 write('constant/transportProperties',header('transportProperties')+'transportModel Newtonian;\nnu 1e-5;\n')
 if model!='distance':
  write('constant/turbulenceProperties',header('turbulenceProperties')+'simulationType RAS;\n'+block('RAS',['RASModel '+model+';','turbulence on;','printCoeffs on;']))
 divs=['default none;','div(phi,U) bounded Gauss upwind;','div(phi,k) bounded Gauss upwind;',
       'div(phi,epsilon) bounded Gauss upwind;','div(phi,omega) bounded Gauss upwind;','div((nuEff*dev2(T(grad(U))))) Gauss linear;']
 write('system/fvSchemes',header('fvSchemes')+block('ddtSchemes',['default steadyState;'])+
  block('gradSchemes',['default Gauss linear;'])+block('divSchemes',divs)+block('laplacianSchemes',['default Gauss linear corrected;'])+
  block('interpolationSchemes',['default linear;'])+block('snGradSchemes',['default corrected;'])+block('wallDist',['method Poisson;']))
 solvers=block('"(p|psi|yPsi)"',['solver PCG;','preconditioner DIC;','tolerance 1e-12;','relTol 0;'])+block('"(U|k|epsilon|omega)"',['solver smoothSolver;','smoother symGaussSeidel;','tolerance 1e-10;','relTol 0.01;'])
 write('system/fvSolution',header('fvSolution')+'solvers\n{\n'+solvers+'}\n'+block('SIMPLE',['nNonOrthogonalCorrectors 0;','residualControl','{','    p 1e-7;','    U 1e-7;','    "(k|epsilon|omega)" 1e-7;','}'])+
  'relaxationFactors\n{\n    fields\n    {\n        p 0.3;\n    }\n    equations\n    {\n        U 0.6;\n        k 0.5;\n        epsilon 0.5;\n        omega 0.5;\n    }\n}\n')
 app='fvmWallDistanceNotebook' if model=='distance' else 'simpleFoam'
 write('system/controlDict',header('controlDict')+f'application {app};\nstartFrom startTime;\nstartTime 0;\nstopAt endTime;\nendTime 8000;\ndeltaT 1;\nwriteControl timeStep;\nwriteInterval 1000;\npurgeWrite 1;\nwriteFormat ascii;\nwritePrecision 15;\nrunTimeModifiable false;\n'+
  ('functions\n{\n'+block('yPlus',['type yPlus;','libs (fieldFunctionObjects);','writeControl writeTime;'])+'}\n' if model!='distance' else ''))
 if model=='bookLimitedKEpsilon':
  p=path/'system/controlDict';p.write_text(p.read_text()+'\nlibs ("libbookLimitedKEpsilon.so");\n',newline='\n')
 write('case.json',json.dumps(dict(model=model,nx=nx,ny=ny,length=L,height=1,nu=1e-5,Uin=1,I=.05,mixingLength=.01),indent=2)+'\n')
 write('Allrun','#!/bin/sh\nset -eu\ncd "$(dirname "$0")"\nblockMesh > log.blockMesh 2>&1\ncheckMesh > log.checkMesh 2>&1\n'+app+' > log.'+app+' 2>&1\n')

CASES=[('distance-20','distance',20),('distance-40','distance',40),('distance-80','distance',80),
 ('channel-kEpsilon','kEpsilon',40),('channel-kOmegaSST','kOmegaSST',40),('channel-limitedKEpsilon','bookLimitedKEpsilon',40)]
if __name__=='__main__':
 for n,m,ny in CASES:make(Path(__file__).parent/'cases/turbulence'/n,m,ny)
