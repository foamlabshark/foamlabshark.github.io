/* Source linearization and FitzHugh-Nagumo; OpenCFD v2512; GPL-3.0-or-later. */
#include "fvCFD.H"
#include "Random.H"

int main(int argc,char *argv[])
{
    argList::addBoolOption("audit","Check native Sp, SuSp, matrix and field relaxation");
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    volScalarField c
    (
        IOobject("c",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::AUTO_WRITE),
        mesh
    );
    if(args.found("audit"))
    {
        if(mesh.nCells()!=2) FatalErrorInFunction<<"Use the two-cell audit case"<<exit(FatalError);
        c[0]=1;c[1]=2;
        volScalarField sp
        (
            IOobject("sp",runTime.timeName(),mesh,IOobject::NO_READ,IOobject::NO_WRITE),
            mesh,dimensionedScalar("zero",dimless/dimTime,0)
        );
        sp[0]=-2;sp[1]=3;
        OFstream out(runTime.path()/"source-audit.csv");out.precision(16);
        out<<"test,cell,actual,expected,error"<<nl;
        scalar worst=0;
        auto check=[&](const word& name,label i,scalar actual,scalar expected)
        {
            scalar error=mag(actual-expected);
            worst=max(worst,error);
            out<<name<<','<<i<<','<<actual<<','<<expected<<','<<error<<nl;
        };
        fvScalarMatrix pure(fvm::Sp(sp,c)),split(fvm::SuSp(sp,c));
        forAll(c,i)
        {
            check("SpDiagonal",i,pure.diag()[i]/mesh.V()[i],sp[i]);
            check("SpSource",i,pure.source()[i]/mesh.V()[i],0);
            check("SuSpDiagonal",i,split.diag()[i]/mesh.V()[i],max(sp[i],scalar(0)));
            check("SuSpSource",i,split.source()[i]/mesh.V()[i],-min(sp[i],scalar(0))*c[i]);
        }
        fvScalarMatrix A(c,dimVol*c.dimensions()/dimTime);
        A.diag()[0]=4*mesh.V()[0];A.diag()[1]=5*mesh.V()[1];
        A.upper()=-mesh.V()[0];A.lower()=-mesh.V()[0];
        A.source()[0]=7*mesh.V()[0];A.source()[1]=8*mesh.V()[1];
        const scalarField initialResidual(A.residual()/mesh.V());
        check("UnrelaxedResidual",0,initialResidual[0],5);
        check("UnrelaxedResidual",1,initialResidual[1],-1);
        A.relax(.5);
        check("RelaxedDiagonal",0,A.diag()[0]/mesh.V()[0],8);
        check("RelaxedDiagonal",1,A.diag()[1]/mesh.V()[1],10);
        check("RelaxedSource",0,A.source()[0]/mesh.V()[0],11);
        check("RelaxedSource",1,A.source()[1]/mesh.V()[1],18);
        c.storePrevIter();
        c[0]=5;c[1]=8;
        c.relax(.25);
        check("FieldRelaxation",0,c[0],2);
        check("FieldRelaxation",1,c[1],3.5);
        Info<<"maximumSourceCheckError "<<worst<<nl;
        return worst<1e-11?0:2;
    }
    volScalarField u
    (
        IOobject("u",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::AUTO_WRITE),
        mesh
    );
    IOdictionary props
    (
        IOobject("reactionProperties",runTime.constant(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE)
    );
    const dimensionedScalar a("a",dimViscosity,props),b("b",dimViscosity,props);
    const dimensionedScalar rate("rate",dimless/dimTime,props);
    const dimensionedScalar kappa("kappa",dimless/dimTime,props);
    const scalar tau=props.get<scalar>("tau");
    const scalar tolerance=props.lookupOrDefault<scalar>("outerTolerance",1e-9);
    const label maximum=props.lookupOrDefault<label>("maxOuterCorrectors",20);
    const label seed=props.lookupOrDefault<label>("seed",1426);
    Random random(seed);
    forAll(c,i){c[i]=random.sample01<scalar>();u[i]=1-c[i];}
    c.correctBoundaryConditions();u.correctBoundaryConditions();
    c.write();u.write();
    c.oldTime();u.oldTime();
    OFstream history(runTime.path()/"reaction-history.csv");history.precision(16);
    history<<"time,outerIterations,change,nonlinearBalance,minC,maxC,minU,maxU,meanC,meanU"<<nl;
    label allSteps=0;scalar worstBalance=0;label maxIterations=0;
    while(runTime.run())
    {
        ++runTime;allSteps++;
        scalar change=GREAT,balance=GREAT;
        label outer=0;
        for(;outer<maximum;++outer)
        {
            const scalarField oldC(c.primitiveField()),oldU(u.primitiveField());
            // The cubic sink has non-positive physical source coefficient.
            fvScalarMatrix cEqn
            (
                fvm::ddt(c)-fvm::laplacian(a,c)+fvm::Sp(rate*sqr(c),c)
                ==rate*(c-u)+kappa
            );
            cEqn.solve();
            fvScalarMatrix uEqn
            (
                tau*fvm::ddt(u)-fvm::laplacian(b,u)+fvm::Sp(rate,u)==rate*c
            );
            uEqn.solve();
            c.correctBoundaryConditions();u.correctBoundaryConditions();
            change=max(gMax(mag(c.primitiveField()-oldC)),gMax(mag(u.primitiveField()-oldU)));
            if(change<tolerance)
            {
                // Reassemble with updated fields; a small inner solver residual
                // alone does not test the nonlinear reaction term.
                fvScalarMatrix checkC
                (
                    fvm::ddt(c)-fvm::laplacian(a,c)+fvm::Sp(rate*sqr(c),c)
                    ==rate*(c-u)+kappa
                );
                fvScalarMatrix checkU
                (
                    tau*fvm::ddt(u)-fvm::laplacian(b,u)+fvm::Sp(rate,u)==rate*c
                );
                balance=max(gMax(mag(checkC.residual()/mesh.V())),
                            gMax(mag(checkU.residual()/mesh.V())));
                if(balance<1e-6){outer++;break;}
            }
        }
        if(outer>=maximum && balance>=1e-6)
        {
            FatalErrorInFunction<<"Nonlinear iteration failed at "<<runTime.value()
                <<" change "<<change<<" balance "<<balance<<exit(FatalError);
        }
        worstBalance=max(worstBalance,balance);maxIterations=max(maxIterations,outer);
        if(allSteps%100==0||runTime.writeTime())
            history<<runTime.value()<<','<<outer<<','<<change<<','<<balance<<','
                <<gMin(c.primitiveField())<<','<<gMax(c.primitiveField())<<','
                <<gMin(u.primitiveField())<<','<<gMax(u.primitiveField())<<','
                <<gSum(c.primitiveField()*mesh.V())/gSum(mesh.V())<<','
                <<gSum(u.primitiveField()*mesh.V())/gSum(mesh.V())<<nl;
        runTime.write();
    }
    OFstream field(runTime.path()/"reaction-final.csv");field.precision(16);
    field<<"x,y,c,u"<<nl;
    forAll(c,i)field<<mesh.C()[i].x()<<','<<mesh.C()[i].y()<<','<<c[i]<<','<<u[i]<<nl;
    OFstream status(runTime.path()/"reaction-status.txt");
    status.precision(16);
    status<<"completedTime "<<runTime.value()<<nl<<"steps "<<allSteps<<nl
        <<"maximumOuterIterations "<<maxIterations<<nl<<"maximumNonlinearBalance "<<worstBalance<<nl;
    return 0;
}
