/* FoamLab time-discretization notebook; GPL-3.0-or-later.
 * OpenCFD OpenFOAM v2512. Uses the native ddt matrices without relaxation. */
#include "fvCFD.H"

int main(int argc, char *argv[])
{
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    volScalarField c
    (
        IOobject("c",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::AUTO_WRITE),
        mesh
    );
    volScalarField rho
    (
        IOobject("rho",runTime.timeName(),mesh,IOobject::NO_READ,IOobject::AUTO_WRITE),
        mesh,dimensionedScalar("one",dimless,1)
    );
    IOdictionary props
    (
        IOobject("transportProperties",runTime.constant(),mesh,
            IOobject::MUST_READ,IOobject::NO_WRITE)
    );
    const scalarList steps(props.lookup("stepSizes"));
    const dimensionedScalar D("D",dimViscosity,props);
    const dimensionedScalar decay("decay",dimless/dimTime,props);
    const scalar densitySlope=props.lookupOrDefault<scalar>("densitySlope",0);
    // Allocate history before changing the density at the first new time.
    rho.oldTime();
    c.oldTime();
    OFstream values(runTime.path()/"time-values.csv");
    values.precision(16);
    values<<"step,time,deltaT,cell,x,c,rho,ddtDiagPerVolume,ddtSourcePerVolume,balance"<<nl;
    scalar worst=0;
    forAll(steps,step)
    {
        runTime.setDeltaT(steps[step],false);
        ++runTime;
        rho=dimensionedScalar("rhoNow",dimless,1+densitySlope*runTime.value());
        c.correctBoundaryConditions();
        fvScalarMatrix timeMatrix(fvm::ddt(rho,c));
        const scalarField diagonal(timeMatrix.diag()/mesh.V());
        const scalarField history(timeMatrix.source()/mesh.V());
        fvScalarMatrix equation
        (
            timeMatrix-fvm::laplacian(D,c)+fvm::Sp(decay*rho,c)
        );
        equation.solve();
        c.correctBoundaryConditions();
        const scalarField balance(equation.residual()/mesh.V());
        worst=max(worst,gMax(mag(balance)));
        forAll(c,i)
            values<<step+1<<','<<runTime.value()<<','<<steps[step]<<','<<i<<','
                <<mesh.C()[i].x()<<','<<c[i]<<','<<rho[i]<<','
                <<diagonal[i]<<','<<history[i]<<','<<balance[i]<<nl;
        c.write();
        rho.write();
    }
    Info<<"completedSteps "<<steps.size()<<" maximumEquationBalance "<<worst<<nl;
    return worst<1e-9 ? 0:2;
}
