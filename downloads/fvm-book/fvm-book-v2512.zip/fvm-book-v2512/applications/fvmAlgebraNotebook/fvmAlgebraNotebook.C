#include "scalarField.H"
#include "IOstreams.H"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <cmath>
#include <stdexcept>
using Foam::scalar;
using Foam::label;
using Foam::scalarField;
using Matrix = std::vector<scalarField>;

scalar dot(const scalarField& a, const scalarField& b)
{
    scalar result=0;
    forAll(a,i) result+=a[i]*b[i];
    return result;
}
scalar maxMag(const scalarField& a)
{
    scalar result=0;
    forAll(a,i) result=std::max(result,std::abs(a[i]));
    return result;
}
scalarField mul(const Matrix& a, const scalarField& x)
{
    scalarField y(x.size(),0);
    forAll(y,i) y[i]=dot(a[i],x);
    return y;
}
void row(const std::string& name, const scalarField& x)
{
    std::cout<<name;
    forAll(x,i) std::cout<<' '<<x[i];
    std::cout<<'\n';
}
void matrix(const std::string& name,const Matrix& a)
{
    for (label i=0;i<label(a.size());++i) row(name+"_"+std::to_string(i),a[i]);
}
void checkPivot(scalar d)
{
    if(std::abs(d)<1e-14) throw std::runtime_error("Zero or very small pivot");
}
Matrix factor(Matrix a,bool incomplete)
{
    const Matrix original=a;
    const label n=a.size();
    for(label k=0;k<n-1;++k)
    {
        checkPivot(a[k][k]);
        for(label i=k+1;i<n;++i)
        {
            if(incomplete && original[i][k]==0) continue;
            a[i][k]/=a[k][k];
            for(label j=k+1;j<n;++j)
            {
                if(!incomplete || original[i][j]!=0) a[i][j]-=a[i][k]*a[k][j];
            }
        }
    }
    checkPivot(a[n-1][n-1]);
    return a;
}
scalarField applyLU(const Matrix& lu,scalarField r)
{
    const label n=r.size();
    for(label i=0;i<n;++i)
        for(label j=0;j<i;++j) r[i]-=lu[i][j]*r[j];
    for(label i=n-1;i>=0;--i)
    {
        for(label j=i+1;j<n;++j) r[i]-=lu[i][j]*r[j];
        r[i]/=lu[i][i];
    }
    return r;
}
scalarField diagonal(const Matrix& a,bool dilu)
{
    const label n=a.size();
    scalarField d(n,0);
    for(label i=0;i<n;++i) d[i]=a[i][i];
    if(dilu)
        for(label i=0;i<n;++i)
        {
            checkPivot(d[i]);
            for(label j=i+1;j<n;++j) d[j]-=a[j][i]*a[i][j]/d[i];
        }
    forAll(d,i) checkPivot(d[i]);
    return d;
}
scalarField apply(const Matrix& a,const Matrix& lu,const scalarField& diag,scalarField r,const std::string& method)
{
    if(method=="lu" || method=="ilu") return applyLU(lu,r);
    const label n=r.size();
    for(label i=0;i<n;++i)
    {
        if(method=="gs" || method=="dilu")
            for(label j=0;j<i;++j) r[i]-=a[i][j]*r[j];
        r[i]/=diag[i];
    }
    if(method=="dilu")
        for(label i=n-1;i>=0;--i)
            for(label j=i+1;j<n;++j) r[i]-=a[i][j]*r[j]/diag[i];
    return r;
}
int main(int argc,char** argv)
{
    try
    {
        if(argc<4) throw std::runtime_error("Usage: fvmAlgebraNotebook input.txt lu|ilu|dilu|jacobi|gs|pcg iterations [tolerance]");
        std::ifstream input(argv[1]);
        label n=0;input>>n;
        if(!input || n<1 || n>10000) throw std::runtime_error("Invalid matrix input");
        Matrix a(n,scalarField(n,0));scalarField b(n,0);
        for(label i=0;i<n;++i) for(label j=0;j<n;++j) input>>a[i][j];
        forAll(b,i) input>>b[i];
        if(!input) throw std::runtime_error("Incomplete matrix or right-hand side");
        const std::string method=argv[2];const label limit=std::stoi(argv[3]);
        const scalar tolerance=argc>4?std::stod(argv[4]):-1;
        if(method!="lu" && method!="ilu" && method!="dilu" && method!="jacobi" && method!="gs" && method!="pcg")
            throw std::runtime_error("Unknown method");
        Matrix lu;
        if(method=="lu" || method=="ilu") lu=factor(a,method=="ilu");
        const scalarField diag=diagonal(a,method=="dilu");
        std::cout<<std::setprecision(17);
        if(!lu.empty()) matrix("factor",lu);
        row("diagonal",diag);
        scalarField x(n,0),r(b),z(n,0),d(n,0);
        scalar rho=0;
        if(method=="pcg")
        {
            z=apply(a,lu,diag,r,"jacobi");d=z;rho=dot(r,z);
        }
        for(label iter=1;iter<=limit;++iter)
        {
            if(maxMag(r)<1e-14) break;
            if(method=="pcg")
            {
                const scalarField q=mul(a,d);const scalar denom=dot(d,q);
                if(denom<=0) throw std::runtime_error("PCG requires positive definite matrix");
                const scalar alpha=rho/denom;
                forAll(x,i) {x[i]+=alpha*d[i];r[i]-=alpha*q[i];}
                std::cout<<"alpha_"<<iter<<' '<<alpha<<'\n';
                z=apply(a,lu,diag,r,"jacobi");const scalar next=dot(r,z);
                forAll(d,i) d[i]=z[i]+(next/rho)*d[i];
                rho=next;
            }
            else
            {
                z=apply(a,lu,diag,r,method);
                forAll(x,i) x[i]+=z[i];
            }
            const scalarField ax=mul(a,x);scalarField trueResidual(n,0);
            forAll(r,i) trueResidual[i]=b[i]-ax[i];
            if(method!="pcg") r=trueResidual;
            row("x_"+std::to_string(iter),x);
            const scalar norm=maxMag(trueResidual);
            std::cout<<"residual_"<<iter<<' '<<norm<<'\n';
            if(!std::isfinite(norm)) throw std::runtime_error("Non-finite residual");
            if(norm<tolerance || norm>1e30) break;
        }
    }
    catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
    return 0;
}
