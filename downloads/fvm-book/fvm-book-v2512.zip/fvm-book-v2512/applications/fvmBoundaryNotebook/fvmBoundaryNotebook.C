#include "fvCFD.H"
#include <fstream>
#include <iomanip>
#include <cmath>
int main(int argc,char* argv[])
{
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    volVectorField U(IOobject("U",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE),mesh);
    volScalarField T(IOobject("T",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE),mesh);
    const dimensionedScalar gamma("gamma",dimViscosity,0.7);
    scalar maxGradient=0,maxFace=0,maxMatrix=0,maxScalar=0;label checks=0;
    std::ofstream csv("boundary-coefficients.csv");
    csv<<std::setprecision(16)<<"sample,patch,nx,ny,nz,gx,gy,gz,expectedX,expectedY,expectedZ\n";
    for(label sample=0;sample<100;++sample)
    {
        const vector u(std::sin(sample+0.1),std::cos(2*sample+.4),std::sin(3*sample+.7));
        U.primitiveFieldRef()=u;
        fvVectorMatrix diffusion(-fvm::laplacian(gamma,U));
        forAll(U.boundaryField(),pi)
        {
            const fvPatchVectorField& b=U.boundaryField()[pi];
            const vectorField n(b.patch().nf()),uc(b.patchInternalField()),uw(b);
            const scalarField dc(b.patch().deltaCoeffs());
            const vectorField gi(b.gradientInternalCoeffs()),gb(b.gradientBoundaryCoeffs());
            const vectorField sn(b.snGrad());
            const vectorField vi(b.valueInternalCoeffs(tmp<scalarField>::New(b.size(),1)));
            const vectorField vb(b.valueBoundaryCoeffs(tmp<scalarField>::New(b.size(),1)));
            forAll(b,f)
            {
                const vector du=uw[f]-uc[f];
                const vector expected=dc[f]*(du-n[f]*(n[f]&du));
                const vector actual=cmptMultiply(gi[f],uc[f])+gb[f];
                const vector assembled=cmptMultiply(diffusion.internalCoeffs()[pi][f],uc[f])-diffusion.boundaryCoeffs()[pi][f];
                maxGradient=max(maxGradient,mag(actual-expected));
                maxGradient=max(maxGradient,mag(sn[f]-expected));
                maxFace=max(maxFace,mag(cmptMultiply(vi[f],uc[f])+vb[f]-uw[f]));
                maxMatrix=max(maxMatrix,mag(assembled+0.7*b.patch().magSf()[f]*expected));
                csv<<sample<<','<<pi<<','<<n[f].x()<<','<<n[f].y()<<','<<n[f].z()<<','
                   <<actual.x()<<','<<actual.y()<<','<<actual.z()<<','
                   <<expected.x()<<','<<expected.y()<<','<<expected.z()<<'\n';
                ++checks;
            }
        }
    }
    T.primitiveFieldRef()=scalar(5);
    T.correctBoundaryConditions();
    std::ofstream scalars("scalar-coefficients.csv");
    scalars<<std::setprecision(16)<<"patch,type,A,B,C,D,face,gradient\n";
    forAll(T.boundaryField(),pi)
    {
        const fvPatchScalarField& b=T.boundaryField()[pi];
        const scalarField vi(b.valueInternalCoeffs(tmp<scalarField>::New(b.size(),1)));
        const scalarField vb(b.valueBoundaryCoeffs(tmp<scalarField>::New(b.size(),1)));
        const scalarField gi(b.gradientInternalCoeffs()),gb(b.gradientBoundaryCoeffs());
        forAll(b,f)
        {
            const scalar delta=b.patch().deltaCoeffs()[f];
            scalar A=0,B=3,C=-delta,D=3*delta;
            if(b.type()=="zeroGradient"){A=1;B=0;C=0;D=0;}
            if(b.type()=="fixedGradient"){A=1;B=2/delta;C=0;D=2;}
            if(b.type()=="mixed"){A=.7;B=.3*8+.7*2/delta;C=-.3*delta;D=.3*8*delta+.7*2;}
            maxScalar=max(maxScalar,mag(vi[f]-A)+mag(vb[f]-B)+mag(gi[f]-C)+mag(gb[f]-D));
            maxScalar=max(maxScalar,mag(b[f]-(A*5+B)));
            scalars<<pi<<','<<b.type()<<','<<vi[f]<<','<<vb[f]<<','<<gi[f]<<','<<gb[f]<<','<<b[f]<<','<<(gi[f]*5+gb[f])<<'\n';
        }
    }
    std::ofstream report("boundary-status.txt");
    report<<std::setprecision(16)<<"checks "<<checks<<"\ngradientError "<<maxGradient<<"\nfaceError "<<maxFace
          <<"\nmatrixError "<<maxMatrix<<"\nscalarError "<<maxScalar<<'\n';
    Info<<"checks "<<checks<<"; gradient "<<maxGradient<<"; face "<<maxFace<<"; matrix "<<maxMatrix<<"; scalar "<<maxScalar<<nl;
    return (maxGradient>1e-11 || maxFace>1e-11 || maxMatrix>1e-11 || maxScalar>1e-11);
}
