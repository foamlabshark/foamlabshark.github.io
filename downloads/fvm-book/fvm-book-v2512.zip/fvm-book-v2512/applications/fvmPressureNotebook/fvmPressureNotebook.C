// Native OpenFOAM v2512 companion for textbook chapter 15.
// GPL-3.0-or-later; pressure-loop structure follows OpenFOAM simpleFoam/pisoFoam.
#include "fvCFD.H"
#include "constrainHbyA.H"
#include "constrainPressure.H"
#include "adjustPhi.H"
#include <fstream>
#include <iomanip>
#include <cmath>

int main(int argc, char *argv[])
{
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    volVectorField U(IOobject("U",runTime.timeName(),mesh,
        IOobject::MUST_READ,IOobject::AUTO_WRITE),mesh);
    volScalarField p(IOobject("p",runTime.timeName(),mesh,
        IOobject::MUST_READ,IOobject::AUTO_WRITE),mesh);
    surfaceScalarField phi(IOobject("phi",runTime.timeName(),mesh,
        IOobject::READ_IF_PRESENT,IOobject::AUTO_WRITE),fvc::flux(U));
    IOdictionary props(IOobject("flowProperties",runTime.constant(),mesh,
        IOobject::MUST_READ,IOobject::NO_WRITE));
    dimensionedScalar nu("nu",dimViscosity,props);
    const word algorithm=props.get<word>("algorithm");
    const bool transient=algorithm=="PISO" || algorithm=="PISO-correction";
    const bool consistent=algorithm=="SIMPLEC";
    const bool correction=algorithm=="correction" || algorithm=="PISO-correction";
    const label correctors=props.getOrDefault<label>("nCorrectors",2);
    const label nonOrth=props.getOrDefault<label>("nNonOrthogonalCorrectors",0);
    const scalar alphaU=props.getOrDefault<scalar>("alphaU",0.7);
    const scalar alphaP=props.getOrDefault<scalar>("alphaP",0.3);
    const scalar tolerance=props.getOrDefault<scalar>("steadyTolerance",1e-8);
    const scalar end=runTime.endTime().value();
    volScalarField pp(IOobject("pp",runTime.timeName(),mesh,
        IOobject::NO_READ,IOobject::NO_WRITE),mesh,
        dimensionedScalar("zero",p.dimensions(),0),p.boundaryField().types());
    mesh.setFluxRequired(p.name());
    mesh.setFluxRequired(pp.name());
    U.oldTime(); phi.oldTime();
    std::ofstream history((runTime.path()/"pressure-history.csv").c_str());
    history<<std::setprecision(16)
        <<"step,time,change,massBefore,massAfter,momentumResidual\n";
    label step=0;
    scalar change=GREAT,massAfter=GREAT,balance=GREAT,maxMass=0;
    bool converged=false;
    while (runTime.loop())
    {
        ++step;
        const vectorField oldU(U.primitiveField());
        U.storePrevIter(); p.storePrevIter(); phi.storePrevIter();
        fvVectorMatrix UEqn
        (
            fvm::div(phi,U)-fvm::laplacian(nu,U)
        );
        if (transient) UEqn+=fvm::ddt(U);
        if (!transient) UEqn.relax(alphaU);
        solve(UEqn == -fvc::grad(p));
        volScalarField rAU("rAU",1.0/UEqn.A());
        scalar massBefore=0;
        if (correction)
        {
          for(label corr=0;corr<(transient?correctors:1);++corr)
          {
            if(corr)
            {
                U=rAU*(UEqn.H()-fvc::grad(p));
                U.correctBoundaryConditions();
            }
            // The base textbook p' algorithm, with the relaxation history term.
            surfaceScalarField rAUf(fvc::interpolate(rAU));
            surfaceVectorField gradBar(fvc::interpolate(fvc::grad(p)));
            phi=fvc::flux(U)-rAUf
                *(fvc::snGrad(p)*mesh.magSf()-(gradBar & mesh.Sf()))
                +(transient?0:1-alphaU)
                *(phi.prevIter()-fvc::flux(U.prevIter()));
            if(transient) phi+=rAUf*fvc::ddtCorr(U,phi);
            forAll(U.boundaryField(),patchi)
            {
                if (U.boundaryField()[patchi].fixesValue())
                {
                    phi.boundaryFieldRef()[patchi]=
                        (U.boundaryField()[patchi] & mesh.Sf().boundaryField()[patchi]);
                }
            }
            adjustPhi(phi,U,p);
            if(!corr) massBefore=gMax(mag(fvc::div(phi)().primitiveField()));
            pp=dimensionedScalar("zero",p.dimensions(),0);
            pp.correctBoundaryConditions();
            for(label no=0;no<=nonOrth;++no)
            {
                fvScalarMatrix ppEqn
                (
                    fvm::laplacian(rAU,pp)==fvc::div(phi)
                );
                ppEqn.setReference(0,0);
                ppEqn.solve();
                if(no==nonOrth) phi-=ppEqn.flux();
            }
            p+=alphaP*pp;
            p.correctBoundaryConditions();
            U-=rAU*fvc::grad(pp);
            U.correctBoundaryConditions();
          }
        }
        else
        {
            for(label corr=0;corr<(transient?correctors:1);++corr)
            {
                volVectorField HbyA(constrainHbyA(rAU*UEqn.H(),U,p));
                surfaceScalarField phiHbyA("phiHbyA",fvc::flux(HbyA));
                if(transient) phiHbyA+=fvc::interpolate(rAU)*fvc::ddtCorr(U,phi);
                volScalarField rAtU("rAtU",rAU);
                if(consistent)
                {
                    rAtU=1.0/(1.0/rAU-UEqn.H1());
                    phiHbyA+=fvc::interpolate(rAtU-rAU)
                        *fvc::snGrad(p)*mesh.magSf();
                    HbyA-=(rAU-rAtU)*fvc::grad(p);
                }
                adjustPhi(phiHbyA,U,p);
                constrainPressure(p,U,phiHbyA,rAtU);
                if(!corr) massBefore=gMax(mag(fvc::div(phiHbyA)().primitiveField()));
                for(label no=0;no<=nonOrth;++no)
                {
                    fvScalarMatrix pEqn
                    (
                        fvm::laplacian(rAtU,p)==fvc::div(phiHbyA)
                    );
                    pEqn.setReference(0,0);
                    pEqn.solve();
                    if(no==nonOrth) phi=phiHbyA-pEqn.flux();
                }
                if(!transient) p.relax(alphaP);
                U=HbyA-rAtU*fvc::grad(p);
                U.correctBoundaryConditions();
            }
        }
        change=gMax(mag(U.primitiveField()-oldU));
        massAfter=gMax(mag(fvc::div(phi)().primitiveField()));
        maxMass=max(maxMass,massAfter);
        // Reassemble the original, unrelaxed equations after correcting phi.
        fvVectorMatrix original(fvm::div(phi,U)-fvm::laplacian(nu,U)
            ==-fvc::grad(p));
        if(transient) original+=fvm::ddt(U);
        const volVectorField originalBalance
        (
            original.A()*U-original.H()
        );
        balance=gMax(mag(originalBalance.primitiveField()));
        history<<step<<','<<runTime.value()<<','<<change<<','<<massBefore
            <<','<<massAfter<<','<<balance<<'\n';
        runTime.write();
        if(!std::isfinite(change+massAfter+balance))
            FatalErrorInFunction<<"nonfinite field"<<exit(FatalError);
        if(!transient && change<tolerance && massAfter<tolerance
            && balance<10*tolerance)
        {
            converged=true;runTime.writeNow();break;
        }
    }
    if(transient) converged=runTime.value()>=end-1e-10 && massAfter<1e-6;
    std::ofstream out((runTime.path()/"pressure-final.csv").c_str());
    out<<std::setprecision(16)<<"x,y,ux,uy,p\n";
    forAll(U,celli)
        out<<mesh.C()[celli].x()<<','<<mesh.C()[celli].y()<<','
            <<U[celli].x()<<','<<U[celli].y()<<','<<p[celli]<<'\n';
    std::ofstream flux((runTime.path()/"boundary-flux.csv").c_str());
    flux<<std::setprecision(16)<<"patch,flux\n";
    forAll(phi.boundaryField(),patchi)
        flux<<mesh.boundary()[patchi].name()<<','
            <<gSum(phi.boundaryField()[patchi])<<'\n';
    std::ofstream status((runTime.path()/"pressure-status.txt").c_str());
    status<<std::setprecision(16)<<"steps "<<step<<"\ntime "<<runTime.value()
        <<"\nchange "<<change<<"\nmassAfter "<<massAfter
        <<"\nmaxMassAfter "<<maxMass<<"\nmomentumResidual "<<balance
        <<"\nconverged "<<converged<<'\n';
    Info<<"Notebook finished: converged "<<converged<<" time "<<runTime.value()
        <<" continuity "<<massAfter<<" momentum "<<balance<<endl;
    return converged?0:2;
}
