#include "scalar.H"
#include "physicoChemicalConstants.H"
#include <vector>
#include <array>
#include <cmath>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <stdexcept>
using Foam::scalar;
using Vec=std::vector<scalar>;
using Mat=std::vector<Vec>;
Vec solve(Mat a,Vec b)
{
    const int n=b.size();
    for(int k=0;k<n;k++)
    {
        int j=k;for(int i=k+1;i<n;i++) if(std::abs(a[i][k])>std::abs(a[j][k])) j=i;
        std::swap(a[k],a[j]);std::swap(b[k],b[j]);
        if(std::abs(a[k][k])<1e-15) throw std::runtime_error("singular matrix");
        for(int i=k+1;i<n;i++)
        {
            scalar s=a[i][k]/a[k][k];
            for(int l=k;l<n;l++) a[i][l]-=s*a[k][l];
            b[i]-=s*b[k];
        }
    }
    for(int i=n-1;i>=0;i--)
    {
        for(int j=i+1;j<n;j++) b[i]-=a[i][j]*b[j];
        b[i]/=a[i][i];
    }
    return b;
}
scalar maxAbs(const Vec& a){scalar r=0;for(auto v:a)r=std::max(r,std::abs(v));return r;}
void network()
{
    const std::array<int,5> from={0,1,3,3,2},to={3,2,2,4,4};
    const Vec c={1.2,1.4,1.2,1.6,1.8};
    Vec p={400,350,300,320,250};
    std::ofstream out("gas-network.csv");out<<std::setprecision(15);
    out<<"iteration,p3,p4,p5,mA,mB,mC,mD,mE,maxMassResidual\n";
    for(int it=0;it<15;it++)
    {
        Mat J(3,Vec(3,0));Vec r(3,0),m(5);
        for(int e=0;e<5;e++)
        {
            int i=from[e],j=to[e];scalar k=c[e]/4000.;
            m[e]=k*(p[i]*p[i]-p[j]*p[j]);
            for(int row:{i,j}) if(row>=2)
            {
                scalar sign=row==i?1:-1;r[row-2]+=sign*m[e];
                if(i>=2)J[row-2][i-2]+=sign*2*k*p[i];
                if(j>=2)J[row-2][j-2]-=sign*2*k*p[j];
            }
        }
        r[2]+=25;
        out<<it;for(int i=2;i<5;i++)out<<','<<p[i];
        for(auto v:m)out<<','<<v;out<<','<<maxAbs(r)<<'\n';
        if(maxAbs(r)<1e-11)break;
        for(auto& v:r)v=-v;Vec dp=solve(J,r);
        for(int i=0;i<3;i++)p[i+2]+=dp[i];
    }
}
void nozzle(bool sup)
{
    const scalar R=2078,gamma=1.4,cp=gamma*R/(gamma-1),dx=.5;
    scalar uIn=1.2*std::sqrt(gamma*R*303);
    scalar totalT=sup?303+uIn*uIn/(2*cp):303;
    scalar totalP=sup?1e5:100701.8;
    scalar pIn=totalP/std::pow(1+.2*1.2*1.2,3.5);
    Vec area=sup?Vec{.9,1.6,2.3,3}:Vec{3,2.3,1.6,.9};
    Vec p(3,1e5),T(3,sup?303:290),u(3,sup?uIn:.1*std::sqrt(gamma*R*290));
    Vec rho(3),m(4);
    for(int i=0;i<3;i++)rho[i]=p[i]/(R*T[i]);
    for(int f=0;f<4;f++)m[f]=rho[std::min(f,2)]*u[std::min(f,2)]*area[f];
    std::ofstream out(sup?"nozzle-supersonic-three.csv":"nozzle-subsonic-three.csv");
    std::ofstream matout(sup?"nozzle-supersonic-matrices.csv":"nozzle-subsonic-matrices.csv");
    out<<std::setprecision(15);matout<<std::setprecision(15);
    out<<"iteration,cell,p,U,T,rho,mLeft,mRight,linearMassResidual\n";
    matout<<"iteration,row,a0,a1,a2,b,pPrime\n";
    for(int it=1;it<=3;it++)
    {
        scalar boundaryU=sup?uIn:u[0];
        scalar boundaryT=sup?303:totalT-boundaryU*boundaryU/(2*cp);
        scalar boundaryP=sup?pIn:totalP/std::pow(totalT/boundaryT,gamma/(gamma-1));
        scalar boundaryRho=boundaryP/(R*boundaryT);
        Vec pf={boundaryP,.5*(p[0]+p[1]),.5*(p[1]+p[2]),sup?p[2]:1e5};
        Vec vol(3),grad(3),D(3);Mat a(3,Vec(3,0));Vec b(3,0);
        for(int i=0;i<3;i++)
        {
            vol[i]=.5*(area[i]+area[i+1])*dx;grad[i]=(pf[i+1]-pf[i])/dx;
            b[i]=-vol[i]*grad[i];
            if(i==0)b[i]+=m[0]*boundaryU;
            else {a[i][i]+=std::max(-m[i],scalar(0));a[i][i-1]-=std::max(m[i],scalar(0));}
            if(i==2)a[i][i]+=m[3];
            else {a[i][i]+=std::max(m[i+1],scalar(0));a[i][i+1]+=std::min(m[i+1],scalar(0));}
            scalar oldDiag=a[i][i];a[i][i]/=.7;b[i]+=(1/.7-1)*oldDiag*u[i];
            D[i]=vol[i]/a[i][i];
        }
        Vec us=solve(a,b),uf(4),rf(4),tf(4),Df(4),md(4),B(4),K(4);
        for(int f=1;f<3;f++)
        {
            Df[f]=.5*(D[f-1]+D[f]);
            uf[f]=.5*(us[f-1]+us[f])-Df[f]*((p[f]-p[f-1])/dx-.5*(grad[f-1]+grad[f]));
            int up=uf[f]>=0?f-1:f;rf[f]=rho[up];tf[f]=T[up];
        }
        Df[0]=D[0];Df[3]=D[2];
        uf[0]=sup?uIn:us[0]-D[0]*((p[0]-boundaryP)/(.5*dx)-grad[0]);
        uf[3]=sup?us[2]:us[2]-D[2]*((1e5-p[2])/(.5*dx)-grad[2]);
        rf[0]=boundaryRho;tf[0]=boundaryT;
        rf[3]=(sup?p[2]:1e5)/(R*T[2]);tf[3]=T[2];
        for(int f=0;f<4;f++)
        {
            md[f]=rf[f]*uf[f]*area[f];B[f]=md[f]/rf[f]/(R*tf[f]);
            K[f]=rf[f]*Df[f]*area[f]/((f==0||f==3)?.5*dx:dx);
        }
        // Face coefficients express positive-x mass-flux corrections.
        Mat fc(4,Vec(3,0));
        for(int f=1;f<3;f++)
        {
            fc[f][f-1]=K[f]+std::max(B[f],scalar(0));
            fc[f][f]=-K[f]+std::min(B[f],scalar(0));
        }
        scalar cb=0;
        if(!sup)
        {
            scalar X=1+.5*(gamma-1)*uf[0]*uf[0]/(gamma*R*boundaryT);
            // Derivative with respect to outward (negative) inlet mass flow.
            cb=md[0]*totalP/(rf[0]*rf[0]*area[0]*area[0]*R*boundaryT)*std::pow(X,-(2*gamma-1)/(gamma-1));
            fc[0][0]=-K[0]/(1+(K[0]+B[0])*cb);
        }
        fc[3][2]=sup?B[3]:K[3];
        Mat ap(3,Vec(3,0));Vec bp(3);
        for(int i=0;i<3;i++)
        {
            bp[i]=md[i]-md[i+1];
            for(int j=0;j<3;j++)ap[i][j]=fc[i+1][j]-fc[i][j];
        }
        Vec pp=solve(ap,bp),mp(4,0);
        for(int f=0;f<4;f++)for(int j=0;j<3;j++)mp[f]+=fc[f][j]*pp[j];
        scalar ppIn=sup?0:-cb*mp[0];
        Vec ppf={ppIn,.5*(pp[0]+pp[1]),.5*(pp[1]+pp[2]),sup?pp[2]:0};
        for(int i=0;i<3;i++)
        {
            matout<<it<<','<<i;for(auto v:ap[i])matout<<','<<v;matout<<','<<bp[i]<<','<<pp[i]<<'\n';
            p[i]+=.3*pp[i];u[i]=us[i]-D[i]*(ppf[i+1]-ppf[i])/dx;
            T[i]=totalT-u[i]*u[i]/(2*cp);
            if(p[i]<=0||T[i]<=0)throw std::runtime_error("nonphysical iterate: reduce relaxation");
            rho[i]=p[i]/(R*T[i]);
            out<<it<<','<<i<<','<<p[i]<<','<<u[i]<<','<<T[i]<<','<<rho[i]<<','
                <<md[i]+mp[i]<<','<<md[i+1]+mp[i+1]<<','<<md[i+1]+mp[i+1]-md[i]-mp[i]<<'\n';
        }
        for(int f=0;f<4;f++)m[f]=md[f]+mp[f];
    }
}
int main()
{
    std::cout<<std::setprecision(16)<<"native universal gas constant "
        <<1000*Foam::constant::physicoChemical::R.value()<<'\n';
    network();nozzle(false);nozzle(true);
    std::cout<<"network and two three-iteration nozzle exercises completed\n";
    return 0;
}
