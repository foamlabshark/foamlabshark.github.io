/* FoamLab teaching solver; GPL-3.0-or-later. OpenCFD OpenFOAM v2512. */
#include "fvCFD.H"
#include "simpleControl.H"

int main(int argc, char *argv[])
{
    argList::addBoolOption("inspect", "Write geometry, linear-field gradient and matrix coefficients");
    argList::addBoolOption("interpolation-test", "Verify interpolation identities and list available scalar schemes");
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    simpleControl simple(mesh);
    volScalarField c(IOobject("c",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::AUTO_WRITE),mesh);
    volVectorField U(IOobject("U",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE),mesh);
    surfaceScalarField phi(IOobject("phi",runTime.timeName(),mesh,IOobject::NO_READ,IOobject::AUTO_WRITE),fvc::flux(U));
    IOdictionary props(IOobject("transportProperties",runTime.constant(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE));
    dimensionedScalar D("D",dimViscosity,props);
    dimensionedScalar decay("decay",dimless/dimTime,props);
    dimensionedScalar source("source",dimless/dimTime,props);
    const word velocityProfile=props.lookupOrDefault<word>("velocityProfile","read");
    const scalar steadyTolerance=props.lookupOrDefault<scalar>("steadyTolerance",0);
    if (velocityProfile!="read")
    {
        if (velocityProfile!="polynomial" && velocityProfile!="smithHutton")
        {
            FatalErrorInFunction<<"Unknown velocityProfile "<<velocityProfile<<exit(FatalError);
        }
        const auto velocity=[&](const vector& p)
        {
            const scalar x=p.x(), y=p.y();
            if (velocityProfile=="polynomial") return vector(2*y*x*x,-2*x*y*y,0);
            return vector(2*y*(1-x*x),-2*x*(1-y*y),0);
        };
        forAll(U,i) U[i]=velocity(mesh.C()[i]);
        forAll(U.boundaryField(),p)
        {
            forAll(U.boundaryField()[p],f)
                U.boundaryFieldRef()[p][f]=velocity(mesh.Cf().boundaryField()[p][f]);
        }
        // Exact face-centre evaluation preserves discrete continuity for these
        // polynomial fields on the supplied Cartesian meshes.
        forAll(phi,f) phi[f]=velocity(mesh.Cf()[f]) & mesh.Sf()[f];
        forAll(phi.boundaryField(),p)
        {
            forAll(phi.boundaryField()[p],f)
                phi.boundaryFieldRef()[p][f]=
                    velocity(mesh.Cf().boundaryField()[p][f]) & mesh.Sf().boundaryField()[p][f];
        }
    }
    Info<<"max flux divergence "<<gMax(mag(fvc::div(phi)().primitiveField()))<<nl;

    if (args.found("interpolation-test"))
    {
        Info<<"available scalar schemes "<<
            surfaceInterpolationScheme<scalar>::MeshFluxConstructorTablePtr_->sortedToc()<<nl;
        OFstream test(runTime.path()/"interpolation-checks.csv");
        test.precision(15);
        test<<"test,maxError"<<nl;
        scalar worst=0;
        for (const auto values : {Pair<scalar>(4,9),Pair<scalar>(0,9),
            Pair<scalar>(9,9),Pair<scalar>(1,16),Pair<scalar>(0,0)})
        {
            volScalarField probe(c);
            forAll(probe,i) probe[i]=i%2 ? values.second():values.first();
            IStringStream data("bookGeometric");
            auto scheme=surfaceInterpolationScheme<scalar>::New(mesh,phi,data());
            const surfaceScalarField face(scheme().interpolate(probe));
            scalar error=0;
            forAll(mesh.neighbour(),f)
                error=max(error,mag(face[f]-Foam::sqrt(probe[mesh.owner()[f]]*probe[mesh.neighbour()[f]])));
            reduce(error,maxOp<scalar>());
            worst=max(worst,error);
            test<<"geometric_"<<values.first()<<'_'<<values.second()<<','<<error<<nl;
        }
        for (const word name : {"bookSOU","bookQUICK"})
        {
            volScalarField probe(c);
            forAll(probe,i) probe[i]=1+2*mesh.C()[i].x()+3*mesh.C()[i].y();
            forAll(probe.boundaryField(),p)
                forAll(probe.boundaryField()[p],f)
                {
                    const vector& x=mesh.Cf().boundaryField()[p][f];
                    probe.boundaryFieldRef()[p][f]=1+2*x.x()+3*x.y();
                }
            IStringStream data(name+" grad(c)");
            auto scheme=surfaceInterpolationScheme<scalar>::New(mesh,phi,data());
            const surfaceScalarField face(scheme().interpolate(probe));
            scalar error=0;
            forAll(mesh.neighbour(),f)
            {
                const vector& x=mesh.Cf()[f];
                error=max(error,mag(face[f]-(1+2*x.x()+3*x.y())));
            }
            reduce(error,maxOp<scalar>());
            worst=max(worst,error);
            test<<name<<"_linear,"<<error<<nl;
        }
        Info<<"interpolation max error "<<worst<<nl;
        return worst<1e-11 ? 0:1;
    }

    if (args.found("inspect"))
    {
        OFstream geometry(runTime.path()/"geometry.csv");
        geometry<<"cell,x,y,z,volume"<<nl;
        forAll(mesh.V(), i)
        {
            const vector& x=mesh.C()[i];
            geometry<<i<<','<<x.x()<<','<<x.y()<<','<<x.z()<<','<<mesh.V()[i]<<nl;
        }
        OFstream faces(runTime.path()/"internal-faces.csv");
        faces<<"face,owner,neighbour,Sx,Sy,Sz"<<nl;
        forAll(mesh.neighbour(), f)
        {
            const vector& sf=mesh.Sf()[f];
            faces<<f<<','<<mesh.owner()[f]<<','<<mesh.neighbour()[f]<<','<<sf.x()<<','<<sf.y()<<','<<sf.z()<<nl;
        }
        volScalarField probe(IOobject("linearProbe",runTime.timeName(),mesh,IOobject::NO_READ,IOobject::NO_WRITE),mesh,dimensionedScalar("zero",dimless,0));
        forAll(probe, i) probe[i]=1+2*mesh.C()[i].x()+3*mesh.C()[i].y();
        forAll(probe.boundaryField(), p)
        {
            forAll(probe.boundaryField()[p], f)
            {
                const vector& x=mesh.Cf().boundaryField()[p][f];
                probe.boundaryFieldRef()[p][f]=1+2*x.x()+3*x.y();
            }
        }
        volVectorField gradient(fvc::grad(probe));
        OFstream grad(runTime.path()/"gradient.csv");
        grad<<"cell,gx,gy,gz,error"<<nl;
        forAll(gradient, i) grad<<i<<','<<gradient[i].x()<<','<<gradient[i].y()<<','<<gradient[i].z()<<','<<mag(gradient[i]-vector(2,3,0))<<nl;
    }

    bool first=true;
    scalar finalBalance=GREAT, finalChange=GREAT;
    label completedSteps=0;
    while (simple.loop())
    {
        const scalarField previous(c.primitiveField());
        Info<<"Time = "<<runTime.timeName()<<nl;
        while (simple.correctNonOrthogonal())
        {
            fvScalarMatrix cEqn
            (
                fvm::ddt(c)
              + fvm::div(phi,c)
              - fvm::laplacian(D,c)
              + fvm::Sp(decay,c)
             == source
            );
            if (first && args.found("inspect"))
            {
                OFstream matrix(runTime.path()/"matrix.txt");
                matrix<<"INTERNAL diagonal (boundary contributions stored separately)"<<nl<<cEqn.diag()<<nl;
                matrix<<"upper"<<nl<<cEqn.upper()<<nl<<"lower"<<nl<<cEqn.lower()<<nl;
                matrix<<"source"<<nl<<cEqn.source()<<nl;
                matrix<<"boundary internalCoeffs"<<nl<<cEqn.internalCoeffs()<<nl;
                matrix<<"boundary boundaryCoeffs"<<nl<<cEqn.boundaryCoeffs()<<nl;
                first=false;
            }
            cEqn.relax();
            cEqn.solve();
        }
        Info<<"c range "<<gMin(c.primitiveField())<<' '<<gMax(c.primitiveField())<<nl;
        ++completedSteps;
        if (steadyTolerance>0)
        {
            volScalarField balance
            (
                fvc::div(phi,c)-fvc::laplacian(D,c)+decay*c-source
            );
            finalBalance=gMax(mag(balance.primitiveField()));
            finalChange=gMax(mag(c.primitiveField()-previous));
            Info<<"true steady balance "<<finalBalance<<" change "<<finalChange<<nl;
            if (finalBalance<steadyTolerance && finalChange<steadyTolerance)
            {
                runTime.writeNow();
                break;
            }
        }
        runTime.write();
    }
    if (steadyTolerance>0)
    {
        OFstream report(runTime.path()/"convergence.txt");
        report.precision(15);
        report<<"iterations "<<completedSteps<<nl
              <<"balance "<<finalBalance<<nl<<"change "<<finalChange<<nl
              <<"converged "<<(finalBalance<steadyTolerance && finalChange<steadyTolerance)<<nl;
    }
    OFstream values(runTime.path()/"solution.csv");
    values.precision(12);
    values<<"x,y,c"<<nl;
    forAll(c, i) values<<mesh.C()[i].x()<<','<<mesh.C()[i].y()<<','<<c[i]<<nl;
    Info<<"End"<<nl;
    return (steadyTolerance>0 && (finalBalance>=steadyTolerance || finalChange>=steadyTolerance)) ? 2:0;
}
