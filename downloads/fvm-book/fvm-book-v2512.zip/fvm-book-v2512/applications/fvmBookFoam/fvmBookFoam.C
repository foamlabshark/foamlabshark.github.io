/* FoamLab teaching solver; GPL-3.0-or-later. OpenCFD OpenFOAM v2512. */
#include "fvCFD.H"
#include "simpleControl.H"

int main(int argc, char *argv[])
{
    argList::addBoolOption("inspect", "Write geometry, linear-field gradient and matrix coefficients");
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    simpleControl simple(mesh);
    volScalarField c(IOobject("c",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::AUTO_WRITE),mesh);
    volVectorField U(IOobject("U",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE),mesh);
    surfaceScalarField phi(IOobject("phi",runTime.timeName(),mesh,IOobject::NO_READ,IOobject::AUTO_WRITE),fvc::flux(U));
    IOdictionary props(IOobject("transportProperties",runTime.constant(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE));
    dimensionedScalar D("D",dimViscosity,props);
    dimensionedScalar decay("decay",dimless/dimTime,props);
    dimensionedScalar source("source",dimless/dimTime,props);

    if (args.found("inspect"))
    {
        OFstream geometry(runTime.path()/"geometry.csv");
        geometry<<"cell,x,y,z,volume"<<nl;
        forAll(mesh.V(), i)
        {
            const vector& x=mesh.C()[i];
            geometry<<i<<','<<x.x()<<','<<x.y()<<','<<x.z()<<','<<mesh.V()[i]<<nl;
        }
        OFstream faces(runTime.path()/"internal-faces.csv");
        faces<<"face,owner,neighbour,Sx,Sy,Sz"<<nl;
        forAll(mesh.neighbour(), f)
        {
            const vector& sf=mesh.Sf()[f];
            faces<<f<<','<<mesh.owner()[f]<<','<<mesh.neighbour()[f]<<','<<sf.x()<<','<<sf.y()<<','<<sf.z()<<nl;
        }
        volScalarField probe(IOobject("linearProbe",runTime.timeName(),mesh,IOobject::NO_READ,IOobject::NO_WRITE),mesh,dimensionedScalar("zero",dimless,0));
        forAll(probe, i) probe[i]=1+2*mesh.C()[i].x()+3*mesh.C()[i].y();
        forAll(probe.boundaryField(), p)
        {
            forAll(probe.boundaryField()[p], f)
            {
                const vector& x=mesh.Cf().boundaryField()[p][f];
                probe.boundaryFieldRef()[p][f]=1+2*x.x()+3*x.y();
            }
        }
        volVectorField gradient(fvc::grad(probe));
        OFstream grad(runTime.path()/"gradient.csv");
        grad<<"cell,gx,gy,gz,error"<<nl;
        forAll(gradient, i) grad<<i<<','<<gradient[i].x()<<','<<gradient[i].y()<<','<<gradient[i].z()<<','<<mag(gradient[i]-vector(2,3,0))<<nl;
    }

    bool first=true;
    while (simple.loop())
    {
        Info<<"Time = "<<runTime.timeName()<<nl;
        while (simple.correctNonOrthogonal())
        {
            fvScalarMatrix cEqn
            (
                fvm::ddt(c)
              + fvm::div(phi,c)
              - fvm::laplacian(D,c)
              + fvm::Sp(decay,c)
             == source
            );
            if (first && args.found("inspect"))
            {
                OFstream matrix(runTime.path()/"matrix.txt");
                matrix<<"INTERNAL diagonal (boundary contributions stored separately)"<<nl<<cEqn.diag()<<nl;
                matrix<<"upper"<<nl<<cEqn.upper()<<nl<<"lower"<<nl<<cEqn.lower()<<nl;
                matrix<<"source"<<nl<<cEqn.source()<<nl;
                matrix<<"boundary internalCoeffs"<<nl<<cEqn.internalCoeffs()<<nl;
                matrix<<"boundary boundaryCoeffs"<<nl<<cEqn.boundaryCoeffs()<<nl;
                first=false;
            }
            cEqn.relax();
            cEqn.solve();
        }
        Info<<"c range "<<gMin(c.primitiveField())<<' '<<gMax(c.primitiveField())<<nl;
        runTime.write();
    }
    OFstream values(runTime.path()/"solution.csv");
    values.precision(12);
    values<<"x,y,c"<<nl;
    forAll(c, i) values<<mesh.C()[i].x()<<','<<mesh.C()[i].y()<<','<<c[i]<<nl;
    Info<<"End"<<nl;
    return 0;
}
