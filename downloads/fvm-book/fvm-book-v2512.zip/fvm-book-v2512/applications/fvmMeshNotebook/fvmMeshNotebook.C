/* FoamLab mesh and gradient exercises; GPL-3.0-or-later. OpenCFD v2512. */
#include "fvCFD.H"
#include "gradScheme.H"

scalar probeValue(const vector& x, const word& name)
{
    if (name == "quadratic") return 10*x.x()*x.y() + 5*sqr(x.y());
    if (name == "quartic") return 10*sqr(x.x())*sqr(x.y());
    if (name == "quarticX") return 10*sqr(x.x())*sqr(x.y()) + 3*x.x();
    if (name == "quarticY") return 10*sqr(x.x())*sqr(x.y()) + 3*x.y();
    return 1 + 2*x.x() + 3*x.y();
}

vector exactGradient(const vector& x, const word& name)
{
    if (name == "quadratic") return vector(10*x.y(), 10*x.x()+10*x.y(), 0);
    if (name == "quartic") return vector(20*x.x()*sqr(x.y()), 20*sqr(x.x())*x.y(), 0);
    if (name == "quarticX") return vector(20*x.x()*sqr(x.y())+3, 20*sqr(x.x())*x.y(), 0);
    if (name == "quarticY") return vector(20*x.x()*sqr(x.y()), 20*sqr(x.x())*x.y()+3, 0);
    return vector(2, 3, 0);
}

int main(int argc, char *argv[])
{
    argList::addOption("probe", "name", "linear, quadratic, quartic, quarticX, quarticY");
    argList::addOption("method", "name", "gauss, leastSquares, pointLinear, skewCorrected");
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    const word name(args.getOrDefault<word>("probe", "linear"));
    const word method(args.getOrDefault<word>("method", "gauss"));
    if (name != "linear" && name != "quadratic" && name != "quartic"
        && name != "quarticX" && name != "quarticY")
    {
        FatalErrorInFunction << "Unknown probe " << name << exit(FatalError);
    }

    const labelList& owner = mesh.faceOwner();
    const labelList& neighbour = mesh.faceNeighbour();
    const vectorField& areas = mesh.faceAreas();
    const vectorField& centres = mesh.faceCentres();
    const scalarField& volumes = mesh.cellVolumes();
    vectorField closure(mesh.nCells(), vector::zero);
    scalarField areaSum(mesh.nCells(), 0);
    forAll(owner, facei)
    {
        closure[owner[facei]] += areas[facei];
        areaSum[owner[facei]] += mag(areas[facei]);
    }
    forAll(neighbour, facei)
    {
        closure[neighbour[facei]] -= areas[facei];
        areaSum[neighbour[facei]] += mag(areas[facei]);
    }
    scalar maxClosure = 0;
    forAll(closure, celli)
    {
        maxClosure = max(maxClosure, mag(closure[celli])/max(areaSum[celli], VSMALL));
    }

    const fileName folder(runTime.path()/"notebook");
    mkDir(folder);
    OFstream cells(folder/"cells.txt");
    forAll(mesh.cells(), celli)
    {
        cells << "cell " << celli << " faces " << mesh.cells()[celli]
            << " neighbours " << mesh.cellCells()[celli]
            << " centre " << mesh.cellCentres()[celli]
            << " volume " << volumes[celli] << nl;
    }
    OFstream faceFile(folder/"faces.csv");
    faceFile.precision(14);
    faceFile << "face,owner,neighbour,cx,cy,cz,Sx,Sy,Sz" << nl;
    forAll(owner, facei)
    {
        const vector& x = centres[facei];
        const vector& s = areas[facei];
        faceFile << facei << ',' << owner[facei] << ','
            << (facei < neighbour.size() ? neighbour[facei] : -1) << ','
            << x.x() << ',' << x.y() << ',' << x.z() << ','
            << s.x() << ',' << s.y() << ',' << s.z() << nl;
    }
    OFstream patches(folder/"patches.txt");
    forAll(mesh.boundaryMesh(), patchi)
    {
        const polyPatch& patch = mesh.boundaryMesh()[patchi];
        patches << patch.name() << " type " << patch.type()
            << " start " << patch.start() << " size " << patch.size() << nl;
    }

    volScalarField q
    (
        IOobject("notebookProbe", runTime.timeName(), mesh, IOobject::NO_READ, IOobject::NO_WRITE),
        mesh,
        dimensionedScalar("zero", dimless, 0)
    );
    forAll(q, celli) q[celli] = probeValue(mesh.C()[celli], name);
    forAll(q.boundaryField(), patchi)
    {
        auto& values = q.boundaryFieldRef()[patchi];
        const auto& x = mesh.Cf().boundaryField()[patchi];
        forAll(values, facei) values[facei] = probeValue(x[facei], name);
    }
    const surfaceScalarField faceQ(fvc::interpolate(q));
    vectorField manual(mesh.nCells(), vector::zero);
    forAll(mesh.neighbour(), facei)
    {
        const vector contribution = mesh.Sf()[facei]*faceQ[facei];
        manual[owner[facei]] += contribution;
        manual[neighbour[facei]] -= contribution;
    }
    forAll(faceQ.boundaryField(), patchi)
    {
        const auto& values = faceQ.boundaryField()[patchi];
        const auto& sf = mesh.Sf().boundaryField()[patchi];
        const auto& fc = mesh.boundary()[patchi].faceCells();
        forAll(values, facei) manual[fc[facei]] += sf[facei]*values[facei];
    }
    forAll(manual, celli) manual[celli] /= volumes[celli];
    string scheme("Gauss linear");
    if (method == "leastSquares") scheme = "leastSquares";
    else if (method == "pointLinear") scheme = "Gauss pointLinear";
    else if (method == "skewCorrected") scheme = "Gauss skewCorrected linear";
    else if (method != "gauss")
    {
        FatalErrorInFunction << "Unknown method " << method << exit(FatalError);
    }
    IStringStream schemeInput(scheme);
    const volVectorField native
    (
        fv::gradScheme<scalar>::New(mesh, schemeInput)().grad(q, "grad(notebookProbe)")
    );
    const word resultName(name + "-" + method);
    scalar maxError=0, sumError=0, manualError=0;
    OFstream gradient(folder/(resultName+"-gradient.csv"));
    gradient.precision(14);
    gradient << "cell,x,y,z,gx,gy,gz,exactX,exactY,exactZ,error" << nl;
    forAll(native, celli)
    {
        const vector& x = mesh.C()[celli];
        const vector& g = native[celli];
        const vector exact = exactGradient(x, name);
        const scalar error = mag(g-exact);
        maxError = max(maxError, error);
        sumError += volumes[celli]*sqr(error);
        manualError = max(manualError, mag(g-manual[celli]));
        gradient << celli << ',' << x.x() << ',' << x.y() << ',' << x.z() << ','
            << g.x() << ',' << g.y() << ',' << g.z() << ','
            << exact.x() << ',' << exact.y() << ',' << exact.z() << ',' << error << nl;
    }
    volVectorField exactCell(native);
    forAll(exactCell, celli) exactCell[celli] = exactGradient(mesh.C()[celli], name);
    forAll(exactCell.boundaryField(), patchi)
    {
        auto& values = exactCell.boundaryFieldRef()[patchi];
        const auto& x = mesh.Cf().boundaryField()[patchi];
        forAll(values, facei) values[facei] = exactGradient(x[facei], name);
    }
    const surfaceVectorField averageFace(fvc::interpolate(exactCell));
    scalar faceAverageError=0, faceCorrectedError=0;
    OFstream faceGradient(folder/(resultName+"-face-gradient.csv"));
    faceGradient.precision(14);
    faceGradient << "face,averageX,averageY,correctedX,correctedY,exactX,exactY,averageError,correctedError" << nl;
    forAll(neighbour, facei)
    {
        const vector d = mesh.C()[neighbour[facei]] - mesh.C()[owner[facei]];
        const vector e = d/mag(d);
        const vector average = averageFace[facei];
        const vector corrected = average
          + ((q[neighbour[facei]]-q[owner[facei]])/mag(d)-(average & e))*e;
        const vector exact = exactGradient(mesh.Cf()[facei], name);
        const scalar averageError = mag(average-exact);
        const scalar correctedError = mag(corrected-exact);
        faceAverageError += sqr(averageError);
        faceCorrectedError += sqr(correctedError);
        faceGradient << facei << ',' << average.x() << ',' << average.y() << ','
            << corrected.x() << ',' << corrected.y() << ',' << exact.x() << ','
            << exact.y() << ',' << averageError << ',' << correctedError << nl;
    }
    OFstream summary(folder/(resultName+"-summary.txt"));
    summary.precision(14);
    summary << "method " << method << nl
        << "cells " << mesh.nCells() << nl
        << "totalVolume " << sum(volumes) << nl
        << "relativeClosureMax " << maxClosure << nl
        << "manualVsNativeMax " << manualError << nl
        << "analyticErrorMax " << maxError << nl
        << "analyticErrorRMS " << Foam::sqrt(sumError/sum(volumes)) << nl
        << "faceAverageRMS " << Foam::sqrt(faceAverageError/max(label(1),neighbour.size())) << nl
        << "faceCorrectedRMS " << Foam::sqrt(faceCorrectedError/max(label(1),neighbour.size())) << nl;
    Info << "Probe " << name << " max error " << maxError
        << " RMS " << Foam::sqrt(sumError/sum(volumes))
        << " manual/native difference " << manualError
        << " closure " << maxClosure << nl << "End" << nl;
    return 0;
}
