#include "fvCFD.H"
#include "wallDist.H"
#include <fstream>
#include <iomanip>

int main(int argc, char *argv[])
{
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    volScalarField psi
    (
        IOobject("psi", runTime.timeName(), mesh, IOobject::MUST_READ, IOobject::AUTO_WRITE),
        mesh
    );
    solve(fvm::laplacian(psi) == dimensionedScalar("minusOne", dimless, -1));
    volVectorField gradPsi(fvc::grad(psi));
    volScalarField distance
    (
        IOobject("distance", runTime.timeName(), mesh, IOobject::NO_READ, IOobject::AUTO_WRITE),
        2*max(psi, dimensionedScalar("zero", sqr(dimLength), 0))
       /(sqrt(magSqr(gradPsi)+2*psi)+mag(gradPsi)
          +dimensionedScalar("small", dimLength, SMALL))
    );
    const volScalarField& native = wallDist::New(mesh).y();
    std::ofstream out("wall-distance.csv");
    out << std::setprecision(16) << "x,y,psi,distance,exact,native\n";
    scalar err=0, difference=0;
    forAll(mesh.C(), c)
    {
        const scalar z=mesh.C()[c].y();
        const scalar exact=min(z, 1-z);
        err=max(err, mag(distance[c]-exact));
        difference=max(difference, mag(distance[c]-native[c]));
        out<<mesh.C()[c].x()<<','<<z<<','<<psi[c]<<','<<distance[c]<<','<<exact<<','<<native[c]<<'\n';
    }
    psi.write(); distance.write();
    Info<<"wallDistance Linf = "<<err<<"; native difference = "<<difference<<nl;
    return 0;
}
