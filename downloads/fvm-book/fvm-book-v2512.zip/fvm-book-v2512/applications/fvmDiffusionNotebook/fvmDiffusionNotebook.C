/* Explicit nonorthogonal decompositions for chapter 8. GPL-3.0-or-later. */
#include "fvCFD.H"
#include "mixedFvPatchFields.H"
using namespace Foam;
int main(int argc,char* argv[])
{
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    IOdictionary cfg(IOobject("notebookDict",runTime.system(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE));
    const word method(cfg.get<word>("decomposition"));
    const scalar relax=cfg.getOrDefault<scalar>("relaxation",1);
    const label limit=cfg.getOrDefault<label>("iterations",10000);
    volScalarField T(IOobject("T",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::AUTO_WRITE),mesh);
    forAll(T.boundaryField(),pi)
    {
        if (isA<mixedFvPatchScalarField>(T.boundaryField()[pi]))
        {
            auto& b=refCast<mixedFvPatchScalarField>(T.boundaryFieldRef()[pi]);
            b.valueFraction()=1/(1+mesh.boundary()[pi].deltaCoeffs());
        }
    }
    T.correctBoundaryConditions();
    const auto& owner=mesh.owner();const auto& nei=mesh.neighbour();
    auto split=[&](const vector& s,const vector& d)
    {
        const vector e=d/mag(d);
        scalar a=s&e;
        if(method=="equal") a=mag(s);
        else if(method=="over") a=magSqr(s)/(s&e);
        else if(method!="minimum") FatalErrorInFunction<<"Unknown split"<<exit(FatalError);
        return a*e;
    };
    OFstream history("history.csv");history.precision(16);
    history<<"iteration,maxChange,linearInitialResidual"<<nl;
    label iteration=0;scalar change=GREAT;
    while (++iteration<=limit)
    {
        const scalarField old(T.primitiveField());
        const volVectorField grad(fvc::grad(T));
        const surfaceVectorField gf(fvc::interpolate(grad));
        fvScalarMatrix eq(T,dimTemperature*dimLength);
        forAll(nei,fi)
        {
            const label c=owner[fi],f=nei[fi];
            const vector d=mesh.C()[f]-mesh.C()[c],s=mesh.Sf()[fi],e=split(s,d);
            const scalar g=mag(e)/mag(d),q=gf[fi]&(s-e);
            eq.diag()[c]+=g;eq.diag()[f]+=g;
            eq.upper()[fi]=-g;
            eq.source()[c]+=q;eq.source()[f]-=q;
        }
        forAll(mesh.boundary(),pi)
        {
            const auto& b=T.boundaryField()[pi];const auto& p=mesh.boundary()[pi];
            if(p.type()=="empty"||b.type()=="zeroGradient")continue;
            forAll(p,fi)
            {
                const label c=p.faceCells()[fi];
                if(isA<mixedFvPatchScalarField>(b))
                {
                    const auto& mixed=refCast<const mixedFvPatchScalarField>(b);
                    const scalar g=p.magSf()[fi]*p.deltaCoeffs()[fi]*mixed.valueFraction()[fi];
                    eq.diag()[c]+=g;eq.source()[c]+=g*mixed.refValue()[fi];
                }
                else
                {
                    const vector d=mesh.Cf().boundaryField()[pi][fi]-mesh.C()[c];
                    const vector s=mesh.Sf().boundaryField()[pi][fi],e=split(s,d);
                    const scalar g=mag(e)/mag(d),q=grad[c]&(s-e);
                    eq.diag()[c]+=g;eq.source()[c]+=g*b[fi]+q;
                }
            }
        }
        eq.relax(relax);
        const auto perf=eq.solve();
        T.correctBoundaryConditions();
        change=gMax(mag(T.primitiveField()-old));
        history<<iteration<<','<<change<<','<<perf.initialResidual()<<nl;
        if(iteration==4)
        {
            OFstream four("iteration-four.csv");four.precision(16);four<<"cell,T"<<nl;
            forAll(T,c)four<<c<<','<<T[c]<<nl;
        }
        if(change<1e-10 && iteration>=4)break;
    }
    const volVectorField grad(fvc::grad(T));
    OFstream field("solution.csv");field.precision(16);field<<"cell,x,y,z,T"<<nl;
    forAll(T,c)field<<c<<','<<mesh.C()[c].x()<<','<<mesh.C()[c].y()<<','<<mesh.C()[c].z()<<','<<T[c]<<nl;
    OFstream flux("boundary-flux.csv");flux.precision(16);flux<<"patch,outwardFlux"<<nl;
    scalar sumFlux=0,sumAbs=0;
    forAll(mesh.boundary(),pi)
    {
        const auto& b=T.boundaryField()[pi];const auto& p=mesh.boundary()[pi];scalar total=0;
        if(p.type()!="empty"&&b.type()!="zeroGradient")
        {
            forAll(p,fi)
            {
                const label c=p.faceCells()[fi];scalar q=0;
                if(isA<mixedFvPatchScalarField>(b))q=(b[fi]-T[c])*p.deltaCoeffs()[fi]*p.magSf()[fi];
                else
                {
                    const vector d=mesh.Cf().boundaryField()[pi][fi]-mesh.C()[c];
                    const vector s=mesh.Sf().boundaryField()[pi][fi],e=split(s,d);
                    q=mag(e)/mag(d)*(b[fi]-T[c])+(grad[c]&(s-e));
                }
                total-=q;sumAbs+=mag(q);
            }
        }
        sumFlux+=total;flux<<p.name()<<','<<total<<nl;
    }
    T.write();
    OFstream status("diffusion-status.txt");status.precision(16);
    status<<"iterations "<<iteration<<nl<<"maxChange "<<change<<nl
          <<"relativeFluxImbalance "<<mag(sumFlux)/max(sumAbs,VSMALL)<<nl;
    return iteration>limit ? 2:0;
}
