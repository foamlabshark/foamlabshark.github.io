#include "fvCFD.H"
#include "../../libraries/bookInterpolation/bookHRFunctions.H"
#include <iomanip>
#include <iostream>
using namespace Foam;
int main()
{
    scalar maxError=0,maxBoundViolation=0;
    for (label i=-200;i<=1200;++i)
    {
        const scalar s=scalar(i)/1000;
        for (const scalar scale : {scalar(1e-12),scalar(1),scalar(1e12)})
        {
            for (const scalar sign : {scalar(-1),scalar(1)})
            {
                const scalar u=sign*scale*s,d=sign*scale,v=0;
                const scalar a=bookHRFunctions::correction("SMART",u,d,v);
                const scalar b=bookHRFunctions::correction("SMART_TVD",u,d,v);
                maxError=max(maxError,mag(a-b)/scale);
            }
        }
        if (s>=0 && s<=1)
        {
            for (const word name : {"SMART","STOIC","OSHER","MINMOD","MUSCL","SUPERBEE"})
            {
                const scalar f=bookHRFunctions::normalized(name,s);
                maxBoundViolation=max(maxBoundViolation,max(s-f,f-1));
            }
        }
    }
    std::cout<<std::setprecision(16)
        <<"normalized,TVD equivalence error,"<<maxError<<"\n"
        <<"CBC violation,"<<maxBoundViolation<<"\n"
        <<"U,C,D,SMART,OSHER,QUICK,SOU,vanLeer,MINMOD\n";
    const scalar values[][3]={{30,20,10},{10,5,15},{30,10,5},{30,25,5}};
    for (const auto& a : values)
    {
        const scalar U=a[0],C=a[1],D=a[2],r=(C-U)/(D-C);
        std::cout<<U<<","<<C<<","<<D<<","
            <<C+bookHRFunctions::correction("SMART",C,D,U)<<","
            <<C+bookHRFunctions::correction("OSHER",C,D,U)<<","
            <<0.375*D+0.75*C-0.125*U<<","<<1.5*C-0.5*U<<","
            <<C+0.5*(r+mag(r))/(1+mag(r))*(D-C)<<","
            <<C+bookHRFunctions::correction("MINMOD",C,D,U)<<"\n";
    }
    return maxError>1e-12 || maxBoundViolation>1e-12 ? 2:0;
}
