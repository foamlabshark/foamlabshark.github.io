"""Native v2512, slender planar nozzles with a perfect gas and slip walls."""
from pathlib import Path
import math,json
from makePressureCase import header,block

def make(path,supersonic=False,nx=80,highOrder=False):
    path=Path(path)
    for d in ['0','constant','system']:(path/d).mkdir(parents=True,exist_ok=True)
    def write(f,s):(path/f).write_bytes(s.encode())
    R=2078.;gam=1.4;cp=R*gam/(gam-1);Ti=303.;Mi=1.2
    ui=Mi*math.sqrt(gam*R*Ti);pi=1e5/(1+(gam-1)*Mi*Mi/2)**(gam/(gam-1))
    L=30.;Hi,Ho=(.9,3.) if supersonic else (3.,.9)
    # Unit depth: cross-sectional area is numerically equal to the channel height.
    verts=[(0,-Hi/2,0),(L,-Ho/2,0),(L,Ho/2,0),(0,Hi/2,0),
           (0,-Hi/2,1),(L,-Ho/2,1),(L,Ho/2,1),(0,Hi/2,1)]
    faces={'inlet':['(0 4 7 3)'],'outlet':['(1 2 6 5)'],
           'walls':['(0 1 5 4)','(3 7 6 2)'],'frontAndBack':['(0 3 2 1)','(4 5 6 7)']}
    mesh=header('blockMeshDict')+'scale 1;\nvertices\n(\n'
    mesh+=''.join('    ('+' '.join(str(x) for x in v)+')\n' for v in verts)+');\n'
    mesh+=f'blocks\n(\n    hex (0 1 2 3 4 5 6 7) ({nx} 12 1) simpleGrading (1 1 1)\n);\nedges ();\nboundary\n(\n'
    for k,fs in faces.items():
        typ='empty' if k=='frontAndBack' else ('wall' if k=='walls' else 'patch')
        mesh+=block(k,['type '+typ+';','faces','(',*['    '+f for f in fs],');'])
    mesh+=');\nmergePatchPairs ();\n'
    write('system/blockMeshDict',mesh)
    for field,cls,dim,init in [('p','volScalarField','[1 -1 -2 0 0 0 0]',pi if supersonic else 100000),
        ('T','volScalarField','[0 0 0 1 0 0 0]',Ti),
        ('U','volVectorField','[0 1 -1 0 0 0 0]',f'({ui if supersonic else 40} 0 0)')]:
        data=header(field,cls)+f'dimensions {dim};\ninternalField uniform {init};\nboundaryField\n{{\n'
        for patch in faces:
            if patch=='frontAndBack':ls=['type empty;']
            elif patch=='walls':ls=['type slip;'] if field=='U' else ['type zeroGradient;']
            elif patch=='outlet':
                ls=['type fixedValue;','value uniform 100000;'] if field=='p' and not supersonic else ['type zeroGradient;']
            elif supersonic:ls=['type '+('bookSupersonicInletPressure' if field=='p' else 'fixedValue')+';',f'value uniform {init};']
            elif field=='p':ls=['type totalPressure;','p0 uniform 100701.8;','U U;','phi phi;','rho rho;','psi thermo:psi;','gamma 1.4;','value uniform 100000;']
            elif field=='T':ls=['type totalTemperature;','T0 uniform 303;','U U;','phi phi;','psi thermo:psi;','gamma 1.4;','value uniform 303;']
            else:ls=['type pressureDirectedInletVelocity;','inletDirection uniform (1 0 0);','phi phi;','rho rho;','value uniform (40 0 0);']
            data+=block(patch,ls)
        write('0/'+field,data+'}\n')
    thermo=header('thermophysicalProperties')+block('thermoType',[
        'type hePsiThermo;','mixture pureMixture;','transport const;','thermo hConst;',
        'equationOfState perfectGas;','specie specie;','energy sensibleEnthalpy;'])
    # v2512 shipped constants: k=1.38065e-23, NA=6.022141793e23.
    universalR=1.38065e-23*6.022141793e23*1000
    thermo+='mixture\n{\n'+block('specie',[f'molWeight {universalR/R:.16g};'])+block('thermodynamics',[f'Cp {cp:.16g};','Hf 0;'])+block('transport',['mu 1e-5;','Pr 0.7;'])+'}\n'
    write('constant/thermophysicalProperties',thermo)
    write('constant/turbulenceProperties',header('turbulenceProperties')+'simulationType laminar;\n')
    vectorScheme='limitedLinearV 1' if highOrder else 'upwind'
    scalarScheme='limitedLinear 1' if highOrder else 'upwind'
    write('system/fvSchemes',header('fvSchemes')+
        block('ddtSchemes',['default steadyState;'])+block('gradSchemes',['default Gauss linear;'])+
        block('divSchemes',['default none;',f'div(phi,U) Gauss {vectorScheme};',f'div(phi,h) Gauss {scalarScheme};',
            f'div(phi,K) Gauss {scalarScheme};','div(phid,p) Gauss upwind;',
            'div(((rho*nuEff)*dev2(T(grad(U))))) Gauss linear;'])+
        block('laplacianSchemes',['default Gauss linear corrected;'])+
        block('interpolationSchemes',['default linear;'])+block('snGradSchemes',['default corrected;']))
    solvers=block('p',['solver PBiCGStab;','preconditioner DILU;','tolerance 1e-10;','relTol 0.01;','maxIter 2000;'])
    solvers+=block('"(U|h)"',['solver PBiCGStab;','preconditioner DILU;','tolerance 1e-10;','relTol 0.01;','maxIter 2000;'])
    write('system/fvSolution',header('fvSolution')+'solvers\n{\n'+solvers+'}\n'+
        block('SIMPLE',['nNonOrthogonalCorrectors 1;','transonic yes;','consistent no;','pMin 100;','pMax 200000;',
            'residualControl','{','    p 1e-7;','    U 1e-7;','    h 1e-7;','}'])+
        'relaxationFactors\n{\n    fields\n    {\n        p 0.3;\n    }\n    equations\n    {\n        p 0.7;\n        U 0.5;\n        h 0.5;\n    }\n}\n')
    if nx >= 320:
        f=path/'system/fvSolution'
        f.write_text(f.read_text().replace('U 0.5;', 'U 0.25;').replace('h 0.5;', 'h 0.25;'))
    funcs=block('Mach',['type MachNo;','libs (fieldFunctionObjects);','executeControl timeStep;','executeInterval 100;','writeControl writeTime;'])
    for patch in ['inlet','outlet']:
        funcs+=block(patch+'Mass',['type surfaceFieldValue;','libs (fieldFunctionObjects);','regionType patch;',
            'name '+patch+';','operation sum;','fields (phi);','writeFields false;','writeControl timeStep;','writeInterval 20;','log false;'])
    funcs+=block('minMax',['type fieldMinMax;','libs (fieldFunctionObjects);','fields (p T U);','writeControl timeStep;','writeInterval 100;','log false;'])
    write('system/controlDict',header('controlDict')+
        'application rhoSimpleFoam;\nstartFrom startTime;\nstartTime 0;\nstopAt endTime;\nendTime 24000;\ndeltaT 1;\n'
        'writeControl timeStep;\nwriteInterval 1000;\npurgeWrite 1;\nwriteFormat ascii;\nwritePrecision 15;\n'
        'runTimeModifiable false;\nlibs ("libbookCompressibleBoundary.so");\nfunctions\n{\n'+funcs+'}\n')
    if highOrder:write('system/fvSchemes.highOrder',(path/'system/fvSchemes').read_text())
    write('Allrun','#!/bin/sh\nset -eu\ncd "$(dirname "$0")"\npython3 ../../../runCompressibleCase.py\n')
    write('case.json',json.dumps(dict(R=R,gamma=gam,Cp=cp,L=L,Hi=Hi,Ho=Ho,nx=nx,ny=12,
        supersonic=supersonic,p0=1e5 if supersonic else 100701.8,
        T0=Ti+ui*ui/(2*cp) if supersonic else 303,staticInletPressure=pi if supersonic else None,highOrder=highOrder),indent=2)+'\n')

CASES=[('converging-subsonic',False,80,False),('diverging-supersonic',True,80,False),
       ('diverging-upwind-160',True,160,False),('diverging-upwind-320',True,320,False)]
EXPERIMENTS=[('diverging-limited-160',True,160,True)]
if __name__=='__main__':
    import sys
    for n,s,nx,ho in CASES:make(Path(__file__).parent/'cases/compressible'/n,s,nx,ho)
    if '--experiments' in sys.argv:
        for n,s,nx,ho in EXPERIMENTS:make(Path(__file__).parent/'experiments/compressible'/n,s,nx,ho)
